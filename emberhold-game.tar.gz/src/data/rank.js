// v10 แรงค์ PvP: five tiers by rank points. Every finished duel / team match moves the points: a win adds, a loss takes
// away (never below 0). Beating someone of a higher tier pays more; losing to one costs less. Each tier gives its own
// title (ยศ), shown above the name in the village and the arena — the player can hide it (ตั้งค่า › แสดงยศแรงค์).
export const RANK_MAX = 99_999;
export const RANK_TIERS = Object.freeze([
  { id: 'bronze', n: 0, name: 'สำริด', min: 0, title: 'นักดวลสำริด', col: '#d08a5a', glow: '#ffb07a' },
  { id: 'silver', n: 1, name: 'เงิน', min: 300, title: 'อัศวินเงินยวง', col: '#d8e0ec', glow: '#ffffff' },
  { id: 'gold', n: 2, name: 'ทองคำ', min: 700, title: 'แม่ทัพทองคำ', col: '#ffd24a', glow: '#fff3a0' },
  { id: 'plat', n: 3, name: 'แพลทินัม', min: 1200, title: 'จอมยุทธ์แพลทินัม', col: '#7affd8', glow: '#d8fff4' },
  { id: 'diamond', n: 4, name: 'เพชรนิรันดร์', min: 1800, title: 'ราชันเพชรนิรันดร์', col: '#b8a0ff', glow: '#ffe8ff' },
]);
export function tierOf(pts) {
  let t = RANK_TIERS[0];
  for (const x of RANK_TIERS) if ((pts | 0) >= x.min) t = x;
  return t;
}
export const nextTier = (pts) => RANK_TIERS.find((x) => x.min > (pts | 0)) || null;
// points for one result. oppTier: the average tier (0..4) of the other side
export function rankDelta(pts, oppTier, result) {
  const me = tierOf(pts).n, diff = Math.max(-4, Math.min(4, Math.round(oppTier) - me));
  if (result === 'win') return Math.max(15, 30 + diff * 6);
  if (result === 'lose') return -Math.max(me === 0 ? 6 : 10, (me === 0 ? 12 : 22) - Math.max(0, diff) * 4 + Math.max(0, -diff) * 3);
  return 0;
}
