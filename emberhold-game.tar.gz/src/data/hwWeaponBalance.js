// v10.2.2 Halloween weapon balance (hand-tuned; data/weaponBalance.js is generated and leaves event weapons out).
// Target, measured with the same model as the wiki tier list (data/balanceModel.js):
//   farm — 5–20% above the best normal weapon (ดาบสุริยคราส): the event weapons are the strongest farming tools
//   pvp  — 0–12% above the best normal weapon: an edge, never a weapon nobody can beat
// คาตานะมุรามาสะ also halves its damage against players (pvpHalf, scenes/matchScene.js); its pvp value makes up for that.
export const HW_WEAPON_BAL = Object.freeze({
  w_hw_reaper_scythe: { farm: 1.00, pvp: 0.66 },
  w_hw_pumpkin_blade: { farm: 1.49, pvp: 0.89 },
  w_hw_twin_pistols: { farm: 1.58, pvp: 0.86 },
  w_hw_witch_broom: { farm: 1.61, pvp: 1.05 },
  w_hw_muramasa: { farm: 1.80, pvp: 1.92 },
  w_hw_candy_lance: { farm: 1.83, pvp: 0.95 },
  w_hw_pumpkin_cannon: { farm: 2.65, pvp: 1.91 },
});
