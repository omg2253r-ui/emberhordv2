// v10.2 อาชีพ (classes). One class per weapon type plus six special classes. A class is rolled at the class hall
// (500,000 gold or 500 ประกายอำพัน per roll); every class owned can be switched to for free, a class rolled again adds a
// star (up to 5, +10% to its bonuses each). Each class gives:
//   base     – always on while it is the active class
//   weapon   – extra, only while holding its weapon type (special classes have none, their base is bigger)
//   talents  – three more bonuses, unlocked one by one by the class quests (counted only while the class is active)
//   skill    – a unique active skill on its own button (H / 6), cast by battle/skillCast*.js like any skill
//   look     – how the hero changes (battle/jobLook.js): colours, headgear, aura and the floating emblem
// Bonus keys are the ones systems/extraBonuses.js adds up.
import { JOBS2 } from './jobs2.js';

export const JOB_ROLL_GOLD = 500000;
export const JOB_ROLL_SPARKS = 500;
export const JOB_MAX_STARS = 5;
export const JOB_GRADES = Object.freeze({
  A: { id: 'A', name: 'อาชีพสายอาวุธ', col: '#7fc7ff' },
  S: { id: 'S', name: 'อาชีพพิเศษ', col: '#ffcf5a' },
  SS: { id: 'SS', name: 'อาชีพในตำนาน', col: '#ff5f7a' },
});
// what a quest counts (all from the save's counters; zones = every land cleared)
export const QUEST_KINDS = Object.freeze({
  kills: 'กำจัดศัตรู', bossKills: 'ปราบบอส', parries: 'แพร์รี่สำเร็จ', perfects: 'หลบเฉียดฉิว', ults: 'ใช้ท่าไม้ตาย',
  casts: 'ใช้สกิล', jobUses: 'ใช้สกิลอาชีพ', runs: 'จบการผจญภัย', zones: 'พิชิตดินแดน',
});
const same = (a) => [a, a, a];
const sk = (id, name, el, sym, cast, cooldown, nums, opt, desc) => Object.freeze({ id, name, el, kind: 'active', cat: 'job', theme: 'job', rarity: 'legendary', art: Object.freeze({ m: 'sym', s: sym }), maxRank: 1,
  cooldown: same(cooldown), cast, ...Object.fromEntries(Object.entries(nums).map(([k, v]) => [k, same(v)])), opt: Object.freeze(opt || {}), flaw: null, desc });
const q = (k, n) => Object.freeze({ k, n });
const t = (name, b) => Object.freeze({ name, b: Object.freeze(b) });

const L = [
  // ================================================================= weapon classes
  { id: 'knight', name: 'อัศวินศักดิ์สิทธิ์', grade: 'A', wtype: 'sword', w: 10, el: 'holy', sym: 'helm',
    blurb: 'ยืนแถวหน้า โล่ไม่เคยถอย ยิ่งโดนตียิ่งสวนกลับแรง', traits: ['ทนทานสูง', 'สวนกลับ', 'ดึงศัตรูเข้าหาตัว'],
    base: { hpPct: 0.08, defPct: 0.08 }, weapon: { atkPct: 0.06, guardPower: 0.15 },
    talents: [t('เกราะศรัทธา', { dmgTaken: -0.05 }), t('ดาบผู้พิทักษ์', { counterBonus: 0.3, atkPct: 0.04 }), t('ปณิธานเหล็ก', { hpPct: 0.08, regen: 0.004 })],
    quests: [q('kills', 300), q('parries', 40), q('bossKills', 15)],
    look: { col: '#e8eef8', glow: '#ffe08a', hat: 'plume', aura: 'cross' },
    skill: sk('job_knight', 'ปฏิญาณอัศวิน', 'holy', 'helm', 'support', 20, { power: 0.8, shield: 0.3, reduce: 0.25, counter: 2.5, counterPow: 1.5, duration: 5, radius: 260 },
      { mode: 'burst', vis: 'knight', foe: { kb: -320 }, foeR: 300, eff: { sym: 'shield' }, sound: 'block' },
      (r) => `กล่าวปฏิญาณ ดึงศัตรูรอบตัวเข้ามาหา ${Math.round(r.power * 100)}% ได้โล่ 30% รับดาเมจน้อยลง 25% และ 2.5 วินาทีแรกใครตีจะโดนสวนกลับ (เพื่อนในรัศมีได้ด้วย)`) },
  { id: 'samurai', name: 'ซามูไรจันทร์เสี้ยว', grade: 'A', wtype: 'katana', w: 10, el: 'steel', sym: 'katana',
    blurb: 'ชักดาบครั้งเดียว ทุกอย่างบนเส้นทางขาดเป็นสอง', traits: ['คริติคอลรุนแรง', 'จังหวะแม่นยำ', 'ฟันทะลุแนว'],
    base: { crit: 0.04, critMult: 0.15 }, weapon: { atkPct: 0.07, perfectBonus: 0.2 },
    talents: [t('สมาธิไร้คลื่น', { crit: 0.03 }), t('ดาบเดียวชี้ขาด', { critMult: 0.2 }), t('วิถีไร้ลังเล', { dashCd: 0.1, atkPct: 0.05 })],
    quests: [q('kills', 300), q('perfects', 40), q('bossKills', 15)],
    look: { col: '#2a2a3a', glow: '#cfe0f0', hat: 'kabuto', aura: 'petal' },
    skill: sk('job_samurai', 'อิไอ: ดาบจันทร์เสี้ยว', 'steel', 'katana', 'iai', 16, { power: 3, distance: 420 }, {},
      (r) => `ตั้งท่าชักดาบครู่หนึ่ง (ไม่โดนดาเมจ) แล้วพุ่งผ่าน ${r.distance} หน่วย ทุกตัวบนเส้นทางโดนคริติคอล ${Math.round(r.power * 100)}%`) },
  { id: 'assassin', name: 'นักฆ่าเงาสนธยา', grade: 'A', wtype: 'dagger', w: 10, el: 'shadow', sym: 'dagger',
    blurb: 'ไม่มีใครเห็นมา ไม่มีใครเห็นไป มีแต่คนที่ล้มลง', traits: ['คล่องแคล่ว', 'สังหารเป้าเลือดน้อย', 'หลบบ่อย'],
    base: { spd: 0.06, crit: 0.03 }, weapon: { atkPct: 0.06, lowFoeDmg: 0.12 },
    talents: [t('ก้าวไร้เสียง', { dashCd: 0.12 }), t('จุดตาย', { lowFoeDmg: 0.12, crit: 0.02 }), t('เงาสองชั้น', { perfectBonus: 0.25, spd: 0.04 })],
    quests: [q('kills', 400), q('perfects', 50), q('jobUses', 40)],
    look: { col: '#1a1428', glow: '#9a6aff', hat: 'hood', aura: 'smoke' },
    skill: sk('job_assassin', 'ม่านเงาสังหาร', 'shadow', 'dagger', 'shadowkill', 14, { power: 2.6, range: 460 }, { exec: 0.25 },
      (r) => `หายตัวไปโผล่หลังศัตรูที่เลือดน้อยที่สุดในระยะ ${r.range} แทงคริติคอล ${Math.round(r.power * 100)}% ศัตรูทั่วไปที่เลือดต่ำกว่า 25% ตายทันที แล้วทิ้งม่านควันทำให้ศัตรูรอบๆ ช้าลง`) },
  { id: 'berserker', name: 'ผู้คลั่งศึกโลหิต', grade: 'A', wtype: 'greatsword', w: 10, el: 'blood', sym: 'axe',
    blurb: 'ยิ่งเจ็บยิ่งแรง ยิ่งใกล้ตายยิ่งน่ากลัว', traits: ['พลังโจมตีสูง', 'ดูดเลือด', 'แรงขึ้นตอนเลือดน้อย'],
    base: { atkPct: 0.08, lowHpDmg: 0.1 }, weapon: { atkPct: 0.06, lifesteal: 0.02 },
    talents: [t('เลือดเดือด', { lowHpDmg: 0.15 }), t('ขวานกระหายเลือด', { lifesteal: 0.02, atkPct: 0.04 }), t('ไม่ยอมล้ม', { hpPct: 0.1 })],
    quests: [q('kills', 400), q('bossKills', 12), q('jobUses', 30)],
    look: { col: '#5a1a1a', glow: '#ff4a5a', hat: 'horns', aura: 'rage' },
    skill: sk('job_berserker', 'โทสะคลั่งโลหิต', 'blood', 'axe', 'howl', 22, { power: 1.4, radius: 200, stun: 0.5, duration: 7, dmg: 0.35, haste: 0.25, lifesteal: 0.1 }, { sym: 'axe' },
      (r) => `คำรามเข้าสู่โทสะ กระแทกพื้นรอบตัว ${Math.round(r.power * 100)}% ดาเมจ +35% ตีเร็ว +25% ดูดเลือด 10% นาน ${r.duration} วินาที`) },
  { id: 'archmage', name: 'จอมเวทอาร์คาน', grade: 'A', wtype: 'staff', w: 10, el: 'arcane', sym: 'wizhat',
    blurb: 'ทุกคาถาคือความรู้ ทุกความรู้คือพลังทำลาย', traits: ['สกิลแรง', 'คูลดาวน์สั้น', 'ทำลายวงกว้าง'],
    base: { skillPower: 0.1, skillCd: 0.05 }, weapon: { atkPct: 0.05, skillPower: 0.06 },
    talents: [t('ตำราเล่มแรก', { skillCd: 0.05 }), t('คลื่นมานา', { skillPower: 0.1 }), t('จิตอาร์คาน', { ultGain: 0.15, crit: 0.02 })],
    quests: [q('casts', 150), q('kills', 400), q('ults', 20)],
    look: { col: '#3a2a7a', glow: '#ff7ad8', hat: 'wizard', aura: 'runes' },
    skill: sk('job_archmage', 'ดาวตกอาร์คาน', 'arcane', 'wizhat', 'sunbeam', 18, { power: 0.9, count: 6, radius: 190 }, { sym: 'star', gap: 0.26, final: 2.4 },
      (r) => `เรียกดวงดาวอาร์คานเหนือศัตรู ยิงลำแสง ${r.count} ครั้ง ครั้งละ ${Math.round(r.power * 100)}% แล้วปิดท้าย ${Math.round(r.power * 240)}% รัศมี ${r.radius}`) },
  { id: 'ranger', name: 'พรานพิรุณศร', grade: 'A', wtype: 'bow', w: 10, el: 'wind', sym: 'arrow',
    blurb: 'ฝนห่าใหญ่ที่ตกลงมาทุกครั้งที่น้าวสาย', traits: ['ระยะไกล', 'คริติคอล', 'เคลื่อนที่เร็ว'],
    base: { crit: 0.03, spd: 0.05 }, weapon: { atkPct: 0.07, highFoeDmg: 0.1 },
    talents: [t('ตาเหยี่ยว', { crit: 0.03 }), t('ลมนำทาง', { spd: 0.05, dashCd: 0.06 }), t('ลูกศรทะลวง', { highFoeDmg: 0.12, critMult: 0.1 })],
    quests: [q('kills', 400), q('perfects', 30), q('zones', 15)],
    look: { col: '#2f6a3a', glow: '#9fe6cf', hat: 'feather', aura: 'leaves' },
    skill: sk('job_ranger', 'ห่าศรพิรุณ', 'wind', 'arrow', 'lob', 16, { power: 0.55, count: 16, radius: 55 }, { sym: 'arrow', spread: 210, fly: 0.38, stagger: 0.035, h: 320, spin: 0, size: 40, sound: 'bow' },
      (r) => `ยิงลูกศรขึ้นฟ้า ${r.count} ดอกตกลงมาเป็นห่าฝนรอบศัตรู ดอกละ ${Math.round(r.power * 100)}%`) },
  { id: 'dragoon', name: 'อัศวินมังกรเหินฟ้า', grade: 'A', wtype: 'spear', w: 10, el: 'volt', sym: 'spear',
    blurb: 'กระโดดสูงจนแตะเมฆ แล้วพุ่งลงมาเหมือนสายฟ้า', traits: ['กระโดดโจมตี', 'ระยะเอื้อมยาว', 'ทะลวงเกราะ'],
    base: { atkPct: 0.05, hpPct: 0.05 }, weapon: { atkPct: 0.06, critMult: 0.12 },
    talents: [t('ปีกมังกร', { dashCd: 0.08 }), t('หอกฟ้าผ่า', { atkPct: 0.05, crit: 0.02 }), t('เกล็ดมังกร', { defPct: 0.1, hpPct: 0.05 })],
    quests: [q('kills', 350), q('bossKills', 12), q('jobUses', 30)],
    look: { col: '#2a3a6a', glow: '#ffe65a', hat: 'dragonhelm', aura: 'sparks' },
    skill: sk('job_dragoon', 'มังกรดิ่งสายฟ้า', 'volt', 'spear', 'leap', 15, { power: 2.4, radius: 170 }, { reach: 520 },
      (r) => `กระโดดสูงลงใส่ศัตรูใกล้สุดเหมือนสายฟ้าฟาด ${Math.round(r.power * 100)}% รัศมี ${r.radius}`) },
  { id: 'reaper', name: 'ยมทูตเก็บวิญญาณ', grade: 'A', wtype: 'scythe', w: 10, el: 'spirit', sym: 'skull',
    blurb: 'ทุกตัวที่ล้มลง วิญญาณจะมาเป็นพลังให้', traits: ['ฟื้นเลือดจากการฆ่า', 'โจมตีวงกว้าง', 'กดดันศัตรู'],
    base: { healOnKill: 0.015, atkPct: 0.05 }, weapon: { atkPct: 0.06, lifesteal: 0.015 },
    talents: [t('กลิ่นความตาย', { healOnKill: 0.015 }), t('เคียวเย็นเยียบ', { atkPct: 0.05, debuff: 0.1 }), t('ประตูยมโลก', { lowFoeDmg: 0.15 })],
    quests: [q('kills', 500), q('bossKills', 12), q('runs', 20)],
    look: { col: '#1a2a2a', glow: '#8ff0e0', hat: 'reaperhood', aura: 'souls' },
    skill: sk('job_reaper', 'เก็บเกี่ยววิญญาณ', 'spirit', 'skull', 'soulharvest', 18, { power: 1.3, radius: 260, heal: 0.03 }, {},
      (r) => `ฉีกวิญญาณศัตรูทุกตัวในรัศมี ${r.radius} ออกมา ${Math.round(r.power * 100)}% วิญญาณลอยกลับมาฟื้นพลังชีวิตตัวละ ${Math.round(r.heal * 100)}%`) },
  { id: 'dancer', name: 'นักระบำใบมีด', grade: 'A', wtype: 'twinblades', w: 10, el: 'wind', sym: 'ribbon',
    blurb: 'ดาบคู่หมุนเป็นระบำ ศัตรูเห็นแค่ริบบิ้นก่อนล้ม', traits: ['ตีเร็ว', 'คอมโบยาว', 'หลบเก่ง'],
    base: { spd: 0.05, comboPct: 0.15 }, weapon: { atkPct: 0.06, crit: 0.02 },
    talents: [t('จังหวะเท้า', { dashCd: 0.08 }), t('ระบำต่อเนื่อง', { comboPct: 0.2 }), t('ริบบิ้นคมกริบ', { atkPct: 0.05, critMult: 0.1 })],
    quests: [q('kills', 400), q('perfects', 40), q('casts', 120)],
    look: { col: '#7a2a5a', glow: '#ff9fd0', hat: 'ribbons', aura: 'ribbonfx' },
    skill: sk('job_dancer', 'ระบำพันใบมีด', 'wind', 'ribbon', 'multidash', 14, { power: 1, distance: 230 }, { count: 6 },
      (r) => `ร่ายรำพุ่งต่อกัน 6 ครั้ง แต่ละครั้งเล็งศัตรูใกล้สุด ครั้งละ ${Math.round(r.power * 100)}%`) },

  // ================================================================= special classes
  { id: 'paladin', name: 'พาลาดินแสงอรุณ', grade: 'S', wtype: null, w: 3, el: 'holy', sym: 'hammer',
    blurb: 'ทั้งโล่และยาของทีม ค้อนแห่งแสงพิพากษาความมืด', traits: ['ฟื้นฟูทีม', 'ทนทานมาก', 'ดาเมจแสงจากฟ้า'],
    base: { hpPct: 0.12, defPct: 0.1, regen: 0.004 },
    talents: [t('แสงคุ้มครอง', { dmgTaken: -0.06 }), t('มือแห่งการรักษา', { allyPower: 0.2, healOnKill: 0.01 }), t('ค้อนอรุณ', { atkPct: 0.08, skillPower: 0.06 })],
    quests: [q('kills', 400), q('casts', 120), q('bossKills', 15)],
    look: { col: '#f3e6c8', glow: '#fff0a0', hat: 'halo', aura: 'holyring' },
    skill: sk('job_paladin', 'ค้อนพิพากษาอรุณ', 'holy', 'hammer', 'support', 22, { power: 1.6, heal: 0.2, shield: 0.12, duration: 5, radius: 280 },
      { mode: 'burst', vis: 'paladin', foe: { kb: 300 }, foeR: 220, eff: { sym: 'hammer' }, sound: 'slam' },
      (r) => `ค้อนแสงฟาดลงจากฟ้า ศัตรูรอบตัว ${Math.round(r.power * 100)}% กระเด็น ตัวเองและเพื่อนในรัศมี ${r.radius} ฟื้น 20% และได้โล่ 12%`) },
  { id: 'necro', name: 'เนโครแมนเซอร์ราตรี', grade: 'SS', wtype: null, w: 1.2, el: 'spirit', sym: 'skull',
    blurb: 'ความตายไม่ใช่จุดจบ สำหรับคนที่เรียกมันกลับมาได้', traits: ['เรียกกองทัพ', 'สกิลแรงมาก', 'ดูดพลังชีวิต'],
    base: { skillPower: 0.12, atkPct: 0.06, lifesteal: 0.02 },
    talents: [t('สัญญากับความตาย', { healOnKill: 0.02 }), t('กองทัพไม่สิ้นสุด', { skillPower: 0.1, petPower: 0.2 }), t('ราชันกระดูก', { crit: 0.03, atkPct: 0.06 })],
    quests: [q('kills', 600), q('jobUses', 40), q('bossKills', 20)],
    look: { col: '#1a0a24', glow: '#b07ad0', hat: 'bonecrown', aura: 'wisps' },
    skill: sk('job_necro', 'กองทัพโครงกระดูก', 'spirit', 'skull', 'swarm', 24, { power: 0.7, count: 6, duration: 9 }, { sym: 'skull', speed: 330, gap: 0.5, size: 40, sound: 'roar' },
      (r) => `ปลุกกะโหลกวิญญาณ ${r.count} ตัวไล่โจมตีศัตรูเอง ${r.duration} วินาที ครั้งละ ${Math.round(r.power * 100)}%`) },
  { id: 'bard', name: 'กวีเพลงวีรชน', grade: 'S', wtype: null, w: 3, el: 'arcane', sym: 'lute',
    blurb: 'เพลงของเขาทำให้ทุกคนสู้เหมือนวีรบุรุษในตำนาน', traits: ['เสริมพลังทีม', 'คูลดาวน์สั้น', 'หาทองเก่ง'],
    base: { skillCd: 0.08, goldMult: 0.08, spd: 0.04 },
    talents: [t('ท่วงทำนองแรก', { allyPower: 0.15 }), t('เพลงปลุกใจ', { atkPct: 0.06, ultGain: 0.1 }), t('บทกวีทองคำ', { goldMult: 0.12, skillCd: 0.05 })],
    quests: [q('casts', 150), q('runs', 20), q('jobUses', 30)],
    look: { col: '#3a6a8a', glow: '#ffcf5a', hat: 'beret', aura: 'notes' },
    skill: sk('job_bard', 'บทเพลงวีรชน', 'arcane', 'lute', 'support', 20, { dmg: 0.2, haste: 0.15, regen: 0.012, duration: 8, radius: 260 },
      { mode: 'aura', vis: 'bard', eff: { sym: 'note' }, sound: 'unlock' },
      (r) => `บรรเลงเพลงวีรชน ${r.duration} วินาที ทุกคนในรัศมี ${r.radius} รอบตัว ดาเมจ +20% ตีเร็ว +15% และฟื้น 1.2% ต่อวินาที`) },
  { id: 'alchemist', name: 'นักเล่นแร่แปรธาตุ', grade: 'S', wtype: null, w: 3, el: 'poison', sym: 'flask',
    blurb: 'ขวดยาทุกใบอันตราย ยกเว้นใบที่ให้เพื่อน', traits: ['พื้นที่พิษ', 'ฟื้นฟู', 'โชคดีเรื่องทอง'],
    base: { goldMult: 0.12, atkPct: 0.05, debuff: 0.15 },
    talents: [t('สูตรคงทน', { hpPct: 0.08 }), t('กรดกัดกร่อน', { debuff: 0.2, ignite: 0.05 }), t('หินนักปราชญ์', { goldMult: 0.15, skillPower: 0.08 })],
    quests: [q('kills', 400), q('runs', 25), q('casts', 120)],
    look: { col: '#3a5a2a', glow: '#a8e05a', hat: 'goggles', aura: 'bubbles' },
    skill: sk('job_alchemist', 'ระเบิดขวดแปรธาตุ', 'poison', 'flask', 'lob', 16, { power: 1, count: 4, radius: 110 }, { sym: 'flask', spread: 130, puddle: 4, puddlePow: 0.3, fly: 0.55, h: 220, spin: 8, sound: 'potion' },
      (r) => `ปาขวดแปรธาตุ ${r.count} ขวด ขวดละ ${Math.round(r.power * 100)}% รัศมี ${r.radius} แตกเป็นแอ่งกรดเดือด 4 วินาที`) },
  { id: 'chrono', name: 'จอมเวทกาลเวลา', grade: 'SS', wtype: null, w: 0.8, el: 'arcane', sym: 'clock',
    blurb: 'วินาทีของเขายาวกว่าของคนอื่น และย้อนกลับได้', traits: ['ลดคูลดาวน์', 'ย้อนเวลา', 'เร่งทีม'],
    base: { skillCd: 0.12, ultGain: 0.15, dashCd: 0.08 },
    talents: [t('เข็มวินาที', { skillCd: 0.05 }), t('นาฬิกาทราย', { ultGain: 0.15, spd: 0.04 }), t('ห้วงเวลาหยุดนิ่ง', { skillPower: 0.1, crit: 0.03 })],
    quests: [q('casts', 200), q('ults', 25), q('jobUses', 40)],
    look: { col: '#2a2a5a', glow: '#b8d0ff', hat: 'clockring', aura: 'clocks' },
    skill: sk('job_chrono', 'ย้อนกาลเร่งเวลา', 'arcane', 'clock', 'support', 26, { refresh: 0.5, haste: 0.3, rewind: 3, ult: 20, duration: 6, radius: 280 },
      { mode: 'burst', vis: 'chrono', eff: { sym: 'clock' }, sound: 'blink' },
      (r) => `บิดกาลเวลา ตัวเองและเพื่อนในรัศมี ${r.radius}: พลังชีวิตย้อนกลับไปเท่าจุดสูงสุดใน 3 วินาทีก่อน คูลดาวน์สกิลลดลงครึ่งหนึ่ง เกจท่าไม้ตาย +20 และตีเร็ว +30% นาน ${r.duration} วินาที`) },
  { id: 'beast', name: 'จ่าฝูงแห่งพงไพร', grade: 'S', wtype: null, w: 3, el: 'nature', sym: 'wolf',
    blurb: 'ไม่เคยสู้คนเดียว ฝูงหมาป่าและสัตว์เลี้ยงคือครอบครัว', traits: ['สัตว์เลี้ยงแรงขึ้น', 'เรียกฝูงหมาป่า', 'วิ่งเร็ว'],
    base: { petPower: 0.35, spd: 0.05, hpPct: 0.05 },
    talents: [t('สายใยฝูง', { petPower: 0.25 }), t('สัญชาตญาณนักล่า', { atkPct: 0.06, crit: 0.02 }), t('หัวใจพงไพร', { regen: 0.005, hpPct: 0.06 })],
    quests: [q('kills', 500), q('zones', 15), q('jobUses', 30)],
    look: { col: '#4a3a2a', glow: '#7fd06a', hat: 'wolfhood', aura: 'paws' },
    skill: sk('job_beast', 'เสียงเรียกจ่าฝูง', 'nature', 'wolf', 'swarm', 20, { power: 0.9, count: 4, duration: 8 }, { sym: 'wolf', speed: 430, gap: 0.55, size: 50, sound: 'roar' },
      (r) => `หอนเรียกหมาป่าวิญญาณ ${r.count} ตัวกระโจนกัดศัตรูเอง ${r.duration} วินาที ครั้งละ ${Math.round(r.power * 100)}%`) },
];

L.push(...JOBS2);   // v10.2.2: thirty fantasy classes (data/jobs2.js)

export const JOBS = Object.freeze(Object.fromEntries(L.map((j) => [j.id, Object.freeze(j)])));
export const JOB_IDS = Object.freeze(L.map((j) => j.id));
export const getJob = (id) => (Object.prototype.hasOwnProperty.call(JOBS, id) ? JOBS[id] : null);
export const JOB_SKILLS = Object.freeze(Object.fromEntries(L.map((j) => [j.skill.id, j.skill])));
export const getJobSkill = (id) => (Object.prototype.hasOwnProperty.call(JOB_SKILLS, id) ? JOB_SKILLS[id] : null);
export const jobOfWeapon = (wtype) => L.find((j) => j.wtype === wtype) || null;
export const JOB_ODDS = Object.freeze((() => { const tot = L.reduce((a, j) => a + j.w, 0); return Object.fromEntries(L.map((j) => [j.id, j.w / tot])); })());
export const BONUS_NAMES = Object.freeze({
  crit: ['คริติคอล', 'pct'], critMult: ['แรงคริ', 'pct'], spd: ['ความเร็ว', 'pct'], atkPct: ['พลังโจมตี', 'pct'], defPct: ['พลังป้องกัน', 'pct'], hpPct: ['พลังชีวิต', 'pct'],
  skillPower: ['พลังสกิล', 'pct'], skillCd: ['ลดคูลดาวน์สกิล', 'pct'], goldMult: ['ทองที่ได้', 'pct'], lifesteal: ['ดูดเลือด', 'pct'], healOnKill: ['ฟื้นเลือดต่อการฆ่า', 'pct1'],
  regen: ['ฟื้นเลือดต่อวินาที', 'pct1'], petPower: ['พลังสัตว์เลี้ยง', 'pct'], allyPower: ['รับการฟื้นฟู/โล่', 'pct'], dmgTaken: ['ดาเมจที่ได้รับ', 'pct'], ultGain: ['เกจท่าไม้ตาย', 'pct'],
  dashCd: ['ลดคูลดาวน์หลบ', 'pct'], comboPct: ['โบนัสคอมโบ', 'pct'], lowHpDmg: ['ดาเมจตอนเลือดน้อย', 'pct'], lowFoeDmg: ['ดาเมจใส่ศัตรูเลือดน้อย', 'pct'], highFoeDmg: ['ดาเมจใส่ศัตรูเลือดเต็ม', 'pct'],
  perfectBonus: ['โบนัสหลบเฉียดฉิว', 'pct'], guardPower: ['พลังการกัน', 'pct'], counterBonus: ['แรงสวนกลับ', 'pct'], debuff: ['ระยะสถานะผิดปกติ', 'pct'], ignite: ['โอกาสติดไฟ', 'pct'],
  candy: ['แคนดี้ที่ได้', 'pct'], magnet: ['ระยะดูดของ', 'pct'], thorns: ['สะท้อนดาเมจ', 'pct'], atkFlat: ['พลังโจมตี', 'num'], defFlat: ['พลังป้องกัน', 'num'], hpFlat: ['พลังชีวิต', 'num'],
});
export function bonusText(b) {
  return Object.entries(b).filter(([, v]) => v).map(([k, v]) => {
    const [n, f] = BONUS_NAMES[k] || [k, 'pct'];
    const s = v > 0 ? '+' : '−', a = Math.abs(v);
    return f === 'num' ? `${n} ${s}${Math.round(a)}` : f === 'pct1' ? `${n} ${s}${(a * 100).toFixed(1)}%` : `${n} ${s}${Math.round(a * 100)}%`;
  }).join(' · ');
}
