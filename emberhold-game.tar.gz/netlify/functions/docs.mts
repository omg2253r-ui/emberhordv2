// Guild documents and guild actions. Logic lives in ../lib/docs.mjs and ../lib/guildRules.mjs.
// Forwarded to the Cloudflare Worker by default (same as cloud.mts) so guilds match the accounts and rankings there.
import { getStore } from '@netlify/blobs';
import { handleDocs, blobsDocs } from '../lib/docs.mjs';
import { blobsKV } from '../lib/hub.mjs';
import { backendOf, forward } from '../lib/proxy.mjs';

export default async (req: Request, context: { ip?: string }) => {
  const env = process.env;
  if (backendOf(env)) return forward(req, 'docs', { env, ip: context?.ip });
  return handleDocs(
    req,
    blobsDocs(getStore({ name: 'emberhold-docs', consistency: 'strong' })),
    blobsKV(getStore({ name: 'emberhold-hub', consistency: 'strong' })),
    { ip: context?.ip },
  );
};

export const config = { path: '/api/docs' };
