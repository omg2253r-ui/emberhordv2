// v10.2 skin transactions (pure: state in → new state out) and what a worn skin gives.
import { cloneState } from '../core/state.js';
import { getItem, EQUIP_SLOTS } from '../data/items.js';
import { countItem } from './inventory.js';
import { SKINS, SKIN_IDS, SKIN_TIERS, getSkinAny, getBox, PITY_AT, PITY_TIER, tierOfSkin } from '../data/skins.js';
import { hwActive, CANDY_MAX } from '../data/halloween.js';

export const ownsSkin = (st, id) => !!st.skins?.owned?.[id];
export const wornSkinId = (st, wid) => { const id = st.skins?.on?.[wid]; return id && ownsSkin(st, id) && getSkinAny(id)?.wid === wid ? id : null; };
export const wornSkin = (st, wid = st.equipment?.weapon?.id) => getSkinAny(wornSkinId(st, wid));
const ownsWeapon = (st, wid) => countItem(st, wid) > 0 || EQUIP_SLOTS.some((s) => st.equipment[s]?.id === wid);

export function wearSkin(state, wid, id) {
  const next = cloneState(state);
  if (!id) { delete next.skins.on[wid]; return { ok: true, state: next }; }
  const sk = getSkinAny(id);
  if (!sk || sk.wid !== wid || !ownsSkin(state, id)) return { ok: false, reason: 'not_owned' };
  next.skins.on[wid] = id;
  return { ok: true, state: next };
}
// add a skin; a skin you already own turns into gold (its tier's refund)
export function grantSkinInPlace(next, id) {
  const sk = getSkinAny(id); if (!sk) return { dup: false, refund: 0 };
  if (next.skins.owned[id]) { const r = tierOfSkin(sk).refund; next.gold += r; return { dup: true, refund: r }; }
  next.skins.owned[id] = 1;
  if (!next.skins.on[sk.wid]) next.skins.on[sk.wid] = id;      // the first skin of a weapon is worn at once
  return { dup: false, refund: 0 };
}

// one box: pay, roll a tier by weight (the pity guarantees เทพ or better on the 60th box without one), then a skin of
// that tier from the box's pool. rnd: () => [0,1)
export function openSkinBox(state, boxId, rnd) {
  const box = getBox(boxId);
  if (!box) return { ok: false, reason: 'unknown' };
  if (box.hw && !hwActive()) return { ok: false, reason: 'event_over' };
  if (box.cur === 'gold' ? state.gold < box.price : (state.candy || 0) < box.price) return { ok: false, reason: box.cur === 'gold' ? 'gold' : 'candy' };
  const pool = SKIN_IDS.map((id) => SKINS[id]).filter(box.pool);
  if (!pool.length) return { ok: false, reason: 'unknown' };
  const tiers = [...new Set(pool.map((s) => s.t))].sort((a, b) => a - b);
  const next = cloneState(state);
  if (box.cur === 'gold') next.gold -= box.price; else next.candy -= box.price;
  const pity = next.skins.pity + 1 >= PITY_AT && tiers.some((t) => t >= PITY_TIER);
  const cand = pity ? tiers.filter((t) => t >= PITY_TIER) : tiers;
  const total = cand.reduce((a, t) => a + SKIN_TIERS[t].w, 0);
  let r = rnd() * total, tier = cand[0];
  for (const t of cand) { r -= SKIN_TIERS[t].w; if (r < 0) { tier = t; break; } }
  const ofTier = pool.filter((s) => s.t === tier);
  const sk = ofTier[Math.floor(rnd() * ofTier.length) % ofTier.length];
  next.skins.pity = tier >= PITY_TIER ? 0 : next.skins.pity + 1;
  next.skins.boxes += 1;
  const g = grantSkinInPlace(next, sk.id);
  return { ok: true, state: next, skin: sk, dup: g.dup, refund: g.refund, pity };
}

// the bonus of the skin on the weapon in hand (stats.js)
export function skinBonuses(state) {
  const sk = wornSkin(state);
  if (!sk) return { crit: 0, critMult: 0, atkPct: 0 };
  const t = tierOfSkin(sk);
  return { crit: t.crit, critMult: t.critMult, atkPct: t.atkPct };
}
// what the battle scenes need to draw the skin's hits and swing trails
export function skinCombat(state) {
  const sk = wornSkin(state);
  if (!sk) return null;
  const t = tierOfSkin(sk);
  return { id: sk.id, t: sk.t, hit: t.hit ? sk.hit : null, col: sk.pal[4], col2: sk.pal[5], trail: t.hit ? { color: sk.pal[1], glow: sk.pal[4], width: 1.2 } : null };
}
// the Halloween candy shop still sells event skins one by one
export function buySkinCandy(state, id, price) {
  const sk = getSkinAny(id);
  if (!sk || sk.event !== 'hw') return { ok: false, reason: 'unknown' };
  if (!hwActive()) return { ok: false, reason: 'event_over' };
  if (ownsSkin(state, id)) return { ok: false, reason: 'owned' };
  if ((state.candy || 0) < price) return { ok: false, reason: 'candy' };
  const next = cloneState(state); next.candy = Math.min(CANDY_MAX, next.candy - price);
  grantSkinInPlace(next, id);
  return { ok: true, state: next };
}
export { ownsWeapon };
