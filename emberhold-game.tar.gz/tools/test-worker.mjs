// End-to-end check of the Cloudflare Worker SOURCE (cloudflare/worker.mjs) with the CURRENT game code in src/.
// Run: node tools/test-worker.mjs          (no network, no Cloudflare account needed)
// A fake D1 database stands in for the real one; "cloudflare:workers" is stubbed so Node can load the Worker.
import { register } from 'node:module';
register('data:text/javascript,' + encodeURIComponent(`
  export async function resolve(s, c, next) { return s === 'cloudflare:workers' ? { url: 'data:text/javascript,export class DurableObject { constructor(ctx, env) { this.ctx = ctx; this.env = env; } }', shortCircuit: true } : next(s, c); }
`), import.meta.url);

// WORKER=/path/to/_worker.js node tools/test-worker.mjs  → run the same checks against an already-bundled Worker
const target = process.env.WORKER ? new URL('file://' + process.env.WORKER).href : '../cloudflare/worker.mjs';
const { default: worker } = await import(target);
const { createNewState } = await import('../src/core/state.js');
const { exportCode } = await import('../src/persistence/transfer.js');
const { sanitize } = await import('../src/persistence/save.js');
const { scoresOf } = await import('../netlify/lib/rank.mjs');
const { BOARD_IDS } = await import('../netlify/lib/rank.mjs');
const { ZONES } = await import('../src/data/zones.js');
const { PETS } = await import('../src/data/pets.js');

let failed = 0;
const ok = (c, m) => { console.log((c ? 'ok   ' : 'FAIL ') + m); if (!c) failed++; };

import { fakeD1 } from './fake-d1.mjs';
// the game-master check runs against a TEST password set through env (GM_SALT / GM_HASH), never the real one
const { scryptSync } = await import('node:crypto');
const GM_TEST_PASS = 'test-gm-pass-1';
const GM_SALT = 'a1b2c3d4e5f60718293a4b5c6d7e8f90';
const env = { DB: fakeD1(), ASSETS: { fetch: async () => new Response('asset') }, GM_SALT, GM_HASH: scryptSync(GM_TEST_PASS, GM_SALT, 32, { N: 16384, r: 8, p: 1 }).toString('hex') };
const call = async (body) => { const r = await worker.fetch(new Request('https://x.test/api/cloud', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }), env); return { status: r.status, data: await r.json(), headers: r.headers }; };

// ---- a hero that uses everything added since the old Cloudflare bundle: attribute points, the Egypt dungeon (z13), Egypt pets
const st = createNewState(1);
st.story.name = 'ทดสอบอันดับ';
st.player.level = 60; st.player.xp = 1234;
st.attrs = { str: 90, vit: 60, dex: 20, agi: 0, int: 0 };
st.zones.cleared = { z1: 3, z13: 5 };
st.pets.owned = { jackal_cub: { stars: 2 }, gold_scarab: { stars: 1 }, horus_hawk: { stars: 3 }, uraeus_cobra: { stars: 1 } };
const bare = { ...structuredClone(st), attrs: { str: 0, vit: 0, dex: 0, agi: 0, int: 0 } };
const code = exportCode(st);
const expected = scoresOf(sanitize(JSON.parse(Buffer.from(code.split('.')[1], 'base64url').toString())).state);
const expectedBare = scoresOf(sanitize(JSON.parse(Buffer.from(exportCode(bare).split('.')[1], 'base64url').toString())).state);

ok(expected.power > expectedBare.power, `attribute points count in พลังรบ (${expected.power} > ${expectedBare.power} without them)`);
ok(expected.zones === 8, `ดันเจี้ยนรวม counts z13 (z1 3 + z13 5 = ${expected.zones})`);
ok(ZONES.some((z) => z.id === 'z13') && Object.keys(PETS).includes('jackal_cub'), 'game data has z13 and the Egypt pets');
ok(expected.pets >= 4 * 100, `สัตว์เลี้ยง counts the 4 Egypt pets (${expected.pets})`);

let r = await call({ op: 'register', name: 'ranktest', pass: 'secret1', save: code });
ok(r.status === 200 && /^[a-f0-9]{48}$/.test(r.data.token), 'register with a save works through the Worker (D1)');
const token = r.data.token;
ok(r.headers.get('content-security-policy')?.includes("default-src 'self'"), 'security headers are still added');

for (const id of BOARD_IDS) {
  const b = await call({ op: 'ranks', board: id, token });
  const row = b.data.entries?.[0];
  if (expected[id] > 0) ok(row && row.v === expected[id] && row.a === 'ranktest' && b.data.me === 1, `board ${id}: Worker stores ${expected[id]} = what the game computes`);
  else ok(!row, `board ${id}: zero score is not listed`);
}

r = await call({ op: 'card', account: 'ranktest' });
ok(r.status === 200 && r.data.card, 'profile card is built');


// ---- v10 live services: market, news, gift boxes, gifts, game master
{
  r = await call({ op: 'ping' });
  ok(r.status === 200 && Number.isFinite(r.data.t), 'ping answers with the server time');
  r = await call({ op: 'gm_login', name: 'Shin', pass: 'wrong-pass' });
  ok(r.status === 401, 'game-master sign-in refuses a wrong password');
  r = await call({ op: 'gm_login', name: 'Shin', pass: GM_TEST_PASS, peer: 'gmpeer0001' });
  ok(r.status === 200 && /^[a-f0-9]{48}$/.test(r.data.gtok), 'game-master sign-in works with the right name and password (hash only on the server)');
  const gtok = r.data.gtok;
  r = await call({ op: 'gm_stats', gtok: 'f'.repeat(48) });
  ok(r.status === 401, 'game-master tools refuse a made-up token');
  r = await call({ op: 'gm_stats', gtok });
  ok(r.status === 200 && r.data.accounts >= 1 && r.data.per.day.active >= 1 && r.data.per.year.joined >= 1, `stats: ${r.data.accounts} accounts, active today ${r.data.per?.day?.active}`);
  r = await call({ op: 'gm_players', gtok });
  ok(r.status === 200 && r.data.players.some((p) => p.acct === 'ranktest' && /^[a-f0-9]{24}$/.test(p.uid)), 'player list shows each account with its code');
  const targetUid = r.data.players.find((p) => p.acct === 'ranktest').uid;
  r = await call({ op: 'gm_view', gtok, uid: targetUid });
  ok(r.status === 200 && r.data.summary.lv === 60, 'game master can look at a player save summary');
  r = await call({ op: 'gm_announce', gtok, text: 'เซิร์ฟเวอร์จะปิดปรับปรุง 5 นาที' });
  ok(r.status === 200, 'announcement is posted');
  r = await call({ op: 'gm_box', gtok, count: 2, from: 'Shin', pts: [[100, 200], [140, 220]] });
  ok(r.status === 200 && r.data.batch, 'gift boxes are created');
  const batch = r.data.batch;
  r = await call({ op: 'news' });
  ok(r.data.items.some((x) => x.kind === 'say') && r.data.boxes[batch]?.left === 2 && r.data.gms.includes('gmpeer0001'), 'news carries the announcement, the boxes and the game-master peer');
  r = await call({ op: 'box_claim', batch, idx: 0 });
  ok(r.status === 401, 'a box needs an account or a proven player id');
  r = await call({ op: 'box_claim', token, batch, idx: 0 });
  const boxItem = r.data.item;
  const { getItem } = await import('../src/data/items.js');
  ok(r.status === 200 && ['legendary', 'mythic', 'limited'].includes(getItem(boxItem)?.rarity), `box gives legendary or better (${boxItem} · ${getItem(boxItem)?.rarity})`);
  r = await call({ op: 'box_claim', token, batch, idx: 1 });
  ok(r.status === 409 && r.data.error === 'one_each', 'one box per player per drop');
  r = await call({ op: 'gm_gift', gtok, to: targetUid, items: [{ id: 'w_hw_pumpkin_cannon', qty: 1 }], gold: 500, note: 'ของขวัญ' });
  ok(r.status === 200, 'gift to one account is mailed');
  r = await call({ op: 'mail', token });
  ok(r.data.gifts?.length === 1 && r.data.gifts[0].gold === 500, 'the account receives its mail');
  r = await call({ op: 'mail', token });
  ok(r.data.gifts?.length === 0, 'mail is taken once');
  r = await call({ op: 'gm_gift', gtok, to: '*', candy: 300, note: 'แจกทุกคน' });
  const gid = r.data.gid;
  r = await call({ op: 'gift_all', token, gid });
  ok(r.status === 200 && r.data.gift.candy === 300, 'gift to everyone can be claimed');
  r = await call({ op: 'gift_all', token, gid });
  ok(r.status === 409, 'gift to everyone is claimed once per account');

  // market: a seller with a pumpkin cannon in the cloud save, a buyer
  const sell = createNewState(2); sell.story.name = 'คนขาย'; sell.inventory.slots.push({ uid: 9001, id: 'w_hw_pumpkin_cannon', qty: 1, lvl: 0 }); sell.gold = 10;
  r = await call({ op: 'register', name: 'seller1', pass: 'secret1', save: exportCode(sell) });
  const stok = r.data.token;
  r = await call({ op: 'register', name: 'buyer1', pass: 'secret1', save: exportCode(createNewState(3)) });
  const btok = r.data.token;
  r = await call({ op: 'mk_put', token: stok, item: { id: 'w_hw_pumpkin_cannon', qty: 1 }, price: 5000 });
  ok(r.status === 409 && r.data.error === 'no_lot', 'listing needs a lot');
  r = await call({ op: 'mk_rent', token: stok, lot: 7, design: 'sth_01', hero: 'คนขาย' });
  ok(r.status === 200 && r.data.lot === 7, 'a free lot is rented');
  r = await call({ op: 'mk_rent', token: btok, lot: 7, design: 'st_02', hero: 'คนซื้อ' });
  ok(r.status === 409 && r.data.error === 'lot_taken', 'someone else cannot take a rented lot');
  r = await call({ op: 'mk_put', token: stok, item: { id: 'w_hw_reaper_scythe', qty: 1 }, price: 5000 });
  ok(r.status === 409 && r.data.error === 'not_owned', 'cannot list an item the cloud save does not hold');
  r = await call({ op: 'mk_put', token: stok, item: { id: 'w_hw_muramasa', qty: 1 }, price: 5000 });
  ok(r.status === 400, 'secret weapons cannot be sold');
  r = await call({ op: 'mk_put', token: stok, item: { id: 'w_hw_pumpkin_cannon', qty: 1 }, price: 5000 });
  ok(r.status === 200 && r.data.lid, 'item is listed');
  const lid = r.data.lid;
  r = await call({ op: 'mk_list' });
  ok(r.data.lots[7]?.items[0]?.price === 5000 && r.data.lots[7].owner === 'คนขาย', 'market shows the stall, the owner and the price');
  r = await call({ op: 'mk_buy', token: stok, lot: 7, lid, price: 5000 });
  ok(r.status === 409 && r.data.error === 'own', 'cannot buy from yourself');
  r = await call({ op: 'mk_buy', token: btok, lot: 7, lid, price: 4000 });
  ok(r.status === 409 && r.data.error === 'price_changed', 'buy refuses when the price is not the one shown');
  const [a1, a2] = await Promise.all([call({ op: 'mk_buy', token: btok, lot: 7, lid, price: 5000 }), call({ op: 'mk_buy', token: btok, lot: 7, lid, price: 5000 })]);
  ok([a1, a2].filter((x) => x.status === 200).length === 1 && [a1, a2].find((x) => x.status === 200).data.item.id === 'w_hw_pumpkin_cannon', 'two buys at once: only one gets the item');
  r = await call({ op: 'mk_collect', token: stok });
  ok(r.data.gold === 4750, `seller collects the price minus 5% (${r.data.gold})`);
  r = await call({ op: 'mk_collect', token: stok });
  ok(r.data.gold === 0, 'takings are paid once');
}

console.log(failed ? `\n${failed} FAILED` : '\nall passed');
process.exit(failed ? 1 : 0);
