// v10.2 the Halloween pets that fall in the Halloween lands: when a land's boss falls, each of its four pets rolls its
// own chance (5% · 2.5% · 1.2% · 0.5%, data/hwPets2.js). A new pet joins the collection (and the team if there is
// room); a copy adds a star like a summon, and past five stars it turns into Amber Sparks.
import { hwPetsOfZone } from '../data/hwPets2.js';
import { getPet, MAX_STARS, PET_TEAM } from '../data/pets.js';

export const HW_PET_DUP_SPARKS = 30;
export function rollHwPetDrop(zoneId, boss, rnd) {
  if (!boss) return null;
  for (const p of hwPetsOfZone(zoneId)) if (rnd() < p.chance) return p.id;
  return null;
}
export function grantHwPetInPlace(next, id) {
  const p = getPet(id);
  if (!p) return { name: '', dup: false, sparks: 0 };
  const own = next.pets.owned[id];
  if (!own) {
    next.pets.owned[id] = { stars: 1 };
    if (Array.isArray(next.pets.active) && next.pets.active.length < PET_TEAM) next.pets.active.push(id);
    return { name: p.name, dup: false, sparks: 0, isNew: true };
  }
  if (own.stars < MAX_STARS) { own.stars += 1; return { name: p.name, dup: false, sparks: 0, stars: own.stars }; }
  next.sparks = (next.sparks || 0) + HW_PET_DUP_SPARKS;
  return { name: p.name, dup: true, sparks: HW_PET_DUP_SPARKS };
}
