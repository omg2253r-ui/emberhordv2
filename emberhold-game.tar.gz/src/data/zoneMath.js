// Base numbers for a normal monster at zone level L (a boss multiplies these). Kept apart from zones.js so the event
// dungeons (data/hwZones.js) can use it without an import cycle.
export function zoneStats(level) {
  // v8: tougher (was hp 34 + 9L, atk 9 + 1.7L, def 2 + 0.65L)
  return { hp: 40 + level * 11, atk: 10 + level * 2, def: 2 + level * 0.75, xp: 6 + level * 2.2, gold: [4 + level, 8 + level * 2] };
}
