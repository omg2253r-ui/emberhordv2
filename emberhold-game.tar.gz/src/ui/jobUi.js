// v10.2 อาชีพ: the class panel in camp (your class, its skill, its quests and talents, the classes you own, the roll)
// and the roll ceremony — a stage where the hero stands while the class's light pours down, its headgear appears
// and its name, grade and traits are announced.
import { h, glyph, itemImg, fmt } from './dom.js';
import { svgDataUri } from '../art/icons.js';
import { skillIconSvg } from '../art/skillIcons.js';
import { symSvg } from '../art/symbols.js';
import { elOf } from '../battle/skillVfx.js';
import { createRenderer } from '../engine/renderer.js';
import { drawHero } from '../battle/heroDraw.js';
import { getItem } from '../data/items.js';
import { getWeaponType } from '../data/weapons.js';
import { JOBS, JOB_IDS, getJob, JOB_GRADES, JOB_ROLL_GOLD, JOB_ROLL_SPARKS, JOB_ODDS, JOB_MAX_STARS, QUEST_KINDS, bonusText } from '../data/jobs.js';
import { ownsJob, setJob, rollJob, claimQuest, questProgress, jobParts, STAR_STEP, MAXED_REFUND } from '../systems/jobs.js';
import { drawJobGround, drawJobHead } from '../battle/jobLook.js';
import { glowSprite, raysSprite } from '../scenes/ambientFx.js';

const WT_NAME = { sword: 'ดาบ', katana: 'คาตานะ', dagger: 'มีดสั้น', greatsword: 'ดาบใหญ่', staff: 'คทา', bow: 'ธนู', spear: 'หอก', scythe: 'เคียว', twinblades: 'ดาบคู่' };
const emblem = (j, cls = 'job-emb') => h('img', { class: cls, src: svgDataUri(symSvg(j.sym, elOf(j.el))), alt: '', draggable: 'false' });
const skillIcon = (j) => h('img', { class: 'skill-img', src: svgDataUri(skillIconSvg(j.skill)), alt: j.skill.name, draggable: 'false' });
const stars = (n) => h('span', { class: 'job-stars', 'aria-label': `${n} ดาว` }, ...Array.from({ length: JOB_MAX_STARS }, (_, i) => h('i', { class: i < n ? 'on' : '' }, '★')));
const gradeChip = (j) => h('span', { class: `chip job-grade g-${j.grade}`, style: { '--gc': JOB_GRADES[j.grade].col } }, JOB_GRADES[j.grade].name);

// a living picture of the hero wearing a class (used in the panel and the ceremony)
export function jobStage(app, jobId, { big = false } = {}) {
  const canvas = h('canvas', { class: `job-stage ${big ? 'big' : ''}`, 'aria-label': 'ตัวละครในชุดอาชีพ' });
  const r = createRenderer(canvas);
  const st = app.store.get(), t0 = performance.now();
  const type = getWeaponType(getItem(st.equipment.weapon?.id)?.wtype);
  let raf = 0;
  function frame() {
    if (!canvas.isConnected) { cancelAnimationFrame(raf); return; }
    raf = requestAnimationFrame(frame);
    r.resize(); r.screenSpace();
    const { ctx } = r, W = r.view.w, H = r.view.h, t = (performance.now() - t0) / 1000;
    const j = getJob(typeof jobId === 'function' ? jobId() : jobId);
    const col = j ? j.look.glow : '#e0b45a';
    const bg = ctx.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, '#120c1a'); bg.addColorStop(1, '#1c130e');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
    const cx = W / 2, gy = H * 0.84, sc = Math.min(2.4, H / 140);
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.35; ctx.translate(cx, gy - 60 * sc); ctx.rotate(t * 0.15);
    const R = raysSprite(col, 16); ctx.drawImage(R, -H * 0.7, -H * 0.7, H * 1.4, H * 1.4);
    ctx.restore();
    ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.5; ctx.drawImage(glowSprite(col), cx - 90 * sc, gy - 150 * sc, 180 * sc, 180 * sc); ctx.restore();
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.ellipse(cx, gy, 28 * sc, 8 * sc, 0, 0, Math.PI * 2); ctx.fill();
    if (j) drawJobGround(ctx, cx, gy, t, j.id, sc);
    drawHero(r, app.sprites.heroParts, app.sprites.weapon, { x: cx, y: gy, flip: false, time: t, walkT: 0, moving: false, type, scale: sc, vx: 0, speed: 1 });
    if (j) drawJobHead(ctx, cx, gy, t, j.id, false, sc / 0.95);
  }
  queueMicrotask(frame);
  return canvas;
}

export function createJobsPanel(app) {
  let view = 'mine';
  function act(r, msg, sound = 'click') {
    if (!r.ok) { app.toast({ gold: 'ทองไม่พอ', sparks: 'ประกายอำพันไม่พอ', not_yet: 'ภารกิจยังไม่สำเร็จ', not_owned: 'ยังไม่มีอาชีพนี้' }[r.reason] || 'ทำไม่ได้', 'warn'); app.audio.play('error'); return false; }
    app.store.commit(r.state, { reason: 'job' });
    if (msg) app.toast(msg, 'ok');
    app.audio.play(sound);
    app.refreshPresence?.();
    return true;
  }
  function roll(pay) {
    const r = rollJob(app.store.get(), pay, () => app.rng.next());
    if (!act(r, null, 'summon')) return;
    openJobCeremony(app, r, () => app.rerenderPanel?.());
  }
  function currentCard(st) {
    const id = st.job.on, j = getJob(id);
    if (!j) return h('div', { class: 'job-card empty' }, h('div', { class: 'empty-note' }, 'ยังไม่มีอาชีพ ลองสุ่มอาชีพแรกด้านล่าง'), h('small', { class: 'muted' }, 'ทุกอาชีพมีสกิลเฉพาะตัว (ปุ่ม H) ค่าสถานะพิเศษ และภารกิจปลดล็อกความสามารถอีก 3 ขั้น'));
    const c = st.job.own[id], [have, need, stage] = questProgress(st, id), done = stage >= j.quests.length, wt = getItem(st.equipment.weapon?.id)?.wtype;
    const parts = jobParts(st, id) || {};
    return h('div', { class: 'job-card', style: { '--jc': j.look.glow }, 'data-job': id },
      h('div', { class: 'job-head' }, jobStage(app, id),
        h('div', { class: 'job-meta' },
          h('div', { class: 'job-name' }, emblem(j), h('b', {}, j.name)), h('div', { class: 'hw-row' }, gradeChip(j), stars(c.stars)),
          h('p', { class: 'muted' }, j.blurb),
          h('div', { class: 'job-traits' }, ...j.traits.map((t) => h('span', { class: 'chip' }, t))),
          j.wtype ? h('small', { class: wt === j.wtype ? 'ok-txt' : 'muted' }, wt === j.wtype ? `ถือ${WT_NAME[j.wtype]}อยู่: ได้โบนัสอาวุธ (${bonusText(j.weapon)})` : `ถือ${WT_NAME[j.wtype]}จะได้โบนัสอาวุธเพิ่ม: ${bonusText(j.weapon)}`) : h('small', { class: 'muted' }, 'อาชีพพิเศษ: ใช้ได้กับทุกอาวุธ'))),
      h('div', { class: 'job-bonus' }, h('span', { class: 'eyebrow' }, `โบนัสตอนนี้ (×${(1 + STAR_STEP * (c.stars - 1)).toFixed(1)} จากดาว)`), h('span', {}, bonusText(parts) || '—')),
      h('div', { class: 'job-skill' }, h('span', { class: 'sd-ic' }, skillIcon(j)),
        h('div', {}, h('b', {}, j.skill.name, ' ', h('span', { class: 'chip' }, app.touch ? 'ปุ่มอาชีพ' : 'ปุ่ม H / 6')), h('small', {}, j.skill.desc({ ...Object.fromEntries(Object.entries(j.skill).filter(([, v]) => Array.isArray(v)).map(([k, v]) => [k, v[0]])) })), h('small', { class: 'muted' }, `คูลดาวน์ ${j.skill.cooldown[0]} วินาที`))),
      h('div', { class: 'job-quests' }, h('div', { class: 'eyebrow' }, 'ภารกิจอาชีพ (นับเฉพาะตอนใช้อาชีพนี้)'),
        ...j.quests.map((q, i) => {
          const t = j.talents[i], got = i < stage, cur = i === stage && !done;
          return h('div', { class: `job-q ${got ? 'got' : cur ? 'cur' : 'lock'}` },
            h('span', { class: 'q-n' }, got ? glyph('check') : `${i + 1}`),
            h('div', {}, h('b', {}, `${QUEST_KINDS[q.k]} ${fmt(q.n)} ครั้ง`), h('small', {}, `ปลดล็อก «${t.name}»: ${bonusText(t.b)}`),
              cur ? h('span', { class: 'sd-prog' }, h('i', { style: { width: `${Math.min(100, (have / need) * 100)}%` } }), h('b', { class: 'num' }, `${fmt(have)}/${fmt(need)}`)) : null),
            cur && have >= need ? h('button', { class: 'btn gold small', type: 'button', 'data-action': 'job-claim', onclick: () => { const rr = claimQuest(app.store.get(), id); if (act(rr, `ปลดล็อก «${rr.talent?.name}» แล้ว!`, 'levelup')) app.rerenderPanel?.(); } }, 'รับความสามารถ') : null);
        })));
  }
  function owned(st) {
    const ids = JOB_IDS.filter((id) => ownsJob(st, id));
    return h('div', { class: 'job-grid' }, ...JOB_IDS.map((id) => {
      const j = JOBS[id], own = ownsJob(st, id), on = st.job.on === id;
      return h('button', { class: `job-cell ${own ? '' : 'locked'} ${on ? 'on' : ''}`, type: 'button', 'data-job-cell': id, style: { '--jc': j.look.glow }, title: j.name,
        onclick: () => { if (!own) { app.toast(`${j.name} — ได้จากการสุ่มอาชีพ (${(JOB_ODDS[id] * 100).toFixed(1)}%)`, 'info'); return; } if (on) return; if (act(setJob(app.store.get(), id), `เปลี่ยนเป็น ${j.name}`, 'unlock')) { app.refreshHeroSprites?.(); app.rerenderPanel?.(); } } },
        emblem(j), h('b', {}, own ? j.name : '???'), own ? stars(st.job.own[id].stars) : h('small', { class: 'muted' }, JOB_GRADES[j.grade].name));
    }), ids.length ? null : null);
  }
  function rollBox(st) {
    return h('div', { class: 'job-roll' },
      h('div', { class: 'eyebrow' }, 'หอสุ่มอาชีพ'),
      h('small', { class: 'muted' }, `ได้อาชีพใหม่จะเก็บไว้ในคลัง ได้ซ้ำจะเพิ่มดาว (+${Math.round(STAR_STEP * 100)}% โบนัสต่อดาว สูงสุด ${JOB_MAX_STARS} ดาว) ถ้าเต็มแล้วได้ทองคืน ${fmt(MAXED_REFUND)}`),
      h('div', { class: 'hw-row' },
        h('button', { class: `btn ${st.gold >= JOB_ROLL_GOLD ? 'gold' : ''}`, type: 'button', 'data-action': 'job-roll-gold', disabled: st.gold < JOB_ROLL_GOLD, onclick: () => roll('gold') }, glyph('dice'), 'สุ่ม ', itemImg('gold'), fmt(JOB_ROLL_GOLD)),
        h('button', { class: `btn ${st.sparks >= JOB_ROLL_SPARKS ? 'gold' : ''}`, type: 'button', 'data-action': 'job-roll-sparks', disabled: st.sparks < JOB_ROLL_SPARKS, onclick: () => roll('sparks') }, glyph('dice'), 'สุ่ม ', itemImg('spark'), fmt(JOB_ROLL_SPARKS))),
      h('details', { class: 'job-odds' }, h('summary', {}, 'โอกาสของแต่ละอาชีพ'),
        h('div', { class: 'job-odds-list' }, ...JOB_IDS.map((id) => h('span', { style: { color: JOB_GRADES[JOBS[id].grade].col } }, `${JOBS[id].name} ${(JOB_ODDS[id] * 100).toFixed(1)}%`)))));
  }
  return {
    id: 'jobs', title: 'อาชีพ', icon: 'crown',
    badge: () => { const st = app.store.get(); const id = st.job?.on; if (!id) return st.gold >= JOB_ROLL_GOLD || st.sparks >= JOB_ROLL_SPARKS; const [hv, nd, sg] = questProgress(st, id); return sg < 3 && hv >= nd; },
    render(body) {
      const st = app.store.get();
      app.rerenderPanel = () => this.render(body);
      body.replaceChildren(currentCard(st), h('div', { class: 'eyebrow' }, `อาชีพทั้งหมด (มีแล้ว ${JOB_IDS.filter((id) => ownsJob(st, id)).length}/${JOB_IDS.length}) · แตะเพื่อเปลี่ยน`), owned(st), rollBox(st));
    },
  };
}

// the roll ceremony: sealed scroll → light in the class colour → the hero appears in the class's gear → name & traits
// the roll: a slot strip of class emblems spins and slows onto the result (like the bloodline awakening), then the
// stage opens on the hero wearing the class and the card is revealed
function jobRoulette(app, resultId, onEnd) {
  const pick = () => { let x = Math.random(); for (const id of JOB_IDS) { x -= JOB_ODDS[id]; if (x < 0) return id; } return JOB_IDS[0]; };
  const ids = Array.from({ length: 34 }, pick);
  ids.push(resultId, pick(), pick(), pick());
  const cell = (id) => { const j = getJob(id), G = JOB_GRADES[j.grade];
    return h('div', { class: `rl-cell job-rl g-${j.grade}`, style: { '--race': G.col, '--rc': j.look.glow } }, emblem(j, 'job-rl-img'), h('span', {}, j.name), h('small', {}, j.grade)); };
  const strip = h('div', { class: 'rl-strip' }, ids.map(cell));
  const win = h('div', { class: 'rl-window job-rl-window' }, strip, h('i', { class: 'rl-marker' }));
  const CELL = 96;
  requestAnimationFrame(() => {
    const target = 34 * CELL - (win.clientWidth / 2 - CELL / 2);
    const dur = app.reducedMotion ? 10 : 3200;
    strip.style.transition = `transform ${dur}ms cubic-bezier(.1,.7,.12,1)`;
    strip.style.transform = `translateX(${-target}px)`;
    let ticks = 0;
    const tick = setInterval(() => { if (ticks++ < 22) app.audio.play('click'); }, 115);
    setTimeout(() => { clearInterval(tick); strip.children[34]?.classList.add('win'); onEnd(); }, dur + 150);
  });
  return win;
}

export function openJobCeremony(app, r, onClose) {
  const j = r.job, G = JOB_GRADES[j.grade];
  let close;
  const reveal = h('div', { class: 'jc-reveal', hidden: true },
    h('div', { class: 'hw-row' }, gradeChip(j), stars(r.stars)),
    h('h2', { class: 'jc-name' }, emblem(j, 'job-emb big'), j.name),
    h('p', {}, j.blurb),
    h('div', { class: 'job-traits' }, ...j.traits.map((t) => h('span', { class: 'chip' }, t))),
    h('div', { class: 'job-bonus' }, h('span', { class: 'eyebrow' }, 'ค่าสถานะติดตัว'), h('span', {}, bonusText(j.base)), j.wtype ? h('small', { class: 'muted' }, `ถือ${WT_NAME[j.wtype] || ''}: ${bonusText(j.weapon)}`) : null),
    h('div', { class: 'job-skill' }, h('span', { class: 'sd-ic' }, skillIcon(j)), h('div', {}, h('b', {}, `สกิลอาชีพ: ${j.skill.name}`), h('small', {}, j.skill.desc(Object.fromEntries(Object.entries(j.skill).filter(([, v]) => Array.isArray(v) && typeof v[0] === 'number').map(([k, v]) => [k, v[0]])))))),
    r.maxed ? h('div', { class: 'notice' }, `อาชีพนี้ครบ ${JOB_MAX_STARS} ดาวแล้ว ได้ทองคืน ${fmt(r.refund)}`) : r.dup ? h('div', { class: 'notice ok' }, `ได้อาชีพซ้ำ ดาวเพิ่มเป็น ${r.stars} ดาว (โบนัสแรงขึ้น)`) : h('div', { class: 'notice ok' }, 'ได้อาชีพใหม่!'));
  const stage = h('div', { class: `jc-stage g-${j.grade}`, hidden: true, style: { '--jc': j.look.glow, '--gc': G.col } },
    h('div', { class: 'jc-rays' }), h('div', { class: 'jc-seal' }, glyph('dice')), jobStage(app, j.id, { big: true }));
  const btns = h('div', { class: 'actions', hidden: true },
    !r.dup && app.store.get().job.on !== j.id ? h('button', { class: 'btn gold', type: 'button', 'data-action': 'jc-use', onclick: () => { const s2 = setJob(app.store.get(), j.id); if (s2.ok) { app.store.commit(s2.state, { reason: 'job' }); app.refreshPresence?.(); app.toast(`เปลี่ยนเป็น ${j.name}`, 'ok'); } close(); } }, 'ใช้อาชีพนี้เลย') : null,
    h('button', { class: 'btn primary', type: 'button', 'data-action': 'jc-ok', onclick: () => close() }, 'ตกลง'));
  const spin = h('div', { class: 'jc-spin' }, h('div', { class: 'eyebrow', style: { textAlign: 'center' } }, 'กำลังสุ่มอาชีพ...'));
  const content = h('div', { class: 'modal panel job-ceremony', 'data-modal': 'job-ceremony', 'data-job': j.id, style: { '--jc': j.look.glow } }, spin, stage, reveal, btns);
  close = app.modal(content, { onClose });
  app.audio.play('summon');
  spin.append(jobRoulette(app, j.id, () => {
    app.audio.play(j.grade === 'A' ? 'success' : 'legendary');
    if (j.grade !== 'A') app.renderer?.shake?.(6, 0.4);
    setTimeout(() => {
      spin.hidden = true; stage.hidden = false;
      setTimeout(() => { stage.classList.add('open'); app.audio.play(j.grade === 'A' ? 'unlock' : 'legendary'); }, 250);
      setTimeout(() => { reveal.hidden = false; btns.hidden = false; }, 900);
    }, j.grade === 'SS' ? 900 : 600);
  }));
}
