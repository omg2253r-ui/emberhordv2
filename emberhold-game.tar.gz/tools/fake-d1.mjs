// A tiny in-memory stand-in for Cloudflare D1: only the statements cloudflare/d1.mjs issues. Used by the tests.
// v10: also the versioned `docs` table (compare-and-set) used by guilds and the live services.
export function fakeD1() {
  const kv = new Map(), docs = new Map();
  const stmt = (sql) => ({ sql, args: [], bind(...a) { this.args = a; return this; },
    async first() {
      if (/^SELECT v FROM kv/.test(sql)) { const v = kv.get(this.args[0] + '|' + this.args[1]); return v == null ? null : { v }; }
      if (/^SELECT v, ver FROM docs/.test(sql)) { const d = docs.get(this.args[0]); return d ? { v: d.v, ver: d.ver } : null; }
      return null;
    },
    async all() { if (/^SELECT k FROM kv/.test(sql)) { const [ns, lo, hi] = this.args; return { results: [...kv.keys()].filter((x) => x.startsWith(ns + '|')).map((x) => x.slice(ns.length + 1)).filter((k) => k >= lo && k < hi).sort().map((k) => ({ k })) }; } return { results: [] }; },
    async run() {
      if (/^INSERT INTO kv/.test(sql)) kv.set(this.args[0] + '|' + this.args[1], this.args[2]);
      else if (/^DELETE FROM kv/.test(sql)) kv.delete(this.args[0] + '|' + this.args[1]);
      else if (/^UPDATE docs/.test(sql)) { const [v, k, ver] = this.args; const d = docs.get(k); if (!d || d.ver !== ver) return { meta: { changes: 0 } }; docs.set(k, { v, ver: d.ver + 1 }); }
      else if (/^INSERT OR IGNORE INTO docs/.test(sql)) { const [k, v] = this.args; if (docs.has(k)) return { meta: { changes: 0 } }; docs.set(k, { v, ver: 1 }); }
      else if (/^INSERT INTO docs/.test(sql)) { const [k, v] = this.args; const d = docs.get(k); docs.set(k, { v, ver: (d?.ver || 0) + 1 }); }
      return { meta: { changes: 1 } };
    } });
  return { prepare: stmt, async batch() { return []; }, kv, docs };
}
