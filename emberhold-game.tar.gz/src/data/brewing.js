// v10 Brewing (การปรุงยา). Two cauldrons:
//   หม้อปรุงยาปีศาจ (Halloween, event only): 1–4 kinds of herb from สวนแห่งพงไพร, any amount of each, 5,000 gold a brew.
//     112 herbs, 60 potions, 320 recipes. The exact recipe doubles the potion's chance to succeed; anything else becomes the
//     nearest potion it resembles — or, now and then, the secret potion that curses the drinker in the next dungeon.
//   หม้อปรุงทุกสรรพสิ่ง (permanent): 1–4 kinds of ANY item in the game (gear, materials, herbs, event loot…), 3,000 gold.
//     500 potions (25 effects × 20 grades). What goes in decides the effect and the grade; 320 named recipes give a
//     much higher grade than the same items would by weight.
// Every potion is a timed buff (minutes, real time) usable in every dungeon; up to BREW_ACTIVE at once, the same
// effect replaces the old one. Numbers are kept modest on purpose ("ไม่โกงเกินไป").
// Everything is generated from a fixed seed, so every player has the same herbs, potions and recipes.

export const HW_BREW_COST = 5000;
export const ALL_BREW_COST = 3000;
export const BREW_ACTIVE = 4;
export const BREW_MAX_QTY = 20;

function prng(seed) { let s = seed >>> 0; return () => { s = (s + 0x6d2b79f5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

// ------------------------------------------------------------------ effects (what a potion does)
// cap: the value at the best grade. apply(stats, v) changes the finished computeStats result.
export const EFFECTS = Object.freeze({
  atk:      { name: 'พละกำลัง', cap: 0.16, fmt: (v) => `โจมตี +${pct(v)}`, col: '#ff5a3a', mark: 'ATK' },
  def:      { name: 'ผิวเหล็ก', cap: 0.2, fmt: (v) => `ป้องกัน +${pct(v)}`, col: '#8a9ab8', mark: 'DEF' },
  hp:       { name: 'หัวใจแกร่ง', cap: 0.2, fmt: (v) => `พลังชีวิตสูงสุด +${pct(v)}`, col: '#e0303a', mark: 'HP' },
  crit:     { name: 'ตาเหยี่ยว', cap: 0.08, fmt: (v) => `ติดคริ +${pct(v)}`, col: '#ffd84a', mark: 'CR' },
  critMult: { name: 'เขี้ยวสังหาร', cap: 0.3, fmt: (v) => `ดาเมจคริ +${pct(v)}`, col: '#ff8a1f', mark: 'CD' },
  spd:      { name: 'ลมหมุน', cap: 0.12, fmt: (v) => `ความเร็ว +${pct(v)}`, col: '#7affd8', mark: 'SPD' },
  regen:    { name: 'น้ำค้างฟื้นกาย', cap: 0.008, fmt: (v) => `ฟื้นเลือด ${(v * 100).toFixed(2)}%/วินาที`, col: '#6fe08a', mark: '+' },
  lifesteal:{ name: 'ดื่มโลหิต', cap: 0.05, fmt: (v) => `ดูดเลือด ${pct(v)}`, col: '#8a1a2a', mark: 'LS' },
  gold:     { name: 'เหรียญพราย', cap: 0.3, fmt: (v) => `ทองที่ได้ +${pct(v)}`, col: '#e0b45a', mark: 'G' },
  candy:    { name: 'ลูกกวาดล้นกระเป๋า', cap: 0.4, fmt: (v) => `แคนดี้ที่ได้ +${pct(v)}`, col: '#ff9ac8', mark: 'C' },
  dash:     { name: 'เงาหลบเร้น', cap: 0.18, fmt: (v) => `คูลดาวน์หลบ -${pct(v)}`, col: '#9a8ad0', mark: 'DG' },
  skillcd:  { name: 'นาฬิกาย้อน', cap: 0.15, fmt: (v) => `คูลดาวน์สกิล -${pct(v)}`, col: '#5fb0ff', mark: 'CD' },
  skillpow: { name: 'มนตร์เข้ม', cap: 0.15, fmt: (v) => `พลังสกิล +${pct(v)}`, col: '#c86aff', mark: 'SP' },
  healkill: { name: 'เก็บเกี่ยววิญญาณ', cap: 0.03, fmt: (v) => `ฆ่าแล้วฟื้นเลือด ${pct(v)}`, col: '#b8f0ff', mark: 'HK' },
  magnet:   { name: 'มือแม่เหล็ก', cap: 0.8, fmt: (v) => `ระยะดูดของ +${pct(v)}`, col: '#c8c8d8', mark: 'MG' },
  fire:     { name: 'กันไฟ', cap: 0.3, fmt: (v) => `ดาเมจไฟที่ได้รับ -${pct(v)}`, col: '#ff6a1a', mark: 'FR' },
  thorns:   { name: 'หนามย้อน', cap: 0.25, fmt: (v) => `สะท้อนดาเมจ ${pct(v)}`, col: '#5a9a3a', mark: 'TH' },
  trap:     { name: 'เท้าเบา', cap: 0.4, fmt: (v) => `ดาเมจกับดัก -${pct(v)}`, col: '#a88a5a', mark: 'TR' },
  counter:  { name: 'สวนกลับ', cap: 0.3, fmt: (v) => `ดาเมจสวนกลับ +${pct(v)}`, col: '#ffcf5a', mark: 'CT' },
  guard:    { name: 'โล่ใจ', cap: 0.25, fmt: (v) => `พลังป้องกันตอนกัน +${pct(v)}`, col: '#5a7aa8', mark: 'GD' },
  perfect:  { name: 'จังหวะเทพ', cap: 0.25, fmt: (v) => `โบนัสหลบสมบูรณ์ +${pct(v)}`, col: '#bfe3ff', mark: 'PF' },
  shield:   { name: 'เกราะแสง', cap: 0.1, fmt: (v) => `โล่เริ่มห้อง ${pct(v)} ของเลือด`, col: '#fff3a0', mark: 'SH' },
  ult:      { name: 'ไฟสุดท้าย', cap: 0.25, fmt: (v) => `เกจอัลติเติมเร็ว +${pct(v)}`, col: '#ff7ad8', mark: 'UL' },
  combo:    { name: 'คอมโบไม่ขาด', cap: 0.3, fmt: (v) => `โบนัสคอมโบ +${pct(v)}`, col: '#ffb648', mark: 'CB' },
  armor:    { name: 'กระดองหิน', cap: 0.12, fmt: (v) => `ดาเมจที่ได้รับ -${pct(v)}`, col: '#7a7068', mark: 'AR' },
});
function pct(v) { return `${Math.round(v * 1000) / 10}%`; }
export const EFFECT_IDS = Object.freeze(Object.keys(EFFECTS));

// how a brew changes the finished stats (systems/stats.js calls this last)
export function applyEffect(s, eff, v) {
  switch (eff) {
    case 'atk': s.atk = Math.round(s.atk * (1 + v)); break;
    case 'def': s.def = Math.round(s.def * (1 + v)); break;
    case 'hp': s.maxHp = Math.round(s.maxHp * (1 + v)); break;
    case 'crit': s.crit = Math.min(0.75, s.crit + v); break;
    case 'critMult': s.critMult = Math.round((s.critMult + v) * 100) / 100; break;
    case 'spd': s.speed = Math.round(s.speed * (1 + v)); break;
    case 'regen': s.regen += v; break;
    case 'lifesteal': s.lifesteal += v; break;
    case 'gold': s.goldMult = Math.round((s.goldMult + v) * 100) / 100; break;
    case 'candy': s.candyMult = (s.candyMult || 1) + v; break;
    case 'dash': s.dashCdMult = Math.max(0.3, s.dashCdMult * (1 - v)); break;
    case 'skillcd': s.skillCdMult = Math.max(0.4, s.skillCdMult * (1 - v)); break;
    case 'skillpow': s.skillPower += v; break;
    case 'healkill': s.healOnKill += v; break;
    case 'magnet': s.magnetMult += v; break;
    case 'fire': s.fireReduce = Math.min(0.8, s.fireReduce + v); break;
    case 'thorns': s.thorns += v; break;
    case 'trap': s.trapReduce = Math.min(0.9, s.trapReduce + v); break;
    case 'counter': s.counterBonus += v; break;
    case 'guard': s.guardPower += v; break;
    case 'perfect': s.perfectBonus += v; break;
    case 'shield': s.shieldPct += v; break;
    case 'ult': s.ultGain += v; break;
    case 'combo': s.comboPct += v; break;
    case 'armor': s.dmgTaken = Math.max(-0.5, s.dmgTaken - v); break;
    default: break;
  }
}

// ------------------------------------------------------------------ herbs (สมุนไพร) — 8 shapes × 14 kinds = 112
const SHAPES = [['leaf', 'ใบ'], ['root', 'ราก'], ['flower', 'ดอก'], ['mushroom', 'เห็ด'], ['berry', 'ผล'], ['bark', 'เปลือก'], ['moss', 'มอส'], ['seed', 'เมล็ด']];
const KINDS = [
  ['ฟักทองหลอน', '#e8801f'], ['แมงมุมเงา', '#3a3450'], ['จันทร์ซีด', '#d8e0f0'], ['วิญญาณหลง', '#9fffd8'], ['ค้างคาวฝัน', '#5a2a4a'],
  ['หมอกม่วง', '#9a6ad0'], ['ไฟผี', '#5ae0ff'], ['กระดูกขาว', '#efe4cc'], ['เลือดกา', '#8a1a2a'], ['น้ำค้างดำ', '#24304a'],
  ['ลูกกวาดป่า', '#ff7ab8'], ['แม่มดหลับ', '#6a3a8a'], ['หินร้องไห้', '#7a8a9a'], ['ทองพราย', '#e0b45a'],
];
const HERB_RARITY = ['common', 'common', 'uncommon', 'common', 'uncommon', 'rare', 'rare', 'uncommon', 'epic', 'rare', 'uncommon', 'epic', 'legendary', 'legendary'];
const shadeHex = (hex, f) => { const n = parseInt(hex.slice(1), 16); const c = (v) => Math.max(0, Math.min(255, Math.round(v * f))); return '#' + [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => c(v).toString(16).padStart(2, '0')).join(''); };
export const HERBS = Object.freeze(Object.fromEntries(SHAPES.flatMap(([shape, word], si) => KINDS.map(([kname, col], ki) => {
  const id = `hb_${shape}_${String(ki).padStart(2, '0')}`;
  const rarity = HERB_RARITY[(ki + si) % HERB_RARITY.length];
  return [id, { id, name: `${word}${kname}`, category: 'material', rarity, src: 'hw:wild', event: 'hw', herb: true, lazyIcon: true,
    sellPrice: { common: 6, uncommon: 14, rare: 30, epic: 70, legendary: 160 }[rarity],
    art: { hw: true, kind: 'herb', shape, main: col, dark: shadeHex(col, 0.55), glow: ['epic', 'legendary'].includes(rarity) ? col : null },
    desc: `สมุนไพรจากสวนแห่งพงไพร ใช้ปรุงยาในหม้อปรุงยาปีศาจ (และหม้อปรุงทุกสรรพสิ่ง)` }];
}))));
export const HERB_IDS = Object.freeze(Object.keys(HERBS));
const RVAL = { common: 1, uncommon: 2, rare: 4, epic: 8, legendary: 16, mythic: 32, limited: 48, unknown: 1 };
export const rarityValue = (r) => RVAL[r] || 1;

// ------------------------------------------------------------------ potions
const BOTTLE_OF = ['round', 'vial', 'heart', 'flask', 'skull', 'pumpkin'];
// the Halloween cauldron's twelve effects, five grades each
export const HW_POTION_EFFECTS = Object.freeze(['atk', 'def', 'hp', 'crit', 'critMult', 'spd', 'regen', 'lifesteal', 'gold', 'candy', 'dash', 'skillcd']);
const HW_NAMES = { atk: 'ยาโลหิตค้างคาว', def: 'ยาเปลือกฟักทองแกร่ง', hp: 'ยาหัวใจหลุมศพ', crit: 'ยาตาแมวดำ', critMult: 'ยาเขี้ยวหมาป่าจันทร์', spd: 'ยาไม้กวาดลมหมุน', regen: 'ยาน้ำค้างวิญญาณ', lifesteal: 'ยาดื่มเลือดราตรี', gold: 'ยาเหรียญผีพราย', candy: 'ยาลูกกวาดล้นกระเป๋า', dash: 'ยาเงาหลบเร้น', skillcd: 'ยานาฬิกาย้อนเวลา' };
const GRADE_RAR5 = ['uncommon', 'rare', 'epic', 'legendary', 'mythic'];
const GRADE_RAR20 = (g) => (g <= 4 ? 'common' : g <= 8 ? 'uncommon' : g <= 12 ? 'rare' : g <= 15 ? 'epic' : g <= 18 ? 'legendary' : 'mythic');
function potionDef(id, name, rarity, eff, v, minutes, bottle, extra = {}) {
  const E = EFFECTS[eff];
  return { id, name, category: 'consumable', rarity, src: extra.src || 'brew', brew: { eff, v, min: minutes }, lazyIcon: true, sellPrice: Math.round(20 * rarityValue(rarity)),
    art: { hw: true, kind: 'brew', bottle, main: E.col, glow: ['legendary', 'mythic'].includes(rarity) ? E.col : null, mark: E.mark },
    desc: `ดื่มแล้ว ${E.fmt(v)} นาน ${minutes} นาที (ใช้ได้ทุกดันเจี้ยน · ฤทธิ์ชนิดเดียวกันจะแทนที่ของเดิม)`, ...extra };
}
export const HW_POTIONS = Object.freeze(Object.fromEntries(HW_POTION_EFFECTS.flatMap((eff, ei) => [1, 2, 3, 4, 5].map((g) => {
  const id = `bh_${eff}_${g}`, cap = EFFECTS[eff].cap * 0.85;
  const v = Math.round(cap * (0.2 + 0.8 * g / 5) * 10000) / 10000;
  return [id, potionDef(id, `${HW_NAMES[eff]} ขั้น ${g}`, GRADE_RAR5[g - 1], eff, v, 10 + g * 4, BOTTLE_OF[(ei + g) % BOTTLE_OF.length], { src: 'hw:brew', event: 'hw' })];
}))));
// the secret potion: drinking it curses the hero with three random curses when the next dungeon starts
export const SECRET_POTION = Object.freeze({ id: 'bh_secret', name: 'ยาลับปริศนาสีหม่น', category: 'consumable', rarity: 'epic', src: 'hw:brew', event: 'hw', lazyIcon: true, sellPrice: 1,
  secretCurse: true, art: { hw: true, kind: 'brew', bottle: 'skull', main: '#3a2a4a', glow: '#b86aff', mark: '?' },
  desc: 'ยาที่ปรุงผิดสูตรจนกลายเป็นของลับ ดื่มแล้วรู้สึกดีชั่วครู่ แต่ดันเจี้ยนถัดไปจะติดคำสาปสุ่ม 3 อย่างตอนเริ่ม (20 วินาที)' });
export const ALL_POTIONS = Object.freeze(Object.fromEntries(EFFECT_IDS.flatMap((eff, ei) => Array.from({ length: 20 }, (_, i) => {
  const g = i + 1, id = `ba_${eff}_${g}`, cap = EFFECTS[eff].cap;
  const v = Math.round(cap * (0.15 + 0.85 * g / 20) * 10000) / 10000;
  return [id, potionDef(id, `น้ำยา${EFFECTS[eff].name} ขั้น ${g}`, GRADE_RAR20(g), eff, v, 8 + g, BOTTLE_OF[(ei * 3 + g) % BOTTLE_OF.length])];
}))));
export const BREW_ITEMS = Object.freeze({ ...HERBS, ...HW_POTIONS, [SECRET_POTION.id]: SECRET_POTION, ...ALL_POTIONS });

// ------------------------------------------------------------------ Halloween recipes (320)
const sig = (list) => list.map((x) => `${x.id}*${x.qty}`).sort().join('|');
export const HW_RECIPES = Object.freeze((() => {
  const r = prng(0x48a110), out = [], seen = new Set();
  let guard = 0;
  while (out.length < 320 && guard++ < 20000) {
    const n = 1 + Math.floor(r() * 4);
    const pick = new Set(); while (pick.size < n) pick.add(HERB_IDS[Math.floor(r() * HERB_IDS.length)]);
    const items = [...pick].map((id) => ({ id, qty: 1 + Math.floor(r() * 5) }));
    const key = sig(items);
    if (seen.has(key)) continue;
    seen.add(key);
    const weight = items.reduce((a, x) => a + rarityValue(HERBS[x.id].rarity) * x.qty, 0);
    const g = Math.max(1, Math.min(5, Math.round(1 + Math.log2(1 + weight) * 0.7 + (r() - 0.5))));
    const eff = HW_POTION_EFFECTS[Math.floor(r() * HW_POTION_EFFECTS.length)];
    out.push({ id: `hr${out.length + 1}`, items, out: `bh_${eff}_${g}`, key });
  }
  return out;
})());
const HW_BY_KEY = new Map(HW_RECIPES.map((x) => [x.key, x]));
export const BASE_CHANCE = Object.freeze({ 1: 0.45, 2: 0.38, 3: 0.3, 4: 0.22, 5: 0.15 });
const gradeOf = (pid) => Number(String(pid).split('_').pop()) || 1;
// what a pot of herbs would become (the roll happens in systems/brew.js): { kind: 'exact'|'near'|'secret'|'fail', out, chance, recipe }
export function judgeHw(items) {
  const clean = mergeInputs(items).filter((x) => HERBS[x.id]);
  if (!clean.length || clean.length > 4) return { kind: 'fail', chance: 0 };
  const exact = HW_BY_KEY.get(sig(clean));
  if (exact) { const g = gradeOf(exact.out); return { kind: 'exact', out: exact.out, chance: Math.min(0.95, BASE_CHANCE[g] * 2), recipe: exact.id }; }
  // nearest recipe: shared herbs count, amounts that are close count a little more
  let best = null, bs = 0;
  const mine = new Map(clean.map((x) => [x.id, x.qty]));
  for (const rc of HW_RECIPES) {
    let s = 0;
    for (const x of rc.items) if (mine.has(x.id)) s += 1 + 0.5 * (1 - Math.min(1, Math.abs(mine.get(x.id) - x.qty) / 5));
    const score = s / (Math.max(rc.items.length, clean.length) * 1.5);
    if (score > bs) { bs = score; best = rc; }
  }
  if (best && bs >= 0.34) {
    const g = gradeOf(best.out), eff = best.out.split('_')[1];
    const ng = bs >= 0.66 ? g : Math.max(1, g - 1);           // only half right: one grade lower
    return { kind: 'near', out: `bh_${eff}_${ng}`, chance: BASE_CHANCE[ng], secret: 0.12, recipe: best.id, likeness: bs };
  }
  return { kind: 'secret', out: SECRET_POTION.id, chance: 0.4, likeness: bs };
}

// ------------------------------------------------------------------ the cauldron of all things (permanent)
// effect from what goes in: each category leans toward a few effects; materials/herbs pick by their id
const LEAN = { weapon: ['atk', 'crit', 'critMult', 'counter', 'combo'], armor: ['def', 'hp', 'armor', 'guard', 'thorns'], charm: ['crit', 'gold', 'magnet', 'skillpow', 'ult'],
  wings: ['spd', 'dash', 'perfect', 'trap', 'magnet'], consumable: ['regen', 'hp', 'healkill', 'shield', 'lifesteal'], material: EFFECT_IDS };
function hashStr(s) { let h = 2166136261; for (const ch of String(s)) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
export function effectOfItem(def) {
  if (def.brew) return def.brew.eff;
  const lean = LEAN[def.category] || EFFECT_IDS;
  return lean[hashStr(def.id) % lean.length];
}
export function gradeByWeight(w) { return Math.max(1, Math.min(20, Math.round(Math.log2(1 + w) * 2.1))); }
// 320 named recipes over every item that can be put in (built lazily: needs the full item list)
let ALL_RECIPES = null, ALL_BY_KEY = null;
export function allRecipes(itemsById) {
  if (ALL_RECIPES) return ALL_RECIPES;
  const pool = Object.values(itemsById).filter((d) => !d.brew && !d.secretCurse && d.id !== 'p_hw_cross').map((d) => d.id).sort();
  const r = prng(0xa11b5e), out = [], seen = new Set();
  let guard = 0;
  while (out.length < 320 && guard++ < 20000) {
    const n = 2 + Math.floor(r() * 3);
    const pick = new Set(); while (pick.size < n) pick.add(pool[Math.floor(r() * pool.length)]);
    const items = [...pick].map((id) => ({ id, qty: 1 + Math.floor(r() * 3) }));
    const key = sig(items);
    if (seen.has(key)) continue;
    seen.add(key);
    const w = items.reduce((a, x) => a + rarityValue(itemsById[x.id].rarity) * x.qty, 0);
    const g = Math.min(20, gradeByWeight(w) + 4 + Math.floor(r() * 4));      // a named recipe brews far above its weight
    const eff = EFFECT_IDS[Math.floor(r() * EFFECT_IDS.length)];
    out.push({ id: `ar${out.length + 1}`, items, out: `ba_${eff}_${g}`, key });
  }
  ALL_RECIPES = out; ALL_BY_KEY = new Map(out.map((x) => [x.key, x]));
  return out;
}
export function judgeAll(items, itemsById) {
  allRecipes(itemsById);
  const clean = mergeInputs(items).filter((x) => itemsById[x.id] && !itemsById[x.id].secretCurse);
  if (!clean.length || clean.length > 4) return { kind: 'fail', chance: 0 };
  const exact = ALL_BY_KEY.get(sig(clean));
  if (exact) return { kind: 'exact', out: exact.out, chance: 1, recipe: exact.id };
  // by weight: the heaviest ingredient decides the effect
  let w = 0, heavy = null, hw = -1;
  for (const x of clean) { const d = itemsById[x.id], v = rarityValue(d.rarity) * x.qty; w += v; if (v > hw) { hw = v; heavy = d; } }
  const g = gradeByWeight(w);
  return { kind: 'weight', out: `ba_${effectOfItem(heavy)}_${g}`, chance: 0.9 };
}
export function mergeInputs(items) {
  const m = new Map();
  for (const x of items || []) { if (!x || typeof x.id !== 'string') continue; const q = Math.max(0, Math.min(BREW_MAX_QTY, Math.floor(Number(x.qty) || 0))); if (q > 0) m.set(x.id, Math.min(BREW_MAX_QTY, (m.get(x.id) || 0) + q)); }
  return [...m.entries()].map(([id, qty]) => ({ id, qty }));
}
