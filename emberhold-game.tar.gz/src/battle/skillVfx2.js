// v10.2 skill effects for the Halloween, Egypt, secret and support skills. Like skillVfx.js this only draws: the
// records live in the same list (world.sk.fx) and the casts in battle/skillCast2.js move or end them.
// Most effects are built around an illustrated symbol (art/symbols.js) rasterised once per element colour, then
// drawn with glow sprites — a pumpkin that tumbles through the air, a pyramid rising out of the sand, a black hole …
import { registerFx, elOf, hexA } from './skillVfx.js';
import { symSvg } from '../art/symbols.js';
import { glowSprite, raysSprite } from '../scenes/ambientFx.js';
// a glow that respects the alpha already set on the context
function drawGlow(ctx, x, y, r, col, a = 1) { if (a <= 0 || r <= 0) return; const p = ctx.globalAlpha; ctx.globalAlpha = p * Math.min(1, a); ctx.drawImage(glowSprite(col), x - r, y - r, r * 2, r * 2); ctx.globalAlpha = p; }

const TAU = Math.PI * 2;
const clamp01 = (t) => Math.min(1, Math.max(0, t));
const ease = (t) => 1 - Math.pow(1 - clamp01(t), 3);
const back = (t) => { t = clamp01(t); const c = 1.9; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); };
const fade = (e, a = 0.15, b = 0.3) => Math.min(1, e.t / a) * Math.min(1, Math.max(0, (e.dur - e.t) / b));
function rnd(seed) { let s = (seed * 9301 + 49297) % 233280; return () => ((s = (s * 9301 + 49297) % 233280) / 233280); }

// ------------------------------------------------------------------ symbol sprites
const SPR = new Map();
export function symSprite(name, el) {
  const k = `${name}|${el}`;
  let img = SPR.get(k);
  if (!img) {
    img = typeof Image !== 'undefined' ? new Image() : null;
    if (img) img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(symSvg(name, elOf(el)).replace('width="64" height="64"', 'width="128" height="128"'))}`;
    SPR.set(k, img);
  }
  return img;
}
export function drawSym(ctx, name, el, x, y, size, rot = 0, alpha = 1, sx = 1, sy = 1) {
  const img = symSprite(name, el);
  if (alpha <= 0) return;
  ctx.save(); ctx.translate(x, y); if (rot) ctx.rotate(rot); ctx.scale(sx, sy); ctx.globalAlpha *= alpha;
  if (img && img.complete && img.naturalWidth) ctx.drawImage(img, -size / 2, -size / 2, size, size);
  else { const C = elOf(el); ctx.fillStyle = C.glow; ctx.beginPath(); ctx.arc(0, 0, size * 0.32, 0, TAU); ctx.fill(); }
  ctx.restore();
}
// warm the sprites of a skill so the first cast does not pop in late
export function preloadSyms(list) { for (const [n, el] of list) symSprite(n, el); }

// ------------------------------------------------------------------ air layer
// a symbol: pops in, rises from the ground, falls from the sky, flies from a to b, or just floats
registerFx('sym', 'air', (ctx, e, time) => {
  const k = e.t / e.dur, C = elOf(e.el), s = e.size || 60;
  let x = e.x, y = e.y, sc = 1, a = fade(e, 0.08, 0.25), rot = e.rot || 0;
  if (e.mode === 'pop') sc = back(e.t / 0.28);
  else if (e.mode === 'rise') { const r = ease(e.t / 0.35); y = e.y + (1 - r) * s * 0.6; sc = 0.4 + 0.6 * r; }
  else if (e.mode === 'fall') { const r = ease(e.t / (e.land || 0.35)); y = e.y - (1 - r) * (e.h || 420); }
  else if (e.mode === 'fly') { const r = clamp01(k); x = e.x + (e.x2 - e.x) * r; y = e.y + (e.y2 - e.y) * r - Math.sin(r * Math.PI) * (e.h || 0); rot += time * (e.spin || 0); }
  else if (e.mode === 'float') { y = e.y - 20 * k - 6 * Math.sin(time * 4 + e.seed); }
  else if (e.mode === 'agent') { a = Math.min(1, e.t / 0.2) * (e.gone ? Math.max(0, 1 - (e.t - e.gone) / 0.3) : 1); }
  if (e.spin && e.mode !== 'fly') rot += time * e.spin;
  const flap = e.flap ? 0.65 + 0.35 * Math.abs(Math.sin(time * e.flap + e.seed)) : 1;
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  drawGlow(ctx, x, y, s * (e.halo || 0.9) * sc, C.glow, 0.55 * a);
  ctx.restore();
  if (e.mode === 'rise' && e.t < 0.5) { ctx.save(); ctx.globalAlpha = (0.5 - e.t) * 1.6; ctx.fillStyle = 'rgba(30,20,14,0.6)'; ctx.beginPath(); ctx.ellipse(e.x, e.y + s * 0.42, s * 0.6, s * 0.16, 0, 0, TAU); ctx.fill(); ctx.restore(); }
  drawSym(ctx, e.sym, e.el, x, y, s * sc, rot, a, (e.flip ? -1 : 1) * flap, 1);
});

// a lobbed projectile: tumbles along an arc with its shadow on the ground and a spark trail
registerFx('lobfx', 'air', (ctx, e, time) => {
  const r = clamp01(e.t / e.dur), C = elOf(e.el), s = e.size || 44;
  const gx = e.x + (e.x2 - e.x) * r, gy = e.y + (e.y2 - e.y) * r, y = gy - Math.sin(r * Math.PI) * (e.h || 180);
  ctx.save(); ctx.globalAlpha = 0.35; ctx.fillStyle = '#000'; ctx.beginPath(); ctx.ellipse(gx, gy, s * 0.4 * (0.6 + r * 0.4), s * 0.14, 0, 0, TAU); ctx.fill(); ctx.restore();
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (let i = 1; i <= 5; i++) { const q = Math.max(0, r - i * 0.035); const tx = e.x + (e.x2 - e.x) * q, ty = e.y + (e.y2 - e.y) * q - Math.sin(q * Math.PI) * (e.h || 180); drawGlow(ctx, tx, ty, s * (0.5 - i * 0.06), C.spark[i % C.spark.length], 0.5 - i * 0.08); }
  ctx.restore();
  drawSym(ctx, e.sym, e.el, gx, y, s, time * (e.spin ?? 7) + e.seed, 1);
});

// a big symbol high in the sky (the eye of Horus, the sun disk, the blood moon) with rays and a glow
registerFx('skyicon', 'air', (ctx, e, time) => {
  const a = fade(e, 0.3, 0.4), C = elOf(e.el), s = e.size || 140, y = e.y - (e.h || 260) - 8 * Math.sin(time * 1.6);
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  drawGlow(ctx, e.x, y, s * 1.6, C.glow, 0.5 * a);
  ctx.globalAlpha = 0.55 * a; ctx.translate(e.x, y); ctx.rotate(time * 0.25);
  const R = raysSprite(C.glow, 18); ctx.drawImage(R, -s * 1.4, -s * 1.4, s * 2.8, s * 2.8);
  ctx.restore();
  drawSym(ctx, e.sym, e.el, e.x, y, s * (0.85 + 0.15 * ease(e.t / 0.4)), 0, a);
});

// a column of light from the sky onto a point
registerFx('godray', 'air', (ctx, e, time) => {
  const a = fade(e, 0.06, 0.25), C = elOf(e.el), w = (e.w || 46) * (0.8 + 0.2 * Math.sin(time * 30 + e.seed));
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = a;
  const g = ctx.createLinearGradient(e.x - w, 0, e.x + w, 0);
  g.addColorStop(0, hexA(C.glow, 0)); g.addColorStop(0.35, hexA(C.glow, 0.5)); g.addColorStop(0.5, hexA(C.core, 0.95)); g.addColorStop(0.65, hexA(C.glow, 0.5)); g.addColorStop(1, hexA(C.glow, 0));
  ctx.fillStyle = g; ctx.fillRect(e.x - w, e.y - (e.h || 700), w * 2, e.h || 700);
  drawGlow(ctx, e.x, e.y, w * 2.4, C.glow, 0.8);
  ctx.restore();
});

// a wavy glowing line between two points (the soul link, mummy wraps, the life thread)
registerFx('tether', 'air', (ctx, e, time) => {
  const a = fade(e, 0.1, 0.3), C = elOf(e.el);
  const x1 = e.a ? e.a.x : e.x, y1 = (e.a ? e.a.y : e.y) - (e.lift ?? 40), x2 = e.b ? e.b.x : e.x2, y2 = (e.b ? e.b.y : e.y2) - (e.lift2 ?? e.lift ?? 40);
  if (x2 == null) return;
  const d = Math.hypot(x2 - x1, y2 - y1), n = Math.max(6, Math.round(d / 18)), nx = -(y2 - y1) / (d || 1), ny = (x2 - x1) / (d || 1);
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round';
  for (const [wid, col, amp] of [[9, hexA(C.glow, 0.35 * a), 1], [3.4, hexA(C.core, 0.95 * a), 0.6]]) {
    ctx.strokeStyle = col; ctx.lineWidth = wid; ctx.beginPath();
    for (let i = 0; i <= n; i++) { const q = i / n, wv = Math.sin(q * Math.PI * (e.waves || 3) + time * 9) * (e.amp ?? 8) * amp * Math.sin(q * Math.PI); const px = x1 + (x2 - x1) * q + nx * wv, py = y1 + (y2 - y1) * q + ny * wv; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
    ctx.stroke();
  }
  for (let i = 0; i < 3; i++) { const q = (time * 0.8 + i / 3) % 1; drawGlow(ctx, x1 + (x2 - x1) * q, y1 + (y2 - y1) * q, 12, C.core, a); }
  ctx.restore();
});

// a ring of light above a head and sparkles rising around the body: an ally got a blessing
registerFx('halo', 'air', (ctx, e, time) => {
  const a = fade(e, 0.15, 0.35), C = elOf(e.el), R = rnd(e.seed);
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.strokeStyle = hexA(C.core, 0.9 * a); ctx.lineWidth = 3;
  ctx.beginPath(); ctx.ellipse(e.x, e.y - 112 - 3 * Math.sin(time * 3), 22, 7, 0, 0, TAU); ctx.stroke();
  for (let i = 0; i < 10; i++) {
    const q = (time * (0.6 + R() * 0.5) + R()) % 1, ang = R() * TAU;
    drawGlow(ctx, e.x + Math.cos(ang) * (22 + R() * 14), e.y - q * 110, 7 + R() * 5, C.spark[i % 3], (1 - q) * a);
  }
  if (e.sym) drawSym(ctx, e.sym, e.el, e.x, e.y - 150 - 6 * Math.sin(time * 2.4), 34, 0, a * 0.95);
  ctx.restore();
});

// music notes drifting up and around (hymns, the war drum, the echo aria)
registerFx('notes', 'air', (ctx, e, time) => {
  const a = fade(e, 0.2, 0.4), R = rnd(e.seed), n = e.n || 8, r = e.r || 90;
  for (let i = 0; i < n; i++) {
    const q = (time * 0.45 + R()) % 1, ang = R() * TAU + time * 0.6;
    drawSym(ctx, e.sym || 'note', e.el, e.x + Math.cos(ang) * r * (0.4 + 0.6 * q), e.y - 30 - q * 120 + Math.sin(ang) * r * 0.3, 26 + R() * 10, Math.sin(time * 3 + i) * 0.3, a * (1 - q * q));
  }
});

// angel wings opening behind someone
registerFx('wings', 'air', (ctx, e, time) => {
  const a = fade(e, 0.25, 0.4), C = elOf(e.el), open = ease(e.t / 0.45), flap = Math.sin(time * 5) * 0.08;
  ctx.save(); ctx.translate(e.x, e.y - 60); ctx.globalCompositeOperation = 'lighter';
  for (const side of [-1, 1]) {
    ctx.save(); ctx.scale(side, 1); ctx.rotate(-0.25 * open - flap);
    for (let i = 0; i < 6; i++) {
      const len = (60 + i * 16) * open, ang = -0.9 + i * 0.28;
      ctx.fillStyle = hexA(i % 2 ? C.glow : C.core, (0.55 - i * 0.05) * a);
      ctx.beginPath(); ctx.ellipse(18 + Math.cos(ang) * len * 0.5, Math.sin(ang) * len * 0.5, len * 0.5, 9, ang, 0, TAU); ctx.fill();
    }
    ctx.restore();
  }
  drawGlow(ctx, 0, 0, 90, C.glow, 0.4 * a);
  ctx.restore();
});

// a world tree growing out of the ground (x_world_tree)
registerFx('tree', 'air', (ctx, e, time) => {
  const a = fade(e, 0.2, 0.6), g = ease(e.t / 0.9), C = elOf(e.el), H = (e.h || 260) * g, R = rnd(e.seed);
  ctx.save(); ctx.globalAlpha = a; ctx.lineCap = 'round';
  ctx.strokeStyle = '#3a2414'; ctx.lineWidth = 26 * g; ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.bezierCurveTo(e.x - 18, e.y - H * 0.4, e.x + 16, e.y - H * 0.7, e.x, e.y - H); ctx.stroke();
  ctx.strokeStyle = '#6a4424'; ctx.lineWidth = 10 * g; ctx.stroke();
  for (let i = 0; i < 6; i++) { const yy = e.y - H * (0.45 + i * 0.09), dir = i % 2 ? 1 : -1; ctx.strokeStyle = '#4a2e18'; ctx.lineWidth = 8 * g; ctx.beginPath(); ctx.moveTo(e.x, yy); ctx.quadraticCurveTo(e.x + dir * 50 * g, yy - 20, e.x + dir * (70 + i * 6) * g, yy - 50); ctx.stroke(); }
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 16; i++) { const ang = R() * TAU, rr = R() * 110 * g; drawGlow(ctx, e.x + Math.cos(ang) * rr * 1.3, e.y - H - 20 + Math.sin(ang) * rr * 0.55, 46 * g, i % 3 ? '#7fd06a' : C.glow, 0.42); }
  for (let i = 0; i < 12; i++) { const q = (time * 0.3 + R()) % 1; drawGlow(ctx, e.x + (R() - 0.5) * 260 * g + Math.sin(time * 2 + i) * 14, e.y - H + q * H * 1.05, 6, i % 2 ? '#c8ff8a' : '#fff3c4', (1 - q) * 0.9); }
  ctx.restore();
});

// a banner on a pole, its cloth waving (the war banner, the king's decree)
registerFx('bannerfx', 'air', (ctx, e, time) => {
  const a = fade(e, 0.2, 0.4), C = elOf(e.el), up = ease(e.t / 0.3), x = e.x, y = e.y;
  ctx.save(); ctx.globalAlpha = a;
  ctx.strokeStyle = '#141022'; ctx.lineWidth = 8; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y - 170 * up); ctx.stroke();
  ctx.strokeStyle = '#8a5a32'; ctx.lineWidth = 4.5; ctx.stroke();
  ctx.fillStyle = C.glow; ctx.strokeStyle = '#141022'; ctx.lineWidth = 2.6;
  ctx.beginPath(); ctx.moveTo(x + 2, y - 166 * up);
  for (let i = 0; i <= 8; i++) { const q = i / 8; ctx.lineTo(x + 2 + q * 80, y - 166 * up + Math.sin(time * 6 - q * 4) * 6 * q); }
  for (let i = 8; i >= 0; i--) { const q = i / 8; ctx.lineTo(x + 2 + q * 80 - (i === 8 ? 12 : 0), y - 110 * up + Math.sin(time * 6 - q * 4) * 6 * q); }
  ctx.closePath(); ctx.fill(); ctx.stroke();
  drawSym(ctx, e.sym || 'crown', e.el, x + 40, y - 138 * up + Math.sin(time * 6 - 2) * 3, 34, 0, 1);
  ctx.globalCompositeOperation = 'lighter'; drawGlow(ctx, x, y - 170 * up, 26, '#ffcf5a', 0.9);
  ctx.restore();
});

// a pyramid of light rising out of the sand, then crumbling (eg_sk_pyramid)
registerFx('pyramidfx', 'air', (ctx, e, time) => {
  const C = elOf(e.el), up = ease(e.t / 0.45), k = e.t / e.dur, crumble = clamp01((k - 0.82) / 0.18);
  const W = e.r || 150, H = W * 1.05 * up, x = e.x, y = e.y + crumble * 30;
  ctx.save(); ctx.globalAlpha = 1 - crumble;
  ctx.fillStyle = '#c8a060'; ctx.strokeStyle = '#141022'; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(x - W, y); ctx.lineTo(x, y - H); ctx.lineTo(x + W * 0.25, y + W * 0.22); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#8a6a3a'; ctx.beginPath(); ctx.moveTo(x + W * 0.25, y + W * 0.22); ctx.lineTo(x, y - H); ctx.lineTo(x + W, y); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.strokeStyle = 'rgba(60,40,20,0.5)'; ctx.lineWidth = 1.6;
  for (let i = 1; i < 6; i++) { const q = i / 6; ctx.beginPath(); ctx.moveTo(x - W * (1 - q), y - H * q); ctx.lineTo(x + W * 0.25 * (1 - q), y + W * 0.22 * (1 - q) - H * q); ctx.lineTo(x + W * (1 - q), y - H * q); ctx.stroke(); }
  ctx.globalCompositeOperation = 'lighter';
  const pulse = 0.6 + 0.4 * Math.sin(time * 8);
  ctx.strokeStyle = hexA(C.glow, 0.8 * pulse); ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(x - W, y); ctx.lineTo(x, y - H); ctx.lineTo(x + W, y); ctx.stroke();
  drawGlow(ctx, x, y - H, 50, C.core, pulse);
  if (up >= 1) { ctx.globalAlpha = (1 - crumble) * 0.7; const g = ctx.createLinearGradient(x, y - H, x, y - H - 600); g.addColorStop(0, hexA(C.core, 0.8)); g.addColorStop(1, hexA(C.glow, 0)); ctx.fillStyle = g; ctx.fillRect(x - 8, y - H - 600, 16, 600); }
  ctx.restore();
  if (crumble > 0) { const R = rnd(e.seed); ctx.save(); ctx.fillStyle = '#a8803a'; for (let i = 0; i < 18; i++) { const px = x + (R() - 0.5) * W * 2, py = y - R() * H * 0.6 + crumble * 80 * (0.5 + R()); ctx.globalAlpha = 1 - crumble; ctx.fillRect(px, py, 6 + R() * 8, 6 + R() * 8); } ctx.restore(); }
});

// a black hole: lensing ring, a tilted accretion disc and matter spiralling in
registerFx('blackhole', 'air', (ctx, e, time) => {
  const a = fade(e, 0.3, 0.35), C = elOf(e.el), r = (e.r || 60) * (0.5 + 0.5 * ease(e.t / 0.5)), R = rnd(e.seed), y = e.y - 70;
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  drawGlow(ctx, e.x, y, r * 3.2, C.glow, 0.5 * a);
  for (let i = 0; i < 40; i++) {
    const q = (time * (0.35 + R() * 0.3) + R()) % 1, ang = R() * TAU + time * (1.5 + R()) + q * 4, rr = r * 3 * (1 - q) + r;
    drawGlow(ctx, e.x + Math.cos(ang) * rr, y + Math.sin(ang) * rr * 0.4, 5 + 4 * q, C.spark[i % 3], a * q);
  }
  ctx.save(); ctx.translate(e.x, y); ctx.rotate(-0.25);
  for (let i = 0; i < 3; i++) { ctx.strokeStyle = hexA(i ? C.glow : C.core, (0.8 - i * 0.2) * a); ctx.lineWidth = 7 - i * 2; ctx.beginPath(); ctx.ellipse(0, 0, r * (2 + i * 0.35), r * (0.55 + i * 0.1), 0, time * 2 + i, time * 2 + i + TAU * 0.85); ctx.stroke(); }
  ctx.restore();
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = a; ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(e.x, y, r, 0, TAU); ctx.fill();
  ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = hexA('#ffffff', 0.85 * a); ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(e.x, y, r * 1.08, 0, TAU); ctx.stroke();
  ctx.restore();
});

// time stops: a grey bubble, clock numerals and hands spinning backwards
registerFx('timestop', 'air', (ctx, e, time) => {
  const a = fade(e, 0.2, 0.3), C = elOf(e.el), r = (e.r || 300) * ease(e.t / 0.35);
  ctx.save(); ctx.globalAlpha = a;
  ctx.fillStyle = 'rgba(160,170,200,0.16)'; ctx.beginPath(); ctx.ellipse(e.x, e.y, r, r * 0.62, 0, 0, TAU); ctx.fill();
  ctx.globalCompositeOperation = 'lighter';
  ctx.strokeStyle = hexA(C.core, 0.8); ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(e.x, e.y, r, r * 0.62, 0, 0, TAU); ctx.stroke();
  ctx.font = 'bold 22px serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = hexA(C.glow, 0.9);
  const NUM = ['XII', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI'];
  for (let i = 0; i < 12; i++) { const ang = (i / 12) * TAU - Math.PI / 2 - time * 0.2; ctx.fillText(NUM[i], e.x + Math.cos(ang) * r * 0.86, e.y + Math.sin(ang) * r * 0.86 * 0.62); }
  ctx.lineCap = 'round';
  for (const [len, sp, w] of [[0.55, -2.6, 6], [0.75, -9, 3.5]]) { const ang = time * sp; ctx.strokeStyle = hexA(C.core, 0.95); ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(e.x + Math.cos(ang) * r * len, e.y + Math.sin(ang) * r * len * 0.62); ctx.stroke(); }
  drawGlow(ctx, e.x, e.y, 40, C.glow, 1);
  ctx.restore();
});

// rain falling inside a circle (healing rain, the tide's blessing)
registerFx('rainfx', 'air', (ctx, e, time) => {
  const a = fade(e, 0.3, 0.4), C = elOf(e.el), R = rnd(e.seed), n = e.n || 40;
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = hexA(C.core, 0.7 * a); ctx.lineWidth = 2; ctx.lineCap = 'round';
  for (let i = 0; i < n; i++) {
    const q = (time * (1.4 + R()) + R()) % 1, ang = R() * TAU, rr = Math.sqrt(R()) * e.r;
    const gx = e.x + Math.cos(ang) * rr, gy = e.y + Math.sin(ang) * rr * 0.6, y = gy - 360 * (1 - q);
    ctx.beginPath(); ctx.moveTo(gx + 6, y - 22); ctx.lineTo(gx, y); ctx.stroke();
    if (q > 0.92) { ctx.beginPath(); ctx.ellipse(gx, gy, 10 * (q - 0.9) * 20, 3 * (q - 0.9) * 20, 0, 0, TAU); ctx.stroke(); }
  }
  ctx.restore();
});

// a whirl of sand grains around a moving centre
registerFx('sandstorm', 'air', (ctx, e, time) => {
  const a = fade(e, 0.3, 0.5), C = elOf(e.el), R = rnd(e.seed), r = e.r || 120;
  ctx.save();
  for (let i = 0; i < 70; i++) {
    const ang = R() * TAU + time * (2.2 + R() * 1.5), rr = r * (0.2 + 0.85 * R()), lift = (R() * 140 + time * 60 * (0.5 + R())) % 160;
    ctx.globalAlpha = a * (0.4 + 0.6 * (1 - lift / 160));
    ctx.fillStyle = C.spark[i % 3];
    ctx.fillRect(e.x + Math.cos(ang) * rr, e.y + Math.sin(ang) * rr * 0.45 - lift, 3 + (i % 3), 2);
  }
  ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = a * 0.6;
  for (let k = 0; k < 3; k++) { ctx.strokeStyle = hexA(C.glow, 0.5); ctx.lineWidth = 6 - k * 1.5; ctx.beginPath(); ctx.ellipse(e.x, e.y - 30 - k * 40, r * (1 - k * 0.18), r * 0.3, 0, time * 4 + k, time * 4 + k + 4); ctx.stroke(); }
  ctx.restore();
});

// a ring of falling stars/candy/bats circling in the sky (decor for big casts)
registerFx('ringsyms', 'air', (ctx, e, time) => {
  const a = fade(e, 0.2, 0.35), n = e.n || 8, r = (e.r || 120) * (0.6 + 0.4 * ease(e.t / 0.4));
  for (let i = 0; i < n; i++) { const ang = (i / n) * TAU + time * (e.spin ?? 1.5); drawSym(ctx, e.sym, e.el, e.x + Math.cos(ang) * r, e.y - (e.lift ?? 60) + Math.sin(ang) * r * 0.45, e.size || 34, e.turn ? ang : 0, a, e.flap ? 0.6 + 0.4 * Math.abs(Math.sin(time * e.flap + i)) : 1); }
});

// ------------------------------------------------------------------ ground layer
// a big flat emblem on the floor (hex circle, the scales of Anubis, a star map …)
registerFx('emblem', 'ground', (ctx, e, time) => {
  const a = fade(e, 0.25, 0.4), C = elOf(e.el), r = (e.r || 140) * (0.75 + 0.25 * ease(e.t / 0.35));
  ctx.save(); ctx.translate(e.x, e.y); ctx.scale(1, 0.6); ctx.globalAlpha = a;
  ctx.globalCompositeOperation = 'lighter';
  drawGlow(ctx, 0, 0, r * 1.2, C.glow, 0.45);
  ctx.strokeStyle = hexA(C.core, 0.9); ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.stroke();
  ctx.setLineDash([10, 8]); ctx.lineDashOffset = -time * 50; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, r * 0.88, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
  ctx.rotate(time * (e.spin ?? 0.5));
  drawSym(ctx, e.sym, e.el, 0, 0, r * 1.25, 0, 0.85);
  ctx.restore();
});
// glowing footprints of a path (the ghost march, the mend wave)
registerFx('path', 'ground', (ctx, e) => {
  const a = fade(e, 0.1, 0.5), C = elOf(e.el), len = Math.hypot(e.x2 - e.x, e.y2 - e.y), ang = Math.atan2(e.y2 - e.y, e.x2 - e.x), w = e.w || 90;
  ctx.save(); ctx.translate(e.x, e.y); ctx.rotate(ang); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = a * 0.7;
  const g = ctx.createLinearGradient(0, -w, 0, w); g.addColorStop(0, hexA(C.glow, 0)); g.addColorStop(0.5, hexA(C.glow, 0.45)); g.addColorStop(1, hexA(C.glow, 0));
  ctx.fillStyle = g; ctx.fillRect(0, -w, len * clamp01(e.t / (e.grow || 0.4)), w * 2);
  ctx.restore();
});
