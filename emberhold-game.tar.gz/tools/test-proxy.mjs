// Checks for the Netlify → Cloudflare forwarding. Run: node tools/test-proxy.mjs
// A fake "Cloudflare" is the real cloud handler on an in-memory store; the "Netlify" side goes through forward().
import { forward, backendOf, DEFAULT_BACKEND } from '../netlify/lib/proxy.mjs';
import { handleCloud } from '../netlify/lib/cloud.mjs';
import { memoryKV } from '../netlify/lib/hub.mjs';

let failed = 0;
const ok = (c, m) => { console.log((c ? 'ok   ' : 'FAIL ') + m); if (!c) failed++; };

ok(backendOf({}) === DEFAULT_BACKEND, 'default backend is the Cloudflare site');
ok(backendOf({ EMBERHOLD_BACKEND: 'local' }) === null, 'EMBERHOLD_BACKEND=local turns forwarding off');
ok(backendOf({ EMBERHOLD_BACKEND: 'https://x.example.com/' }) === 'https://x.example.com', 'custom https backend, trailing slash trimmed');
ok(backendOf({ EMBERHOLD_BACKEND: 'http://evil.test' }) === DEFAULT_BACKEND, 'non-https backend is ignored');

const cf = memoryKV();
const seen = [];
const fakeFetch = async (url, init) => {
  seen.push({ url, init });
  const r = await handleCloud(new Request(url, { method: init.method, headers: init.headers, body: init.body }), cf, Date.now(), {});
  return r;
};
const post = (body) => new Request('https://emberhordv2.netlify.app/api/cloud', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
const env = { EMBERHOLD_PROXY_KEY: 'k'.repeat(32) };

let r = await forward(post({ op: 'register', name: 'tester', pass: 'secret1' }), 'cloud', { env, ip: '1.2.3.4', fetchImpl: fakeFetch });
let d = await r.json();
ok(r.status === 200 && /^[a-f0-9]{48}$/.test(d.token), 'register through the proxy reaches the Cloudflare store');
ok(seen[0].url === DEFAULT_BACKEND + '/api/cloud', 'forwarded to the Cloudflare /api/cloud URL');
ok(seen[0].init.headers['x-emberhold-ip'] === '1.2.3.4' && seen[0].init.headers['x-emberhold-proxy-key'] === env.EMBERHOLD_PROXY_KEY, 'player IP + secret are sent when a key is set');
ok(r.headers.get('cache-control') === 'no-store', 'answer is never cached');

r = await forward(post({ op: 'login', name: 'tester', pass: 'secret1' }), 'cloud', { env: {}, ip: '1.2.3.4', fetchImpl: fakeFetch });
ok(r.status === 200 && !seen[1].init.headers['x-emberhold-ip'], 'without a key the IP headers are not sent');

r = await forward(post({ op: 'login', name: 'tester', pass: 'wrongpass' }), 'cloud', { env, ip: '1.2.3.4', fetchImpl: fakeFetch });
ok(r.status === 401 && (await r.json()).error === 'wrong', 'backend errors (wrong password) pass through with their status');

r = await forward(post({ op: 'ranks', board: 'power' }), 'cloud', { env, fetchImpl: fakeFetch });
d = await r.json();
ok(r.status === 200 && d.board === 'power' && Array.isArray(d.entries), 'leaderboard read comes from the Cloudflare store');

r = await forward(post({ op: 'ranks', board: 'power' }), 'cloud', { env, fetchImpl: async () => { throw new Error('down'); } });
ok(r.status === 502 && (await r.json()).error === 'network', 'backend unreachable → { error: "network" } (client shows its network message), nothing stored locally');

const g = await forward(new Request('https://emberhordv2.netlify.app/api/docs?path=guilds/gabcdef123', { method: 'GET' }), 'docs', { env, fetchImpl: async (u, i) => { seen.push({ url: u, init: i }); return new Response('{"data":null}', { headers: { 'content-type': 'application/json' } }); } });
ok(seen.at(-1).url === DEFAULT_BACKEND + '/api/docs?path=guilds/gabcdef123' && seen.at(-1).init.body === undefined && g.status === 200, 'GET /api/docs keeps its query string and has no body');

console.log(failed ? `\n${failed} FAILED` : '\nall passed');
process.exit(failed ? 1 : 0);
