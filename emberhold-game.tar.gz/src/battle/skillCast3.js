// v10.2.2 class skills with new rules:
//   summon – creatures that fight on their own AND can be killed: each has its own HP (a share of the hero's max HP),
//            monsters that touch it wear it down, non-boss monsters nearby turn on it (taunt). Some burst when they fall.
//   aegis  – a magic shield in front of the hero: it blocks the next few blows completely and answers each one with a
//            counter blast, then shatters (charges used up or time over). The block itself lives in battle/player.js.
// Same rules as every cast: damage only through C.hit (never on a replay), visuals for everyone.
import { registerCast, SK } from './skillCast.js';
import { registerFx, elOf } from './skillVfx.js';

const TAU = Math.PI * 2;
const { nearest, within, burst } = SK;
const isBoss = (e) => !!(e.type?.boss || e.boss);
const cx = (C) => (C.ghost ? C.x : C.p.x), cy = (C) => (C.ghost ? C.y : C.p.y);

registerCast('summon', (C) => {
  const { v, o } = C, n = v.count || 3, dur = (v.duration || 12) * (v.pvp ? 0.6 : 1);
  const ox = cx(C), oy = cy(C);
  const maxHp = Math.max(30, Math.round((C.ghost ? 300 : C.p.maxHp) * (v.hp || 0.2)));
  const size = o.size || 40, speed = o.speed || 300, reach = o.reach || 34;
  C.fx.add({ type: 'flash', x: ox, y: oy - 30, r: 110, el: C.el, dur: 0.4, rays: 14 });
  C.fx.add({ type: 'rune', x: ox, y: oy, r: 90, el: C.el, dur: 0.9, sides: 6 });
  C.w.sfx?.(o.sound || 'summon', { power: 1.2 });
  C.w.shake?.(4, 0.2);
  const units = [];
  for (let i = 0; i < n; i++) {
    const ang = (i / n) * TAU + 0.4, x = ox + Math.cos(ang) * 70, y = oy + Math.sin(ang) * 36;
    const u = { x, y, vx: 0, vy: 0, hp: maxHp, maxHp, cd: 0.4 + i * 0.12, alive: true, seed: i * 1.7 };
    u.fx = C.fx.add({ type: 'sym', mode: 'agent', sym: o.sym || 'wolf', el: C.el, x, y: y - size * 0.6, size, dur: dur + 0.5, flap: o.flap || 0, halo: 0.7 });
    u.bar = C.fx.add({ type: 'sbar', ref: u, el: C.el, lift: size * 1.25, dur: dur + 0.5 });
    C.fx.add({ type: 'shock', x, y, r: 60, el: C.el, dur: 0.4, band: 14 });
    units.push(u);
  }
  const fall = (u, quiet) => {
    u.alive = false; u.fx.gone = u.fx.t; u.fx.dur = u.fx.t + 0.3; u.bar.dur = u.bar.t;
    if (quiet) return;
    C.fx.add({ type: 'flash', x: u.x, y: u.y - 30, r: 60, el: C.el, dur: 0.3, rays: 8 });
    burst(C.w, u.x, u.y - 24, 16, C.el, { max: 260 });
    if (o.boom) { C.fx.add({ type: 'shock', x: u.x, y: u.y, r: o.boomR || 120, el: C.el, dur: 0.4, band: 20 }); for (const e of within(C.w, u.x, u.y, o.boomR || 120)) C.hit(e, v.power * o.boom, C.push(e, u, 260)); C.w.sfx?.('crit'); }
  };
  C.w.sk.act({ max: dur + 0.6, step: (dt, a) => {
    let left = 0;
    for (const u of units) {
      if (!u.alive) continue;
      left++;
      u.cd -= dt;
      const t = nearest(C.w, u.x, u.y, 640);
      const home = C.ghost ? { x: ox, y: oy } : C.p;
      const gx = t ? t.x - Math.sign(t.x - u.x || 1) * (t.r || 20) * 0.6 : home.x + Math.cos(a.t + u.seed) * 70, gy = t ? t.y : home.y + Math.sin(a.t + u.seed) * 30;
      const ang = Math.atan2(gy - u.y, gx - u.x), far = Math.hypot(gx - u.x, gy - u.y) > 8;
      const sp = far ? speed : 0;
      u.vx += (Math.cos(ang) * sp - u.vx) * Math.min(1, dt * 6); u.vy += (Math.sin(ang) * sp - u.vy) * Math.min(1, dt * 6);
      u.x += u.vx * dt; u.y += u.vy * dt;
      u.fx.x = u.x; u.fx.y = u.y - size * 0.6 - Math.abs(Math.sin(a.t * 9 + u.seed)) * (far ? 6 : 1); u.fx.flip = u.vx < 0;
      if (t && u.cd <= 0 && Math.hypot(t.x - u.x, t.y - u.y) < (t.r || 20) + reach) {
        u.cd = o.gap || 0.6;
        C.fx.add({ type: 'flash', x: t.x, y: t.y - 30, r: 36, el: C.el, dur: 0.18 });
        if (o.cleave) for (const e of within(C.w, t.x, t.y, o.cleave)) C.hit(e, v.power, C.push(e, u, 140));
        else C.hit(t, v.power, C.push(t, u, 120));
      }
      if (C.ghost) continue;
      // monsters wear it down by touching it, and the ones nearby (not bosses) turn on it
      for (const e of within(C.w, u.x, u.y, (o.taunt || 200))) {
        if (e.dead || e.peer || e.hp == null) continue;
        const d = Math.hypot(e.x - u.x, e.y - u.y);
        if (d < (e.r || 20) + 26) u.hp -= (e.atk || 10) * (isBoss(e) ? 1.6 : 1) * dt * 0.9;
        else if (!isBoss(e)) { const k = Math.atan2(u.y - e.y, u.x - e.x); e.vx = (e.vx || 0) + Math.cos(k) * 260 * dt; e.vy = (e.vy || 0) + Math.sin(k) * 260 * dt; }
      }
      if (u.hp <= 0) fall(u, false);
    }
    if (a.t >= dur || (!C.ghost && !left)) { for (const u of units) if (u.alive) fall(u, true); return false; }
    return true;
  } });
});

registerCast('aegis', (C) => {
  const { v, o } = C, dur = v.duration || 10, n = v.charges || 3;
  C.fx.add({ type: 'flash', x: cx(C), y: cy(C) - 50, r: 120, el: C.el, dur: 0.4, rays: 16 });
  C.fx.add({ type: 'shock', x: cx(C), y: cy(C), r: 140, el: C.el, dur: 0.45, band: 20 });
  C.w.sfx?.(o.sound || 'block', { power: 1.3 });
  const state = { n, t: dur, pow: v.power, r: v.radius || 150, el: C.el, sym: o.sym || 'shield', heal: v.heal || 0, reflect: o.reflect || 0, counter: (w, pl, at) => aegisCounter(w, pl, at) };
  if (!C.ghost) C.p.aegis = state;
  C.fx.add({ type: 'aegis', ref: C.ghost ? null : C.p, st: C.ghost ? null : state, x: cx(C), y: cy(C), a: C.a, sym: state.sym, el: C.el, dur: dur + 0.4 });
});

// called by battle/player.js when the shield takes a blow: counter blast around the hero (and the attacker)
export function aegisCounter(w, p, attacker) {
  const A = p.aegis; if (!A) return;
  const fx = w.sk?.fx;
  fx?.add({ type: 'shock', x: p.x, y: p.y - 10, r: A.r, el: A.el, dur: 0.4, band: 22 });
  fx?.add({ type: 'flash', x: p.x + Math.cos(p.facing) * 40, y: p.y - 50, r: 70, el: A.el, dur: 0.25, rays: 12 });
  burst(w, p.x, p.y - 40, 18, A.el, { max: 320 });
  const hit = new Set();
  for (const e of within(w, p.x, p.y, A.r)) { hit.add(e); try { w.playerStrike(e, A.pow, { kx: Math.cos(Math.atan2(e.y - p.y, e.x - p.x)) * 380, ky: Math.sin(Math.atan2(e.y - p.y, e.x - p.x)) * 380 }); } catch { /* a target gone mid-hit */ } }
  if (attacker && !attacker.dead && !hit.has(attacker) && attacker.hp != null) { try { w.playerStrike(attacker, A.pow, {}); } catch { /* ignore */ } }
  if (A.heal) { p.hp = Math.min(p.maxHp, p.hp + p.maxHp * A.heal); }
  w.hitStop?.(0.05); w.shake?.(5, 0.18);
}

// ------------------------------------------------------------------ visuals
// HP bar over a summoned creature
registerFx('sbar', 'air', (ctx, e) => {
  const u = e.ref; if (!u || !u.alive) return;
  const C = elOf(e.el), w = 40, x = u.x - w / 2, y = u.y - (e.lift || 50) - 8, f = Math.max(0, u.hp / u.maxHp);
  ctx.save();
  ctx.fillStyle = 'rgba(10,8,14,0.75)'; ctx.fillRect(x - 1, y - 1, w + 2, 6);
  ctx.fillStyle = f > 0.5 ? '#7fd06a' : f > 0.25 ? '#ffcf5a' : '#ff5f5f'; ctx.fillRect(x, y, w * f, 4);
  ctx.strokeStyle = C.glow; ctx.globalAlpha = 0.8; ctx.lineWidth = 1; ctx.strokeRect(x - 1, y - 1, w + 2, 6);
  ctx.restore();
});
// the magic shield floating in front of the hero; one pip per block left
registerFx('aegis', 'air', (ctx, e, time) => {
  const p = e.ref, st = e.st;
  if (p && p.aegis !== st) { if (!e.end) { e.end = e.t; } }
  const out = e.end != null ? Math.max(0, 1 - (e.t - e.end) / 0.35) : 1;
  if (out <= 0) { e.dur = e.t; return; }
  const C = elOf(e.el), a = Math.min(1, e.t / 0.25) * out;
  const x0 = p ? p.x : e.x, y0 = p ? p.y : e.y, ang = p ? p.facing : e.a || 0;
  const x = x0 + Math.cos(ang) * 46, y = y0 - 52 + Math.sin(ang) * 18 + Math.sin(time * 3) * 3;
  ctx.save(); ctx.globalAlpha = a;
  ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createRadialGradient(x, y, 4, x, y, 64); g.addColorStop(0, C.core); g.addColorStop(0.4, C.glow); g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.globalAlpha = a * (0.45 + 0.15 * Math.sin(time * 6)); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 64, 0, TAU); ctx.fill();
  ctx.globalAlpha = a; ctx.globalCompositeOperation = 'source-over';
  ctx.translate(x, y); ctx.scale(Math.cos(ang) < 0 ? -1 : 1, 1);
  // the shield: a kite shape with a glowing rim and a rune
  ctx.beginPath(); ctx.moveTo(0, -30); ctx.quadraticCurveTo(24, -28, 24, -10); ctx.quadraticCurveTo(22, 16, 0, 32); ctx.quadraticCurveTo(-22, 16, -24, -10); ctx.quadraticCurveTo(-24, -28, 0, -30); ctx.closePath();
  ctx.fillStyle = C.deep; ctx.globalAlpha = a * 0.75; ctx.fill(); ctx.globalAlpha = a;
  ctx.lineWidth = 3.4; ctx.strokeStyle = C.glow; ctx.stroke(); ctx.lineWidth = 1.4; ctx.strokeStyle = C.core; ctx.stroke();
  ctx.rotate(time * 1.4); ctx.strokeStyle = C.core; ctx.lineWidth = 1.6;
  ctx.beginPath(); for (let i = 0; i < 6; i++) { const q = (i / 6) * TAU; ctx.lineTo(Math.cos(q) * 11, Math.sin(q) * 11); } ctx.closePath(); ctx.stroke();
  ctx.rotate(-time * 1.4);
  const left = st ? st.n : 0;
  for (let i = 0; i < left; i++) { ctx.fillStyle = C.core; ctx.beginPath(); ctx.arc(-12 + i * 12, 40, 3.6, 0, TAU); ctx.fill(); }
  ctx.restore();
});
