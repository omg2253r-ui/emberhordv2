// v10.2 classes (อาชีพ): rolling, switching, class quests and the bonuses of the active class. Pure transactions
// (state in → new state out) like the other systems. The bonus part registers itself into extraBonuses.
import { cloneState } from '../core/state.js';
import { getItem } from '../data/items.js';
import { JOBS, JOB_IDS, getJob, JOB_ROLL_GOLD, JOB_ROLL_SPARKS, JOB_MAX_STARS } from '../data/jobs.js';
import { registerBonus } from './extraBonuses.js';

export const STAR_STEP = 0.1;             // +10% to every class bonus per extra star
export const MAXED_REFUND = 150000;       // a class rolled again at 5 stars turns into gold

// the counters a class quest reads
export function counterOf(state, k) {
  if (k === 'zones') return Object.values(state.zones?.cleared || {}).reduce((a, n) => a + (n | 0), 0);
  return state.stats?.[k] || 0;
}
export const ownsJob = (state, id) => !!state.job?.own?.[id];
export const activeJob = (state) => (state.job?.on && ownsJob(state, state.job.on) ? getJob(state.job.on) : null);

// progress of the current quest of a class: [have, need, stageIndex] (stage 3 = all done)
export function questProgress(state, id) {
  const j = getJob(id), c = state.job?.own?.[id];
  if (!j || !c) return [0, 0, 0];
  if (c.stage >= j.quests.length) return [1, 1, j.quests.length];
  const qd = j.quests[c.stage];
  const live = state.job.on === id && c.base != null ? Math.max(0, counterOf(state, qd.k) - c.base) : 0;
  return [Math.min(qd.n, (c.acc || 0) + live), qd.n, c.stage];
}

function freeze(next, id) {            // stop counting for a class we leave
  const j = getJob(id), c = next.job.own[id];
  if (!j || !c || c.stage >= j.quests.length) return;
  const k = j.quests[c.stage].k;
  if (c.base != null) c.acc = (c.acc || 0) + Math.max(0, counterOf(next, k) - c.base);
  c.base = null;
}
function arm(next, id) {               // start counting for the class we switch to
  const j = getJob(id), c = next.job.own[id];
  if (!j || !c || c.stage >= j.quests.length) return;
  c.base = counterOf(next, j.quests[c.stage].k);
}

export function setJob(state, id) {
  if (id && !ownsJob(state, id)) return { ok: false, reason: 'not_owned' };
  const next = cloneState(state);
  if (next.job.on) freeze(next, next.job.on);
  next.job.on = id || null;
  if (id) arm(next, id);
  return { ok: true, state: next };
}

export function claimQuest(state, id) {
  const [have, need, stage] = questProgress(state, id), j = getJob(id);
  if (!j || !ownsJob(state, id)) return { ok: false, reason: 'not_owned' };
  if (stage >= j.quests.length) return { ok: false, reason: 'done' };
  if (have < need) return { ok: false, reason: 'not_yet' };
  const next = cloneState(state), c = next.job.own[id];
  c.stage += 1; c.acc = 0; c.base = null;
  if (next.job.on === id) arm(next, id);
  return { ok: true, state: next, talent: j.talents[stage] };
}

// one roll at the class hall. pay: 'gold' | 'sparks'; rnd: () => [0,1)
export function rollJob(state, pay, rnd) {
  if (pay === 'gold' ? state.gold < JOB_ROLL_GOLD : (state.sparks || 0) < JOB_ROLL_SPARKS) return { ok: false, reason: pay === 'gold' ? 'gold' : 'sparks' };
  const next = cloneState(state);
  if (pay === 'gold') next.gold -= JOB_ROLL_GOLD; else next.sparks -= JOB_ROLL_SPARKS;
  const tot = JOB_IDS.reduce((a, id) => a + JOBS[id].w, 0);
  let r = rnd() * tot, pick = JOB_IDS[0];
  for (const id of JOB_IDS) { r -= JOBS[id].w; if (r < 0) { pick = id; break; } }
  next.job.rolls = (next.job.rolls || 0) + 1;
  const had = next.job.own[pick];
  let dup = false, maxed = false, refund = 0;
  if (had) {
    dup = true;
    if (had.stars >= JOB_MAX_STARS) { maxed = true; refund = MAXED_REFUND; next.gold += refund; }
    else had.stars += 1;
  } else next.job.own[pick] = { stars: 1, stage: 0, acc: 0, base: null };
  if (!next.job.on) { next.job.on = pick; arm(next, pick); }
  return { ok: true, state: next, job: getJob(pick), dup, maxed, refund, stars: next.job.own[pick].stars };
}

// what the active class gives right now: base + weapon (holding its weapon type) + unlocked talents, × stars
export function jobParts(state, id = state.job?.on) {
  const j = getJob(id), c = state.job?.own?.[id];
  if (!j || !c) return null;
  const wt = getItem(state.equipment?.weapon?.id)?.wtype || null;
  const parts = [j.base];
  if (j.wtype && wt === j.wtype && j.weapon) parts.push(j.weapon);
  for (let i = 0; i < Math.min(c.stage, j.talents.length); i++) parts.push(j.talents[i].b);
  const k = 1 + STAR_STEP * (Math.max(1, c.stars) - 1), out = {};
  for (const p of parts) for (const [key, v] of Object.entries(p)) out[key] = (out[key] || 0) + v * k;
  return out;
}
export function jobBonuses(state) { return state.job?.on ? jobParts(state) : null; }
registerBonus(jobBonuses);

// what the battle scenes need: the class skill to put on its button and the look
export function jobCombat(state) {
  const j = activeJob(state);
  if (!j) return null;
  const stars = state.job.own[j.id].stars;
  return { id: j.id, skill: j.skill, stars, look: j.look, el: j.el };
}
export function jobLookId(state) { return activeJob(state)?.id || null; }
