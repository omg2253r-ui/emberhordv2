// v10 Halloween item art: weapon models in the hand (each keeps its family's canvas and grip so the existing poses hold
// it), 64×64 icons for every event item, the candy currency, wing bodies and the three event pets.
// Every model here is new — none of them is a recolour of an older weapon.
import { INK } from './palette.js';

const T = `stroke="${INK}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"`;
const T1 = `stroke="${INK}" stroke-width="1.4" stroke-linejoin="round" stroke-linecap="round"`;
const svg = (w, h, body, defs = '') => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}"><defs>${defs}</defs>${body}</svg>`;
const wrap64 = (body, defs = '') => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs>${defs}</defs>${body}</svg>`;
export function shade(hex, f) {
  const n = parseInt(String(hex).slice(1), 16);
  const c = (v) => Math.max(0, Math.min(255, Math.round(v * f)));
  return '#' + [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => c(v).toString(16).padStart(2, '0')).join('');
}

// ------------------------------------------------------------------ weapon models (blade / tip pointing up)
const FAM = {
  cannon: { w: 22, h: 110, ax: 11, ay: 70 }, broom: { w: 22, h: 110, ax: 11, ay: 70 },
  pumpkinblade: { w: 20, h: 64, ax: 10, ay: 58 }, reaper: { w: 66, h: 142, ax: 51, ay: 104 },
  pistol: { w: 12, h: 38, ax: 6, ay: 29 }, candycane: { w: 18, h: 132, ax: 9, ay: 92 }, muramasa: { w: 15, h: 84, ax: 7.5, ay: 70 },
};

function cannonBody(a) {
  const b = a.body || '#e06a1a', g = a.glow || '#ffcf5a', tr = a.trim || '#2a1a10';
  return `<circle cx="11" cy="12" r="12" fill="${g}" opacity="0.3"/>
    <rect x="7" y="70" width="8" height="34" rx="3" fill="${shade(tr, 1.4)}" ${T1}/><path d="M7 80 L15 80 M7 88 L15 88 M7 96 L15 96" stroke="${shade(tr, 0.7)}" stroke-width="1"/>
    <path d="M5 20 L17 20 L16 72 L6 72 Z" fill="${tr}" ${T}/>${[30, 44, 58].map((y) => `<rect x="4" y="${y}" width="14" height="4" rx="1.5" fill="${shade(b, 0.85)}" ${T1}/>`).join('')}
    <path d="M3 64 L19 64 L18 74 L4 74 Z" fill="${shade(b, 0.7)}" ${T1}/>
    <ellipse cx="6.5" cy="12" rx="5" ry="8.5" fill="${shade(b, 0.85)}" ${T1}/><ellipse cx="15.5" cy="12" rx="5" ry="8.5" fill="${shade(b, 0.85)}" ${T1}/><ellipse cx="11" cy="12" rx="5.5" ry="9" fill="${b}" ${T1}/>
    <path d="M10 3 L13 -1 L14 3" fill="#3a6a2a" ${T1}/><circle cx="11" cy="12" r="3.4" fill="#1a0e08"/><circle cx="11" cy="12" r="2" fill="${g}"/>
    <path d="M6.5 8 L8.5 10 M15.5 8 L13.5 10" stroke="${g}" stroke-width="1.2"/>`;
}
function broomBody(a) {
  const wd = a.wood || '#3a2418', o = a.orb || '#b86aff', tr = a.trim || '#e0b45a', br = a.bristle || '#c8a050';
  return `<path d="M9.5 104 C8.6 80 9 48 10 18 L12.4 18 C13 48 13.2 80 12.5 104 Z" fill="${wd}" ${T1}/>
    <path d="M10.4 30 C11 50 10.8 74 11 100" stroke="${shade(wd, 1.5)}" stroke-width="0.8" fill="none"/>
    <path d="M4 86 L18 86 L21 108 Q11 111 1 108 Z" fill="${br}" ${T1}/>${[4, 7, 10, 13, 16].map((x) => `<path d="M${x + 1} 88 L${x - 1 + (x > 11 ? 3 : 0)} 108" stroke="${shade(br, 0.7)}" stroke-width="0.9"/>`).join('')}
    <path d="M5 86 Q11 82 17 86" stroke="${tr}" stroke-width="2.4" fill="none"/><path d="M5 86 Q11 82 17 86" stroke="${INK}" stroke-width="0.6" fill="none"/>
    <circle cx="11" cy="12" r="10" fill="${o}" opacity="0.28"/>
    <path d="M14 4 A8 8 0 1 0 14 20 A6 6 0 1 1 14 4 Z" fill="${tr}" ${T1}/><circle cx="12.6" cy="12" r="3.6" fill="${o}" ${T1}/><circle cx="11.6" cy="11" r="1.1" fill="#fff"/>`;
}
function pumpkinBladeBody(a) {
  const bl = a.blade || '#e06a1a', ed = a.edge || '#ffcf5a', g = a.glow || '#ff8a1f', v = a.vine || '#3a6a2a';
  return `<path d="M10 0 C17 10 17 30 14 45 L6 45 C3 30 3 10 10 0 Z" fill="${g}" opacity="0.32"/>
    <path d="M6 45 C4 32 4 14 10 2 C16 14 16 32 14 45 Z" fill="${bl}" ${T1}/>
    <path d="M7 40 C6 30 6 18 9.5 7" stroke="${shade(bl, 0.75)}" stroke-width="1" fill="none"/><path d="M13 40 C14 30 14 18 10.5 7" stroke="${ed}" stroke-width="1.2" fill="none"/>
    <path d="M7.5 20 L9 22.5 L6.8 22.6 Z M12.5 20 L11 22.5 L13.2 22.6 Z" fill="#1a0e08"/><path d="M7 28 Q10 32 13 28 L12 29.5 L11 28.6 L10 30 L9 28.6 L8 29.5 Z" fill="#1a0e08"/>
    <path d="M8.5 21.6 L8.5 22 M11.5 21.6 L11.5 22" stroke="${ed}" stroke-width="0.8"/>
    <path d="M10 45 C6 40 4 36 3 32 M10 45 C14 41 17 38 17 33" stroke="${v}" stroke-width="1.4" fill="none"/><circle cx="3.3" cy="31.5" r="1.4" fill="${v}"/><circle cx="17" cy="32.5" r="1.4" fill="${v}"/>
    <path d="M1 45 Q5 42 10 46 Q15 42 19 45 L18 50 Q10 48 2 50 Z" fill="${v}" ${T1}/>
    <rect x="7.5" y="49" width="5" height="10" rx="1.5" fill="#2a1a10" ${T1}/><circle cx="10" cy="61" r="2.8" fill="${bl}" ${T1}/>`;
}
function reaperBody(a) {
  const bl = a.blade || '#1a1a24', sh = a.shaft || '#2a1a14', g = a.glow || '#b8f0ff', ed = a.edge || '#e8f4ff';
  return `<path d="M48.5 140 L48.2 20 L53.8 20 L53.5 140 Z" fill="${sh}" ${T}/>${[40, 64, 88, 116].map((y) => `<path d="M48 ${y} L54 ${y + 3}" stroke="${shade(sh, 1.8)}" stroke-width="1.2"/>`).join('')}
    <path d="M47 22 Q51 14 55 22 L55 30 L47 30 Z" fill="${shade(bl, 1.6)}" ${T1}/><circle cx="51" cy="25" r="2.4" fill="${g}"/>
    <path d="M50 26 C34 8 12 6 2 24 C18 16 32 20 46 34 Z" fill="${g}" opacity="0.28"/>
    <path d="M51 24 C36 6 14 4 3 22 C16 18 30 22 47 34 Z" fill="${bl}" ${T}/>
    <path d="M6 21 C18 14 32 16 45 30" stroke="${ed}" stroke-width="1.6" fill="none"/><path d="M20 15 L22 20 M30 15 L31 21" stroke="${g}" stroke-width="1" opacity="0.7"/>
    <circle cx="51" cy="104" r="3.4" fill="${g}" opacity="0.6"/><path d="M47 132 L55 132 L54 141 L48 141 Z" fill="${shade(bl, 1.4)}" ${T1}/>`;
}
function pistolBody(a) {
  const b = a.body || '#2a1a24', g = a.glow || '#ff8a1f', tr = a.trim || '#e0b45a';
  return `<circle cx="6" cy="4" r="5" fill="${g}" opacity="0.35"/>
    <rect x="3.5" y="2" width="5" height="17" rx="1.5" fill="${b}" ${T1}/><path d="M3.5 6 L8.5 6 M3.5 10 L8.5 10" stroke="${tr}" stroke-width="0.9"/>
    <ellipse cx="6" cy="3" rx="3.6" ry="2.4" fill="#e06a1a" ${T1}/><circle cx="6" cy="3" r="1" fill="#1a0e08"/>
    <path d="M1.5 17 L10.5 17 L10 24 L2 24 Z" fill="${shade(b, 1.4)}" ${T1}/><circle cx="6" cy="20.5" r="1.6" fill="${g}"/>
    <path d="M3 24 L9 24 L8.5 36 L3.5 36 Z" fill="#4a2a18" ${T1}/><path d="M3.5 27 L8.5 27 M3.5 30 L8.5 30 M3.5 33 L8.5 33" stroke="${tr}" stroke-width="0.7"/>`;
}
function candycaneBody(a) {
  const s = a.shaft || '#ffffff', tr = a.trim || '#e0303a', g = a.glow || '#ffd8e8';
  let stripes = '';
  for (let y = 24; y < 128; y += 7) stripes += `<path d="M6 ${y} L12 ${y + 4}" stroke="${tr}" stroke-width="2.6"/>`;
  return `<path d="M6 128 L6 22 L12 22 L12 128 Z" fill="${s}" ${T1}/>${stripes}<path d="M6 128 L6 22 L12 22 L12 128 Z" fill="none" ${T1}/>
    <path d="M9 22 C9 8 17 6 17 14 C17 18 14 19 13 17" stroke="${INK}" stroke-width="7" fill="none" stroke-linecap="round"/>
    <path d="M9 22 C9 8 17 6 17 14 C17 18 14 19 13 17" stroke="${s}" stroke-width="4.6" fill="none" stroke-linecap="round"/>
    <path d="M9 18 C9.5 11 13 9 15.5 10.5" stroke="${tr}" stroke-width="2" fill="none" stroke-dasharray="3 3"/>
    <path d="M9 2 L12.5 18 L5.5 18 Z" fill="${g}" ${T1}/><path d="M9 4 L9 16" stroke="#ffffff" stroke-width="1"/>
    <circle cx="9" cy="128" r="3.4" fill="${tr}" ${T1}/>`;
}
function muramasaBody(a) {
  const bl = a.blade || '#f6f4f2', ed = a.edge || '#ffffff', st = a.stain || '#7a1a3a', g = a.glow || '#ff6a8a';
  return `<path d="M7 1 C12 20 11 42 9 61 L5 61 C6 42 7 20 7 1 Z" fill="${g}" opacity="0.38"/>
    <path d="M6 61 C6 40 7 20 9 3 C11 6 11.5 9 11 12 C10 28 9.5 44 9 61 Z" fill="${bl}" ${T1}/>
    <path d="M9.6 8 C9 26 8.6 42 8.4 59" stroke="${ed}" stroke-width="1.3" fill="none"/>
    <path d="M7.2 20 C8.4 22 7 26 8.6 29 C7.4 31 8.6 35 7.6 38 L6.6 38 C6.8 30 7 24 7.2 20 Z" fill="${st}" opacity="0.85"/>
    <path d="M8.2 44 C9.4 46 7.6 50 9 54 L8 56 C7.4 52 7.8 48 8.2 44 Z" fill="${st}" opacity="0.7"/><circle cx="9.6" cy="33" r="0.9" fill="${st}"/><circle cx="7.4" cy="13" r="0.7" fill="${st}"/>
    <path d="M1.6 61 Q7.5 58 13.4 61 Q7.5 65 1.6 61 Z" fill="${a.guard || '#1a1014'}" ${T1}/><circle cx="7.5" cy="61.5" r="1.2" fill="${g}"/>
    <rect x="5" y="63.5" width="5" height="17" rx="1.6" fill="${a.grip || '#3a0a14'}" ${T1}/>
    <path d="M5 66 L10 69 M10 66 L5 69 M5 71 L10 74 M10 71 L5 74 M5 76 L10 79 M10 76 L5 79" stroke="${a.wrap || '#e8e0d8'}" stroke-width="1.2"/>
    <rect x="4.6" y="80" width="5.8" height="2.6" rx="1" fill="${g}" ${T1}/>`;
}
const BODY = { cannon: cannonBody, broom: broomBody, pumpkinblade: pumpkinBladeBody, reaper: reaperBody, pistol: pistolBody, candycane: candycaneBody, muramasa: muramasaBody };

export function hwWeaponSprite(a) {
  const f = FAM[a.form] || FAM.pumpkinblade, body = (BODY[a.form] || pumpkinBladeBody)(a);
  const meta = a.form === 'cannon' || a.form === 'broom' ? { tip: a.glow || a.orb, tipAt: 57 } : undefined;
  return { w: f.w, h: f.h, ax: f.ax, ay: f.ay, svg: svg(f.w, f.h, body), ...(meta ? { meta } : {}) };
}
export function hwWeaponIcon(a) {
  const f = FAM[a.form] || FAM.pumpkinblade;
  const body = (BODY[a.form] || pumpkinBladeBody)(a);
  if (a.form === 'pistol') {
    const off = a.off ? pistolBody({ ...a, ...a.off }) : body;
    return `<g transform="translate(23 34) rotate(-28) scale(1.3) translate(-6 -19)">${off}</g><g transform="translate(41 34) rotate(28) scale(1.3) translate(-6 -19)">${body}</g>`;
  }
  const scale = Math.min(52 / f.h * 1.15, 52 / f.w);
  return `<g transform="translate(32 33) rotate(40) scale(${scale.toFixed(3)}) translate(${-f.w / 2} ${-f.h / 2})">${body}</g>`;
}

// ------------------------------------------------------------------ icons for armour, charms, consumables
function jackPlateIcon(a) {
  return `<path d="M14 18 Q32 10 50 18 L48 52 Q32 58 16 52 Z" fill="${a.main}" ${T}/>
    ${[22, 32, 42].map((x) => `<path d="M${x} 14 Q${x + (x - 32) * 0.2} 34 ${x} 55" stroke="${shade(a.main, 0.7)}" stroke-width="2" fill="none"/>`).join('')}
    <path d="M22 28 L27 24 L28 31 Z M42 28 L37 24 L36 31 Z" fill="#1a0e08"/><path d="M20 40 L24 44 L28 40 L32 44 L36 40 L40 44 L44 40 L42 47 L22 47 Z" fill="#1a0e08"/>
    <path d="M23 29 L26 27 M41 29 L38 27" stroke="${a.accent}" stroke-width="1.4"/><path d="M22 44 L42 44" stroke="${a.accent}" stroke-width="1.2" opacity="0.7"/>
    <ellipse cx="11" cy="20" rx="7" ry="6" fill="${shade(a.main, 0.9)}" ${T1}/><ellipse cx="53" cy="20" rx="7" ry="6" fill="${shade(a.main, 0.9)}" ${T1}/>
    <path d="M10 14 L12 10 M52 14 L54 10" stroke="#3a6a2a" stroke-width="2.4"/>`;
}
function witchRobeIcon(a) {
  return `<path d="M20 22 L44 22 L54 58 Q32 62 10 58 Z" fill="${a.main}" ${T}/>
    <path d="M10 58 L14 52 L18 58 L22 52 L26 58 L30 52 L34 58 L38 52 L42 58 L46 52 L50 58 L54 58" stroke="${a.trim}" stroke-width="2" fill="none"/>
    <path d="M22 26 L27 40 M42 26 L37 40" stroke="${a.trim}" stroke-width="1.4" stroke-dasharray="2 2"/>
    <path d="M28 34 L36 34 L32 40 L36 46 L28 46 L32 40 Z" fill="${a.accent}" ${T1}/>
    <path d="M14 22 Q32 16 50 22 L46 26 Q32 22 18 26 Z" fill="${shade(a.main, 0.7)}" ${T1}/>
    <path d="M18 20 L32 2 L46 20 Z" fill="${shade(a.main, 0.85)}" ${T}/><path d="M24 14 L40 14" stroke="${a.trim}" stroke-width="2.4"/><circle cx="34" cy="6" r="2" fill="${a.accent}"/>`;
}
function reaperShroudIcon(a) {
  return `<path d="M32 6 C46 6 52 20 50 34 L56 58 L48 54 L44 60 L38 54 L32 60 L26 54 L20 60 L16 54 L8 58 L14 34 C12 20 18 6 32 6 Z" fill="${a.main}" ${T}/>
    <path d="M22 26 C22 16 42 16 42 26 C42 36 38 40 32 40 C26 40 22 36 22 26 Z" fill="#05030a" ${T1}/>
    <circle cx="27.5" cy="27" r="2.6" fill="${a.accent}"/><circle cx="36.5" cy="27" r="2.6" fill="${a.accent}"/>
    <path d="M18 44 C24 48 40 48 46 44" stroke="${a.trim}" stroke-width="1.6" fill="none"/><path d="M30 6 C24 10 20 18 20 26" stroke="${shade(a.main, 2.2)}" stroke-width="1.4" fill="none" opacity="0.6"/>`;
}
function candyHeartIcon(a) {
  return `<circle cx="32" cy="34" r="24" fill="${a.trim}" opacity="0.3"/>
    <path d="M32 54 C14 42 8 30 14 20 C20 12 28 14 32 22 C36 14 44 12 50 20 C56 30 50 42 32 54 Z" fill="${a.main}" ${T}/>
    <path d="M20 22 C18 26 18 30 20 34" stroke="#fff" stroke-width="3" fill="none" opacity="0.6" stroke-linecap="round"/>
    <path d="M26 30 L38 42 M32 26 L44 38 M22 34 L32 44" stroke="${a.trim}" stroke-width="2.4" opacity="0.8"/>
    <path d="M8 26 L14 22 L14 30 Z M56 26 L50 22 L50 30 Z" fill="${a.trim}" ${T1}/>`;
}
function spiteMaskIcon(a) {
  return `<path d="M32 4 C50 6 56 22 54 36 C52 50 42 58 32 60 C22 58 12 50 10 36 C8 22 14 6 32 4 Z" fill="${a.main}" ${T}/>
    <path d="M17 28 Q24 20 30 28 Q24 33 17 28 Z M34 28 Q40 20 47 28 Q40 33 34 28 Z" fill="#0b0810"/>
    <circle cx="23.5" cy="27" r="1.8" fill="#ff5a9a"/><circle cx="40.5" cy="27" r="1.8" fill="#ff5a9a"/>
    <path d="M20 46 Q32 38 44 46" stroke="${INK}" stroke-width="2.4" fill="none"/><path d="M32 6 L32 16" stroke="${a.trim}" stroke-width="2"/>
    <path d="M14 40 Q10 46 14 52 M50 40 Q54 46 50 52" stroke="${a.trim}" stroke-width="2" fill="none"/>
    <text x="32" y="63" text-anchor="middle" font-size="9" font-weight="900" fill="${a.trim}">???</text>`;
}
function crossIcon(a) {
  return `<circle cx="32" cy="32" r="26" fill="${a.glow}" opacity="0.32"/>
    <path d="M27 6 L37 6 L37 20 L52 20 L52 30 L37 30 L37 58 L27 58 L27 30 L12 30 L12 20 L27 20 Z" fill="${a.main}" ${T}/>
    <path d="M29 9 L29 55 M15 23 L49 23" stroke="#fff" stroke-width="1.4" opacity="0.6"/><circle cx="32" cy="25" r="4.4" fill="${a.trim}" ${T1}/>`;
}
export function candyIconSvg() {
  return wrap64(`<path d="M8 22 L20 26 L18 38 L6 42 Z" fill="#ffd8e8" ${T1}/><path d="M56 22 L44 26 L46 38 L58 42 Z" fill="#ffd8e8" ${T1}/>
    <ellipse cx="32" cy="32" rx="15" ry="13" fill="#e0303a" ${T}/><path d="M22 26 Q32 34 42 26 M20 34 Q32 42 44 34" stroke="#ffffff" stroke-width="3" fill="none"/>
    <path d="M24 24 C26 22 28 21 30 21" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity="0.8"/>`);
}
// herbs (สมุนไพร): eight silhouettes × colour → a hundred-odd different icons
const HERB_SHAPES = {
  leaf: (c, d) => `<path d="M32 56 C14 46 12 22 32 8 C52 22 50 46 32 56 Z" fill="${c}" ${T}/><path d="M32 54 L32 14 M32 30 L22 22 M32 38 L42 30" stroke="${d}" stroke-width="2" fill="none"/>`,
  root: (c, d) => `<path d="M26 10 C38 10 42 20 38 34 C36 42 40 50 34 58 C32 50 28 52 26 44 C20 32 16 14 26 10 Z" fill="${c}" ${T}/><path d="M28 18 L34 20 M26 28 L32 30 M30 40 L34 42" stroke="${d}" stroke-width="2"/><path d="M28 10 C24 4 30 2 32 6 C34 0 40 4 36 10" fill="#5a9a3a" ${T1}/>`,
  flower: (c, d) => `${[0, 72, 144, 216, 288].map((r) => `<ellipse cx="32" cy="18" rx="7" ry="11" fill="${c}" ${T1} transform="rotate(${r} 32 30)"/>`).join('')}<circle cx="32" cy="30" r="6" fill="${d}" ${T1}/><path d="M32 40 L32 60" stroke="#3a6a2a" stroke-width="3"/>`,
  mushroom: (c, d) => `<path d="M10 32 C10 14 54 14 54 32 Z" fill="${c}" ${T}/><circle cx="22" cy="24" r="3" fill="#fff"/><circle cx="36" cy="20" r="2.4" fill="#fff"/><circle cx="44" cy="28" r="2" fill="#fff"/><path d="M26 32 L24 56 L40 56 L38 32 Z" fill="#efe4cc" ${T}/><path d="M28 38 L36 38" stroke="${d}" stroke-width="1.4"/>`,
  berry: (c, d) => `<path d="M32 8 L32 22 M32 14 C26 8 18 10 18 10 C22 16 28 16 32 14" stroke="#3a6a2a" stroke-width="2.4" fill="#5a9a3a"/>${[[22, 34], [42, 34], [32, 46], [26, 24], [38, 24]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="9" fill="${c}" ${T1}/><circle cx="${x - 3}" cy="${y - 3}" r="2.2" fill="#fff" opacity="0.7"/>`).join('')}<circle cx="32" cy="34" r="2" fill="${d}"/>`,
  bark: (c, d) => `<path d="M14 10 L50 14 L46 56 L18 52 Z" fill="${c}" ${T}/><path d="M22 14 C24 26 20 38 24 52 M32 13 C30 26 34 40 30 54 M42 15 C44 28 40 40 42 54" stroke="${d}" stroke-width="2.4" fill="none"/>`,
  moss: (c, d) => `<path d="M8 46 C10 30 20 24 26 30 C28 18 40 16 44 28 C52 24 58 34 54 46 Z" fill="${c}" ${T}/>${[[18, 38], [30, 30], [42, 36], [26, 42], [46, 42]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="3" fill="${d}"/>`).join('')}<path d="M8 46 L56 46" ${T}/>`,
  seed: (c, d) => `${[[20, 22, -20], [40, 20, 20], [30, 40, 0], [18, 44, -30], [44, 42, 30]].map(([x, y, r]) => `<ellipse cx="${x}" cy="${y}" rx="7" ry="11" fill="${c}" ${T1} transform="rotate(${r} ${x} ${y})"/><path d="M${x} ${y - 6} L${x} ${y + 6}" stroke="${d}" stroke-width="1.4" transform="rotate(${r} ${x} ${y})"/>`).join('')}`,
};
export function herbIconSvg(a) {
  const f = HERB_SHAPES[a.shape] || HERB_SHAPES.leaf;
  return wrap64(`${a.glow ? `<circle cx="32" cy="32" r="28" fill="${a.glow}" opacity="0.25"/>` : ''}${f(a.main, a.dark || shade(a.main, 0.6))}`);
}
// brewed potions: six bottle shapes, liquid colour, an emblem for the stat
const BOTTLES = {
  round: (c) => `<rect x="26" y="6" width="12" height="8" rx="2" fill="#a87848" ${T1}/><path d="M27 14 L27 22 C16 26 12 34 14 44 C16 54 24 58 32 58 C40 58 48 54 50 44 C52 34 48 26 37 22 L37 14 Z" fill="#d9e4e6" ${T}/><path d="M15 40 C20 36 44 36 49 40 C48 52 40 56 32 56 C24 56 16 52 15 40 Z" fill="${c}"/>`,
  vial: (c) => `<rect x="25" y="4" width="14" height="7" rx="2" fill="#7a5a3a" ${T1}/><path d="M24 11 L40 11 L40 52 Q32 62 24 52 Z" fill="#d9e4e6" ${T}/><path d="M24 28 L40 28 L40 52 Q32 62 24 52 Z" fill="${c}"/>`,
  skull: (c) => `<rect x="27" y="4" width="10" height="8" rx="2" fill="#3a2a20" ${T1}/><path d="M28 12 L36 12 L36 16 C48 18 52 30 48 40 L44 44 L44 54 L20 54 L20 44 L16 40 C12 30 16 18 28 16 Z" fill="#d9e4e6" ${T}/><path d="M17 34 L47 34 L44 44 L44 54 L20 54 L20 44 Z" fill="${c}"/><circle cx="26" cy="28" r="4" fill="#1a0e08"/><circle cx="38" cy="28" r="4" fill="#1a0e08"/>`,
  heart: (c) => `<rect x="27" y="4" width="10" height="8" rx="2" fill="#a87848" ${T1}/><path d="M32 58 C14 46 10 32 16 22 C20 16 28 16 30 14 L34 14 C36 16 44 16 48 22 C54 32 50 46 32 58 Z" fill="#d9e4e6" ${T}/><path d="M14 34 L50 34 C48 44 42 50 32 58 C22 50 16 44 14 34 Z" fill="${c}"/>`,
  flask: (c) => `<rect x="26" y="4" width="12" height="8" rx="2" fill="#a87848" ${T1}/><path d="M28 12 L36 12 L36 26 L52 54 Q52 58 48 58 L16 58 Q12 58 12 54 L28 26 Z" fill="#d9e4e6" ${T}/><path d="M20 42 L44 42 L52 54 Q52 58 48 58 L16 58 Q12 58 12 54 Z" fill="${c}"/>`,
  pumpkin: (c) => `<rect x="28" y="4" width="8" height="9" rx="2" fill="#3a6a2a" ${T1}/><ellipse cx="22" cy="38" rx="11" ry="18" fill="#d9e4e6" ${T1}/><ellipse cx="42" cy="38" rx="11" ry="18" fill="#d9e4e6" ${T1}/><ellipse cx="32" cy="38" rx="11" ry="19" fill="#d9e4e6" ${T}/><path d="M14 40 C20 46 44 46 50 40 C50 50 42 56 32 57 C22 56 14 50 14 40 Z" fill="${c}"/>`,
};
export function brewIconSvg(a) {
  const b = BOTTLES[a.bottle] || BOTTLES.round;
  return wrap64(`${a.glow ? `<circle cx="32" cy="36" r="26" fill="${a.glow}" opacity="0.22"/>` : ''}${b(a.main)}<circle cx="24" cy="32" r="2.6" fill="#fff" opacity="0.7"/>${a.mark ? `<text x="32" y="50" text-anchor="middle" font-size="13" font-weight="900" fill="#fff" stroke="${INK}" stroke-width="2.5" paint-order="stroke">${a.mark}</text>` : ''}`);
}

export function hwItemIconSvg(def) {
  const a = def.art || {};
  if (def.category === 'weapon') return wrap64(hwWeaponIcon(a));
  if (a.kind === 'herb') return herbIconSvg(a);
  if (a.kind === 'brew') return brewIconSvg(a);
  switch (def.id) {
    case 'a_hw_jack_plate': return wrap64(jackPlateIcon(a));
    case 'a_hw_witch_robe': return wrap64(witchRobeIcon(a));
    case 'a_hw_reaper_shroud': return wrap64(reaperShroudIcon(a));
    default: break;
  }
  if (a.kind === 'candyheart') return wrap64(candyHeartIcon(a));
  if (a.kind === 'spitemask') return wrap64(spiteMaskIcon(a));
  if (a.kind === 'cross') return wrap64(crossIcon(a));
  return null;
}

// ------------------------------------------------------------------ wings (art/wings.js canvas: 96×92, root at 88,84)
export function hwWingBody(kind, main, trim, glow) {
  const AX = 88, AY = 84;
  if (kind === 'hwbat') {
    return `<path d="M${AX} ${AY} C70 50 40 20 6 14 C14 26 12 34 6 40 C18 40 22 46 18 56 C30 52 36 58 34 70 C46 64 56 70 58 82 C68 76 78 80 ${AX} ${AY} Z" fill="url(#g)" stroke="${INK}" stroke-width="2.2" stroke-linejoin="round"/>
      <path d="M${AX} ${AY} L8 16 M${AX} ${AY} L20 54 M${AX} ${AY} L36 68 M${AX} ${AY} L58 80" stroke="${shade(main, 0.6)}" stroke-width="2" fill="none"/>
      <path d="M${AX - 2} ${AY - 2} L10 18" stroke="${trim}" stroke-width="1.4" opacity="0.8"/><circle cx="8" cy="15" r="2.6" fill="${glow}"/>`;
  }
  if (kind === 'hwlantern') {
    return `<path d="M${AX} ${AY} C66 56 50 26 22 10 C30 26 18 36 12 44 C26 46 26 58 20 66 C38 64 50 72 54 84 C66 78 78 82 ${AX} ${AY} Z" fill="${main}" opacity="0.75" stroke="${INK}" stroke-width="1.8" stroke-linejoin="round"/>
      <path d="M${AX} ${AY} C66 60 52 40 26 18 M${AX} ${AY} C64 70 46 64 24 60" stroke="#ffffff" stroke-width="2" fill="none" opacity="0.7"/>
      <path d="M22 10 L22 18" stroke="${INK}" stroke-width="1.4"/><ellipse cx="22" cy="24" rx="8" ry="7" fill="${trim}" stroke="${INK}" stroke-width="1.6"/>
      <path d="M18 23 L20 21 L20 24 Z M26 23 L24 21 L24 24 Z M18 27 Q22 30 26 27" stroke="#1a0e08" stroke-width="1" fill="#1a0e08"/><circle cx="22" cy="24" r="12" fill="${glow}" opacity="0.3"/>`;
  }
  // six bone wings: three bone fingers fanned, joints glowing
  let out = '';
  for (let i = 0; i < 3; i++) {
    const a = -0.5 - i * 0.48, len = 70 - i * 6;
    const ex = AX + Math.cos(Math.PI + a) * len, ey = AY + Math.sin(Math.PI + a) * len;
    const mx = AX + Math.cos(Math.PI + a) * len * 0.5, my = AY + Math.sin(Math.PI + a) * len * 0.5;
    out += `<path d="M${AX} ${AY} L${mx.toFixed(1)} ${my.toFixed(1)} L${ex.toFixed(1)} ${ey.toFixed(1)}" stroke="${INK}" stroke-width="7" fill="none" stroke-linecap="round"/>`;
    out += `<path d="M${AX} ${AY} L${mx.toFixed(1)} ${my.toFixed(1)} L${ex.toFixed(1)} ${ey.toFixed(1)}" stroke="${main}" stroke-width="4" fill="none" stroke-linecap="round"/>`;
    out += `<circle cx="${mx.toFixed(1)}" cy="${my.toFixed(1)}" r="3.6" fill="${glow}" stroke="${INK}" stroke-width="1.2"/><circle cx="${ex.toFixed(1)}" cy="${ey.toFixed(1)}" r="2.6" fill="${trim}"/>`;
    for (let k = 1; k <= 3; k++) { const fx = mx + (ex - mx) * k / 4, fy = my + (ey - my) * k / 4; out += `<path d="M${fx.toFixed(1)} ${fy.toFixed(1)} l${(-4 - k).toFixed(1)} ${(8 + k * 2).toFixed(1)}" stroke="${main}" stroke-width="2" opacity="0.8"/>`; }
  }
  return out;
}

// ------------------------------------------------------------------ the three event pets (new body plans)
const SP = (W, H, body, ay = H - 3) => ({ w: W, h: H, ax: W / 2, ay, svg: svg(W, H, body) });
export function petWitchCat() {
  return SP(58, 60, `<path d="M8 52 C4 40 10 34 18 36 C16 28 22 22 30 24 C40 22 48 30 46 40 C52 42 54 50 50 54 Z" fill="#1a1424" ${T}/>
    <path d="M46 44 C56 40 58 30 52 26" stroke="${INK}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M46 44 C56 40 58 30 52 26" stroke="#2a2034" stroke-width="3" fill="none" stroke-linecap="round"/>
    <path d="M20 28 L18 16 L26 24 Z M38 26 L42 14 L34 22 Z" fill="#1a1424" ${T1}/>
    <path d="M14 22 L30 2 L40 20 Z" fill="#4a2a6a" ${T1}/><path d="M12 21 Q28 16 44 21" stroke="${INK}" stroke-width="3" fill="none"/><path d="M20 15 L36 15" stroke="#e0b45a" stroke-width="2"/>
    <ellipse cx="24" cy="33" rx="3.4" ry="4" fill="#ffd84a"/><ellipse cx="35" cy="33" rx="3.4" ry="4" fill="#ffd84a"/><path d="M24 31 L24 35 M35 31 L35 35" stroke="#1a0e08" stroke-width="1.6"/>
    <path d="M28 39 L30 41 L32 39" stroke="#ff9ac8" stroke-width="1.6" fill="none"/>`);
}
export function petPumpkinHopper() {
  return SP(54, 54, `<ellipse cx="17" cy="34" rx="11" ry="15" fill="#c8641a" ${T1}/><ellipse cx="37" cy="34" rx="11" ry="15" fill="#c8641a" ${T1}/><ellipse cx="27" cy="34" rx="12" ry="17" fill="#e8801f" ${T}/>
    <path d="M25 17 C24 10 28 6 32 8" stroke="#3a6a2a" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M30 12 C36 8 42 10 40 14 C36 16 32 14 30 12 Z" fill="#5a9a3a" ${T1}/>
    <path d="M18 30 L23 26 L24 32 Z M36 30 L31 26 L30 32 Z" fill="#ffd84a" ${T1}/><path d="M17 40 L21 44 L25 40 L29 44 L33 40 L37 44 L35 47 L19 47 Z" fill="#ffd84a" ${T1}/>
    <path d="M12 50 L10 53 M42 50 L44 53" stroke="#3a6a2a" stroke-width="3" stroke-linecap="round"/>`);
}
export function petLanternGhost() {
  return SP(50, 62, `<circle cx="25" cy="26" r="22" fill="#bfe8ff" opacity="0.22"/>
    <path d="M10 46 C6 30 10 10 25 8 C40 10 44 30 40 46 L36 42 L32 48 L28 42 L24 48 L20 42 L16 48 L14 42 Z" fill="#eaf6ff" ${T}/>
    <ellipse cx="19" cy="24" rx="3" ry="4.4" fill="#1a2a3a"/><ellipse cx="31" cy="24" rx="3" ry="4.4" fill="#1a2a3a"/><ellipse cx="25" cy="33" rx="3" ry="2.2" fill="#1a2a3a"/>
    <path d="M40 34 L46 40" stroke="${INK}" stroke-width="2"/><path d="M42 40 L50 40 L50 52 L42 52 Z" fill="#ff8a1f" opacity="0.85" ${T1}/><circle cx="46" cy="46" r="7" fill="#ffcf5a" opacity="0.4"/><path d="M42 44 L50 44 M42 48 L50 48" stroke="#3a2010" stroke-width="1.2"/>`, 52);
}
