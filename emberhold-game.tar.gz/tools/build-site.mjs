// Netlify build: copy only what the browser needs into dist/ (the game is plain ES modules, no bundling).
import { cp, rm, mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const OUT = join(ROOT, 'dist');
await rm(OUT, { recursive: true, force: true });
await mkdir(OUT, { recursive: true });
for (const p of ['index.html', 'css', 'src', 'app']) await cp(join(ROOT, p), join(OUT, p), { recursive: true });
// mark the page as having the online hub (/api/hub, /api/docs), so the game connects instead of staying offline
const page = join(OUT, 'index.html');
await writeFile(page, (await readFile(page, 'utf8')).replace('<head>', '<head>\n  <meta name="emberhold-hub" content="/api">'));
// Cloudflare Pages (v8): the online code runs as dist/_worker.js (advanced mode); Netlify never gets this file
if (process.env.CF_PAGES) await cp(join(ROOT, 'cloudflare/_worker.js'), join(OUT, '_worker.js'));
console.log('Emberhold site built into dist/');
