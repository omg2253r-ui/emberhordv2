// Checks the Netlify → Cloudflare player import end to end, offline. Run: node tools/test-migrate.mjs
// "Old Netlify" = the real cloud handler on an in-memory store; "Cloudflare" = the real Worker on a fake D1.
import { register } from 'node:module';
register('data:text/javascript,' + encodeURIComponent(`
  export async function resolve(s, c, next) { return s === 'cloudflare:workers' ? { url: 'data:text/javascript,export class DurableObject {}', shortCircuit: true } : next(s, c); }
`), import.meta.url);
const { default: worker } = await import('../cloudflare/worker.mjs');
const { handleCloud } = await import('../netlify/lib/cloud.mjs');
const { memoryKV } = await import('../netlify/lib/hub.mjs');
const { createNewState } = await import('../src/core/state.js');
const { exportCode } = await import('../src/persistence/transfer.js');
const { collectRecords } = await import('./migrate-export.mjs');
const { importRecords } = await import('./migrate-import.mjs');
const { fakeD1 } = await import('./fake-d1.mjs');

let failed = 0;
const ok = (c, m) => { console.log((c ? 'ok   ' : 'FAIL ') + m); if (!c) failed++; };
const KEY = 'k'.repeat(32);

const hero = (name, level, extra = {}, t = 1000) => { const s = createNewState(1); s.story.name = name; s.player.level = level; s.updatedAt = t; Object.assign(s, extra); return exportCode(s); };
const post = (kv, body) => handleCloud(new Request('https://x.test/api/cloud', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }), kv, 5000, {}).then((r) => r.json());

// ---- the OLD site: three farmers + one with no save + one whose name is also used on Cloudflare
const oldKV = memoryKV();
await post(oldKV, { op: 'register', name: 'farmerA', pass: 'passA123', save: hero('ชาวไร่เอ', 70, { attrs: { str: 100, vit: 80, dex: 0, agi: 0, int: 0 }, gold: 5_000_000 }) });
await post(oldKV, { op: 'register', name: 'climberB', pass: 'passB123', save: hero('นักไต่บี', 45) });
await post(oldKV, { op: 'register', name: 'emptyC', pass: 'passC123' });
await post(oldKV, { op: 'register', name: 'dupname', pass: 'oldpass1', save: hero('ซ้ำเก่า', 20) });
const sessionsOnOld = [...oldKV.map.keys()].filter((k) => k.startsWith('sess/')).length;

// ---- Cloudflare already has its own players (one with the same name as an old one)
const env = { DB: fakeD1(), ASSETS: { fetch: async () => new Response('asset') } };
const cf = async (path, body, headers = {}) => { const r = await worker.fetch(new Request('https://x.test' + path, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body) }), env); const t = await r.text(); let d; try { d = JSON.parse(t); } catch { d = t; } return { status: r.status, data: d }; };
await cf('/api/cloud', { op: 'register', name: 'cfplayer', pass: 'cfpass123', save: hero('คนคลาวด์', 33) });
await cf('/api/cloud', { op: 'register', name: 'dupname', pass: 'newpass1', save: hero('ซ้ำใหม่', 25) });

// ---- export (what tools/migrate-export.mjs does against Netlify Blobs)
const exp = await collectRecords(oldKV);
ok(exp.records.length === 4 && exp.records.filter((r) => r.save).length === 3, 'export reads 4 accounts, 3 of them with saves');
ok(!JSON.stringify(exp).includes('sess/') && exp.records.every((r) => !('token' in r)), 'sessions are not exported');

// ---- the route is closed without the secret
let r = await cf('/api/migrate', { records: [] });
ok(r.status === 404, 'no MIGRATE_KEY on the Worker → route answers 404 (switched off)');
env.MIGRATE_KEY = KEY;
r = await cf('/api/migrate', { records: [] }, { 'x-migrate-key': 'wrong'.repeat(8) });
ok(r.status === 401, 'wrong key → 401');
r = await cf('/api/migrate', { records: [] });
ok(r.status === 401, 'missing key → 401');

const send = (dry) => importRecords(exp.records, (b) => cf('/api/migrate', b, { 'x-migrate-key': KEY }).then((x) => x.data), { dry, batch: 3 });

// ---- dry run writes nothing
let sum = await send(true);
ok(sum.counts.imported === 3 && sum.counts.name_taken === 1, `dry run reports 3 to import, 1 name clash (${JSON.stringify(sum.counts)})`);
r = await cf('/api/cloud', { op: 'login', name: 'farmerA', pass: 'passA123' });
ok(r.status === 401, 'dry run changed nothing (farmerA still cannot log in on Cloudflare)');

// ---- real import
sum = await send(false);
ok(sum.counts.imported === 3 && sum.counts.name_taken === 1 && sum.taken[0] === 'dupname', 'import: 3 copied, "dupname" skipped and reported');
r = await cf('/api/cloud', { op: 'login', name: 'farmerA', pass: 'passA123' });
ok(r.status === 200 && r.data.save === exp.records[0].save.save, 'farmerA logs in on Cloudflare with the SAME password and gets the old save');
r = await cf('/api/cloud', { op: 'login', name: 'emptyC', pass: 'passC123' });
ok(r.status === 200 && r.data.save === null, 'account with no save is imported too');
r = await cf('/api/cloud', { op: 'login', name: 'dupname', pass: 'newpass1' });
ok(r.status === 200, 'the Cloudflare "dupname" is untouched');
r = await cf('/api/cloud', { op: 'login', name: 'dupname', pass: 'oldpass1' });
ok(r.status === 401, 'the old "dupname" password does NOT work on Cloudflare (no overwrite)');

// ---- rankings now show the imported players, scored by today's rules
const tokenOf = (await cf('/api/cloud', { op: 'login', name: 'climberB', pass: 'passB123' })).data.token;
const lv = (await cf('/api/cloud', { op: 'ranks', board: 'level', token: tokenOf })).data;
const names = lv.entries.map((e) => e.a);
ok(names.join() === 'farmerA,climberB,cfplayer,dupname', `level board: ${names.join(' > ')} (old players + Cloudflare players together)`);
ok(lv.me === 2, 'climberB sees own rank (2)');
const pw = (await cf('/api/cloud', { op: 'ranks', board: 'power' })).data.entries;
ok(pw[0].a === 'farmerA' && pw[0].v > pw[1].v, 'power board: farmerA first (attribute points counted)');
const gd = (await cf('/api/cloud', { op: 'ranks', board: 'gold' })).data.entries;
ok(gd[0].a === 'farmerA' && gd[0].v === 5_000_000, 'gold board carries over');
r = await cf('/api/cloud', { op: 'card', account: 'farmerA' });
ok(r.status === 200 && r.data.card, 'profile card exists for an imported player');

// ---- running it again is safe; a NEWER Cloudflare save is never replaced by the old one
const tokenA = (await cf('/api/cloud', { op: 'login', name: 'farmerA', pass: 'passA123' })).data.token;
const newer = hero('ชาวไร่เอ', 80, {}, 9_000_000);
await cf('/api/cloud', { op: 'push', token: tokenA, save: newer, force: true });
sum = await send(false);
ok(sum.counts.existing === 3 && sum.counts.imported === undefined, 'second run: nothing imported twice');
ok(sum.saves.kept_cloudflare === 2 && sum.saves.none === 1, `second run: Cloudflare saves kept (${JSON.stringify(sum.saves)})`);
r = await cf('/api/cloud', { op: 'pull', token: tokenA });
ok(r.data.save === newer, 'farmerA keeps the newer save made on Cloudflare');

// ---- bad input
r = await cf('/api/migrate', { records: [{ acct: { name: 'x', uid: 'bad' }, save: null }] }, { 'x-migrate-key': KEY });
ok(r.data.results[0].status === 'invalid', 'a malformed record is rejected, not written');
console.log(`(old site had ${sessionsOnOld} sessions; none were copied)`);
console.log(failed ? `\n${failed} FAILED` : '\nall passed');
process.exit(failed ? 1 : 0);
