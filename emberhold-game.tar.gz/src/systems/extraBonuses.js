// v10.2 bonuses that sit on top of everything else in stats.js: the worn weapon skin, the class (อาชีพ) and the
// Halloween artifacts. Each part returns plain numbers; this module only adds them up.
import { skinBonuses } from './skins.js';

const ZERO = () => ({ crit: 0, critMult: 0, spd: 0, atkFlat: 0, defFlat: 0, hpFlat: 0, atkPct: 0, defPct: 0, hpPct: 0, skillPower: 0, skillCd: 0, goldMult: 0, lifesteal: 0, healOnKill: 0, regen: 0, candy: 0, petPower: 0, allyPower: 0, dmgTaken: 0, ultGain: 0, dashCd: 0, comboPct: 0, thorns: 0, ignite: 0, lowHpDmg: 0, lowFoeDmg: 0, highFoeDmg: 0, perfectBonus: 0, guardPower: 0, counterBonus: 0, debuff: 0, magnet: 0 });
const parts = [];
// systems register their part (classes, Halloween artifacts) so this file never imports them (no import cycles)
export function registerBonus(fn) { parts.push(fn); }
export function extraBonuses(state, scale = 1) {
  const out = ZERO();
  const add = (b) => { if (!b) return; for (const k of Object.keys(out)) if (b[k]) out[k] += b[k] * scale; };
  try { add(skinBonuses(state)); } catch { /* a broken skin never breaks the stats */ }
  for (const f of parts) { try { add(f(state)); } catch { /* same for every part */ } }
  return out;
}
