// v10.2 Halloween artifacts (อาร์ติแฟกต์ฮาโลวีน): 30 relics that exist only in the Halloween event. They drop in the
// Halloween dungeons and come out of the candy shop's relic chest. Three can be worn at the Halloween altar.
// Each has a small stat part (`fx`, added through systems/extraBonuses.js) and its own trick in battle (`proc`, run by
// battle/hwaRuntime.js). Duplicates raise the level (1–5): stats +25% per level, the trick's numbers +15% per level.
//   on: kill · hit · crit · hurt · lowhp · tick (every `every` s) · dash · cast
export const HWA_LEVEL_MAX = 5;
export const HWA_SLOTS = 3;
export const HWA_CHEST = Object.freeze({ price: 3200, name: 'หีบอาร์ติแฟกต์ฮาโลวีน' });
export const HWA_RARITY_W = Object.freeze({ common: 40, uncommon: 28, rare: 18, epic: 9, legendary: 4, mythic: 1 });
const A = (id, name, rarity, sym, el, fx, proc, desc, lore) => [id, Object.freeze({ id, name, rarity, sym, el, fx: Object.freeze(fx), proc: Object.freeze(proc), desc, lore })];

export const HW_ARTIFACTS = Object.freeze(Object.fromEntries([
  A('hwa_jack_candle', 'เทียนในฟักทองแจ็ค', 'uncommon', 'pumpkin', 'pumpkin', { atkPct: 0.02 }, { on: 'kill', chance: 0.2, power: 1.2, r: 90 },
    (k) => `กำจัดศัตรูแล้ว ${Math.round(20 * k)}% ที่ศพจะกลายเป็นฟักทองระเบิด ${Math.round(120 * k)}% รัศมี 90`, 'เทียนที่ไม่เคยดับ เพราะมันกินไส้ฟักทองแทนขี้ผึ้ง'),
  A('hwa_bat_fang', 'เขี้ยวค้างคาวแวมไพร์', 'rare', 'bat', 'blood', { crit: 0.01 }, { on: 'hit', heal: 0.004, gap: 0.3 },
    (k) => `ทุกการโจมตีโดนดูดเลือด ${(0.4 * k).toFixed(2)}% ของพลังชีวิตสูงสุด (ทุก 0.3 วินาที)`, 'ค้างคาวตัวนี้กัดแค่ครั้งเดียว แต่ไม่เคยหยุดดูด'),
  A('hwa_witch_broom', 'ไม้กวาดแม่มด', 'uncommon', 'broom', 'hex', { spd: 0.03 }, { on: 'dash', power: 0.5, r: 90 },
    (k) => `ทุกครั้งที่พุ่งหลบ ฝุ่นเวทระเบิดตรงจุดเริ่ม ${Math.round(50 * k)}% รัศมี 90`, 'ไม้กวาดที่บินได้ ไม่เคยกวาดบ้านสักครั้ง'),
  A('hwa_ghost_lantern', 'ตะเกียงวิญญาณหลง', 'rare', 'ghost', 'spirit', { hpPct: 0.03 }, { on: 'tick', every: 6, power: 0.9, r: 420 },
    (k) => `ทุก 6 วินาที วิญญาณในตะเกียงพุ่งไปหาศัตรูใกล้สุด ${Math.round(90 * k)}%`, 'แสงในตะเกียงคือคนที่หลงทางในทุ่งเก็บเกี่ยว'),
  A('hwa_skull_goblet', 'ถ้วยกะโหลกโลหิต', 'epic', 'skull', 'blood', { atkPct: 0.03 }, { on: 'kill', buff: 'dmg', v: 0.08, t: 4 },
    (k) => `กำจัดศัตรูแล้วดาเมจ +${Math.round(8 * k)}% นาน 4 วินาที`, 'ดื่มจากถ้วยนี้หนึ่งครั้ง จะไม่อยากดื่มน้ำอีกเลย'),
  A('hwa_cursed_doll', 'ตุ๊กตาต้องสาป', 'rare', 'doll', 'hex', { defPct: 0.03 }, { on: 'hurt', chance: 0.35, mark: 0.2, t: 4 },
    (k) => `โดนโจมตีแล้ว ${Math.round(35 * k)}% ที่ผู้โจมตีจะติดคำสาป รับดาเมจเพิ่ม 20% นาน 4 วินาที`, 'ทุกเข็มที่ปักลงในตุ๊กตา มีคนอีกฝั่งรู้สึกเสมอ'),
  A('hwa_reaper_hourglass', 'นาฬิกาทรายยมทูต', 'epic', 'hourglass', 'spirit', { skillCd: 0.03 }, { on: 'kill', cdr: 0.4 },
    (k) => `กำจัดศัตรูแล้วคูลดาวน์สกิลทุกช่องลดลง ${(0.4 * k).toFixed(1)} วินาที`, 'ทรายในนั้นคือเวลาของคนที่ยมทูตมาเก็บแล้ว'),
  A('hwa_candy_heart', 'ลูกอมหัวใจหวานแหวว', 'common', 'candy', 'candy', { hpPct: 0.03 }, { on: 'lowhp', below: 0.5, regen: 0.003 },
    (k) => `เมื่อพลังชีวิตต่ำกว่าครึ่ง ฟื้น ${(0.3 * k).toFixed(2)}% ต่อวินาที`, 'หวานจนหัวใจลืมไปว่ากำลังเจ็บ'),
  A('hwa_spider_silk', 'ใยแมงมุมราตรี', 'common', 'spider', 'shadow', { crit: 0.01 }, { on: 'hit', chance: 0.15, slow: 0.6, t: 2 },
    (k) => `ตีโดนแล้ว ${Math.round(15 * k)}% ที่ศัตรูติดใยช้าลง 2 วินาที`, 'ใยที่เหนียวที่สุดถักในคืนที่มืดที่สุด'),
  A('hwa_black_cat', 'กระดิ่งแมวดำ', 'rare', 'cat', 'shadow', { dashCd: 0.06 }, { on: 'dash', chance: 0.3, buff: 'crit', v: 0.12, t: 3 },
    (k) => `พุ่งหลบแล้ว ${Math.round(30 * k)}% ที่คริติคอล +12% นาน 3 วินาที (แมวดำนำโชคมาให้เจ้าของ)`, 'แมวดำไม่ได้นำโชคร้าย มันแค่เลือกว่าจะให้ใคร'),
  A('hwa_moon_mirror', 'กระจกจันทร์เลือด', 'epic', 'mirror', 'blood', { defPct: 0.04 }, { on: 'hurt', chance: 0.25, power: 1.1, r: 130, cd: 3 },
    (k) => `โดนโจมตีแล้ว ${Math.round(25 * k)}% ที่กระจกสะท้อนแรงระเบิด ${Math.round(110 * k)}% รอบตัว`, 'เงาในกระจกยิ้มก่อนเจ้าเสมอ'),
  A('hwa_grave_soil', 'ดินหลุมศพ', 'uncommon', 'tomb', 'earth', { hpPct: 0.05 }, { on: 'kill', chance: 0.12, stun: 0.8, r: 130 },
    (k) => `กำจัดศัตรูแล้ว ${Math.round(12 * k)}% ที่มือจากหลุมศพโผล่มาจับศัตรูรอบๆ ชะงัก 0.8 วินาที`, 'ดินที่เคยฝังทุกอย่าง ยังจำได้ว่าต้องคว้าอะไร'),
  A('hwa_hex_ring', 'แหวนคำสาปสามวง', 'rare', 'hex', 'hex', { critMult: 0.06 }, { on: 'hit', every: 5, mark: 0.15, t: 4 },
    (k) => `ทุกการโจมตีครั้งที่ 5 ประทับคำสาป ศัตรูรับดาเมจเพิ่ม ${Math.round(15 * k)}% นาน 4 วินาที`, 'สามวง สามคำสาป ไม่มีวงไหนอ่อนโยน'),
  A('hwa_owl_feather', 'ขนนกฮูกเฝ้ายาม', 'uncommon', 'feather', 'star', { crit: 0.02 }, { on: 'tick', every: 12, ward: 1 },
    (k) => `ทุก ${Math.max(6, Math.round(12 / k))} วินาที ได้ม่านกำบังปัดการโจมตี 1 ครั้ง (ถ้ายังไม่มี)`, 'นกฮูกไม่เคยหลับ มันแค่หลับตาข้างเดียว'),
  A('hwa_cauldron_bubble', 'ฟองหม้อยาเดือด', 'uncommon', 'cauldron', 'poison', { atkPct: 0.02 }, { on: 'kill', puddle: 3, power: 0.25, r: 80 },
    (k) => `กำจัดศัตรูแล้วศพกลายเป็นแอ่งยาพิษ 3 วินาที ${Math.round(25 * k)}% ทุกครึ่งวินาที`, 'สูตรของแม่มดใช้ทุกอย่าง ไม่เว้นแม้แต่ศัตรู'),
  A('hwa_scarecrow_hat', 'หมวกหุ่นไล่กา', 'common', 'wizhat', 'pumpkin', { defPct: 0.04 }, { on: 'hurt', chance: 0.25, kb: 360, stun: 0.5, r: 160, cd: 4 },
    (k) => `โดนโจมตีแล้ว ${Math.round(25 * k)}% ที่ศัตรูรอบตัวตกใจกระเด็นหนีและชะงัก`, 'อีกาไม่กลัวหุ่นไล่กา แต่ปีศาจกลัว'),
  A('hwa_bone_whistle', 'นกหวีดกระดูก', 'epic', 'bone', 'spirit', { skillPower: 0.04 }, { on: 'cast', n: 5, power: 0.35 },
    (k) => `ใช้สกิลแล้วเศษกระดูก 5 ชิ้นพุ่งไล่ศัตรู ชิ้นละ ${Math.round(35 * k)}%`, 'เป่าครั้งเดียว กระดูกทั้งสุสานลุกขึ้นฟัง'),
  A('hwa_pumpkin_crown', 'มงกุฎราชาฟักทอง', 'legendary', 'crown', 'pumpkin', { atkPct: 0.06 }, { on: 'hit', chance: 0.08, power: 0.9, r: 75, gap: 0.4 },
    (k) => `ตีโดนแล้ว ${Math.round(8 * k)}% ที่ฟักทองระเบิดตรงศัตรู ${Math.round(90 * k)}% รัศมี 75`, 'มงกุฎของแจ็คผู้ไม่ยอมตาย ไม่ยอมแม้แต่จะลงหลุม'),
  A('hwa_vampire_cape', 'ผ้าคลุมแวมไพร์', 'legendary', 'wing', 'blood', { lifesteal: 0.02 }, { on: 'lowhp', below: 0.3, bats: 5, power: 0.5, cd: 20 },
    (k) => `เมื่อพลังชีวิตต่ำกว่า 30% ผ้าคลุมแตกเป็นค้างคาว 5 ตัวไล่กัด ${Math.round(50 * k)}% และดูดเลือดคืน (ทุก 20 วินาที)`, 'ราตรีไม่เคยปล่อยให้ลูกของมันตายง่ายๆ'),
  A('hwa_phantom_mask', 'หน้ากากภูตพราย', 'rare', 'mask', 'spirit', { spd: 0.03 }, { on: 'dash', iframes: 0.25 },
    (k) => `พุ่งหลบแล้วอยู่ในสภาพภูตต่ออีก ${(0.25 * k).toFixed(2)} วินาที (ไม่โดนดาเมจ)`, 'ใส่แล้วแม้แต่เงาของเจ้าก็หาตัวเจ้าไม่เจอ'),
  A('hwa_will_wisp', 'ดวงไฟวิลโอวิสป์', 'uncommon', 'ember', 'spirit', { crit: 0.01, spd: 0.02 }, { on: 'tick', every: 4, zap: 0.55, r: 320 },
    (k) => `ทุก 4 วินาที ดวงไฟผีช็อตศัตรูใกล้สุด ${Math.round(55 * k)}% และติดไฟ`, 'อย่าตามแสงในหนองน้ำ เว้นแต่จะให้มันตามเจ้า'),
  A('hwa_coffin_nail', 'ตะปูโลงศพ', 'rare', 'coffin', 'steel', { lowFoeDmg: 0.2 }, { on: 'crit', chance: 0.25, stun: 0.4 },
    (k) => `ดาเมจใส่ศัตรูเลือดน้อย +${Math.round(20 * k)}% และคริติคอลแล้ว ${Math.round(25 * k)}% ที่ตอกศัตรูชะงัก 0.4 วินาที`, 'ตะปูตัวสุดท้ายที่ปิดโลง ต้องตอกให้แน่น'),
  A('hwa_haunted_bell', 'ระฆังผีสิง', 'epic', 'bell', 'spirit', { hpPct: 0.04 }, { on: 'tick', every: 10, stun: 0.7, r: 170 },
    (k) => `ทุก ${Math.max(6, Math.round(10 / k))} วินาที ระฆังดังเอง ศัตรูทั่วไปรอบตัวชะงัก 0.7 วินาที`, 'ไม่มีใครตี แต่มันดังทุกคืนตอนเที่ยงคืน'),
  A('hwa_trick_box', 'กล่องกลเล่ห์', 'uncommon', 'gift', 'candy', { goldMult: 0.05 }, { on: 'kill', chance: 0.08 },
    (k) => `กำจัดศัตรูแล้ว ${Math.round(8 * k)}% ที่กล่องเปิดเอง: ฟื้นเลือด 6% / ได้แคนดี้ / เกจท่าไม้ตาย +10`, 'ขนมหรือโดนหลอก? กล่องเป็นคนเลือก'),
  A('hwa_raven_eye', 'ตาอีกาผู้รู้', 'epic', 'raven', 'shadow', { crit: 0.03, critMult: 0.08 }, { on: 'crit', chance: 0.3, power: 0.45, gap: 0.25 },
    (k) => `คริติคอลแล้ว ${Math.round(30 * k)}% ที่อีกาโฉบจิกซ้ำ ${Math.round(45 * k)}%`, 'อีกาเห็นทุกอย่าง และจำทุกคนที่เคยทำร้ายมัน'),
  A('hwa_frost_tomb', 'โลงน้ำแข็งราตรี', 'rare', 'coffin', 'ice', { defPct: 0.04 }, { on: 'hurt', slow: 0.5, t: 2, r: 150, cd: 6 },
    (k) => `โดนโจมตีแล้วไอเย็นระเบิดออก ศัตรูรอบตัวช้าลง 2 วินาที (ทุก ${Math.max(3, Math.round(6 / k))} วินาที)`, 'นอนในนี้ร้อยปี ก็ยังไม่ละลาย'),
  A('hwa_harvest_sickle', 'เคียวเก็บเกี่ยวเล็ก', 'legendary', 'scythe', 'spirit', { atkPct: 0.03 }, { on: 'kill', stack: 0.01, max: 15 },
    (k) => `ทุกการกำจัดศัตรูในด่านนี้ดาเมจ +${Math.round(1 * k * 10) / 10}% สะสมได้ 15 ชั้น`, 'เก็บเกี่ยวทีละต้น ไม่ช้าก็เต็มยุ้ง'),
  A('hwa_blood_moon_shard', 'เศษจันทร์เลือด', 'epic', 'moon', 'blood', { lowHpDmg: 0.15 }, { on: 'lowhp', below: 0.4, buff: 'haste', v: 0.2 },
    (k) => `ดาเมจตอนเลือดน้อย +${Math.round(15 * k)}% และเมื่อเลือดต่ำกว่า 40% ตีเร็วขึ้น ${Math.round(20 * k)}%`, 'เศษที่หล่นจากจันทร์คืนที่หมาป่าหอนพร้อมกัน'),
  A('hwa_witch_eye', 'ตาแม่มดในขวดโหล', 'legendary', 'eye', 'hex', { skillPower: 0.08 }, { on: 'cast', chance: 0.2, refund: 0.5 },
    (k) => `พลังสกิล +${Math.round(8 * k)}% และใช้สกิลแล้ว ${Math.round(20 * k)}% ที่คูลดาวน์ของสกิลนั้นคืนครึ่งหนึ่ง`, 'มันยังกะพริบอยู่ และมองหาเจ้าของใหม่'),
  A('hwa_soul_jar', 'โถเก็บวิญญาณ', 'mythic', 'flask', 'spirit', { hpPct: 0.05, atkPct: 0.03 }, { on: 'kill', souls: 10 },
    (k) => `เก็บวิญญาณจากศัตรูที่กำจัด (สูงสุด 10) เมื่อเลือดต่ำกว่า 20% ใช้ 5 ดวงฟื้นเลือด ${Math.round(18 * k)}% ทันที`, 'วิญญาณในโถไม่ได้ถูกขัง มันอาสาเฝ้าเจ้าของเอง'),
]));
export const HWA_IDS = Object.freeze(Object.keys(HW_ARTIFACTS));
export const getHwArtifact = (id) => (Object.prototype.hasOwnProperty.call(HW_ARTIFACTS, id) ? HW_ARTIFACTS[id] : null);
export const hwaStatMult = (lvl) => 1 + 0.25 * (Math.max(1, Math.min(HWA_LEVEL_MAX, lvl | 0)) - 1);
export const hwaProcMult = (lvl) => 1 + 0.15 * (Math.max(1, Math.min(HWA_LEVEL_MAX, lvl | 0)) - 1);
// drop chance per Halloween monster kill (bosses use the boss value); rarity then rolls by HWA_RARITY_W
export const HWA_DROP = Object.freeze({ mob: 0.012, elite: 0.04, boss: 0.35 });
