// v10 market stalls (ซุ้ม): one SVG per design — roof shape × cloth pattern × colours × props for the everyday 50,
// and ten one-off Halloween builds. 120×132, anchored at the middle of the counter's foot.
import { INK } from './palette.js';
const O = `stroke="${INK}" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"`;
const O2 = `stroke="${INK}" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round"`;
const W = 120, H = 132;
const shade = (hex, f) => { const n = parseInt(hex.slice(1), 16); const c = (v) => Math.max(0, Math.min(255, Math.round(v * f))); return '#' + [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => c(v).toString(16).padStart(2, '0')).join(''); };

function pattern(id, d) {
  const a = d.main, b = d.trim;
  switch (d.pattern) {
    case 'stripes': return `<pattern id="${id}" width="16" height="16" patternUnits="userSpaceOnUse"><rect width="16" height="16" fill="${a}"/><rect width="8" height="16" fill="${b}"/></pattern>`;
    case 'dots': return `<pattern id="${id}" width="14" height="14" patternUnits="userSpaceOnUse"><rect width="14" height="14" fill="${a}"/><circle cx="7" cy="7" r="2.6" fill="${b}"/></pattern>`;
    case 'checker': return `<pattern id="${id}" width="16" height="16" patternUnits="userSpaceOnUse"><rect width="16" height="16" fill="${a}"/><rect width="8" height="8" fill="${b}"/><rect x="8" y="8" width="8" height="8" fill="${b}"/></pattern>`;
    case 'stars': return `<pattern id="${id}" width="20" height="20" patternUnits="userSpaceOnUse"><rect width="20" height="20" fill="${a}"/><path d="M10 4 L11.5 8.5 L16 8.6 L12.4 11.4 L13.6 16 L10 13.3 L6.4 16 L7.6 11.4 L4 8.6 L8.5 8.5 Z" fill="${b}"/></pattern>`;
    case 'waves': return `<pattern id="${id}" width="20" height="10" patternUnits="userSpaceOnUse"><rect width="20" height="10" fill="${a}"/><path d="M0 7 Q5 2 10 7 T20 7" stroke="${b}" stroke-width="2" fill="none"/></pattern>`;
    case 'diamonds': return `<pattern id="${id}" width="16" height="16" patternUnits="userSpaceOnUse"><rect width="16" height="16" fill="${a}"/><path d="M8 2 L14 8 L8 14 L2 8 Z" fill="${b}"/></pattern>`;
    case 'leaves': return `<pattern id="${id}" width="18" height="18" patternUnits="userSpaceOnUse"><rect width="18" height="18" fill="${a}"/><path d="M4 14 C4 6 12 4 14 4 C14 10 10 14 4 14 Z" fill="${b}" opacity="0.85"/></pattern>`;
    default: return `<pattern id="${id}" width="10" height="10" patternUnits="userSpaceOnUse"><rect width="10" height="10" fill="${a}"/></pattern>`;
  }
}
function roof(d) {
  switch (d.roof) {
    case 'tent': return `<path d="M8 50 L60 6 L112 50 Z" fill="url(#cl)" ${O}/><path d="M60 6 L60 50" stroke="${shade(d.main, 0.7)}" stroke-width="2"/>`;
    case 'dome': return `<path d="M10 52 C10 18 110 18 110 52 Z" fill="url(#cl)" ${O}/><circle cx="60" cy="16" r="5" fill="${d.trim}" ${O2}/>`;
    case 'pagoda': return `<path d="M2 52 Q30 40 60 22 Q90 40 118 52 Z" fill="url(#cl)" ${O}/><path d="M24 30 Q42 20 60 8 Q78 20 96 30 Z" fill="${shade(d.main, 0.85)}" ${O}/><path d="M2 52 L-2 46 M118 52 L122 46" ${O}/>`;
    case 'scallop': return `<path d="M8 22 L112 22 L112 46 ${Array.from({ length: 8 }, (_, i) => `Q${112 - i * 13 - 6.5} 58 ${112 - (i + 1) * 13} 46`).join(' ')} Z" fill="url(#cl)" ${O}/>`;
    case 'flat': return `<rect x="6" y="26" width="108" height="20" rx="3" fill="url(#cl)" ${O}/><path d="M6 46 L114 46" stroke="${d.trim}" stroke-width="3"/>`;
    default: return `<path d="M4 50 L14 20 L106 20 L116 50 Z" fill="url(#cl)" ${O}/><path d="M4 50 ${Array.from({ length: 7 }, (_, i) => `Q${4 + i * 16 + 8} 60 ${4 + (i + 1) * 16} 50`).join(' ')}" fill="${d.trim}" ${O2}/>`;
  }
}
function props(d) {
  let s = '';
  if (d.flag) s += `<path d="M60 ${d.roof === 'tent' ? 6 : 20} L60 -4 L76 0 L60 6" fill="${d.trim}" ${O2}/>`;
  if (d.lantern) s += `<path d="M16 54 L16 64" stroke="${INK}" stroke-width="1.5"/><ellipse cx="16" cy="70" rx="6" ry="8" fill="#ffcf5a" ${O2}/><path d="M104 54 L104 64" stroke="${INK}" stroke-width="1.5"/><ellipse cx="104" cy="70" rx="6" ry="8" fill="#ffcf5a" ${O2}/>`;
  if (d.plant) s += `<rect x="96" y="112" width="14" height="14" rx="2" fill="#8a5a3a" ${O2}/><circle cx="103" cy="106" r="9" fill="#5a9a3a" ${O2}/>`;
  if (d.sign) s += `<rect x="38" y="78" width="44" height="14" rx="3" fill="#efe4cc" ${O2}/><path d="M44 85 L76 85" stroke="${shade(d.main, 0.6)}" stroke-width="2"/>`;
  return s;
}
function halloween(d) {
  const m = d.main, t = d.trim;
  switch (d.theme) {
    case 'pumpkin': return `<ellipse cx="34" cy="34" rx="22" ry="26" fill="${shade(m, 0.85)}" ${O}/><ellipse cx="86" cy="34" rx="22" ry="26" fill="${shade(m, 0.85)}" ${O}/><ellipse cx="60" cy="32" rx="30" ry="30" fill="${m}" ${O}/><path d="M44 24 L52 18 L54 28 Z M76 24 L68 18 L66 28 Z" fill="#ffcf5a"/><path d="M42 40 L48 46 L54 40 L60 46 L66 40 L72 46 L78 40 L74 50 L46 50 Z" fill="#ffcf5a"/><path d="M58 2 L64 -6 L66 4" fill="#3a6a2a" ${O2}/>`;
    case 'coffin': return `<path d="M30 6 L90 6 L104 28 L96 60 L24 60 L16 28 Z" fill="${m}" ${O}/><path d="M60 16 L60 46 M50 26 L70 26" stroke="${t}" stroke-width="4"/>`;
    case 'web': return `<path d="M4 54 L60 4 L116 54 Z" fill="${m}" ${O}/>${[0.25, 0.5, 0.75].map((k) => `<path d="M${4 + 56 * (1 - k)} ${54 - 50 * k} L${116 - 56 * (1 - k)} ${54 - 50 * k}" stroke="${t}" stroke-width="1.2"/>`).join('')}<path d="M60 4 L30 54 M60 4 L90 54 M60 4 L60 54" stroke="${t}" stroke-width="1.2"/><circle cx="60" cy="32" r="4" fill="#1a1424"/><path d="M56 32 L50 28 M56 34 L50 36 M64 32 L70 28 M64 34 L70 36" stroke="#1a1424" stroke-width="1.4"/>`;
    case 'bats': return `<rect x="6" y="24" width="108" height="26" fill="${m}" ${O}/>${[22, 60, 98].map((x) => `<path d="M${x} 36 q-8 -10 -16 -2 q6 0 8 6 q2 -4 8 -4 q6 0 8 4 q2 -6 8 -6 q-8 -8 -16 2 Z" fill="${t}" ${O2}/>`).join('')}`;
    case 'candycane': return `${[12, 108].map((x) => `<path d="M${x} 126 L${x} 20 Q${x} 4 ${x + (x < 60 ? 14 : -14)} 8" stroke="${INK}" stroke-width="9" fill="none"/><path d="M${x} 126 L${x} 20 Q${x} 4 ${x + (x < 60 ? 14 : -14)} 8" stroke="#ffffff" stroke-width="6" fill="none" stroke-dasharray="6 6"/><path d="M${x} 126 L${x} 20" stroke="${t}" stroke-width="6" fill="none" stroke-dasharray="6 6" stroke-dashoffset="6"/>`).join('')}<rect x="8" y="22" width="104" height="22" rx="10" fill="${t}" ${O}/>`;
    case 'witchhat': return `<ellipse cx="60" cy="52" rx="58" ry="10" fill="${m}" ${O}/><path d="M28 50 Q46 30 50 4 Q70 20 92 50 Z" fill="${m}" ${O}/><rect x="34" y="38" width="52" height="8" fill="${t}" ${O2}/>`;
    case 'cauldron': return `<ellipse cx="60" cy="40" rx="50" ry="20" fill="#1a1a1a" ${O}/><ellipse cx="60" cy="26" rx="46" ry="10" fill="${t}" ${O2}/><circle cx="44" cy="22" r="5" fill="${shade(t, 1.3)}" ${O2}/><circle cx="74" cy="18" r="4" fill="${shade(t, 1.3)}" ${O2}/>`;
    case 'ghost': return `<path d="M6 54 C4 10 116 10 114 54 L104 46 L94 56 L84 46 L74 56 L64 46 L54 56 L44 46 L34 56 L24 46 L14 56 Z" fill="${m}" ${O}/><ellipse cx="46" cy="30" rx="6" ry="9" fill="#1a2a3a"/><ellipse cx="74" cy="30" rx="6" ry="9" fill="#1a2a3a"/>`;
    case 'grave': return `<path d="M14 54 L14 24 Q14 6 34 6 L86 6 Q106 6 106 24 L106 54 Z" fill="${m}" ${O}/><text x="60" y="38" text-anchor="middle" font-size="16" font-weight="900" fill="${t}">R.I.P.</text>`;
    case 'skulls': return `<rect x="6" y="24" width="108" height="24" fill="${m}" ${O}/>${[22, 60, 98].map((x) => `<circle cx="${x}" cy="60" r="9" fill="#efe4cc" ${O2}/><circle cx="${x - 3}" cy="59" r="2" fill="${t}"/><circle cx="${x + 3}" cy="59" r="2" fill="${t}"/>`).join('')}`;
    default: return '';
  }
}
export function stallSvg(d) {
  const body = d.halloween
    ? `${halloween(d)}`
    : `${roof(d)}${props(d)}`;
  const counter = `<rect x="12" y="92" width="96" height="34" rx="3" fill="${d.halloween ? shade(d.main, 0.6) : '#8a5a3a'}" ${O}/><rect x="8" y="86" width="104" height="10" rx="2" fill="${d.halloween ? d.trim : '#c8a070'}" ${O2}/>
    <path d="M20 104 L100 104 M20 116 L100 116" stroke="${INK}" stroke-width="1" opacity="0.4"/>`;
  const posts = d.halloween && d.theme === 'candycane' ? '' : `<rect x="14" y="44" width="6" height="48" fill="${d.post || '#6b4a2c'}" ${O2}/><rect x="100" y="44" width="6" height="48" fill="${d.post || '#6b4a2c'}" ${O2}/>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-4 -10 ${W + 8} ${H + 12}" width="${W + 8}" height="${H + 12}"><defs>${pattern('cl', d)}</defs>${posts}${counter}${body}</svg>`;
}
export const STALL_SIZE = { w: W + 8, h: H + 12, ax: (W + 8) / 2, ay: H + 6 };
