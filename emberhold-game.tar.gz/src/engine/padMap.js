// v10 gamepad bindings (pure). The standard browser mapping numbers the buttons 0..16:
//   0 A/✕ · 1 B/○ · 2 X/□ · 3 Y/△ · 4 LB/L1 · 5 RB/R1 · 6 LT/L2 · 7 RT/R2 · 8 Back/Share · 9 Start/Options
//   10 L3 · 11 R3 · 12 ↑ · 13 ↓ · 14 ← · 15 → · 16 Home
// The player can bind every game action to any button (ตั้งค่า › จอยเกม). Saved in settings.pad as { action: button }.
export const PAD_ACTIONS = Object.freeze([
  { id: 'attack', name: 'โจมตี / ยืนยัน' }, { id: 'dash', name: 'หลบ' }, { id: 'skill0', name: 'สกิลช่อง 1' }, { id: 'skill1', name: 'สกิลช่อง 2' },
  { id: 'skill2', name: 'สกิลช่อง 3' }, { id: 'race', name: 'สกิลเผ่า' }, { id: 'guard', name: 'กัน (ค้าง)' }, { id: 'ult', name: 'อัลติ' }, { id: 'job', name: 'สกิลอาชีพ' },
  { id: 'interact', name: 'คุย / เปิด / ชุบเพื่อน' }, { id: 'potion', name: 'ใช้ยา' }, { id: 'pause', name: 'หยุดเกม / เมนู' }, { id: 'bag', name: 'กระเป๋า' },
]);
export const DEFAULT_PAD = Object.freeze({ attack: 0, dash: 1, skill0: 2, skill1: 3, skill2: 4, race: 5, guard: 6, ult: 7, interact: 11, potion: 10, pause: 9, bag: 8, job: 12 });
export const BUTTON_NAMES = Object.freeze(['A / ✕', 'B / ○', 'X / □', 'Y / △', 'LB / L1', 'RB / R1', 'LT / L2', 'RT / R2', 'Back / Share', 'Start / Options', 'L3 (กดสติ๊กซ้าย)', 'R3 (กดสติ๊กขวา)', 'ปุ่มลูกศร ↑', 'ปุ่มลูกศร ↓', 'ปุ่มลูกศร ←', 'ปุ่มลูกศร →', 'Home']);
export const buttonName = (b) => BUTTON_NAMES[b] ?? `ปุ่ม ${b}`;
export function cleanPad(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const out = {};
  for (const a of PAD_ACTIONS) { const v = raw[a.id]; if (Number.isInteger(v) && v >= 0 && v <= 31) out[a.id] = v; }
  return Object.keys(out).length ? out : null;
}
export const bindingsOf = (pad) => ({ ...DEFAULT_PAD, ...(cleanPad(pad) || {}) });
