// v10 ถนนตลาด (the market street): 100 lots east of the village. A player with a game account rents one lot, puts up
// a stall in one of 60 designs, lists up to 8 items at their own prices, and anyone online buys at once. The server
// (netlify/lib/live.mjs) holds the listings and settles every sale; the game only moves items in and out of the bag.
import { h, glyph, itemImg, fmt, clear } from './dom.js';
import { getItem, isEquipment } from '../data/items.js';
import { rarityOf } from '../data/rarity.js';
import { MARKET, STALL_DESIGNS, getDesign } from '../data/market.js';
import { cloneState } from '../core/state.js';
import { addInPlace, canAdd, removeSlotInPlace, sortedSlots, isLocked } from '../systems/inventory.js';
import { buyStall } from '../systems/hwShop.js';
import { cloudError } from '../net/cloud.js';

// what the scene draws: { [lot]: { owner, acct, design, items:[{lid,id,qty,lvl,price}], seen } }
export function createMarketFeed(app) {
  let lots = {}, at = 0, busy = false, mine = null;
  async function refresh(force = false) {
    if (busy || !app.cloud?.available || (!force && Date.now() - at < 15_000)) return lots;
    busy = true;
    const d = await app.cloud.live('mk_list');
    busy = false; at = Date.now();
    if (d.lots) lots = d.lots;
    if (app.cloud.account()) { const m = await app.cloud.live('mk_mine'); if (!m.error) mine = m; } else mine = null;
    return lots;
  }
  return { refresh, get lots() { return lots; }, get mine() { return mine; }, set(n, v) { if (v) lots[n] = v; else delete lots[n]; } };
}

const NEED_ACCOUNT = 'ตลาดใช้บัญชีเกม (เซฟออนไลน์) เพื่อจำว่าใครเป็นเจ้าของซุ้มและของ เข้าสู่ระบบก่อน';
const tradable = (d) => d && ['weapon', 'armor', 'charm', 'wings', 'consumable', 'material'].includes(d.category) && !d.secret && d.rarity !== 'unknown' && !d.cosmetic && !d.noTrade;

function designPreview(app, id, cls = 'stall-prev') { return h('img', { class: cls, src: app.stallUri(id), alt: getDesign(id)?.name || '', draggable: 'false' }); }

export function openMarketLot(app, n) {
  const feed = app.market;
  let close;
  const body = h('div', { class: 'mk-body' });
  const say = (text, kind = '') => { const el = body.querySelector('[data-say]'); if (el) { el.textContent = text; el.className = `notice ${kind}`; el.hidden = !text; } };
  const content = h('div', { class: 'modal panel mk-modal', 'data-modal': 'market', 'data-lot': n }, body);
  async function draw() {
    await feed.refresh(true);
    const lot = feed.lots[n], acct = app.cloud.account(), mineLot = feed.mine?.lot;
    clear(body);
    body.append(h('div', { class: 'eyebrow', style: { textAlign: 'center' } }, `ถนนตลาด · ล็อต ${n} / ${MARKET.lots}`));
    body.append(h('div', { class: 'notice', 'data-say': '', hidden: true }));
    if (!lot) drawEmpty(acct, mineLot);
    else if (acct && mineLot === n) drawMine(lot);
    else drawShop(lot);
  }
  function drawEmpty(acct, mineLot) {
    const st = app.store.get();
    let pick = st.market.design;
    const grid = designGrid(st, (id) => { pick = id; }, pick);
    body.append(h('h2', {}, 'ล็อตว่าง'),
      h('p', { class: 'muted', style: { margin: 0 } }, `เช่าได้ฟรี บัญชีละ 1 ล็อต ซุ้มอยู่ได้ตราบที่คุณแวะมาอย่างน้อยทุก ${MARKET.rentDays} วัน ทุกการขายหัก ${Math.round(MARKET.fee * 100)}% ให้หมู่บ้าน`),
      grid,
      h('div', { class: 'actions' },
        !app.cloud.available ? h('div', { class: 'notice warn' }, 'ต้องเปิดเกมจากเว็บไซต์ของเกม') :
        !acct ? h('button', { class: 'btn gold', type: 'button', onclick: () => { close(); app.openAccount(); } }, glyph('globe'), 'เข้าสู่ระบบบัญชีเกม') :
        mineLot ? h('div', { class: 'notice' }, `คุณมีซุ้มอยู่แล้วที่ล็อต ${mineLot}`) :
        h('button', { class: 'btn gold', type: 'button', 'data-action': 'mk-rent', onclick: async () => {
          const d = await app.cloud.live('mk_rent', { lot: n, design: pick, hero: app.store.get().story.name });
          if (d.error) { say(cloudError(d.error), 'warn'); return; }
          const nx = cloneState(app.store.get()); nx.market.design = pick; app.store.commit(nx, { reason: 'market' });
          app.audio.play('buy'); app.toast(`ตั้งซุ้มที่ล็อต ${n} แล้ว`, 'ok'); draw();
        } }, glyph('shop'), 'เช่าล็อตนี้'),
        h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'ปิด')),
      !acct ? h('div', { class: 'notice' }, NEED_ACCOUNT) : null);
  }
  function drawShop(lot) {
    const st = app.store.get(), acct = app.cloud.account();
    body.append(h('div', { class: 'mk-head' }, designPreview(app, lot.design), h('div', {}, h('h2', {}, `ซุ้มของ ${lot.owner}`), h('small', { class: 'muted' }, `บัญชี ${lot.acct} · ${getDesign(lot.design)?.name || ''}`), h('div', { class: 'chip' }, glyph('gold'), `ทองของคุณ ${fmt(st.gold)}`))));
    if (!lot.items.length) body.append(h('div', { class: 'empty-note' }, 'ซุ้มนี้ยังไม่มีของวางขาย'));
    body.append(h('div', { class: 'mk-grid' }, ...lot.items.map((x) => {
      const d = getItem(x.id); if (!d) return null;
      return h('div', { class: `mk-item r-${d.rarity}`, 'data-lid': x.lid },
        h('div', { class: 'mk-icon' }, itemImg(x.id), x.qty > 1 ? h('span', { class: 'qty' }, x.qty) : null),
        h('b', { class: 'rc-text' }, `${d.name}${x.lvl ? ` +${x.lvl}` : ''}`), h('small', { class: 'muted' }, rarityOf(d.rarity).name),
        h('button', { class: 'btn gold sm', type: 'button', 'data-action': 'mk-buy', disabled: st.gold < x.price, onclick: async (e) => {
          const cur = app.store.get();
          if (!app.cloud.available) { say('ต้องเปิดเกมจากเว็บไซต์ของเกม', 'warn'); return; }
          if (!acct) { say(NEED_ACCOUNT, 'warn'); return; }
          if (cur.gold < x.price) { say('ทองไม่พอ', 'warn'); return; }
          if (!canAdd(cur, x.id, x.qty)) { say('กระเป๋าเต็ม', 'warn'); return; }
          e.currentTarget.disabled = true;
          const d2 = await app.cloud.live('mk_buy', { lot: n, lid: x.lid, price: x.price });
          if (d2.error) { say(cloudError(d2.error), 'warn'); draw(); return; }
          const nx = cloneState(app.store.get());
          nx.gold = Math.max(0, nx.gold - x.price);
          addInPlace(nx, d2.item.id, d2.item.qty, d2.item.lvl);
          app.store.commit(nx, { reason: 'market-buy' });
          app.cloud.syncSoon(); app.audio.play('buy');
          app.toast(`ซื้อ ${d.name} จาก ${lot.owner} แล้ว (${fmt(x.price)} ทอง)`, 'ok');
          draw();
        } }, glyph('gold'), fmt(x.price)));
    })));
    body.append(h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'ปิด')));
    if (!acct) body.append(h('div', { class: 'notice' }, NEED_ACCOUNT));
  }
  function drawMine(lot) {
    const st = app.store.get(), mine = feed.mine || {};
    body.append(h('div', { class: 'mk-head' }, designPreview(app, lot.design), h('div', {}, h('h2', {}, 'ซุ้มของฉัน'), h('small', { class: 'muted' }, `วางขาย ${lot.items.length} / ${MARKET.maxListings} ชิ้น`),
      h('div', { class: 'chip ok' }, glyph('gold'), `รายได้รอเก็บ ${fmt(mine.earn || 0)}`))));
    body.append(h('div', { class: 'actions', style: { flexWrap: 'wrap' } },
      h('button', { class: 'btn gold', type: 'button', 'data-action': 'mk-collect', disabled: !(mine.earn > 0), onclick: async () => {
        const d = await app.cloud.live('mk_collect');
        if (d.error) { say(cloudError(d.error), 'warn'); return; }
        const nx = cloneState(app.store.get()); nx.gold += d.gold | 0; app.store.commit(nx, { reason: 'market-collect' }); app.cloud.syncSoon();
        app.audio.play('gold'); app.toast(`เก็บรายได้ ${fmt(d.gold)} ทอง`, 'ok'); draw();
      } }, glyph('gold'), 'เก็บรายได้'),
      h('button', { class: 'btn', type: 'button', 'data-action': 'mk-design', onclick: () => pickDesign() }, glyph('shop'), 'เปลี่ยนแบบซุ้ม'),
      h('button', { class: 'btn danger', type: 'button', 'data-action': 'mk-leave', onclick: async () => {
        const d = await app.cloud.live('mk_leave');
        if (d.error) { say(cloudError(d.error), 'warn'); return; }
        const nx = cloneState(app.store.get()); nx.gold += d.gold | 0; const lost = [];
        for (const it of d.items || []) if (!addInPlace(nx, it.id, it.qty, it.lvl).ok) lost.push(it);
        app.store.commit(nx, { reason: 'market-leave' }); app.cloud.syncSoon();
        app.toast(lost.length ? 'คืนล็อตแล้ว แต่กระเป๋าเต็ม ของบางชิ้นหายไป' : 'คืนล็อตแล้ว ของที่วางขายกลับเข้ากระเป๋า', lost.length ? 'warn' : 'ok'); draw();
      } }, glyph('exit'), 'คืนล็อต')));
    body.append(h('div', { class: 'eyebrow' }, 'ของที่วางขาย'));
    body.append(h('div', { class: 'mk-grid' }, ...lot.items.map((x) => {
      const d = getItem(x.id);
      return h('div', { class: `mk-item r-${d?.rarity}` }, h('div', { class: 'mk-icon' }, itemImg(x.id), x.qty > 1 ? h('span', { class: 'qty' }, x.qty) : null), h('b', { class: 'rc-text' }, d?.name || x.id), h('small', {}, `${fmt(x.price)} ทอง`),
        h('button', { class: 'btn sm', type: 'button', 'data-action': 'mk-take', onclick: async () => {
          if (!canAdd(app.store.get(), x.id, x.qty)) { say('กระเป๋าเต็ม', 'warn'); return; }
          const r = await app.cloud.live('mk_take', { lid: x.lid });
          if (r.error) { say(cloudError(r.error), 'warn'); draw(); return; }
          const nx = cloneState(app.store.get()); addInPlace(nx, r.item.id, r.item.qty, r.item.lvl); app.store.commit(nx, { reason: 'market-take' }); app.cloud.syncSoon(); draw();
        } }, 'เก็บคืน'));
    })));
    if (mine.log?.length) body.append(h('div', { class: 'eyebrow' }, 'ขายไปล่าสุด'), h('ul', { class: 'mk-log' }, ...mine.log.map((l) => h('li', {}, `${getItem(l.id)?.name || l.id}${l.qty > 1 ? ' ×' + l.qty : ''} · ${fmt(l.price)} ทอง · ${l.by}`))));
    // list something from the bag
    const price = h('input', { type: 'number', min: 1, max: MARKET.maxPrice, value: '1000', class: 'mk-price', 'data-field': 'price' });
    const qty = h('input', { type: 'number', min: 1, value: '1', class: 'mk-qty', 'data-field': 'qty' });
    let sel = null;
    const pickRow = h('div', { class: 'mk-bag' }, ...sortedSlots(st).filter((s) => tradable(getItem(s.id)) && !isLocked(s)).slice(0, 80).map((s) => {
      const d = getItem(s.id);
      return h('button', { class: `cell r-${d.rarity}`, type: 'button', title: d.name, 'data-uid': s.uid, onclick: (e) => { sel = s; pickRow.querySelectorAll('.on').forEach((x) => x.classList.remove('on')); e.currentTarget.classList.add('on'); qty.max = String(s.qty); qty.value = String(Math.min(Number(qty.value) || 1, s.qty)); } }, itemImg(s.id), s.qty > 1 ? h('span', { class: 'qty' }, s.qty) : null);
    }));
    body.append(h('div', { class: 'eyebrow' }, 'วางขายของจากกระเป๋า (ของที่ล็อก ★ ไว้จะไม่แสดง)'), pickRow,
      h('div', { class: 'mk-form' }, h('label', {}, 'จำนวน ', qty), h('label', {}, 'ราคา (ทอง) ', price),
        h('button', { class: 'btn gold', type: 'button', 'data-action': 'mk-put', disabled: lot.items.length >= MARKET.maxListings, onclick: async (e) => {
          if (!sel) { say('เลือกไอเทมก่อน', 'warn'); return; }
          const d = getItem(sel.id), q = isEquipment(d) ? 1 : Math.max(1, Math.min(sel.qty, Number(qty.value) | 0)), p = Math.max(1, Math.min(MARKET.maxPrice, Number(price.value) | 0));
          e.currentTarget.disabled = true;
          say('กำลังบันทึกเซฟขึ้นบัญชีเพื่อยืนยันของ…');
          const sync = await app.cloudSyncNow();
          if (!sync.ok) { say(sync.message || cloudError(sync.error), 'warn'); e.currentTarget.disabled = false; return; }
          const r = await app.cloud.live('mk_put', { item: { id: sel.id, qty: q, lvl: sel.lvl | 0 }, price: p });
          if (r.error) { say(cloudError(r.error), 'warn'); e.currentTarget.disabled = false; return; }
          const nx = cloneState(app.store.get());
          removeSlotInPlace(nx, sel.uid, q);
          app.store.commit(nx, { reason: 'market-put' });
          await app.cloudSyncNow();
          app.audio.play('gold'); app.toast(`วางขาย ${d.name} ${fmt(p)} ทอง`, 'ok'); draw();
        } }, glyph('sell'), 'วางขาย')));
    body.append(h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'ปิด')));
  }
  function pickDesign() {
    const st = app.store.get();
    let pick = st.market.design;
    let c2;
    const grid = designGrid(st, (id) => { pick = id; }, pick);
    const box = h('div', { class: 'modal panel', 'data-modal': 'mk-designs' }, h('h2', {}, 'แบบซุ้ม'), grid,
      h('div', { class: 'actions' }, h('button', { class: 'btn gold', type: 'button', onclick: async () => {
        const d = await app.cloud.live('mk_design', { design: pick });
        if (d.error) { app.toast(cloudError(d.error), 'warn'); return; }
        const nx = cloneState(app.store.get()); nx.market.design = pick; app.store.commit(nx, { reason: 'market' });
        c2(); draw();
      } }, 'ใช้แบบนี้'), h('button', { class: 'btn primary', type: 'button', onclick: () => c2() }, 'ปิด')));
    c2 = app.modal(box);
  }
  // owned designs can be picked; the rest can be bought here with gold (Halloween ones with candy at the candy shop)
  function designGrid(st, onPick, cur) {
    const wrap = h('div', { class: 'mk-designs' });
    const paint = () => {
      const s = app.store.get();
      clear(wrap);
      for (const d of STALL_DESIGNS) {
        const own = d.free || s.market.designs[d.id];
        wrap.append(h('button', { class: `mk-design${own ? '' : ' locked'}${d.id === cur ? ' on' : ''}${d.halloween ? ' hw' : ''}`, type: 'button', 'data-design': d.id, title: d.name,
          onclick: () => {
            if (own) { cur = d.id; onPick(d.id); paint(); return; }
            if (d.halloween) { app.toast('ซุ้มฮาโลวีนแลกได้ที่ร้านแคนดี้ในโลกฮาโลวีน', 'warn'); return; }
            const r = buyStall(app.store.get(), d.id, d.price);
            if (!r.ok) { app.toast(r.reason === 'gold' ? `ทองไม่พอ (ต้องใช้ ${fmt(d.price)})` : 'ซื้อไม่ได้', 'warn'); app.audio.play('error'); return; }
            app.store.commit(r.state, { reason: 'stall' }); app.audio.play('buy'); cur = d.id; onPick(d.id); paint();
          } }, designPreview(app, d.id, 'mk-design-img'), h('small', {}, d.name), own ? null : h('span', { class: 'mk-price-tag' }, d.halloween ? `${fmt(d.candy)} แคนดี้` : `${fmt(d.price)} ทอง`)));
      }
    };
    void st; paint();
    return wrap;
  }
  close = app.modal(content);
  body.append(h('div', { class: 'muted', style: { textAlign: 'center', padding: '20px' } }, 'กำลังโหลดตลาด…'));
  draw();
  return close;
}
