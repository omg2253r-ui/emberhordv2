// v10 Halloween windows: the candy shop, the demon cauldron, the cauldron of all things, the dungeon gates and the
// event board. All of them are plain DOM modals over the scene (app.modal).
import { h, glyph, itemImg, rarityClass, fmt } from './dom.js';
import { getItem, ITEMS } from '../data/items.js';
import { rarityOf } from '../data/rarity.js';
import { hwActive, hwLeftMs, fmtCountdown, skinsOf, getSkin, HW_SKINS } from '../data/halloween.js';
import { SHOP_TABS, shopRows, candyPrice } from '../data/hwShop.js';
import { buyWithCandy, buyPet, buyStall, setMask, ownsItem } from '../systems/hwShop.js';
import { buySkinCandy, wearSkin, ownsSkin, wornSkinId } from '../systems/skins.js';
import { SKIN_TIERS, getSkinAny } from '../data/skins.js';
import { boxCards } from './skinUi.js';
import { relicTab, hwPetDropCards } from './hwaUi.js';
import { HERBS, HW_RECIPES, HW_BREW_COST, ALL_BREW_COST, EFFECTS, allRecipes, BREW_MAX_QTY } from '../data/brewing.js';
import { brewHalloween, brewAll, activeBrews } from '../systems/brew.js';
import { getZone } from '../data/zones.js';
import { HW_ZONES, HW_REQ } from '../data/hwZones.js';
import { getEnemy } from '../data/enemies.js';
import { sortedSlots } from '../systems/inventory.js';

const REASON = { candy: 'แคนดี้ไม่พอ', gold: 'ทองไม่พอ', bag_full: 'กระเป๋าเต็ม', owned: 'มีอยู่แล้ว', max_stars: 'ดาวเต็มแล้ว', event_over: 'กิจกรรมฮาโลวีนจบแล้ว', missing: 'ของในกระเป๋าไม่พอ', empty: 'ยังไม่ได้ใส่อะไรลงหม้อ', too_many: 'ใส่ได้สูงสุด 4 ชนิด', not_herb: 'หม้อนี้รับเฉพาะสมุนไพร', not_allowed: 'ของชิ้นนี้ใส่หม้อไม่ได้', not_owned: 'ยังไม่มีของชิ้นนี้' };
const candyChip = (app) => h('span', { class: 'chip hw-candy', 'data-candy': '' }, itemImg('candy'), h('b', { class: 'num' }, fmt(app.store.get().candy || 0)));
function timerChip() {
  const el = h('span', { class: 'chip hw-timer', 'data-hw-left': '' }, glyph('star'), h('b', { class: 'num' }, fmtCountdown(hwLeftMs())));
  const id = setInterval(() => { if (!el.isConnected) { clearInterval(id); return; } el.lastChild.textContent = fmtCountdown(hwLeftMs()); }, 1000);
  return el;
}
const put = (el, ...kids) => el.replaceChildren(...kids.flat().filter((k) => k != null && k !== false));
const fxClass = (wid) => { const n = null; void n; return 'hw-anim'; };

// ------------------------------------------------------------------ ร้านแคนดี้
export function openCandyShop(app, startTab = 'weapons') {
  let tab = startTab, close;
  const body = h('div', { class: 'hw-shop-body' });
  const head = h('div', { class: 'hw-shop-head' });
  const tabs = h('div', { class: 'seg hw-tabs', role: 'tablist' });
  function act(r, okText) {
    if (!r.ok) { app.toast(REASON[r.reason] || 'ทำไม่สำเร็จ', 'warn'); app.audio.play('error'); return false; }
    app.store.commit(r.state, { reason: 'hw-shop' }); app.toast(okText, 'loot', null, { rarity: 'legendary' }); app.audio.play('buy');
    app.refreshHeroSprites(); render(); return true;
  }
  function render() {
    const st = app.store.get();
    head.replaceChildren(h('div', {}, h('div', { class: 'eyebrow' }, 'กิจกรรมฮาโลวีน'), h('h2', {}, 'ร้านแคนดี้ของแม่มดเพ็ปเปอร์มินต์')), h('div', { class: 'hw-chips' }, candyChip(app), timerChip()));
    tabs.replaceChildren(...SHOP_TABS.map((t) => h('button', { class: 'btn small', type: 'button', role: 'tab', 'aria-checked': String(t.id === tab), 'data-hw-tab': t.id, onclick: () => { tab = t.id; app.audio.play('tab'); render(); } }, t.name)));
    const rows = shopRows(tab);
    const cards = rows.map((r) => {
      if (r.kind === 'skin') {
        const sk = r.skin, owned = ownsSkin(st, sk.id), worn = wornSkinId(st, sk.wid) === sk.id, hasW = ownsItem(st, sk.wid);
        return h('div', { class: `hw-card ${rarityClass(r.def.rarity)}`, 'data-skin': sk.id },
          h('div', { class: `hw-prev hw-anim fx-${sk.fx} t${sk.tier}` }, h('img', { class: 'item-img', alt: sk.name, src: app.skinIconUri(sk.id) })),
          h('b', {}, sk.name), h('small', { class: 'muted' }, `สกินของ ${r.def.name} · ระดับ${SKIN_TIERS[getSkinAny(sk.id).t].name} · เอฟเฟกต์เคลื่อนไหวตลอดเวลา`),
          owned ? h('div', { class: 'hw-row' }, worn ? h('button', { class: 'btn small', type: 'button', onclick: () => act(wearSkin(app.store.get(), sk.wid, null), 'ถอดสกินแล้ว') }, 'ถอดสกิน') : h('button', { class: 'btn small primary', type: 'button', 'data-action': 'wear-skin', onclick: () => act(wearSkin(app.store.get(), sk.wid, sk.id), `ใส่สกิน ${sk.name} แล้ว`) }, 'ใส่สกิน'), hasW ? null : h('small', { class: 'muted' }, 'ยังไม่มีอาวุธนี้'))
            : buyBtn(r.price, () => act(buySkinCandy(app.store.get(), sk.id, r.price), `ได้สกิน ${sk.name}`)));
      }
      if (r.kind === 'pet') {
        const own = st.pets.owned[r.id];
        return h('div', { class: `hw-card ${rarityClass(r.pet.rarity)}`, 'data-pet': r.id },
          h('div', { class: 'hw-prev hw-anim fx-float' }, h('img', { class: 'item-img', alt: r.pet.name, src: app.petUri(r.id) })),
          h('b', {}, r.pet.name), h('small', { class: 'muted' }, `${r.pet.role} · ${r.pet.ability.name} · ${r.pet.desc}`),
          own ? h('span', { class: 'chip ok' }, `มีแล้ว ${'★'.repeat(own.stars)}`) : null,
          buyBtn(r.price, () => act(buyPet(app.store.get(), r.id, r.price), own ? `${r.pet.name} +1 ดาว` : `ได้ ${r.pet.name}! ไปตั้งเป็นทีมได้ที่แท็บสัตว์เลี้ยง`)));
      }
      if (r.kind === 'stall') {
        const d = r.design, own = !!st.market.designs[d.id];
        return h('div', { class: 'hw-card r-limited', 'data-stall': d.id },
          h('div', { class: 'hw-prev hw-anim fx-float' }, h('img', { class: 'item-img', alt: d.name, src: app.stallUri(d.id) })),
          h('b', {}, d.name), h('small', { class: 'muted' }, 'แบบซุ้มขายของสำหรับตลาดซุ้มในหมู่บ้าน (ของฮาโลวีน แลกได้ช่วงกิจกรรมเท่านั้น)'),
          own ? h('span', { class: 'chip ok' }, 'มีแล้ว') : buyBtn(r.price, () => act(buyStall(app.store.get(), d.id, r.price), `ได้แบบซุ้ม ${d.name}`)));
      }
      const d = r.def, rar = rarityOf(d.rarity);
      return h('div', { class: `hw-card ${rarityClass(d.rarity)}${r.dropOnly ? ' drop-only' : ''}`, 'data-item': r.id },
        h('div', { class: `hw-prev ${d.event ? 'hw-anim fx-glow' : ''}` }, itemImg(d.id)),
        h('b', { class: 'rc-text' }, d.name), h('small', { class: 'rc-text' }, rar.name),
        h('small', { class: 'muted' }, d.desc),
        r.power ? h('small', { class: 'hw-value' }, `ค่าพลัง ${fmt(r.power)}${r.price ? ` · ${(r.power / r.price * 1000).toFixed(1)} พลัง/1,000 แคนดี้` : ''}`) : null,
        r.dropOnly ? h('span', { class: 'chip warn' }, `ดรอปเท่านั้น: ${r.dropOnly}`) : buyBtn(r.price, () => act(buyWithCandy(app.store.get(), d.id, r.price), `แลก ${d.name} แล้ว`)));
    });
    put(body,
      tab === 'weapons' ? h('div', { class: 'notice' }, 'อาวุธลิมิเต็ด ฮาโลวีน แรงกว่าอาวุธซีเคร็ตทุกเล่ม (รวมดาบสุริยคราสและคาตานะมุรามาสะ) · ราคาคิดจากความหายากและค่าพลัง ยิ่งโกงยิ่งแพง') : null,
      tab === 'weapons' ? boxCards(app, ['hw'], () => render()) : null,
      tab === 'skins' ? h('div', { class: 'notice' }, 'อาวุธฮาโลวีนทุกเล่มมี 3 สกิน แต่ละสกินมีเอฟเฟกต์เคลื่อนไหวรอบตัวตลอดเวลา (คนอื่นเห็นด้วย) · สกินระดับสูงราคาแพงขึ้น') : null,
      maskRow(app, render),
      tab === 'relics' ? relicTab(app, render) : h('div', { class: 'hw-grid' }, cards),
      tab === 'pets' ? hwPetDropCards(app) : null);
  }
  function buyBtn(price, fn) {
    const st = app.store.get(), can = (st.candy || 0) >= price && hwActive();
    return h('button', { class: `btn small ${can ? 'gold' : ''}`, type: 'button', 'data-action': 'hw-buy', disabled: !hwActive(), onclick: fn }, itemImg('candy'), fmt(price));
  }
  render();
  const content = h('div', { class: 'modal panel hw-shop', 'data-modal': 'hw-shop' }, head, tabs, body,
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', 'data-action': 'close', onclick: () => close() }, 'ปิด')));
  close = app.modal(content);
  return close;
}
function maskRow(app, render) {
  const st = app.store.get();
  if (!ownsItem(st, 'c_hw_spite_mask')) return null;
  const sw = h('input', { type: 'checkbox', class: 'switch', 'data-setting': 'hw-mask' }); sw.checked = !!st.hw.mask;
  sw.addEventListener('change', () => { const r = setMask(app.store.get(), sw.checked); if (r.ok) { app.store.commit(r.state, { reason: 'mask' }); app.refreshPresence?.(); render?.(); } });
  return h('label', { class: 'setting hw-mask-row' }, itemImg('c_hw_spite_mask'), h('span', {}, 'สวมหน้ากากแห่งความเคียดแค้นทับชุด', h('small', { class: 'muted setting-sub' }, 'ใส่ซ้อนกับสกินและชุดทุกแบบ ไม่มีพลังใดๆ (ตามที่หน้ากากบอกไว้)')), sw);
}
export { maskRow };

// ------------------------------------------------------------------ cauldrons
// mode 'hw': หม้อปรุงยาปีศาจ (herbs only, 5,000 gold) · mode 'all': หม้อปรุงทุกสรรพสิ่ง (anything, 3,000 gold)
export function openCauldron(app, mode = 'hw') {
  const HW = mode === 'hw';
  let close, pot = [];          // [{ id, qty }]
  let filter = '';
  const potEl = h('div', { class: 'hw-pot' }), bagEl = h('div', { class: 'hw-bag grid' }), info = h('div', { class: 'hw-pot-info' }), bookEl = h('div', { class: 'hw-book' });
  const cost = HW ? HW_BREW_COST : ALL_BREW_COST;
  const allowed = (def) => (HW ? !!def.herb : !def.secretCurse && def.id !== 'p_hw_cross');
  function have(id) { return sortedSlots(app.store.get()).filter((x) => x.id === id).reduce((a, x) => a + x.qty, 0); }
  function render() {
    const st = app.store.get();
    potEl.replaceChildren(...[0, 1, 2, 3].map((i) => {
      const x = pot[i];
      if (!x) return h('div', { class: 'hw-slot empty' }, h('small', { class: 'muted' }, `ช่อง ${i + 1}`));
      const def = getItem(x.id);
      return h('div', { class: `hw-slot ${rarityClass(def.rarity)}`, 'data-pot': x.id }, itemImg(x.id), h('small', {}, def.name),
        h('div', { class: 'hw-qty' },
          h('button', { class: 'btn icon small', type: 'button', 'aria-label': 'ลด', onclick: () => { x.qty -= 1; if (x.qty <= 0) pot.splice(i, 1); render(); } }, '−'),
          h('b', { class: 'num' }, x.qty),
          h('button', { class: 'btn icon small', type: 'button', 'aria-label': 'เพิ่ม', onclick: () => { if (x.qty < Math.min(BREW_MAX_QTY, have(x.id))) x.qty += 1; render(); } }, '+')));
    }));
    const list = sortedSlots(st).filter((x) => allowed(getItem(x.id)) && (!filter || getItem(x.id).name.includes(filter)));
    const seen = new Set();
    bagEl.replaceChildren(...list.filter((x) => (seen.has(x.id) ? false : seen.add(x.id))).map((x) => {
      const def = getItem(x.id), inPot = pot.find((p) => p.id === x.id);
      return h('button', { class: `cell ${rarityClass(def.rarity)}${inPot ? ' selected' : ''}`, type: 'button', title: def.name, 'data-bag-item': x.id, onclick: () => {
        if (inPot) { if (inPot.qty < Math.min(BREW_MAX_QTY, have(x.id))) inPot.qty += 1; }
        else if (pot.length < 4) pot.push({ id: x.id, qty: 1 }); else { app.toast('ใส่ได้สูงสุด 4 ชนิด', 'warn'); return; }
        app.audio.play('click'); render();
      } }, itemImg(x.id), h('span', { class: 'qty' }, have(x.id)));
    }));
    if (!bagEl.children.length) bagEl.replaceChildren(h('div', { class: 'empty-note' }, HW ? 'ยังไม่มีสมุนไพร ไปเก็บที่ "สวนแห่งพงไพร" ผ่านประตูในโลกฮาโลวีน' : 'กระเป๋าว่าง'));
    put(info,
      h('div', { class: 'kv' }, h('div', {}, h('span', { class: 'muted' }, 'ค่าปรุง'), h('b', {}, `${fmt(cost)} ทอง`)), h('div', {}, h('span', { class: 'muted' }, 'ทองที่มี'), h('b', {}, fmt(st.gold))), h('div', {}, h('span', { class: 'muted' }, 'สูตรที่ค้นพบ'), h('b', {}, `${Object.keys(st.brew.known).filter((k) => k.startsWith(HW ? 'hr' : 'ar')).length} / 320`))),
      h('small', { class: 'muted' }, HW
        ? 'ใส่สมุนไพร 1–4 ชนิด กำหนดจำนวนได้เอง · ถ้าตรงสูตร โอกาสสำเร็จ ×2 · ไม่ตรงสูตรจะได้ยาที่ใกล้เคียงที่สุด หรือบางทีก็ได้ "ยาลับ" ที่สาปตอนลงดันถัดไป'
        : 'ใส่ของอะไรก็ได้ในเกม 1–4 ชนิด · ยาที่ได้ขึ้นกับว่าใส่อะไร (หนักสุดเป็นตัวกำหนดฤทธิ์) และใส่มากน้อยแค่ไหน (ขั้น 1–20) · สูตรเฉพาะ 320 สูตรให้ขั้นสูงกว่าน้ำหนักจริงมาก'),
      activeRow(app));
    renderBook();
  }
  function renderBook() {
    const st = app.store.get();
    const list = HW ? HW_RECIPES : allRecipes(ITEMS);
    const known = list.filter((r) => st.brew.known[r.id]);
    bookEl.replaceChildren(h('div', { class: 'eyebrow' }, `ตำราสูตรที่รู้แล้ว (${known.length})`),
      known.length ? h('div', { class: 'hw-recipes' }, known.slice(0, 60).map((r) => h('button', { class: 'hw-recipe', type: 'button', 'data-recipe': r.id, onclick: () => { pot = r.items.map((x) => ({ ...x })); render(); } },
        h('span', {}, r.items.map((x) => `${getItem(x.id).name}×${x.qty}`).join(' + ')), h('b', { class: rarityClass(getItem(r.out).rarity) + ' rc-text' }, `→ ${getItem(r.out).name}`)))) : h('small', { class: 'muted' }, 'ยังไม่รู้สูตรไหน ลองผสมดู สูตรที่ปรุงตรงจะถูกจดไว้ที่นี่'));
  }
  function brew() {
    const st = app.store.get();
    const rnd = () => app.rng.next();
    const r = HW ? brewHalloween(st, pot, rnd) : brewAll(st, pot, rnd);
    if (!r.ok) { app.toast(REASON[r.reason] || 'ปรุงไม่สำเร็จ', 'warn'); app.audio.play('error'); return; }
    app.store.commit(r.state, { reason: 'brew' });
    potEl.classList.remove('boil'); void potEl.offsetWidth; potEl.classList.add('boil');
    app.audio.play('forge');
    setTimeout(() => {
      const out = r.out ? getItem(r.out) : null;
      const exact = r.kind === 'exact';
      if (out) { app.audio.play(out.secretCurse ? 'fail' : 'success'); app.toast(`${exact ? 'ตรงสูตร! ' : r.kind === 'secret' ? 'ยาลับ… ' : r.kind === 'near' ? 'ใกล้เคียงสูตร: ' : ''}ได้ ${out.name}`, out.secretCurse ? 'warn' : 'loot', null, { itemId: out.id, rarity: out.rarity }); }
      else { app.audio.play('fail'); app.toast(exact ? 'ตรงสูตร แต่ไฟแรงไป ยาไหม้หมด (ลองอีกครั้ง)' : 'ยาเดือดล้นหม้อ… ไม่ได้อะไรเลย', 'warn'); }
      pot = pot.filter((x) => have(x.id) >= x.qty);
      render();
    }, 900);
  }
  render();
  const content = h('div', { class: `modal panel hw-cauldron ${HW ? 'demon' : 'all'}`, 'data-modal': HW ? 'hw-cauldron' : 'all-cauldron' },
    h('div', { class: 'eyebrow', style: { textAlign: 'center' } }, HW ? 'กิจกรรมฮาโลวีน' : 'ระบบปรุงยา'),
    h('h2', {}, HW ? 'หม้อปรุงยาปีศาจ' : 'หม้อปรุงทุกสรรพสิ่ง'),
    HW ? h('div', { class: 'hw-chips' }, timerChip()) : null,
    potEl,
    h('div', { class: 'actions' }, h('button', { class: 'btn gold', type: 'button', 'data-action': 'brew', onclick: brew }, glyph('potion'), `ปรุง (${fmt(cost)} ทอง)`), h('button', { class: 'btn', type: 'button', onclick: () => { pot = []; render(); } }, 'เทออก')),
    info,
    h('input', { type: 'search', class: 'text-in', placeholder: 'ค้นหาของในกระเป๋า', oninput: (e) => { filter = e.target.value.trim(); render(); } }),
    bagEl, bookEl,
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'ปิด')));
  close = app.modal(content);
  return close;
}
function activeRow(app) {
  const list = activeBrews(app.store.get());
  if (!list.length) return null;
  return h('div', { class: 'hw-active' }, h('small', { class: 'eyebrow' }, 'ยาที่ออกฤทธิ์อยู่'), ...list.map((b) => h('span', { class: 'chip ok' }, `${EFFECTS[b.def.brew.eff].fmt(b.def.brew.v)} · ${Math.ceil((b.until - Date.now()) / 60000)} นาที`)));
}

// ------------------------------------------------------------------ dungeon gates (Halloween world)
export function openHwGate(app, zoneId) {
  const z = getZone(zoneId); if (!z) return;
  const st = app.store.get(), lock = app.zoneLock(zoneId);
  let close;
  const boss = getEnemy(z.boss);
  const content = h('div', { class: 'modal panel hw-gate', 'data-modal': 'hw-gate', 'data-zone': zoneId },
    h('div', { class: 'eyebrow', style: { textAlign: 'center' } }, `ประตูฮาโลวีน · เลเวลแนะนำ ${z.level}`),
    h('h2', {}, z.name),
    h('p', { class: 'muted', style: { margin: 0 } }, z.desc),
    h('div', { class: 'notice' }, z.mechanicText),
    boss ? h('div', { class: 'kv' }, h('div', {}, h('span', { class: 'muted' }, 'บอส'), h('b', {}, boss.name)), h('div', {}, h('span', { class: 'muted' }, 'ผู้เล่นสูงสุด'), h('b', {}, `${z.partyMax} คน`)), h('div', {}, h('span', { class: 'muted' }, 'ต้องเลเวล'), h('b', {}, String(HW_REQ[zoneId] || 1)))) : null,
    lock ? h('div', { class: 'notice warn' }, lock) : null,
    h('div', { class: 'actions', style: { flexWrap: 'wrap' } },
      h('button', { class: 'btn gold', type: 'button', 'data-action': 'hw-solo', disabled: !!lock, onclick: () => { close(); app.startZoneSolo(zoneId, app.hwFrom?.() || 'camp'); } }, glyph('sword'), 'เข้าคนเดียว'),
      h('button', { class: 'btn', type: 'button', 'data-action': 'hw-room', disabled: !!lock || !app.online.online, title: app.online.online ? '' : 'ต้องออนไลน์', onclick: () => { close(); app.openHwRoom(zoneId); } }, glyph('people'), `เปิดห้องกับเพื่อน (สูงสุด ${z.partyMax})`),
      h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'ปิด')));
  close = app.modal(content);
  void st;
}

// ------------------------------------------------------------------ the event board
export function openHwBoard(app) {
  let close;
  const st = app.store.get();
  const content = h('div', { class: 'modal panel hw-board', 'data-modal': 'hw-board' },
    h('div', { class: 'eyebrow', style: { textAlign: 'center' } }, 'กิจกรรมฮาโลวีน · ประตูมิติแห่งโลกฮาโลวีน'),
    h('h2', {}, 'คืนฟักทองสิบห้าราตรี'),
    h('div', { class: 'hw-chips' }, timerChip(), candyChip(app)),
    h('ul', { class: 'hw-list' },
      h('li', {}, 'แคนดี้ (Candy) หลุดจากตัวยมทูตและแม่มดจอมล่อลวงทุกครั้งที่ตีโดน และจากมอนสเตอร์ฮาโลวีนทุกตัวเมื่อล้ม นำไปแลกที่ร้านแคนดี้'),
      h('li', {}, 'อาวุธลิมิเต็ด ฮาโลวีน แรงกว่าอาวุธซีเคร็ต · อาวุธละ 3 สกินเคลื่อนไหว · ชุด ปีก สัตว์เลี้ยง ยา และซุ้มฮาโลวีน'),
      h('li', {}, 'หม้อปรุงยาปีศาจ: ผสมสมุนไพรจากสวนแห่งพงไพร มีกว่า 100 ชนิด 320 สูตร ครั้งละ 5,000 ทอง'),
      h('li', {}, 'แม่มดจอมหลอกลวง (สูงสุด 8 คน): ทำดาเมจให้ถึง 1,000,000 แล้วจะมีบางอย่างเปิดออก…'),
      h('li', {}, `แม่มดจอมล่อลวงที่ล้มไปแล้ว: ${fmt(st.hw.lureKills)} ตัว (การันตีปืนคู่ฟักทองอีก ${fmt(1500 - st.hw.lurePity)} ตัว)`),
      h('li', {}, 'เมื่อกิจกรรมจบ ประตูจะปิดและร้านจะหายไป แต่ของที่ได้ไปแล้วยังอยู่กับคุณ')),
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'ปิด')));
  close = app.modal(content);
}
export { HW_ZONES, candyPrice, HW_SKINS, skinsOf, getSkin, fxClass };
