// v10 Halloween mechanics inside the shared co-op run (scenes/coopScene.js calls these hooks).
//   • candy (แคนดี้) that falls out of event monsters when YOU hit them, and when they fall (personal, like all loot)
//   • the fifteen curses on your own hero (applied where the potion splashes) and the twin pistols' curses on monsters
//   • แจ็กโอแลนเทิร์น's mirror world: the trapped hero fights their own reflection on their own screen
//   • แม่มดจอมหลอกลวง: at 1,000,000 damage she is stunned and the black ??? portal opens on the left
//   • the wizard's secret dungeon: the wizard and his artifact bag (for everyone), the cross (1,000,000 gold), downed heroes
//     revived by a friend holding the button 10 s (half health), the five guardians and their crystals, the emperor's
//     endless respawns and healing, the God of Creation fighting beside you, and Muramasa at the end.
//   • the Light Guardian's clash (5 s of button presses), the Wisdom Guardian's chessboard
// Network: small events prefixed 'hw' (onMessage) and `rs.hw` (room state, from the host).
import { CURSE_IDS, getCurse, GUARDIAN_CRYSTALS, CROSS_PRICE, LURE_PITY, LURE_PISTOL_CHANCE, DECEIVER_THRESHOLD } from '../data/halloween.js';
import { getEnemy } from '../data/enemies.js';
import { getItem } from '../data/items.js';
import { computeDamage } from '../systems/combat.js';
import { createDrop } from './drops.js';
import { cloneState } from '../core/state.js';
import { countItem, removeItem, addItem } from '../systems/inventory.js';
import { drawPumpkin } from '../art/hwShots.js';
import { h, glyph, itemImg } from '../ui/dom.js';
import { paintZoneRoom } from '../scenes/zoneBackdrop.js';

const TAU = Math.PI * 2;
const num = (v, lo, hi, d = 0) => (typeof v === 'number' && Number.isFinite(v) ? Math.max(lo, Math.min(hi, v)) : d);
const CLASH_TIME = 5, MIRROR_TIME = 40, SECRET_REVIVE = 10;
const HW_PORTAL = { x: 250, y: 540, r: 90 };

// ------------------------------------------------------------------ setup
export function installHw(w, api) {
  const { app, audio, rng } = api;
  w.hwApi = api;
  w.hw = {
    crystals: 0, bag: false, portal: false, hold: false, chamber: 0, board: null, mirror: null, clash: null,
    curses: {}, cursePulse: 0, downed: new Set(), talked: false, cine: null, candyCd: 0, room: null, mirrorBusy: false, meter: 0,
  };
  const H = w.hw;
  // the world API the event behaviours use (battle/hwBehaviours.js)
  w.mirrorTrap = (t, boss) => {
    if (!w.amHost) return;
    H.mirrorBusy = true; H.mirrorBossId = boss.id;
    if (t === w.player) startMirror(w, boss.id);
    else if (t?.peer) api.queue(['hwm', t.peer, boss.id]);
    setTimeout(() => { H.mirrorBusy = false; }, (MIRROR_TIME + 3) * 1000);
  };
  H.finish = (e) => { api.killEnemy(e, true); };
  H.summonMasks = (boss) => {
    const m = api.spawnEnemy('t_god_masks', boss.x + 260, boss.y - 40);
    if (!m) return;
    m.hwImmortal = true; m.atk = Math.round(m.atk * 0.6); m.maxHp = m.hp = Math.max(m.hp, 50000);
    w.announce('เทพผู้พิทักษ์อัญเชิญ "ทศพักตร์มาร" จากชั้น 80! (อมตะ — ตีไม่ตายจนกว่าผู้อัญเชิญจะล้ม)');
  };
  H.transmutePools = () => { for (const pl of w.fxs.pools) { pl.kind = 'fire'; pl.mult = Math.max(pl.mult || 0, 0.25); } api.queue(['hwtp']); };
  H.allyBeam = (ally, foe) => {
    const amount = Math.max(1, Math.round(foe.maxHp * 0.012));
    api.damageEnemy(foe, { amount, crit: false }, 0, 0, { src: 'ally' });
    beamFx(w, ally.x, ally.y - 120, foe.x, foe.y - 80);
    api.queue(['hwbeam', Math.round(ally.x), Math.round(ally.y - 120), Math.round(foe.x), Math.round(foe.y - 80)]);
  };
  H.allyHeal = () => { healMe(w, 0.1, 'เทพแห่งการสร้างสรรค์ฟื้นพลังให้ทุกคน'); api.queue(['hwheal']); };
  void app; void audio; void rng;
}

const isSecretRoom = (w) => !!(w.zone?.id === 'hw_deceiver' && w.nestedOpen && w.ri >= 1);
export const hwSecret = (w) => isSecretRoom(w);
export const reviveRule = (w) => (isSecretRoom(w) ? { time: SECRET_REVIVE, hp: 0.5 } : null);
// what the host shares with the room state (presence `rs.hw`)
export function hwRs(w) {
  if (!w.zone?.hw || !w.hw) return undefined;
  const H = w.hw;
  return { p: H.portal ? 1 : 0, cr: H.crystals, bg: H.bag ? 1 : 0, ch: H.chamber || 0 };
}
export function hwReadRs(w, r) {
  if (!r || typeof r !== 'object' || !w.hw) return;
  const H = w.hw;
  if (r.p && !H.portal) { H.portal = true; congratulate(w); }
  const cr = num(r.cr, 0, 31) | 0;
  if (cr !== H.crystals) { const gained = cr & ~H.crystals; H.crystals = cr; if (gained) crystalToast(w, gained); }
  if (r.bg && !H.bag) { H.bag = true; w.hwApi.app.toast('ทุกคนได้รับ "กระเป๋าเก็บอาร์ติแฟกต์" จากพ่อมดแล้ว', 'loot', null, { rarity: 'legendary' }); }
  H.chamber = num(r.ch, 0, 5) | 0;
}

// ------------------------------------------------------------------ spawning
export function hwSpawn(w, e, def) {
  if (def.fixedHp) { e.maxHp = e.hp = def.hp; e.bars = 1; }
  if (def.npc) { e.untargetable = true; e.hwNpc = true; }
  if (def.chess) { const B = w.hw?.board; if (B) { const c = B.cellOf(e.x, e.y); e.ai.col = c.col; e.ai.row = c.row; const at = B.center(c.col, c.row); e.x = at.x; e.y = at.y; } }
}

// ------------------------------------------------------------------ hits on monsters (host)
// returns null to stop the blow, undefined to carry on
export function hwBeforeHit(w, e, pkt, from) {
  if (e.type.npc) return null;
  // the dark guardian: among the copies only a blow on the real one counts — it reveals it, nothing more
  if (e.type.ai === 'hw_g_dark' && e.hwReveal) {
    if (e.state === 'clones') { e.ai.revealed = true; e.hwReveal = false; w.fx.callout(e.x, e.y - 240, 'พบตัวจริง!', '#c88aff'); w.hwApi.audio.play('shatter'); }
    return null;
  }
  if (e.type.ai === 'hw_g_dark') return null;          // inside the pillar chamber it is not in the room at all
  if (e.type.id === 'hw_g_dark_clone') { w.fx.callout(e.x, e.y - 200, 'ตัวปลอม!', '#7a3aff'); w.hwApi.killEnemy(e, false); const t = w.hwApi.spawnEnemy('hw_shadow_fake', e.x, e.y); void t; return null; }
  if (e.hwStunned) return null;
  return undefined;
}
export function hwHitMult(w, e) {
  let m = 1;
  if (e.mockT > 0) m *= 1.5;                           // the Luring Witch stops to laugh: hit her now
  if (e.hwFoe?.markT > 0) m *= 1 + (e.hwFoe.mark || 0);
  return m;
}
// the twin pistols: a random curse of the fifteen on the monster that was hit (host)
export function hwAfterHit(w, e, pkt) {
  if (!pkt.curse || e.dead) return;
  const c = getCurse(typeof pkt.curse === 'string' ? pkt.curse : CURSE_IDS[(Math.random() * CURSE_IDS.length) | 0]);
  if (!c) return;
  const f = c.foe; e.hwFoe ||= {};
  if (f.slow) { e.slowT = Math.max(e.slowT || 0, f.t || 2); e.slowMult = e.type.boss ? Math.min(1, f.slow + 0.25) : f.slow; }
  if (f.atkDown) { e.hwFoe.atkDownT = f.t || 3; if (!e.hwFoe.baseAtk) e.hwFoe.baseAtk = e.atk; e.atk = Math.round(e.hwFoe.baseAtk * (1 - f.atkDown)); }
  if (f.mark) { e.hwFoe.mark = f.mark; e.hwFoe.markT = f.t || 3; }
  if (f.stun && !e.type.boss) e.hitstun = Math.max(e.hitstun || 0, f.stun);
  if (f.burn) e.burnT = Math.max(e.burnT || 0, 2);
  if (Math.random() < 0.35) w.fx.callout(e.x, e.y - (e.r || 24) * 2 - 44, c.name, c.col);
}
export function hwFoeTick(e, dt) {
  const f = e.hwFoe; if (!f) return;
  if (f.markT > 0) f.markT -= dt;
  if (f.atkDownT > 0) { f.atkDownT -= dt; if (f.atkDownT <= 0 && f.baseAtk) { e.atk = f.baseAtk; f.baseAtk = 0; } }
}
// a monster that cannot die (the Deceiving Witch): at zero she is stunned and the secret opens
export function hwNoDeath(w, e) {
  e.hp = 1; e.hwStunned = true; e.untargetable = true; e.invuln = 0; e.warn = 0; e.state = 'stunned';
  for (const x of w.enemies) if (!x.dead && x !== e) w.hwApi.killEnemy(x, false);
  w.fxs.strikes.length = 0; w.fxs.shots.length = 0;
  w.hw.portal = true;
  // open the dungeon inside the dungeon
  if (w.zone.nested && !w.nestedOpen) { w.nestedOpen = true; w.zone = { ...w.zone, rooms: [...w.zone.rooms, ...w.zone.nested] }; }
  w.rphase = 'clear'; w.phaseT = 0; w.hwApi.publishRs();
  w.announce('แม่มดสตั้น! มิติ ??? สีดำเปิดออกทางซ้าย');
  congratulate(w);
}
function congratulate(w) {
  if (w.hw.congrats) return;
  w.hw.congrats = true;
  const { app, audio, store } = w.hwApi;
  app.hud.banner('ยินดีด้วย! คุณมาถึงอีเว้นต์ลับ', 'ทำดาเมจใส่แม่มดจอมหลอกลวงครบ 1,000,000 · เดินเข้ามิติ ??? ทางซ้าย');
  audio.play('legendary');
  const n = cloneState(store.get()); n.hw.deceiverStuns += 1; store.commit(n, { reason: 'hw', persist: false });
}

// ------------------------------------------------------------------ kills
// host: what happens in the room when an event monster falls
export function hwOnKill(w, e) {
  const id = e.type.id, H = w.hw;
  const bit = { hw_g_dark: 1, hw_g_wisdom: 2, hw_g_light: 4, hw_g_alchemy: 8, hw_emperor: 16 }[id];
  if (bit) { H.crystals |= bit; w.hwApi.publishRs(); crystalToast(w, bit); }
  if (id === 'hw_g_alchemy') {
    for (const m of w.enemies) if (!m.dead && m.type.id === 't_god_masks') { m.hwImmortal = false; w.hwApi.killEnemy(m, false); }
    w.announce('ทศพักตร์มารล้มลงตามผู้อัญเชิญ… แล้วทิ้งหน้ากากไว้ (ว้าว ในที่สุดก็ตีตายจนได้)');
  }
  if (id === 'hw_emperor') for (const m of w.enemies) if (!m.dead && (m.type.id === 'hw_emp_imp' || m.type.id === 'hw_emp_ghost')) w.hwApi.killEnemy(m, false);
  if (id === 'hw_g_wisdom') for (const m of w.enemies) if (!m.dead && m.type.chess) w.hwApi.killEnemy(m, false);
  if (id === 'hw_g_dark') for (const m of w.enemies) if (!m.dead && (m.type.id === 'hw_g_pillar' || m.type.id === 'hw_shadow_fake' || m.type.id === 'hw_g_dark_clone')) w.hwApi.killEnemy(m, false);
}
// everyone: MY personal rewards for an event monster (candy, the pity counter, the guaranteed drops)
export function hwPersonalKill(w, def, x, y) {
  const { store, rng } = w.hwApi;
  const p = w.player;
  const mult = p.stats.candyMult || 1;
  if (def.candyKill) { const [a, b] = def.candyKill; const q = Math.round((a + Math.floor(rng.next() * (b - a + 1))) * mult); dropCandy(w, q, x, y, def.boss ? 6 : 1); }
  const n = cloneState(store.get());
  let changed = true;
  if (def.id === 'hw_witch_lure') {
    n.hw.lureKills += 1; n.hw.lurePity += 1;
    if (rng.next() < LURE_PISTOL_CHANCE || n.hw.lurePity >= LURE_PITY) {
      n.hw.lurePity = 0;
      w.drops.push(createDrop('item', 'w_hw_twin_pistols', 1, x, y, rng));
      w.hwApi.app.hud.banner('ปืนคู่ฟักทองสาปสิบห้า!', 'ของลิมิเต็ดที่หายากที่สุดของกิจกรรม'); w.hwApi.audio.play('legendary');
    } else if (n.hw.lurePity % 100 === 0) w.hwApi.app.toast(`แม่มดจอมล่อลวง: อีก ${LURE_PITY - n.hw.lurePity} ตัวการันตีปืนคู่ฟักทอง`, 'info', 'lure-pity');
  } else if (def.id === 'hw_reaper') n.hw.reaperKills += 1;
  else if (def.id === 'hw_jack') n.hw.jackKills += 1;
  else if (def.id === 'hw_witch_wrath') {
    n.hw.wrathKills += 1; n.hw.secretClears += 1;
    w.drops.push(createDrop('item', 'w_hw_muramasa', 1, x, y, rng));
    w.hwApi.app.hud.banner('คาตานะมุรามาสะ', 'แม่มดแห่งความโกรธเกรี้ยวสลายไป ทิ้งดาบเล่มนี้ไว้เป็นของตอบแทน'); w.hwApi.audio.play('legendary');
  } else if (def.id === 'hw_g_alchemy') w.drops.push(createDrop('item', 'c_hw_spite_mask', 1, x, y - 40, rng));
  else changed = false;
  if (changed) store.commit(n, { reason: 'hw', persist: false });
}
function dropCandy(w, qty, x, y, pieces = 1) {
  if (qty <= 0) return;
  const n = Math.max(1, Math.min(pieces, qty));
  for (let i = 0; i < n; i++) w.drops.push(createDrop('candy', 'candy', Math.max(1, Math.round(qty / n)), x, y, w.hwApi.rng));
}
// MY blow landed on a monster: candy may fall out of it (the Reaper, the Luring Witch, the emperor's servants…)
export function hwMyHit(w, e, o) {
  const H = w.hw;
  if (!e?.type?.candyHit || w.player.dead) return;
  H.candyCd = Math.max(0, H.candyCd);
  if (H.candyCd > 0 || o.src === 'burn') return;
  if (w.hwApi.rng.next() < e.type.candyHit) {
    H.candyCd = 0.3;
    const lv = w.zone?.level || 20;
    dropCandy(w, Math.round((2 + lv / 6) * (w.player.stats.candyMult || 1)), e.x, e.y - 20);
  }
}
export function hwCollectCandy(w, d) {
  const { store, audio } = w.hwApi;
  const n = cloneState(store.get()); n.candy = Math.min(99_999_999, (n.candy || 0) + d.qty);
  store.commit(n, { reason: 'candy', persist: false });
  w.run.candy = (w.run.candy || 0) + d.qty;
  w.fx.number(w.player.x + 18, w.player.y - 90, `แคนดี้ +${d.qty}`, 'info');
  audio.play('pickup', { rarity: 2 });
  return true;
}
function crystalToast(w, bits) {
  for (let i = 0; i < 5; i++) if (bits & (1 << i)) { const c = GUARDIAN_CRYSTALS[i]; w.hwApi.app.toast(`${c.name} เข้ากระเป๋าอาร์ติแฟกต์`, 'loot', null, { rarity: 'mythic' }); }
  if (w.hw.crystals === 31) w.hwApi.app.hud.banner('ผลึกทั้งห้ารวมกันเป็น "คริสตัลแห่งจักรวาล"', 'นำไปมอบให้พ่อมดในห้องถัดไป');
  w.hwApi.audio.play('legendary');
}

// ------------------------------------------------------------------ my hero
export function hwCurseMe(w, id) {
  const c = getCurse(id); if (!c) return;
  const H = w.hw, p = w.player;
  const first = !(H.curses[id] > 0);
  H.curses[id] = Math.max(H.curses[id] || 0, c.dur);
  if (id === 'freeze') p.stunT = Math.max(p.stunT || 0, c.dur);
  if (id === 'mute') w.silence?.(c.dur);
  if (first) { w.fx.callout(p.x, p.y - 150, c.name, c.col); w.hwApi.audio.play('silenced'); }
}
// how much harder a blow lands on me (rust, fragile)
export function hwHurtMult(w) {
  const C = w.hw?.curses; if (!C) return 1;
  return (C.rust > 0 ? 1.5 : 1) * (C.fragile > 0 ? 1.35 : 1);
}
export function hwMyDmgMult(w) { return w.hw?.curses?.weak > 0 ? 0.7 : 1; }
// before a blow: the Light Guardian's clash replaces it when I am swinging too
export function hwBeforeHurt(w, owner, mult, opts) {
  const p = w.player, H = w.hw;
  if (!H || p.dead) return false;
  if (H.mirror && !opts.mirror) return true;                    // in the mirror world nothing outside can touch me
  if (opts.clash && !H.clash && p.move && (p.move.phase === 'windup' || p.move.phase === 'active')) { startClash(w, opts.ownerId ?? owner?.id); return true; }
  if (H.clash) return true;
  return false;
}
// the cross: in the wizard's dungeon, the first lethal blow is cancelled (one cross is used up)
export function hwLethal(w, amount) {
  const p = w.player;
  if (!isSecretRoom(w) || amount < p.hp) return amount;
  const { store, app, audio } = w.hwApi;
  if (countItem(store.get(), 'p_hw_cross') <= 0) return amount;
  const r = removeItem(store.get(), 'p_hw_cross', 1);
  if (!r.ok) return amount;
  store.commit(r.state, { reason: 'cross', persist: false });
  p.hp = Math.round(p.maxHp * 0.5); p.iframes = 2;
  w.fx.ring(p.x, p.y - 40, 10, 150, '#fff3c4', 0.8, 8); app.hud.banner('ไม้กางเขนพ่อมดแตกสลาย', 'กันความตายได้ 1 ครั้ง'); audio.play('levelup');
  return 0;
}

// ------------------------------------------------------------------ every frame (my side)
export function hwTick(w, dt, intent) {
  const H = w.hw, p = w.player;
  if (!H) return;
  H.candyCd -= dt;
  // curses
  const C = H.curses;
  for (const k of Object.keys(C)) { C[k] -= dt; if (C[k] <= 0) delete C[k]; }
  if (!p.dead) {
    if (C.slow > 0) p.chillT = Math.max(p.chillT || 0, 0.12);
    if (C.mute > 0) p.silenceT = Math.max(p.silenceT || 0, 0.12);
    if (C.blind > 0) w.darkT = Math.max(w.darkT || 0, 0.7);
    if (C.confuse > 0) { intent.mx = -intent.mx; intent.my = -intent.my; }
    if (C.heavy > 0) intent.dash = false;
    if (C.clumsy > 0 && intent.attack && w.hwApi.rng.next() < 0.4) { intent.attack = false; w.fx.callout(p.x, p.y - 120, 'มือลื่น!', '#ff9ac8'); }
    if (C.dizzy > 0) { intent.mx += Math.sin(w.time * 5) * 0.7; intent.my += Math.cos(w.time * 4) * 0.5; }
    if (C.hex > 0) for (const s of w.skills) if (s && s.cd > 0) s.cd += dt * 0.5;
    H.dot = (H.dot || 0) + dt;
    if (H.dot >= 0.5) {
      H.dot = 0;
      const pct = (C.poison > 0 ? 0.01 : 0) + (C.burn > 0 ? 0.015 : 0);
      if (pct > 0) { const amt = Math.max(1, Math.round(p.maxHp * pct)); p.hp = Math.max(0, p.hp - amt); w.fx.number(p.x, p.y - 70, amt, 'player'); if (p.hp <= 0) { p.dead = true; p.deathT = 0; p.move = null; w.onPlayerDeath(); } }
    }
    H.hpWas = p.hp;
  }
  if (H.mirror) tickMirror(w, dt, intent);
  if (H.clash) tickClash(w, dt, intent);
  // the emperor's room: heroes rise again (after 3.5 s) while anyone else still stands
  if (w.zone?.id === 'hw_deceiver' && w.enemies.some((e) => e.type?.id === 'hw_emperor' && !e.dead)) {
    if (p.dead) {
      H.respawnT = (H.respawnT || 0) + dt;
      const othersUp = [...w.allies.values()].some((a) => a.seen && !a.ko && a.goneT < 4);
      if (othersUp && H.respawnT > 3.5) { H.respawnT = 0; p.dead = false; p.deathT = 0; p.hp = Math.round(p.maxHp * 0.6); p.iframes = 2.5; p.x = 170; p.y = 540; w.hwApi.app.hud.banner('ฟื้นคืนชีพ', 'ในห้องจักรพรรดิ ผู้เล่นจะเกิดใหม่ไปเรื่อยๆ จนกว่าคนสุดท้ายจะล้ม'); w.hwApi.audio.play('levelup'); }
    } else H.respawnT = 0;
  }
}
// after the frame: "คำสาปไม่ฟื้น" undoes any healing
export function hwPostTick(w) {
  const H = w.hw, p = w.player;
  if (H?.curses.noheal > 0 && !p.dead && H.hpWas != null && p.hp > H.hpWas) p.hp = H.hpWas;
}
// host: room-level timeline (the emperor's healing, the wizard's cinematic)
export function hwHostTick(w, dt) {
  const H = w.hw; if (!H) return;
  // a hero fell: the emperor drinks their life (+10% of its health)
  const emp = w.enemies.find((e) => !e.dead && e.type.id === 'hw_emperor');
  if (emp) {
    const down = new Set(); if (w.player.dead) down.add('me'); for (const a of w.allies.values()) if (a.seen && a.ko) down.add(a.peer);
    for (const k of down) if (!H.downed.has(k)) { emp.hp = Math.min(emp.maxHp, emp.hp + Math.round(emp.maxHp * 0.1)); w.announce('จักรพรรดิดูดพลังชีวิตจากผู้ที่ล้ม (+10%)'); w.fx.ring(emp.x, emp.y - 120, 20, 200, '#fff3c4', 0.7, 8); }
    H.downed = down;
  } else H.downed.clear();
  for (const e of w.enemies) if (e.hwFoe) hwFoeTick(e, dt);
  if (H.cine) tickCine(w, dt);
}

// ------------------------------------------------------------------ the mirror world (Jack-o'-lantern)
export function startMirror(w, bossId) {
  const H = w.hw, p = w.player, st = p.stats, A = w.arena;
  if (H.mirror || p.dead) return;
  const def = getEnemy('hw_mirror_self');
  const e = { type: def, id: -77, x: A.w * 0.66, y: A.h * 0.5, vx: 0, vy: 0, r: 20, hp: Math.round(p.maxHp * 2.4), maxHp: Math.round(p.maxHp * 2.4), atk: Math.max(10, Math.round(st.atk * 0.5)), def: st.def, crit: 0, critMult: 1.5,
    state: 'idle', t: 0, flash: 0, dead: false, deathT: 0, spawning: 0, ai: {}, hitstun: 0, sx: 1, sy: 1, hwLocal: true, warn: 0 };
  H.mirror = { t: 0, e, bossId, from: { x: p.x, y: p.y }, at: { x: p.x, y: p.y } };
  p.x = A.w * 0.34; p.y = A.h * 0.5; p.vx = p.vy = 0; p.iframes = 1;
  w.hwApi.app.hud.banner('โลกกระจก', 'เอาชนะเงาของตัวเอง! ชนะ = แจ็กเสียเลือด 20% · แพ้ = ล้มทันที');
  w.hwApi.audio.play('godIntro');
}
function tickMirror(w, dt, intent) {
  const H = w.hw, M = H.mirror, e = M.e, p = w.player;
  M.t += dt;
  if (e.flash > 0) e.flash -= dt * 6;
  if (!e.dead) {
    const d = Math.hypot(p.x - e.x, p.y - e.y), a = Math.atan2(p.y - e.y, p.x - e.x);
    e.t += dt; e.flip = p.x < e.x;
    const step = (k) => { e.vx += (Math.cos(a) * 230 * k - e.vx) * Math.min(1, dt * 6); e.vy += (Math.sin(a) * 230 * k - e.vy) * Math.min(1, dt * 6); };
    if (e.state === 'idle' || e.state === 'walk') { step(d > 120 ? 1 : 0); if (e.t > 0.9) { e.state = d < 160 ? 'combo' : (e.ai.n = (e.ai.n || 0) + 1) % 3 === 0 ? 'skill' : 'dash'; e.t = 0; e.ai.k = 0; e.ai.dir = a; } }
    else if (e.state === 'combo') {
      e.vx *= 0.8; e.vy *= 0.8;
      const tel = 0.42;
      e.warn = Math.min(1, (e.t % tel) / tel);
      if (e.t >= tel * (e.ai.k + 1)) {
        e.ai.k += 1; e.ai.dir = a;
        if (d < 150 && Math.abs(angle(a, e.ai.dir)) < 1.2) w.hwApi.hurtMe({ atk: e.atk, crit: 0.1, critMult: 1.5 }, 1.0, Math.cos(a) * 260, Math.sin(a) * 260, false, false, { attacker: e, mirror: true });
        w.fx.slash(e.x, e.y - 30, e.ai.dir, 2.1, 120, 1.2, '#e8f4ff', false, '#bfe3ff');
        w.hwApi.audio.play('swing');
        if (e.ai.k >= 3) { e.state = 'walk'; e.t = 0; e.warn = 0; }
      }
    } else if (e.state === 'dash') {
      if (e.t < 0.45) { e.vx *= 0.8; e.vy *= 0.8; e.warn = e.t / 0.45; }
      else { e.warn = 0; e.vx = Math.cos(e.ai.dir) * 760; e.vy = Math.sin(e.ai.dir) * 760; if (!e.ai.hit && Math.hypot(p.x - e.x, p.y - e.y) < 60) { e.ai.hit = true; w.hwApi.hurtMe({ atk: e.atk, crit: 0, critMult: 1.5 }, 1.2, Math.cos(e.ai.dir) * 320, Math.sin(e.ai.dir) * 320, false, false, { attacker: e, mirror: true }); } }
      if (e.t > 0.8) { e.state = 'walk'; e.t = 0; e.ai.hit = false; }
    } else if (e.state === 'skill') {
      // it uses YOUR first skill slot's name as it casts a burst — the reflection knows what you know
      e.vx *= 0.8; e.vy *= 0.8; e.warn = Math.min(1, e.t / 0.8);
      if (e.t < dt * 1.5) { const sk = w.skills.find(Boolean); w.fx.callout(e.x, e.y - 140, sk ? `เงาใช้ ${sk.name || 'สกิลของคุณ'}!` : 'เงาใช้สกิลของคุณ!', '#bfe3ff'); }
      if (e.t > 0.8 && !e.ai.hit) { e.ai.hit = true; e.warn = 0; w.fx.ring(e.x, e.y - 20, 20, 190, '#bfe3ff', 0.5, 8); if (Math.hypot(p.x - e.x, p.y - e.y) < 190) w.hwApi.hurtMe({ atk: e.atk, crit: 0, critMult: 1.5 }, 1.5, 0, 0, false, false, { attacker: e, mirror: true }); }
      if (e.t > 1.3) { e.state = 'walk'; e.t = 0; e.ai.hit = false; }
    }
    e.x += e.vx * dt; e.y += e.vy * dt; w.clampBody(e);
  }
  const won = e.dead, lost = p.dead || M.t > MIRROR_TIME;
  if (!won && !lost) return;
  H.mirror = null;
  p.x = M.from.x; p.y = M.from.y; p.vx = p.vy = 0;
  const { app, audio, queue } = w.hwApi;
  if (won) {
    app.hud.banner('ชนะเงาของตัวเอง!', 'แจ็กโอแลนเทิร์นเสียเลือด 20%'); audio.play('victory'); p.iframes = 1.5;
    if (w.amHost) mirrorWin(w, M.bossId); else queue(['hwmr', M.bossId, 1]);
  } else {
    app.hud.banner('แพ้ภาพลวงตา', 'ถูกเงาของตัวเองกลืนกิน');
    if (!p.dead) { p.iframes = 0; w.hwApi.hurtMe({ atk: 99999, crit: 0, critMult: 1 }, 1, 0, 0, false, false, { pct: 0.95, unblockable: true, pierce: true, mirror: true }); if (!p.dead) { p.hp = 0; p.dead = true; p.deathT = 0; w.onPlayerDeath(); } }
  }
}
function mirrorWin(w, bossId) {
  const b = w.enemies.find((x) => x.id === bossId && !x.dead);
  if (!b) return;
  w.hwApi.damageEnemy(b, { amount: Math.max(1, Math.round(b.maxHp * 0.2)), crit: true }, 0, 0, { src: 'mirror' });
  w.announce('ภาพลวงแตกสลาย! แจ็กเสียเลือด 20%');
}
const angle = (a, b) => { let d = a - b; while (d > Math.PI) d -= TAU; while (d < -Math.PI) d += TAU; return d; };
// while in the mirror world my attacks only see the reflection
export function hwSwapIn(w) { const M = w.hw?.mirror; if (!M) return null; const real = w.enemies; w.enemies = M.e.dead ? [] : [M.e]; return real; }
export function hwSwapOut(w, real) { if (real) w.enemies = real; }
// my blow on a local-only monster (the reflection)
export function hwLocalHit(w, e, pkt) {
  const dmg = computeDamage({ atk: pkt.atk, crit: pkt.crit, critMult: pkt.critMult, forceCrit: pkt.forceCrit }, e, w.hwApi.rng, pkt.power * hwMyDmgMult(w));
  e.hp = Math.max(0, e.hp - dmg.amount); e.flash = 1;
  w.fx.number(e.x, e.y - 80, dmg.amount, dmg.crit ? 'crit' : 'hit'); w.hwApi.audio.play(dmg.crit ? 'crit' : 'hit');
  if (e.hp <= 0 && !e.dead) { e.dead = true; e.deathT = 0; w.particles.burst(e.x, e.y - 40, 50, { color: ['#e8f4ff', '#bfe3ff', '#ffffff'], speedMin: 100, speedMax: 420, life: 0.7, size: 4, drag: 3, shape: 1 }); w.hwApi.audio.play('shatter'); }
  return dmg;
}

// ------------------------------------------------------------------ the clash (Light Guardian)
function startClash(w, bossId) {
  const H = w.hw;
  H.clash = { t: 0, me: 0, foe: 0, bossId };
  w.player.stunT = 0; w.player.move = null;
  w.hwApi.app.hud.banner('ปะทะ!', 'กดโจมตีรัวๆ ให้ชนะใน 5 วินาที');
  w.hwApi.audio.play('clash');
  if (w.amHost) { const b = w.enemies.find((x) => x.id === bossId); if (b) b.hwClashT = CLASH_TIME + 0.3; }
  else w.hwApi.queue(['hwc', bossId]);
}
function tickClash(w, dt, intent) {
  const C = w.hw.clash, p = w.player;
  C.t += dt;
  if (intent.attack) { C.me += 1; w.fx.ring(p.x, p.y - 40, 6, 50, '#ffe89a', 0.25, 4); w.hwApi.audio.play('hit'); }
  C.foe += dt * 6.2;                                       // the guardian's strength: about six presses a second
  Object.assign(intent, { attack: false, attackHeld: false, dash: false, skill: -1, race: false, mx: 0, my: 0 });
  if (C.t < CLASH_TIME) return;
  w.hw.clash = null;
  const { app, audio, queue } = w.hwApi;
  if (C.me >= C.foe) {
    app.hud.banner('ชนะการปะทะ!', 'ผู้พิทักษ์แห่งแสงเสียเลือด 20%'); audio.play('victory');
    if (w.amHost) clashWin(w, C.bossId); else queue(['hwcr', C.bossId, 1]);
  } else {
    app.hud.banner('แพ้การปะทะ', 'โดนดาเมจ 50% ของพลังชีวิต'); audio.play('hurt');
    p.hp = Math.max(1, p.hp - Math.round(p.maxHp * 0.5)); w.fx.number(p.x, p.y - 80, Math.round(p.maxHp * 0.5), 'player');
    if (!w.amHost) queue(['hwcr', C.bossId, 0]); else { const b = w.enemies.find((x) => x.id === C.bossId); if (b) b.hwClashT = 0; }
  }
}
function clashWin(w, bossId) {
  const b = w.enemies.find((x) => x.id === bossId && !x.dead);
  if (!b) return;
  b.hwClashT = 0;
  w.hwApi.damageEnemy(b, { amount: Math.max(1, Math.round(b.maxHp * 0.2)), crit: true }, 0, 0, { src: 'clash' });
}

// ------------------------------------------------------------------ network events
export function hwOnEvent(w, ev, peer, fromHost) {
  const [k] = ev, H = w.hw;
  if (!H) return;
  if (k === 'hwm' && fromHost && ev[1] === w.me) startMirror(w, ev[2]);
  else if (k === 'hwmr' && w.amHost && ev[2] === 1) mirrorWin(w, ev[1]);
  else if (k === 'hwc' && w.amHost) { const b = w.enemies.find((x) => x.id === ev[1]); if (b) b.hwClashT = CLASH_TIME + 0.3; }
  else if (k === 'hwcr' && w.amHost) { if (ev[2] === 1) clashWin(w, ev[1]); else { const b = w.enemies.find((x) => x.id === ev[1]); if (b) b.hwClashT = 0; } }
  else if (k === 'hwcu' && fromHost && ev[1] === w.me) hwCurseMe(w, ev[2]);
  else if (k === 'hwtalk' && w.amHost) { H.talked = true; }
  else if (k === 'hwbag' && w.amHost) { if (!H.bag) { H.bag = true; w.hwApi.publishRs(); w.announce('ทุกคนได้รับกระเป๋าเก็บอาร์ติแฟกต์จากพ่อมด'); } }
  else if (k === 'hwheal' && fromHost) healMe(w, 0.1, 'เทพแห่งการสร้างสรรค์ฟื้นพลังให้ทุกคน');
  else if (k === 'hwbeam' && fromHost) beamFx(w, num(ev[1], 0, 3000), num(ev[2], -200, 3000), num(ev[3], 0, 3000), num(ev[4], -200, 3000));
  else if (k === 'hwtp' && fromHost) for (const pl of w.fxs.pools) { pl.kind = 'fire'; pl.mult = Math.max(pl.mult || 0, 0.25); }
  else if (k === 'hwline' && fromHost) w.hwApi.app.hud.banner(String(ev[1] || '').slice(0, 80), String(ev[2] || '').slice(0, 120));
}
function healMe(w, f, text) {
  const p = w.player; if (p.dead) return;
  const before = p.hp; p.hp = Math.min(p.maxHp, p.hp + Math.round(p.maxHp * f));
  if (w.hw) w.hw.hpWas = p.hp;
  w.fx.number(p.x, p.y - 90, `+${p.hp - before}`, 'heal'); w.fx.ring(p.x, p.y - 30, 10, 100, '#fff3a0', 0.6, 6);
  if (text) w.hwApi.app.toast(text, 'ok', 'hwheal');
}
function beamFx(w, x0, y0, x1, y1) {
  (w.hw.beams ||= []).push({ x0, y0, x1, y1, t: 0 });
  w.particles.burst(x1, y1, 16, { color: ['#fff3a0', '#ffffff'], speedMin: 80, speedMax: 260, life: 0.4, size: 3, drag: 4, glow: true });
}

// ------------------------------------------------------------------ rooms
export function hwStartRoom(w, ri) {
  const H = w.hw; if (!H) return;
  H.board = null; H.chamber = 0; H.hold = false; H.talked = false; H.cine = null; H.beams = []; H.mirror = null; H.clash = null;
  const def = w.zone.rooms[ri];
  const ids = Array.isArray(def) ? def.map((x) => x[0]) : [];
  if (ids.includes('hw_g_wisdom')) H.board = makeBoard(w.arena);
  H.room = def?.hw || (Array.isArray(def) ? ids[0] : def);
  if (isSecretRoom(w)) w.floor = paintZoneRoom('hwsecret', { ...w.arena, wall: w.wallPad || 60 }, ri * 41 + 5);
}
// the secret dungeon's room titles (after the scene wrote its own)
export function hwRoomTitle(w) {
  const H = w.hw; if (!H) return;
  if (isSecretRoom(w)) {
    const names = { wizard: 'ห้องของพ่อมดผู้หายสาบสูญ', hw_g_dark: 'ผู้พิทักษ์ 1/5 · ความมืด', hw_g_wisdom: 'ผู้พิทักษ์ 2/5 · ปัญญา', hw_g_light: 'ผู้พิทักษ์ 3/5 · แสงสว่าง', hw_g_alchemy: 'ผู้พิทักษ์ 4/5 · การแปรธาตุ', hw_emperor: 'ผู้พิทักษ์ 5/5 · จักรพรรดิสวรรค์', wrath: 'บทสุดท้าย · แม่มดแห่งความโกรธเกรี้ยว' };
    const subs = { wizard: 'คุยกับพ่อมด (กด E / ปุ่มคุย) · รับกระเป๋าอาร์ติแฟกต์ · ไม้กางเขน 1,000,000 ทอง', hw_g_dark: 'หาตัวจริงที่มีเงาบนพื้น แล้วทำลายเสาในห้องเสาค้ำจุน 5 รอบ', hw_g_wisdom: 'หมากรุกเดินตามกติกาจริง ช่องที่มันผ่าน = เลือด -10% ไม่สนเกราะ', hw_g_light: 'โจมตีพร้อมกับค้อนของมัน = ปะทะ 5 วินาที กดรัวๆ', hw_g_alchemy: 'ระวังวงม่วง: ห้ามใช้สกิล 5 วินาที · หน้ากากชั้น 80 ตีไม่ตาย', hw_emperor: 'ทุกครั้งที่มีคนล้ม จักรพรรดิฟื้นเลือด · ผู้เล่นเกิดใหม่ไปเรื่อยๆ จนคนสุดท้ายล้ม', wrath: 'ช่วยเทพแห่งการสร้างสรรค์สู้ให้ถึงที่สุด' };
    w.hwApi.app.hud.roomTitle(`ดันเจี้ยนลับ · ${names[H.room] || ''}`, `ล้มแล้วเพื่อนกดค้าง ${SECRET_REVIVE} วินาทีเพื่อชุบ (เลือดครึ่งหนึ่ง) · ${subs[H.room] || ''}`);
  }
}
// special rooms: returns true/false like nextWave, or undefined for a normal room
export function hwNextWave(w, def) {
  if (!def || !def.hw) return undefined;
  const H = w.hw, A = w.arena;
  w.wave += 1;
  if (w.wave > 0) return false;
  if (def.hw === 'wizard') {
    H.hold = true; H.holdT = 0;
    w.queue.push({ id: 'hw_wizard_npc', x: A.w * 0.55, y: A.h * 0.45, delay: 0.3 });
    w.announce('พ่อมดผู้หายสาบสูญรออยู่… เดินไปคุยกับเขา');
  } else if (def.hw === 'wrath') {
    H.hold = true;
    w.queue.push({ id: 'hw_wizard_npc', x: A.w * 0.4, y: A.h * 0.45, delay: 0.3 });
    H.cine = { t: 0, step: 0 };
  }
  return true;
}
// the host keeps a room "unfinished" while the wizard talks or the cinematic plays
export function hwHold(w) {
  const H = w.hw; if (!H?.hold) return false;
  if (H.room === 'wizard') { H.holdT = (H.holdT || 0) + 1 / 60; if (H.talked || H.holdT > 60) { H.hold = false; for (const e of w.enemies) if (e.type.id === 'hw_wizard_npc') e.hwKeep = true; } }
  return H.hold;
}
function tickCine(w, dt) {
  const C = w.hw.cine, A = w.arena, api = w.hwApi;
  C.t += dt;
  const line = (big, small) => { api.app.hud.banner(big, small); api.queue(['hwline', big, small]); };
  if (C.step === 0 && C.t > 1) { C.step = 1; line('คริสตัลแห่งจักรวาล', 'ผลึกทั้งห้ารวมกันแล้ว เหล่านักล่ามอบมันให้พ่อมด'); }
  else if (C.step === 1 && C.t > 4.5) { C.step = 2; line('พ่อมดกลายเป็นเทพแห่งการสร้างสรรค์', '"ขอบใจเจ้ามาก… ถึงเวลาสะสางความแค้นที่ถูกหักหลังแล้ว"'); for (const e of w.enemies) if (e.type.id === 'hw_wizard_npc' && !e.dead) api.killEnemy(e, false); api.spawnEnemy('hw_wizard_ally', A.w * 0.4, A.h * 0.45); }
  else if (C.step === 2 && C.t > 8.5) { C.step = 3; line('แม่มดจอมหลอกลวงตื่นขึ้น…', '"เจ้าแย่งพลังของข้าไป!" — เธอกลายเป็นแม่มดแห่งความโกรธเกรี้ยว'); }
  else if (C.step === 3 && C.t > 11) { C.step = 4; api.spawnEnemy('hw_witch_wrath', A.w * 0.66, A.h * 0.45); w.hw.hold = false; w.hw.cine = null; }
}
export function hwPortalAt(w) { return w.hw?.portal && w.zone?.id === 'hw_deceiver' && w.ri === 0 ? HW_PORTAL : null; }

// talking to the wizard (E near him): his story, the bag for everyone, the cross
export function hwInteract(w, intent) {
  const p = w.player, H = w.hw;
  if (!H || p.dead) return null;
  const wiz = (w.amHost ? w.enemies : [...w.views.values()]).find((e) => !e.dead && e.type.id === 'hw_wizard_npc');
  if (!wiz || H.room !== 'wizard') return null;
  const near = Math.hypot(p.x - wiz.x, p.y - wiz.y) < 150;
  if (near && intent.interact && !H.dialog) openWizard(w);
  return near ? 'คุยกับพ่อมด' : 'เดินไปหาพ่อมด';
}
function openWizard(w) {
  const H = w.hw, { app, audio, store, queue } = w.hwApi;
  H.dialog = true;
  audio.play('open');
  let close;
  const crossCount = () => countItem(store.get(), 'p_hw_cross');
  const info = h('small', { class: 'muted' }, `ไม้กางเขนที่มี: ${crossCount()} · ทอง ${store.get().gold.toLocaleString('th-TH')}`);
  const content = h('div', { class: 'modal panel hw-wizard', 'data-modal': 'hw-wizard' },
    h('div', { class: 'eyebrow', style: { textAlign: 'center' } }, 'ดันเจี้ยนลับ · พ่อมดผู้หายสาบสูญ'),
    h('h2', {}, '"ในที่สุดก็มีคนมาถึง…"'),
    h('p', { class: 'muted', style: { margin: 0 } }, 'ข้าเคยเป็นพ่อมดแห่งหอคอยนี้ จนแม่มดผู้นั้นหลอกข้า แล้ววิญญาณเทพผู้พิทักษ์ทั้งห้าจากสวรรค์ก็ขโมยอาร์ติแฟกต์ของข้าไปแบ่งกันเก็บ ข้าขอร้องเจ้า ช่วยตามผลึกทั้งห้ากลับมาที'),
    h('div', { class: 'notice' }, 'ในดันนี้ ใครล้มจะ "ล้มลง" แทนการตาย เพื่อนต้องยืนข้างแล้วกดค้าง 10 วินาทีเพื่อชุบ (ฟื้นเลือดครึ่งหนึ่ง) · ถ้าเล่นคนเดียว ต้องมีไม้กางเขนกันตาย'),
    h('div', { class: 'actions', style: { flexWrap: 'wrap' } },
      h('button', { class: 'btn gold', type: 'button', 'data-action': 'hw-bag', disabled: H.bag, onclick: (ev) => { if (!H.bag) { H.bag = true; if (w.amHost) { w.hwApi.publishRs(); w.announce('ทุกคนได้รับกระเป๋าเก็บอาร์ติแฟกต์จากพ่อมด'); } else queue(['hwbag']); app.toast('ได้รับ "กระเป๋าเก็บอาร์ติแฟกต์" (ทุกคนในทีมได้ด้วย)', 'loot', null, { rarity: 'legendary' }); audio.play('legendary'); ev.currentTarget.disabled = true; } } }, glyph('bag'), H.bag ? 'รับกระเป๋าแล้ว' : 'รับกระเป๋าเก็บอาร์ติแฟกต์'),
      h('button', { class: 'btn', type: 'button', 'data-action': 'hw-buy-cross', onclick: () => {
        const st = store.get();
        if (st.gold < CROSS_PRICE) { app.toast(`ทองไม่พอ (ต้องมี ${CROSS_PRICE.toLocaleString('th-TH')})`, 'warn'); audio.play('error'); return; }
        const r = addItem(st, 'p_hw_cross', 1);
        if (!r.ok) { app.toast('กระเป๋าเต็ม', 'warn'); return; }
        r.state.gold -= CROSS_PRICE; store.commit(r.state, { reason: 'cross-buy' });
        info.textContent = `ไม้กางเขนที่มี: ${crossCount()} · ทอง ${store.get().gold.toLocaleString('th-TH')}`;
        app.toast('ซื้อไม้กางเขนพ่อมดแล้ว (กันตาย 1 ครั้งในดันนี้)', 'ok'); audio.play('buy');
      } }, itemImg('p_hw_cross'), `ซื้อไม้กางเขน ${CROSS_PRICE.toLocaleString('th-TH')} ทอง`)),
    info,
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', 'data-action': 'hw-go', onclick: () => close() }, 'ออกเดินทาง')));
  close = app.modal(content, { onClose: () => { H.dialog = false; if (w.amHost) H.talked = true; else queue(['hwtalk']); } });
}

// ------------------------------------------------------------------ the chessboard
function makeBoard(A) {
  const cell = 108, n = 8;
  const x0 = Math.round((A.w - cell * n) / 2), y0 = 110;
  const B = {
    x0, y0, cell, n,
    center: (c, r) => ({ x: x0 + (c + 0.5) * cell, y: y0 + (r + 0.5) * cell }),
    rect: (c, r) => ({ x: x0 + c * cell, y: y0 + r * cell }),
    cellOf: (x, y) => ({ col: Math.max(0, Math.min(n - 1, Math.floor((x - x0) / cell))), row: Math.max(0, Math.min(n - 1, Math.floor((y - y0) / cell))) }),
    pieces: () => [],
    occupied: (c, r) => B.occ?.has(`${c},${r}`),
  };
  // the best legal move for a piece: the one that ends nearest a hero (sliding pieces stop before another piece)
  B.bestMove = (pc, players) => {
    if (!players.length) return null;
    B.occ = new Set();
    const world = pc.hwWorld;
    void world;
    const k = pc.type.chess, c0 = pc.ai.col, r0 = pc.ai.row;
    const targets = players.map((t) => B.cellOf(t.x, t.y));
    const inside = (c, r) => c >= 0 && r >= 0 && c < n && r < n;
    const moves = [];
    const slide = (dirs) => { for (const [dc, dr] of dirs) { const path = []; for (let s = 1; s < n; s++) { const c = c0 + dc * s, r = r0 + dr * s; if (!inside(c, r)) break; path.push({ col: c, row: r }); moves.push({ to: { col: c, row: r }, path: path.slice() }); } } };
    const step = (list) => { for (const [dc, dr] of list) { const c = c0 + dc, r = r0 + dr; if (inside(c, r)) moves.push({ to: { col: c, row: r }, path: [{ col: c, row: r }] }); } };
    const ORTHO = [[1, 0], [-1, 0], [0, 1], [0, -1]], DIAG = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
    if (k === 'rook') slide(ORTHO);
    else if (k === 'bishop') slide(DIAG);
    else if (k === 'queen') slide([...ORTHO, ...DIAG]);
    else if (k === 'king') step([...ORTHO, ...DIAG]);
    else if (k === 'knight') step([[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]]);
    else {
      // pawn: one square forward (toward the nearest hero's row); takes diagonally when a hero stands there
      const t = targets.reduce((a, b) => (Math.abs(b.row - r0) + Math.abs(b.col - c0) < Math.abs(a.row - r0) + Math.abs(a.col - c0) ? b : a));
      const fwd = t.row === r0 ? (pc.ai.side || 1) : Math.sign(t.row - r0);
      for (const dc of [-1, 1]) if (targets.some((x) => x.col === c0 + dc && x.row === r0 + fwd)) moves.push({ to: { col: c0 + dc, row: r0 + fwd }, path: [{ col: c0 + dc, row: r0 + fwd }] });
      if (!moves.length && inside(c0, r0 + fwd)) moves.push({ to: { col: c0, row: r0 + fwd }, path: [{ col: c0, row: r0 + fwd }] });
      if (!moves.length) pc.ai.side = -(pc.ai.side || 1);
    }
    if (!moves.length) return null;
    let best = null, bd = Infinity;
    for (const m of moves) { const d = Math.min(...targets.map((t) => Math.hypot(t.col - m.to.col, t.row - m.to.row))) + Math.random() * 0.3; if (d < bd) { bd = d; best = m; } }
    return best;
  };
  return B;
}

// ------------------------------------------------------------------ drawing
export function hwDrawGround(ctx, w) {
  const H = w.hw; if (!H) return;
  const t = w.time;
  if (H.board) {
    const B = H.board;
    ctx.save(); ctx.globalAlpha = 0.85;
    for (let r = 0; r < B.n; r++) for (let c = 0; c < B.n; c++) { ctx.fillStyle = (r + c) % 2 ? 'rgba(26,36,56,0.82)' : 'rgba(232,236,244,0.55)'; ctx.fillRect(B.x0 + c * B.cell, B.y0 + r * B.cell, B.cell, B.cell); }
    ctx.globalAlpha = 1; ctx.strokeStyle = '#5fb0ff'; ctx.lineWidth = 4; ctx.strokeRect(B.x0, B.y0, B.cell * B.n, B.cell * B.n);
    ctx.fillStyle = 'rgba(232,244,255,0.6)'; ctx.font = '700 16px system-ui'; ctx.textAlign = 'center';
    for (let i = 0; i < 8; i++) { ctx.fillText('abcdefgh'[i], B.x0 + (i + 0.5) * B.cell, B.y0 + B.cell * 8 + 22); ctx.fillText(String(8 - i), B.x0 - 18, B.y0 + (i + 0.6) * B.cell); }
    ctx.restore();
  }
  if (H.chamber > 0) {
    // the pillar chamber: the room turns violet and fog creeps in from the walls
    ctx.save(); ctx.fillStyle = `rgba(40,14,70,${0.35 + 0.08 * Math.sin(t * 2)})`; ctx.fillRect(0, 0, w.arena.w, w.arena.h);
    for (let i = 0; i < 10; i++) { const g = ctx.createRadialGradient((i * 173) % w.arena.w, (i * 97) % w.arena.h, 10, (i * 173) % w.arena.w, (i * 97) % w.arena.h, 200); g.addColorStop(0, 'rgba(122,58,255,0.18)'); g.addColorStop(1, 'rgba(122,58,255,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, w.arena.w, w.arena.h); }
    ctx.restore();
  }
  // the black ??? portal of the Deceiver's room
  const P = hwPortalAt(w);
  if (P && w.rphase === 'clear') {
    ctx.save(); ctx.translate(P.x, P.y - 60);
    for (let i = 0; i < 5; i++) { ctx.strokeStyle = `rgba(${i % 2 ? '122,58,255' : '20,8,30'},${0.9 - i * 0.14})`; ctx.lineWidth = 7 - i; ctx.beginPath(); ctx.ellipse(0, 0, 56 + i * 10 + Math.sin(t * 3 + i) * 4, 92 + i * 10, 0, 0, TAU); ctx.stroke(); }
    const g = ctx.createRadialGradient(0, 0, 4, 0, 0, 90); g.addColorStop(0, '#000000'); g.addColorStop(0.7, 'rgba(20,6,30,0.95)'); g.addColorStop(1, 'rgba(122,58,255,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, 0, 60, 96, 0, 0, TAU); ctx.fill();
    ctx.font = '900 46px "Chonburi", serif'; ctx.textAlign = 'center'; ctx.lineWidth = 6; ctx.strokeStyle = '#05030a'; ctx.fillStyle = '#c88aff';
    ctx.strokeText('???', 0, -122 + Math.sin(t * 2) * 4); ctx.fillText('???', 0, -122 + Math.sin(t * 2) * 4);
    ctx.restore();
    if (Math.random() < 0.5) w.particles.spawn({ x: P.x + (Math.random() - 0.5) * 100, y: P.y - 20, vx: 0, vy: -50, life: 1, size: 4, size2: 0.5, color: '#7a3aff', drag: 0.5, glow: true });
  }
}
export function hwDrawWorld(ctx, w, drawHeroFn) {
  const H = w.hw; if (!H) return;
  const p = w.player, t = w.time;
  // the wizard's beams
  for (let i = (H.beams || []).length - 1; i >= 0; i--) {
    const b = H.beams[i]; b.t += 1 / 60; if (b.t > 0.4) { H.beams.splice(i, 1); continue; }
    ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = `rgba(255,243,160,${0.9 - b.t * 2})`; ctx.lineWidth = 10 * (1 - b.t * 2); ctx.beginPath(); ctx.moveTo(b.x0, b.y0); ctx.lineTo(b.x1, b.y1); ctx.stroke(); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 3; ctx.stroke(); ctx.restore();
  }
  // curses over my head
  const list = Object.entries(H.curses).filter(([, v]) => v > 0);
  if (list.length && !p.dead) {
    ctx.save(); ctx.font = '700 12px "Bai Jamjuree", system-ui'; ctx.textAlign = 'center';
    list.slice(0, 5).forEach(([id, left], i) => { const c = getCurse(id); const y = p.y - 150 - i * 18; const tw = ctx.measureText(c.name).width + 26; ctx.fillStyle = 'rgba(15,10,20,0.8)'; ctx.fillRect(p.x - tw / 2, y - 12, tw, 16); ctx.fillStyle = c.col; ctx.fillRect(p.x - tw / 2, y - 12, 4, 16); ctx.fillStyle = '#fff'; ctx.fillText(`${c.name} ${Math.ceil(left)}`, p.x + 2, y); });
    ctx.restore();
  }
  // the mirror world
  if (H.mirror) {
    const A = w.arena, M = H.mirror;
    ctx.save();
    ctx.fillStyle = 'rgba(8,6,16,0.94)'; ctx.fillRect(-200, -200, A.w + 400, A.h + 400);
    for (let i = 0; i < 9; i++) {
      const x = 80 + i * ((A.w - 160) / 8), y = 120 + (i % 2) * 30;
      const g = ctx.createLinearGradient(x - 50, y, x + 50, y + 260); g.addColorStop(0, 'rgba(191,232,255,0.28)'); g.addColorStop(0.5, 'rgba(120,160,200,0.12)'); g.addColorStop(1, 'rgba(191,232,255,0.22)');
      ctx.fillStyle = g; ctx.fillRect(x - 46, y, 92, 260); ctx.strokeStyle = '#3a4a68'; ctx.lineWidth = 4; ctx.strokeRect(x - 46, y, 92, 260);
      ctx.strokeStyle = `rgba(255,255,255,${0.25 + 0.2 * Math.sin(t * 2 + i)})`; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x - 30, y + 20); ctx.lineTo(x + 10, y + 120); ctx.stroke();
    }
    for (const [x, y] of [[180, A.h - 120], [A.w - 180, A.h - 120], [A.w / 2, A.h - 90]]) { drawPumpkin(ctx, x, y, 26, t, 0); const g2 = ctx.createRadialGradient(x, y, 4, x, y, 160); g2.addColorStop(0, 'rgba(255,160,60,0.3)'); g2.addColorStop(1, 'rgba(255,160,60,0)'); ctx.fillStyle = g2; ctx.fillRect(x - 160, y - 160, 320, 320); }
    ctx.restore();
    // the reflection: my own hero, mirrored, pale and shimmering
    const e = M.e;
    if (!e.dead || e.deathT < 0.6) drawHeroFn?.({ x: e.x, y: e.y, flip: !!e.flip, alpha: e.dead ? 0.3 : 0.88, flash: e.flash > 0 ? e.flash : e.warn > 0 ? 0.15 + 0.2 * Math.abs(Math.sin(t * 20)) : 0, tint: true });
    if (!e.dead) { const bw = 140, by = e.y - 150; ctx.fillStyle = 'rgba(15,10,20,0.85)'; ctx.fillRect(e.x - bw / 2 - 1, by - 1, bw + 2, 9); ctx.fillStyle = '#bfe3ff'; ctx.fillRect(e.x - bw / 2, by, bw * (e.hp / e.maxHp), 7); ctx.font = '700 13px system-ui'; ctx.textAlign = 'center'; ctx.fillStyle = '#e8f4ff'; ctx.fillText('เงาในกระจก', e.x, by - 6); }
  }
}
// screen-space HUD of the event (after the world): clash bars, the Deceiver's damage meter, the artifact bag
export function hwDrawScreen(ctx, w, v) {
  const H = w.hw; if (!H) return;
  const t = w.time;
  if (H.clash) {
    const C = H.clash, cx = v.w / 2, cy = v.h * 0.32, W = Math.min(520, v.w - 40);
    ctx.save(); ctx.fillStyle = 'rgba(10,8,6,0.8)'; ctx.fillRect(cx - W / 2 - 10, cy - 50, W + 20, 100);
    ctx.font = '900 26px "Chonburi", serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#fff3c4'; ctx.fillText(`ปะทะ! กดโจมตีรัวๆ  ${Math.max(0, CLASH_TIME - C.t).toFixed(1)}`, cx, cy - 16);
    const tot = Math.max(1, C.me + C.foe), k = C.me / tot;
    ctx.fillStyle = '#ffe89a'; ctx.fillRect(cx - W / 2, cy + 6, W * k, 22); ctx.fillStyle = '#c2412f'; ctx.fillRect(cx - W / 2 + W * k, cy + 6, W * (1 - k), 22);
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.strokeRect(cx - W / 2, cy + 6, W, 22);
    ctx.font = '700 14px system-ui'; ctx.fillStyle = '#1a100c'; ctx.textAlign = 'left'; ctx.fillText(`คุณ ${C.me}`, cx - W / 2 + 8, cy + 22); ctx.textAlign = 'right'; ctx.fillText(`ผู้พิทักษ์ ${Math.floor(C.foe)}`, cx + W / 2 - 8, cy + 22);
    ctx.restore();
  }
  if (H.mirror) {
    ctx.save(); ctx.font = '900 22px "Chonburi", serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#bfe3ff'; ctx.strokeStyle = '#05030a'; ctx.lineWidth = 5;
    const txt = `โลกกระจก · เหลือ ${Math.max(0, MIRROR_TIME - H.mirror.t).toFixed(0)} วินาที`; ctx.strokeText(txt, v.w / 2, 120); ctx.fillText(txt, v.w / 2, 120); ctx.restore();
  }
  // the Deceiver: how close the party is to 1,000,000
  if (w.zone?.id === 'hw_deceiver' && w.ri === 0 && !H.portal) {
    const list = w.amHost ? w.enemies : [...w.views.values()];
    const b = list.find((e) => !e.dead && e.type?.id === 'hw_witch_deceiver');
    if (b) {
      const done = Math.max(0, DECEIVER_THRESHOLD - b.hp);
      const txt = `ดาเมจรวมใส่แม่มด ${Math.round(done).toLocaleString('th-TH')} / ${DECEIVER_THRESHOLD.toLocaleString('th-TH')}`;
      ctx.save(); ctx.font = '700 15px "Bai Jamjuree", system-ui'; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(15,10,20,0.75)';
      const tw = ctx.measureText(txt).width + 24; ctx.fillRect(v.w / 2 - tw / 2, v.h - 120, tw, 26); ctx.fillStyle = '#c88aff'; ctx.fillText(txt, v.w / 2, v.h - 102); ctx.restore();
    }
  }
  // the artifact bag
  if (H.bag && isSecretRoom(w)) {
    const x0 = v.w - 214, y0 = 92;
    ctx.save(); ctx.fillStyle = 'rgba(15,10,20,0.78)'; ctx.fillRect(x0 - 8, y0 - 22, 210, 52);
    ctx.font = '700 12px "Bai Jamjuree", system-ui'; ctx.fillStyle = '#e0b45a'; ctx.textAlign = 'left'; ctx.fillText(H.crystals === 31 ? 'กระเป๋าอาร์ติแฟกต์ · คริสตัลแห่งจักรวาล' : 'กระเป๋าอาร์ติแฟกต์', x0, y0 - 6);
    GUARDIAN_CRYSTALS.forEach((c, i) => { const got = H.crystals & (1 << i), x = x0 + 18 + i * 38, y = y0 + 12; ctx.globalAlpha = got ? 1 : 0.25; ctx.fillStyle = c.col; ctx.beginPath(); ctx.moveTo(x, y - 12); ctx.lineTo(x + 9, y); ctx.lineTo(x, y + 12); ctx.lineTo(x - 9, y); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#1a100c'; ctx.lineWidth = 2; ctx.stroke(); if (got && H.crystals === 31) { ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = `rgba(255,255,255,${0.3 + 0.3 * Math.sin(t * 6 + i)})`; ctx.fill(); ctx.globalCompositeOperation = 'source-over'; } });
    ctx.restore();
  }
}
export function hwDrawPortalOverride(w) { return !!hwPortalAt(w); }
export function hwFinish(w, next, outcome) {
  if (!w.zone?.hw) return;
  if (outcome === 'victory' && w.zone.id === 'hw_deceiver' && w.hw?.crystals === 31) next.hw.secretClears = Math.max(next.hw.secretClears, 1);
}
