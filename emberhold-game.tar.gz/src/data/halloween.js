// v10 กิจกรรมฮาโลวีน (Halloween event). Everything the event needs that is pure data: its clock, the candy currency,
// the fifteen curses the witches throw (and the twin pistols copy), and the three animated skins of every event weapon.
//
// The event runs for HW_EVENT.days days from HW_EVENT.start. When it ends the portal in the village closes, the candy
// shop and the demon cauldron go away; everything already bought or found stays in the bag (event items are permanent).
// The server can move the end (admin panel → กิจกรรม): setHwEnd() takes that value when the game hears it.

export const HW_EVENT = Object.freeze({
  start: Date.UTC(2026, 10, 2, 17, 0, 0),     // 3 พ.ย. 2569 00:00 (เวลาไทย)
  days: 15,
});
let endOverride = null;
export function setHwEnd(ms) { endOverride = Number.isFinite(ms) && ms > HW_EVENT.start ? ms : null; }
export const hwEnd = () => endOverride ?? HW_EVENT.start + HW_EVENT.days * 86400000;
export const hwActive = (now = Date.now()) => now >= HW_EVENT.start && now < hwEnd();
export const hwLeftMs = (now = Date.now()) => Math.max(0, hwEnd() - now);
// "12 วัน 04:31:09" — days, then hours:minutes:seconds
export function fmtCountdown(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const d = Math.floor(s / 86400), hh = Math.floor((s % 86400) / 3600), mm = Math.floor((s % 3600) / 60), ss = s % 60;
  const p = (n) => String(n).padStart(2, '0');
  return `${d} วัน ${p(hh)}:${p(mm)}:${p(ss)}`;
}
export function countdownParts(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  return { d: Math.floor(s / 86400), h: Math.floor((s % 86400) / 3600), m: Math.floor((s % 3600) / 60), s: s % 60 };
}

export const CANDY_MAX = 99_999_999;

// ------------------------------------------------------------------ the fifteen curses (สถานะลบ)
// Player side: thrown by แม่มดจอมล่อลวง (and a few other event monsters). Each one is shown with its own icon colour
// above the hero and in the HUD while it lasts. Enemy side (`foe`): what the twin pumpkin pistols do with the same curse.
export const HW_CURSES = Object.freeze([
  { id: 'slow', name: 'ขาพันใยแมงมุม', col: '#9a8ad0', dur: 5, txt: 'เดินช้าลง 45%', foe: { slow: 0.55, t: 2.5 } },
  { id: 'weak', name: 'แขนอ่อนปวกเปียก', col: '#c8b48a', dur: 6, txt: 'ดาเมจที่ทำลดลง 30%', foe: { atkDown: 0.25, t: 4 } },
  { id: 'rust', name: 'เกราะผุกร่อน', col: '#b8643a', dur: 6, txt: 'พลังป้องกันลดลง 50%', foe: { mark: 0.25, t: 4 } },
  { id: 'mute', name: 'ปากถูกเย็บ', col: '#c8c8ff', dur: 4, txt: 'ใช้สกิลไม่ได้', foe: { poise: 6 } },
  { id: 'blind', name: 'ม่านหมอกดำ', col: '#3a2a4a', dur: 4, txt: 'มองเห็นแค่รอบตัว', foe: { atkDown: 0.15, t: 3 } },
  { id: 'confuse', name: 'มึนหัวกลับด้าน', col: '#ff7ad8', dur: 4, txt: 'ปุ่มเดินกลับด้าน', foe: { stun: 0.5 } },
  { id: 'poison', name: 'พิษฟักทองเน่า', col: '#8ad04a', dur: 6, txt: 'เสียเลือด 2% ต่อวินาที', foe: { burn: true } },
  { id: 'burn', name: 'ไฟผีลวก', col: '#5ae0ff', dur: 4, txt: 'เสียเลือด 3% ต่อวินาที', foe: { burn: true } },
  { id: 'freeze', name: 'น้ำแข็งศพ', col: '#cfeaff', dur: 1.2, txt: 'แข็งค้าง ขยับไม่ได้', foe: { stun: 0.8 } },
  { id: 'heavy', name: 'ตุ้มถ่วงขา', col: '#7a7068', dur: 5, txt: 'หลบไม่ได้', foe: { slow: 0.7, t: 3 } },
  { id: 'fragile', name: 'กระดูกเปราะ', col: '#efe4cc', dur: 6, txt: 'รับดาเมจเพิ่ม 35%', foe: { mark: 0.3, t: 4 } },
  { id: 'noheal', name: 'คำสาปไม่ฟื้น', col: '#6a1a2a', dur: 7, txt: 'ฟื้นเลือดไม่ได้', foe: { mark: 0.15, t: 5 } },
  { id: 'clumsy', name: 'มือลื่นขนม', col: '#ff9ac8', dur: 5, txt: 'โจมตีพลาดบ่อย 40%', foe: { atkDown: 0.2, t: 3 } },
  { id: 'dizzy', name: 'ตาลายลูกอม', col: '#ffd84a', dur: 4, txt: 'ตัวเซไปมาเอง', foe: { stun: 0.4 } },
  { id: 'hex', name: 'นาฬิกาสาป', col: '#b86aff', dur: 6, txt: 'คูลดาวน์สกิลช้าลงครึ่งหนึ่ง', foe: { slow: 0.75, t: 3 } },
]);
export const CURSE_IDS = Object.freeze(HW_CURSES.map((c) => c.id));
export const getCurse = (id) => HW_CURSES.find((c) => c.id === id) || null;

// ------------------------------------------------------------------ animated weapon skins
// Three per event weapon. A skin re-colours the weapon (its own sprite is drawn when first needed) and adds a living
// effect around the hero that never stops (fx). tier 1..3: price and how loud the effect is.
const S = (wid, n, name, tier, fx, art) => ({ id: `${wid}~${n}`, wid, n, name, tier, fx, art });
export const HW_SKINS = Object.freeze([
  S('w_hw_pumpkin_cannon', 1, 'ฟักทองเรืองแสงจันทร์', 1, 'moonglow', { body: '#3a5a8a', glow: '#bfe3ff', trim: '#e8f4ff' }),
  S('w_hw_pumpkin_cannon', 2, 'ปืนใหญ่ผีดิบเขียว', 2, 'ectoplasm', { body: '#4a8a3a', glow: '#9fff7a', trim: '#2a3a1a' }),
  S('w_hw_pumpkin_cannon', 3, 'ราชันฟักทองทองคำ', 3, 'goldpumpkins', { body: '#e0b45a', glow: '#fff3c4', trim: '#7a4a10' }),
  S('w_hw_pumpkin_blade', 1, 'ดาบเถาวัลย์ราตรี', 1, 'vines', { blade: '#3a6a3a', edge: '#b8ff8a', glow: '#6aff5a' }),
  S('w_hw_pumpkin_blade', 2, 'ดาบไฟผีน้ำเงิน', 2, 'bluefire', { blade: '#2a3a8a', edge: '#9fe8ff', glow: '#5ae0ff' }),
  S('w_hw_pumpkin_blade', 3, 'ดาบยิ้มกระชากวิญญาณ', 3, 'grins', { blade: '#1a0a14', edge: '#ff8a1f', glow: '#ffb648' }),
  S('w_hw_reaper_scythe', 1, 'เคียวหมอกหลุมศพ', 1, 'gravefog', { blade: '#8a90a0', shaft: '#2a2a34', glow: '#d8e0f0' }),
  S('w_hw_reaper_scythe', 2, 'เคียวโลหิตจันทร์', 2, 'bloodmoon', { blade: '#8a1a1a', shaft: '#1a0a0a', glow: '#ff4a4a' }),
  S('w_hw_reaper_scythe', 3, 'เคียวพันดวงวิญญาณ', 3, 'souls', { blade: '#e8f4ff', shaft: '#3a2a5a', glow: '#b8f0ff' }),
  S('w_hw_witch_broom', 1, 'ไม้กวาดหมอกม่วง', 1, 'purplemist', { wood: '#4a2a5a', orb: '#c88aff', trim: '#e0b8ff' }),
  S('w_hw_witch_broom', 2, 'ไม้กวาดค้างคาวราตรี', 2, 'bats', { wood: '#1a1424', orb: '#ff5a7a', trim: '#7a2a3a' }),
  S('w_hw_witch_broom', 3, 'ไม้กวาดดาวตกแม่มดหลวง', 3, 'stardust', { wood: '#2a2a5a', orb: '#fff3a0', trim: '#e0b45a' }),
  S('w_hw_twin_pistols', 1, 'ปืนคู่ลูกกวาดขาวแดง', 1, 'candycane', { body: '#f0f0f0', glow: '#ff5a5a', trim: '#c2412f' }),
  S('w_hw_twin_pistols', 2, 'ปืนคู่ใยแมงมุมเงิน', 2, 'webs', { body: '#5a5a6a', glow: '#e8e8ff', trim: '#1a1a24' }),
  S('w_hw_twin_pistols', 3, 'ปืนคู่สิบห้าคำสาป', 3, 'curses', { body: '#2a0a3a', glow: '#ff7ad8', trim: '#ffd84a' }),
  S('w_hw_candy_lance', 1, 'หอกมาร์ชเมลโลว์', 1, 'sugar', { shaft: '#ffe8f0', trim: '#ff9ac8', glow: '#ffffff' }),
  S('w_hw_candy_lance', 2, 'หอกช็อกโกแลตเดือด', 2, 'cocoa', { shaft: '#5a3020', trim: '#c88a5a', glow: '#ffcf8a' }),
  S('w_hw_candy_lance', 3, 'หอกเยลลี่สายรุ้ง', 3, 'rainbow', { shaft: '#7affd8', trim: '#ff7ad8', glow: '#fff3a0' }),
  S('w_hw_muramasa', 1, 'มุรามาสะหิมะโลหิต', 1, 'sakura', { blade: '#f4f0f0', edge: '#ffffff', glow: '#ff7a9a' }),
  S('w_hw_muramasa', 2, 'มุรามาสะคราบหมึกปีศาจ', 2, 'ink', { blade: '#d8d0e0', edge: '#ffffff', glow: '#7a3aff' }),
  S('w_hw_muramasa', 3, 'มุรามาสะคืนพระจันทร์สีเลือด', 3, 'bloodmoon', { blade: '#ffe8e8', edge: '#ffffff', glow: '#ff2a3a' }),
]);
export const getSkin = (id) => HW_SKINS.find((s) => s.id === id) || null;
export const skinsOf = (wid) => HW_SKINS.filter((s) => s.wid === wid);
// the living effect each event weapon has even without a skin
export const BASE_FX = Object.freeze({
  w_hw_pumpkin_cannon: 'pumpkinsmoke', w_hw_pumpkin_blade: 'embers', w_hw_reaper_scythe: 'souls', w_hw_witch_broom: 'purplemist',
  w_hw_twin_pistols: 'curses', w_hw_candy_lance: 'sugar', w_hw_muramasa: 'muramasa',
});

// ------------------------------------------------------------------ the wizard's quest (secret dungeon)
export const GUARDIAN_CRYSTALS = Object.freeze([
  { id: 'dark', name: 'ผลึกแห่งความมืด', col: '#7a3aff' },
  { id: 'wisdom', name: 'ผลึกแห่งปัญญา', col: '#5fb0ff' },
  { id: 'light', name: 'ผลึกแห่งแสงสว่าง', col: '#ffe89a' },
  { id: 'alchemy', name: 'ผลึกแห่งการแปรธาตุ', col: '#6fe08a' },
  { id: 'truth', name: 'ผลึกแห่งความจริงแท้', col: '#ffffff' },
]);
export const CROSS_PRICE = 1_000_000;
export const DECEIVER_THRESHOLD = 1_000_000;
export const LURE_PITY = 1500;
export const LURE_PISTOL_CHANCE = 0.0001;
