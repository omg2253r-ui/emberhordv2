// v10 candy shop transactions (pure: state in → new state out).
import { cloneState } from '../core/state.js';
import { addItem, countItem } from './inventory.js';
import { getItem, EQUIP_SLOTS } from '../data/items.js';
import { hwActive } from '../data/halloween.js';
import { getPet, MAX_STARS } from '../data/pets.js';
import { getDesign } from '../data/market.js';

const ownsItem = (st, id) => countItem(st, id) > 0 || EQUIP_SLOTS.some((s) => st.equipment[s]?.id === id);
function pay(state, price) {
  if (!hwActive()) return { ok: false, reason: 'event_over' };
  if ((state.candy || 0) < price) return { ok: false, reason: 'candy' };
  return null;
}
export function buyWithCandy(state, id, price) {
  const no = pay(state, price); if (no) return no;
  const r = addItem(state, id, 1);
  if (!r.ok) return r;
  r.state.candy -= price;
  return { ok: true, state: r.state };
}
export function buyPet(state, petId, price) {
  const pet = getPet(petId); if (!pet) return { ok: false, reason: 'unknown' };
  const cur = state.pets.owned[petId];
  if (cur && cur.stars >= MAX_STARS) return { ok: false, reason: 'max_stars' };
  const no = pay(state, price); if (no) return no;
  const next = cloneState(state); next.candy -= price;
  next.pets.owned[petId] = { stars: cur ? cur.stars + 1 : 1 };
  return { ok: true, state: next, star: !!cur };
}
export function buyStall(state, designId, price) {
  const d = getDesign(designId); if (!d) return { ok: false, reason: 'unknown' };
  if (state.market.designs[designId] || d.free) return { ok: false, reason: 'owned' };
  if (d.halloween) { const no = pay(state, price); if (no) return no; }
  else if (state.gold < price) return { ok: false, reason: 'gold' };
  const next = cloneState(state);
  if (d.halloween) next.candy -= price; else next.gold -= price;
  next.market.designs[designId] = 1;
  return { ok: true, state: next };
}
export function setMask(state, on) {
  if (on && !ownsItem(state, 'c_hw_spite_mask')) return { ok: false, reason: 'not_owned' };
  const next = cloneState(state); next.hw.mask = !!on; return { ok: true, state: next };
}
export { ownsItem };
