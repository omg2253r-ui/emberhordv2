// v10 ตั้งค่า › จอยเกม: every game action can be put on any gamepad button. Press "เปลี่ยน" and then the button.
import { h, glyph } from './dom.js';
import { PAD_ACTIONS, DEFAULT_PAD, bindingsOf, buttonName } from '../engine/padMap.js';
import { readPad } from '../engine/input.js';

export function openPadRemap(app) {
  let close, listening = null, raf = 0, prev = [];
  const status = h('div', { class: 'pad-status notice' });
  const grid = h('div', { class: 'pad-map' });
  function paint() {
    const map = bindingsOf(app.store.get().settings.pad), pad = readPad();
    status.replaceChildren(glyph('dice'), pad ? `เชื่อมต่อแล้ว: ${pad.id.slice(0, 60)}` : 'ยังไม่พบจอย กดปุ่มใดก็ได้บนจอยเพื่อให้เบราว์เซอร์เห็น');
    status.className = `pad-status notice ${pad ? 'ok' : 'warn'}`;
    grid.replaceChildren(...PAD_ACTIONS.flatMap((a) => [
      h('span', {}, a.name),
      h('button', { class: `btn sm${listening === a.id ? ' listening' : ''}`, type: 'button', 'data-pad-action': a.id, onclick: () => { listening = listening === a.id ? null : a.id; prev = (readPad()?.buttons || []).map((b) => b.pressed); paint(); } },
        listening === a.id ? 'กดปุ่มบนจอย…' : buttonName(map[a.id])),
    ]));
  }
  function save(action, button) {
    const map = bindingsOf(app.store.get().settings.pad);
    // a button does one thing: whatever had it before takes this action's old button
    const old = map[action];
    for (const [k, v] of Object.entries(map)) if (v === button && k !== action) map[k] = old;
    map[action] = button;
    app.updateSettings({ pad: map });
  }
  function loop() {
    raf = requestAnimationFrame(loop);
    const pad = readPad();
    if (!pad || !listening) return;
    const now = pad.buttons.map((b) => b.pressed);
    const i = now.findIndex((p, k) => p && !prev[k]);
    prev = now;
    if (i >= 0) { save(listening, i); app.audio.play('unlock'); listening = null; paint(); }
  }
  const onConn = () => paint();
  window.addEventListener('gamepadconnected', onConn); window.addEventListener('gamepaddisconnected', onConn);
  const content = h('div', { class: 'modal panel', 'data-modal': 'pad-remap' },
    h('h2', {}, 'ปรับปุ่มจอยเกม'), status,
    h('p', { class: 'muted', style: { margin: 0, fontSize: 'var(--step--1)' } }, 'สติ๊กซ้าย / ปุ่มลูกศร = เดิน · สติ๊กขวา = เล็งทิศ · ในหน้าเมนู: สติ๊ก/ลูกศร เลื่อน, A กด, B ปิด, LB/RB เปลี่ยนแท็บ'),
    grid,
    h('div', { class: 'actions' },
      h('button', { class: 'btn', type: 'button', 'data-action': 'pad-default', onclick: () => { app.updateSettings({ pad: { ...DEFAULT_PAD } }); listening = null; paint(); } }, 'ค่าเริ่มต้น'),
      h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'เสร็จ')));
  close = app.modal(content, { onClose: () => { cancelAnimationFrame(raf); window.removeEventListener('gamepadconnected', onConn); window.removeEventListener('gamepaddisconnected', onConn); } });
  paint(); loop();
  return close;
}
