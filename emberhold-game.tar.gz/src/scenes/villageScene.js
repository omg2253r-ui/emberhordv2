// Ember Crossing (หมู่บ้านทางแยกถ่าน): the online hub. Every player whose presence says zone "village" walks
// here; positions arrive as presence (~10×/s) and are smoothed. Tap or press E near someone to open their card
// (friend / party / duel). The gate at the bottom leads back to camp, the notice board explains the online rules.
import { drawHero } from '../battle/heroDraw.js';
import { getItem } from '../data/items.js';
import { getWeaponType } from '../data/weapons.js';
import { teamOf } from '../systems/pets.js';
import { drawTitleLine } from '../ui/nameplate.js';
import { badgeTier } from '../data/titles.js';
import { getPet } from '../data/pets.js';
import { LOTS, MARKET } from '../data/market.js';
import { hwActive, hwLeftMs, countdownParts } from '../data/halloween.js';
import { drawPumpkin } from '../art/hwShots.js';
import { drawHwAura, myHwLook } from '../battle/hwLook.js';
import { drawJobGround, drawJobHead } from '../battle/jobLook.js';
import { drawRankLine } from '../ui/nameplate.js';
import { drawGiftBox } from '../art/giftBox.js';
import { createLighting, createFireworks, createWanderers, createFall, drawGhost, drawButterfly, drawRuneCircle, drawBeam, drawArc, viewRect, fxAmount, rand, hexA } from './ambientFx.js';
// v10.1 houses: where their windows glow and their chimneys smoke (relative to each house sprite's anchor)
const HOUSES = [[520, 330], [1000, 300], [1480, 330]];
const FLOWER_BEDS = [[860, 520], [1150, 760], [470, 1050], [1550, 1020]];
const HW_PUMPKINS = [[1080, 760], [1150, 820], [1220, 880], [1290, 940], [1360, 1000], [1420, 1060], [940, 1120], [1060, 1120], [900, 1200], [1100, 1200], [1590, 1060], [1610, 1180]];

export const VILLAGE = Object.freeze({
  w: 4300, h: 1300,          // v10: the market street runs east of the old village (x 2150 → 4250)
  spawn: { x: 1000, y: 1010 },
  fountain: { x: 1000, y: 640 },
  gate: { x: 1000, y: 1262 },
  ring: { x: 1640, y: 700 },
  board: { x: 760, y: 900 },
  rift: { x: 380, y: 1090 },
  chief: { x: 1240, y: 486 },
  hwPortal: { x: 1500, y: 1110 },   // v10: ประตูมิติแห่งโลกฮาโลวีน (while the event runs)
  marketArch: { x: 2120, y: 830 },
  pot: { x: 1320, y: 830 },          // v10: หม้อปรุงทุกสรรพสิ่ง (permanent)
  windmill: { x: 2060, y: 420 },
  speed: 270,
  sendEvery: 0.1,
  talkRange: 110,
});

const V = VILLAGE;
const V_RIFT = VILLAGE.rift;

// [sprite, x, y, collider] — colliders: {r} circle at the anchor, or {w, h} box whose bottom edge sits at the anchor.
const DECOR = [
  ['v_house_red', 520, 330, { w: 190, h: 90 }], ['v_house_gold', 1000, 300, { w: 190, h: 90 }], ['v_house_teal', 1480, 330, { w: 190, h: 90 }],
  ['v_stall_fruit', 330, 600, { w: 120, h: 40 }], ['v_stall_trinket', 330, 820, { w: 120, h: 40 }],
  ['v_banner_red', 1430, 560, { r: 12 }], ['v_banner_teal', 1850, 560, { r: 12 }], ['v_banner_red', 1430, 860, { r: 12 }], ['v_banner_teal', 1850, 860, { r: 12 }],
  ['v_board', V.board.x, V.board.y, { w: 110, h: 24 }],
  ['v_forge', V.chief.x + 120, V.chief.y - 6, { w: 150, h: 30 }],
  ['v_gate', V.gate.x, V.gate.y, null],
  ['lantern', 860, 1100, { r: 10 }], ['lantern', 1140, 1100, { r: 10 }], ['lantern', 700, 640, { r: 10 }], ['lantern', 1300, 640, { r: 10 }],
  ['v_rift', V_RIFT.x, V_RIFT.y, { w: 150, h: 24 }], ['crates', 160, 900, { r: 40 }], ['crates', 1760, 1080, { r: 40 }],
  ['tree0', 120, 300, { r: 30 }], ['tree1', 1880, 300, { r: 30 }], ['tree2', 160, 1150, { r: 30 }], ['tree0', 1850, 1180, { r: 30 }],
  ['tree1', 760, 160, { r: 30 }], ['tree2', 1240, 160, { r: 30 }], ['tree0', 1980, 760, { r: 30 }], ['tree1', 30, 720, { r: 30 }],
  ['bush', 640, 1180, { r: 24 }], ['bush', 1360, 1180, { r: 24 }], ['bush', 200, 470, { r: 24 }], ['bush', 1800, 450, { r: 24 }],
  ['flowers', 860, 520, null], ['flowers', 1150, 760, null], ['flowers', 470, 1050, null], ['flowers', 1550, 1020, null],
  // v10 market street: trees along the back wall, lanterns between the rows, crates at the far end
  ['tree0', 2300, 300, { r: 30 }], ['tree2', 2900, 290, { r: 30 }], ['tree1', 3500, 300, { r: 30 }], ['tree0', 4100, 290, { r: 30 }],
  ['lantern', 2200, 560, { r: 10 }], ['lantern', 2200, 920, { r: 10 }], ['lantern', 4200, 560, { r: 10 }], ['lantern', 4200, 920, { r: 10 }],
  ['crates', 4220, 1220, { r: 40 }], ['bush', 2240, 1250, { r: 24 }], ['flowers', 3000, 1260, null], ['flowers', 3700, 1260, null],
];

export function blocked(x, y, r = 18) {
  if (x < 60 + r || x > V.w - 60 - r || y < 360 + r * 0.5 || y > V.h - 40) return true;
  // fountain basin (ellipse)
  const fx = (x - V.fountain.x) / (104 + r), fy = (y - (V.fountain.y - 12)) / (40 + r * 0.6);
  if (fx * fx + fy * fy < 1) return true;
  for (const [, dx, dy, c] of DECOR) {
    if (!c) continue;
    if (c.r && Math.hypot(x - dx, y - dy) < c.r + r) return true;
    if (c.w && x > dx - c.w / 2 - r && x < dx + c.w / 2 + r && y > dy - c.h - r * 0.5 && y < dy + r * 0.5) return true;
  }
  if (Math.hypot(x - V.chief.x, (y - V.chief.y) * 1.6) < 26 + r) return true;
  if (Math.hypot(x - V.windmill.x, (y - V.windmill.y) * 1.6) < 60 + r) return true;
  if (Math.hypot(x - V.pot.x, (y - V.pot.y) * 1.6) < 44 + r) return true;
  for (const px of [V.marketArch.x - 6, V.marketArch.x + 6]) if (Math.abs(x - px) < 14 + r && (Math.abs(y - (V.marketArch.y - 230)) < 20 + r || Math.abs(y - (V.marketArch.y + 230)) < 20 + r)) return true;
  // gate posts
  for (const px of [V.gate.x - 78, V.gate.x + 78]) if (Math.abs(x - px) < 16 + r && y > V.gate.y - 30) return true;
  return false;
}

export function createVillageScene(app) {
  const { renderer, input, sprites, audio } = app;
  const ctx = renderer.ctx;
  let w = null;
  let ground = null;

  function paintGround() {
    const c = document.createElement('canvas'); c.width = V.w; c.height = V.h;
    const g = c.getContext('2d');
    // dusk meadow
    const sky = g.createLinearGradient(0, 0, 0, V.h);
    sky.addColorStop(0, '#2a3a26'); sky.addColorStop(1, '#2f3d27');
    g.fillStyle = sky; g.fillRect(0, 0, V.w, V.h);
    let seed = 7;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    for (let i = 0; i < 2600; i++) {
      g.fillStyle = ['rgba(70,96,52,0.35)', 'rgba(36,52,30,0.4)', 'rgba(96,120,64,0.25)'][i % 3];
      const x = rnd() * V.w, y = rnd() * V.h; g.fillRect(x, y, 2 + rnd() * 5, 2 + rnd() * 4);
    }
    // back wall: a low stone wall behind the houses
    g.fillStyle = '#1f2a1c'; g.fillRect(0, 0, V.w, 220);
    // dirt paths
    g.strokeStyle = '#6b5a40'; g.lineCap = 'round';
    const path = (pts, wdt) => { g.lineWidth = wdt; g.beginPath(); g.moveTo(...pts[0]); for (const p of pts.slice(1)) g.lineTo(...p); g.stroke(); };
    path([[V.fountain.x, V.fountain.y], [V.gate.x, V.h]], 150);
    path([[V.fountain.x, V.fountain.y], [300, 700]], 120);
    path([[V.fountain.x, V.fountain.y], [V.ring.x, V.ring.y]], 120);
    path([[520, 340], [V.fountain.x, V.fountain.y], [1480, 340]], 90);
    path([[V.fountain.x, V.fountain.y], [1000, 320]], 100);
    // cobbled plaza
    g.fillStyle = '#7a6b58'; g.beginPath(); g.ellipse(V.fountain.x, V.fountain.y + 30, 400, 260, 0, 0, Math.PI * 2); g.fill();
    g.strokeStyle = '#5a4c3c'; g.lineWidth = 6; g.stroke();
    for (let i = 0; i < 1300; i++) {
      const a = rnd() * Math.PI * 2, rr = Math.sqrt(rnd());
      const x = V.fountain.x + Math.cos(a) * rr * 390, y = V.fountain.y + 30 + Math.sin(a) * rr * 250;
      g.fillStyle = ['#8a7a64', '#6d604f', '#93836b'][i % 3];
      g.strokeStyle = 'rgba(40,30,22,0.55)'; g.lineWidth = 1.5;
      g.beginPath(); g.roundRect(x - 9, y - 6, 16 + rnd() * 6, 10 + rnd() * 4, 3); g.fill(); g.stroke();
    }
    // v10 market street: a cobbled square with a walkway in front of every row of lots
    g.fillStyle = '#6e604e'; g.beginPath(); g.roundRect(2150, 380, 2100, 900, 40); g.fill();
    g.strokeStyle = '#4c4034'; g.lineWidth = 6; g.stroke();
    for (let i = 0; i < 4200; i++) {
      const x = 2160 + rnd() * 2080, y = 390 + rnd() * 880;
      g.fillStyle = ['#7c6d58', '#655846', '#857560'][i % 3]; g.strokeStyle = 'rgba(40,30,22,0.45)'; g.lineWidth = 1.2;
      g.beginPath(); g.roundRect(x - 8, y - 5, 14 + rnd() * 5, 9 + rnd() * 3, 3); g.fill(); g.stroke();
    }
    for (const ry of MARKET.rows) { g.fillStyle = 'rgba(40,30,22,0.22)'; g.fillRect(2170, ry + 18, 2060, 46); }
    // lot plots: a pale outline and the lot number painted on the stones
    g.font = '700 15px "Bai Jamjuree", system-ui'; g.textAlign = 'center';
    for (const l of LOTS) { g.strokeStyle = 'rgba(245,212,138,0.35)'; g.lineWidth = 2; g.setLineDash([6, 5]); g.strokeRect(l.x - 44, l.y - 30, 88, 40); g.setLineDash([]); g.fillStyle = 'rgba(245,212,138,0.45)'; g.fillText(String(l.n), l.x, l.y + 36); }
    path([[V.fountain.x, V.fountain.y], [2150, 830]], 110);
    // the Halloween portal's ring of scorched grass
    g.fillStyle = 'rgba(40,20,50,0.55)'; g.beginPath(); g.ellipse(V.hwPortal.x, V.hwPortal.y, 130, 44, 0, 0, Math.PI * 2); g.fill();
    // the duel ring is part of the ground
    const ring = sprites.v_duel_ring;
    if (ring) g.drawImage(ring.canvas, V.ring.x - ring.ax * 1.3, V.ring.y - ring.ay * 1.3, ring.w * 1.3, ring.h * 1.3);
    g.font = '400 22px "Chonburi", serif'; g.textAlign = 'center'; g.fillStyle = 'rgba(245,212,138,0.55)';
    g.fillText('ลานประลอง', V.ring.x, V.ring.y + 160);
    ground = c;
  }

  // ------------------------------------------------------------ remote players
  function syncRemote(dt) {
    const seen = new Set();
    for (const x of app.online.peers) {
      if (x.p.zone !== 'village') continue;
      seen.add(x.peer);
      let r = w.remote.get(x.peer);
      if (!r) { r = { peer: x.peer, x: x.p.x, y: x.p.y, walkT: 0, petX: x.p.x - 50, petY: x.p.y, fade: 0 }; w.remote.set(x.peer, r); }
      r.p = x.p; r.by = x.by;
      const k = Math.min(1, dt * 10);
      const jump = Math.hypot(x.p.x - r.x, x.p.y - r.y) > 400;   // teleport rather than skate across the map
      r.x = jump ? x.p.x : r.x + (x.p.x - r.x) * k;
      r.y = jump ? x.p.y : r.y + (x.p.y - r.y) * k;
      r.moving = x.p.moving; r.flip = x.p.flip; r.dash = x.p.dash;
      if (r.moving) r.walkT += dt * 10;
      r.fade = Math.min(1, r.fade + dt * 3);
      followPet(r, dt);
    }
    for (const k of [...w.remote.keys()]) if (!seen.has(k)) w.remote.delete(k);
  }

  // up to three pets trail behind each hero, each in its own spot
  const PET_SPOTS = [[54, 6], [86, -22], [78, 34]];
  function followPet(o, dt) {
    o.petPos ||= PET_SPOTS.map(() => ({ x: o.petX ?? o.x, y: o.petY ?? o.y }));
    PET_SPOTS.forEach(([dx, dy], i) => {
      const q = o.petPos[i], tx = o.x + (o.flip ? dx : -dx), ty = o.y + dy;
      const d = Math.hypot(tx - q.x, ty - q.y);
      if (d > 6) { const k = Math.min(1, dt * (4 - i * 0.6)); q.x += (tx - q.x) * k; q.y += (ty - q.y) * k; }
    });
    o.petX = o.petPos[0].x; o.petY = o.petPos[0].y;
  }

  // ------------------------------------------------------------ my hero
  function move(dt, intent) {
    const p = w.me;
    let mx = intent.mx, my = intent.my;
    if (w.walkTo) {
      const dx = w.walkTo.x - p.x, dy = w.walkTo.y - p.y, d = Math.hypot(dx, dy);
      if (d < 8 || mx || my) w.walkTo = null; else { mx = dx / d; my = dy / d; }
    }
    if (intent.dash && p.dashCd <= 0 && (mx || my)) { p.dashT = 0.18; p.dashCd = 0.6; p.dashDir = Math.atan2(my, mx); audio.play('dash'); }
    p.dashCd -= dt;
    let vx = mx * V.speed, vy = my * V.speed;
    if (p.dashT > 0) { p.dashT -= dt; vx = Math.cos(p.dashDir) * 720; vy = Math.sin(p.dashDir) * 720; }
    const nx = p.x + vx * dt, ny = p.y + vy * dt;
    if (!blocked(nx, p.y)) p.x = nx; else if (w.walkTo) w.walkTo = null;
    if (!blocked(p.x, ny)) p.y = ny; else if (w.walkTo) w.walkTo = null;
    p.moving = Math.hypot(vx, vy) > 10;
    if (p.moving) { p.walkT += dt * 10; if (Math.abs(vx) > 5) p.flip = vx < 0; }
    p.vx = vx;
    followPet(p, dt);
  }

  function publishMe(force) {
    const p = w.me;
    const snap = { z: 'village', x: Math.round(p.x), y: Math.round(p.y), f: p.flip ? 1 : 0, m: p.moving ? 1 : 0, d: p.dashT > 0 ? 1 : 0 };
    const key = `${snap.x},${snap.y},${snap.f},${snap.m},${snap.d}`;
    if (!force && key === w.lastKey) return;
    w.lastKey = key;
    app.online.publish(snap);
  }

  // ------------------------------------------------------------ interaction
  function nearestTarget() {
    const p = w.me;
    let best = null, bd = V.talkRange;
    for (const r of w.remote.values()) {
      const d = Math.hypot(r.x - p.x, r.y - p.y);
      if (d < bd) { bd = d; best = { kind: 'player', r }; }
    }
    if (best) return best;
    if (Math.hypot(p.x - V.gate.x, p.y - (V.gate.y - 40)) < 120) return { kind: 'gate' };
    if (Math.hypot(p.x - V.board.x, p.y - (V.board.y + 20)) < 110) return { kind: 'board' };
    if (Math.hypot((p.x - V.ring.x) / 1.6, p.y - V.ring.y) < 130) return { kind: 'ring' };
    if (Math.hypot(p.x - V.rift.x, p.y - (V.rift.y - 20)) < 130) return { kind: 'rift' };
    if (Math.hypot(p.x - V.chief.x, p.y - V.chief.y) < 120) return { kind: 'chief' };
    if (hwActive() && Math.hypot(p.x - V.hwPortal.x, p.y - V.hwPortal.y) < 120) return { kind: 'hw' };
    if (Math.hypot(p.x - V.pot.x, p.y - (V.pot.y + 20)) < 100) return { kind: 'pot' };
    if (p.x > 2150) { let lb = null, ld = 80; for (const l of LOTS) { const d = Math.hypot(p.x - l.x, p.y - (l.y + 40)); if (d < ld) { ld = d; lb = l; } } if (lb) return { kind: 'lot', lot: lb }; }
    return null;
  }
  function labelFor(t) {
    if (!t) return null;
    if (t.kind === 'player') return `ดูข้อมูล ${t.r.p.name}`;
    if (t.kind === 'gate') return 'กลับค่าย';
    if (t.kind === 'ring') return 'ลานประลอง: ห้อง PvP';
    if (t.kind === 'rift') return 'ประตูมิติ: ดันเจี้ยนรวม';
    if (t.kind === 'chief') return 'คุยกับหัวหน้าหมู่บ้าน: แบบแปลนและตีอาวุธ';
    if (t.kind === 'hw') return 'เข้าประตูมิติแห่งโลกฮาโลวีน';
    if (t.kind === 'pot') return 'หม้อปรุงทุกสรรพสิ่ง';
    if (t.kind === 'lot') { const l = app.market.lots[t.lot.n]; return l ? `ซุ้มของ ${l.owner} (${l.items.length} ชิ้น)` : `ล็อต ${t.lot.n}: ว่าง เช่าตั้งซุ้มได้`; }
    return 'อ่านกระดานประกาศ';
  }
  function activate(t) {
    if (!t) return;
    audio.play('click');
    if (t.kind === 'player') app.village.openPlayer(t.r.peer);
    else if (t.kind === 'gate') app.leaveVillage();
    else if (t.kind === 'ring') app.village.openRooms();
    else if (t.kind === 'rift') app.openZones();
    else if (t.kind === 'chief') app.openCrafting();
    else if (t.kind === 'hw') app.enterHalloween();
    else if (t.kind === 'pot') app.openCauldron('all');
    else if (t.kind === 'lot') app.openMarketLot(t.lot.n);
    else app.village.openBoard();
  }

  // tap / click on the map: on a hero opens the card, elsewhere walks there
  function onPointer(e) {
    if (!w || app.village.blocking()) return;
    const rect = renderer.ctx.canvas.getBoundingClientRect();
    const pt = renderer.screenToWorld(e.clientX - rect.left, e.clientY - rect.top);
    let hit = null, bd = 60;
    for (const r of w.remote.values()) {
      const d = Math.hypot(r.x - pt.x, (r.y - 50) - pt.y);
      if (d < bd) { bd = d; hit = r; }
    }
    if (hit) { audio.play('click'); app.village.openPlayer(hit.peer); return; }
    if (Math.hypot(pt.x - V.board.x, pt.y - (V.board.y - 70)) < 80) { activate({ kind: 'board' }); return; }
    if (Math.hypot(pt.x - V.chief.x, pt.y - (V.chief.y - 70)) < 70) { activate({ kind: 'chief' }); return; }
    if (hwActive() && Math.hypot(pt.x - V.hwPortal.x, pt.y - (V.hwPortal.y - 90)) < 90) { activate({ kind: 'hw' }); return; }
    for (const l of LOTS) if (app.market.lots[l.n] && Math.abs(pt.x - l.x) < 50 && pt.y > l.y - 130 && pt.y < l.y + 10) { activate({ kind: 'lot', lot: l }); return; }
    if (!blocked(pt.x, pt.y)) w.walkTo = { x: pt.x, y: pt.y, t: 0 };
  }

  // ------------------------------------------------------------ frame
  function update(dt) {
    if (!w) return;
    w.time += dt;
    const intent = input.poll();
    if (app.village.blocking()) { intent.mx = 0; intent.my = 0; intent.dash = false; intent.interact = false; }
    move(dt, intent);
    syncRemote(dt);
    w.sendAcc += dt;
    if (w.sendAcc >= V.sendEvery) { w.sendAcc = 0; publishMe(false); }
    w.heartbeat += dt;
    if (w.heartbeat > 5) { w.heartbeat = 0; publishMe(true); }
    w.target = nearestTarget();
    app.hud.setInteract(labelFor(w.target));
    if (intent.interact) activate(w.target);
    if (intent.pause) app.village.toggleMenu();
    // v10: the market (every 15 s), gift boxes on the ground, the game master's trail for dropping boxes
    w.marketAcc += dt; if (w.marketAcc > 15) { w.marketAcc = 0; app.market.refresh(); }
    if (app.gm?.active) app.gm.trail('village', w.me.x, w.me.y);
    for (const b of app.live.boxesIn('village')) if (Math.hypot(b.x - w.me.x, b.y - w.me.y) < 60 && Date.now() - b.at > 2500) app.live.claimBox(b);
    // chat bubbles live 6 s
    for (const [k, b] of w.bubbles) if (w.time - b.t > 6) w.bubbles.delete(k);
    updateFx(dt);
    // ambience
    if (Math.random() < dt * 14) app.particles.spawn({ x: V.fountain.x + (Math.random() - 0.5) * 60, y: V.fountain.y - 80, vx: (Math.random() - 0.5) * 50, vy: -30 - Math.random() * 40, life: 0.8, size: 2.2, size2: 0.4, color: '#bfe3ff', drag: 0.6, glow: true });
    if (Math.random() < dt * 3) app.particles.spawn({ x: Math.random() * V.w, y: 400 + Math.random() * (V.h - 400), vx: (Math.random() - 0.5) * 20, vy: -8 - Math.random() * 10, life: 3, size: 2.4, size2: 0.6, color: '#ffe89a', drag: 0.1, glow: true });
    app.particles.update(dt);
    renderer.update(dt);
    // camera follows the hero, clamped to the map
    const v = renderer.view, cam = renderer.cam;
    cam.zoom = Math.max(0.55, Math.min(1.05, app.touch ? Math.min(v.w / 560, v.h / 560) : Math.min(v.w / 1150, v.h / 720)));
    const halfW = v.w / 2 / cam.zoom, halfH = v.h / 2 / cam.zoom;
    const clamp = (val, lo, hi) => (lo > hi ? (lo + hi) / 2 : Math.max(lo, Math.min(hi, val)));
    const tx = clamp(w.me.x, halfW, V.w - halfW), ty = clamp(w.me.y - 40, halfH, V.h - halfH);
    const k = Math.min(1, dt * 6);
    cam.x += (tx - cam.x) * k; cam.y += (ty - cam.y) * k;
  }

  function partsFor(o, isMe) {
    if (isMe) return { parts: sprites.heroParts, weapon: sprites.weapon, type: getWeaponType(getItem(app.store.get().equipment.weapon.id)?.wtype) };
    const wid = getItem(o.p.weapon) ? o.p.weapon : 'w_rust_blade';
    return { parts: app.heroPartsFor(o.p.armor, o.p.race, o.p.wings), weapon: app.weaponSpriteFor(wid, o.p.skin), type: getWeaponType(getItem(wid)?.wtype), wid };
  }

  function drawPets(o, ids) {
    (ids || []).forEach((petId, i) => {
      const pet = getPet(petId), q = o.petPos?.[i];
      if (!pet || !sprites[pet.sprite] || !q) return;
      const s = sprites[pet.sprite], fly = pet.flying;
      const z = fly ? 40 + Math.sin(w.time * 3 + o.x * 0.01 + i) * 6 : 0;
      ctx.fillStyle = 'rgba(12,8,6,0.3)'; ctx.beginPath(); ctx.ellipse(q.x, q.y, s.w * 0.25, 5, 0, 0, Math.PI * 2); ctx.fill();
      renderer.sprite(s, q.x, q.y - z, { sx: 0.75 * (o.flip ? -1 : 1), sy: 0.75 });
    });
  }

  function drawPerson(o, isMe) {
    const { parts, weapon, type } = partsFor(o, isMe);
    ctx.globalAlpha = isMe ? 1 : o.fade;
    ctx.fillStyle = 'rgba(12,8,6,0.4)'; ctx.beginPath(); ctx.ellipse(o.x, o.y, 22, 8, 0, 0, Math.PI * 2); ctx.fill();
    const jid = isMe ? (app.store.get().job?.own?.[app.store.get().job?.on] ? app.store.get().job.on : null) : o.p.job;   // v10.2 class look
    if (jid) drawJobGround(ctx, o.x, o.y, w.time, jid, 0.95);
    drawHero(renderer, parts, weapon, { x: o.x, y: o.y, flip: o.flip, time: w.time, walkT: o.walkT, moving: o.moving, type, scale: 0.9, dashing: isMe ? o.dashT > 0 : o.dash, vx: o.vx || 0, speed: V.speed, alpha: isMe ? 1 : o.fade });
    drawHwAura(ctx, o.x, o.y, isMe ? myHwLook(app.store.get(), o.flip) : { w: getItem(o.p.weapon) ? o.p.weapon : 'w_rust_blade', sk: o.p.skin, mk: o.p.mask, flip: o.flip }, w.time, 0.9);
    if (jid) drawJobHead(ctx, o.x, o.y, w.time, jid, o.flip, 0.9 / 0.95);
    ctx.globalAlpha = 1;
  }

  function tag(o, isMe) {
    const st = app.store.get();
    const name = isMe ? st.story.name : o.p.name;
    const lv = isMe ? st.player.level : o.p.lv;
    const party = app.online.party;
    const inParty = !isMe && party && party.members.some((m) => m.peer === o.peer);
    const friend = !isMe && o.by && st.social.friends[o.by];
    ctx.font = '700 14px "Bai Jamjuree", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    const gtag = isMe ? st.guild?.tag : o.p.gtag;
    const label = `${gtag ? `[${gtag}] ` : ''}${name}  Lv.${lv}`;
    const y = o.y - 108;
    ctx.lineWidth = 4; ctx.strokeStyle = '#120c09';
    ctx.fillStyle = isMe ? '#f5d48a' : inParty ? '#9fe0a0' : friend ? '#bfe3ff' : '#f3e6c8';
    ctx.strokeText(label, o.x, y); ctx.fillText(label, o.x, y);
    let up = drawTitleLine(ctx, o.x, y - 16, isMe ? st.titles?.equipped : o.p.title, isMe ? badgeTier(st) : o.p.badge);
    up += drawRankLine(ctx, o.x, y - 16 - up, isMe ? (st.settings.showRank === false ? -1 : null) : o.p.rank, isMe ? st.rank?.pts : null);
    if (!isMe && app.live.isGm(o.peer)) { ctx.font = '800 11px "Bai Jamjuree", system-ui'; ctx.fillStyle = '#7fe7ff'; ctx.strokeText('◆ ผู้ดูแลเกม', o.x, y - 18 - up); ctx.fillText('◆ ผู้ดูแลเกม', o.x, y - 18 - up); up += 14; }
    if (!isMe && o.p.busy) { ctx.font = '600 11px "Bai Jamjuree", system-ui, sans-serif'; ctx.fillStyle = '#ffb3a4'; ctx.strokeText(busyText(o.p.busy), o.x, y - 16 - up); ctx.fillText(busyText(o.p.busy), o.x, y - 16 - up); }
    // chat bubble
    const b = w.bubbles.get(isMe ? 'me' : o.peer);
    if (b) bubble(o.x, y - (o.p?.busy ? 34 : 20) - up, b.text, Math.min(1, (6 - (w.time - b.t)) * 2));
  }
  function busyText(b) { return b === 'duel' ? 'กำลังประลอง' : b === 'hunt' ? 'กำลังล่า' : b === 'trade' ? 'กำลังแลกเปลี่ยน' : ''; }

  function bubble(x, y, text, alpha) {
    ctx.save(); ctx.globalAlpha = Math.max(0, alpha);
    ctx.font = '600 14px "Bai Jamjuree", system-ui, sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    const words = Array.from(text);
    const lines = []; let cur = '';
    for (const ch of words) { if (ctx.measureText(cur + ch).width > 220) { lines.push(cur); cur = ch; } else cur += ch; if (lines.length === 3) break; }
    if (lines.length < 3 && cur) lines.push(cur);
    const wd = Math.max(...lines.map((l) => ctx.measureText(l).width)) + 20, ht = lines.length * 19 + 12;
    const bx = x - wd / 2, by = y - ht - 8;
    ctx.fillStyle = 'rgba(243,230,200,0.96)'; ctx.strokeStyle = '#2a1a10'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.roundRect(bx, by, wd, ht, 8); ctx.moveTo(x - 6, by + ht); ctx.lineTo(x, by + ht + 8); ctx.lineTo(x + 6, by + ht); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#2a1a10';
    lines.forEach((l, i) => ctx.fillText(l, bx + 10, by + 16 + i * 19));
    ctx.restore();
  }

  function render() {
    if (!w) return;
    const v = renderer.view;
    renderer.screenSpace();
    ctx.fillStyle = '#16200f'; ctx.fillRect(0, 0, v.w, v.h);
    renderer.worldSpace();
    if (!ground) paintGround();
    ctx.drawImage(ground, 0, 0);
    // walk-to marker
    if (w.walkTo) { ctx.strokeStyle = 'rgba(245,212,138,0.8)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(w.walkTo.x, w.walkTo.y, 16 + Math.sin(w.time * 8) * 3, 7, 0, 0, Math.PI * 2); ctx.stroke(); }
    drawBunting();      // v10: under the stalls and heroes
    // y-sorted world
    const list = [];
    for (const [key, x, y] of DECOR) if (sprites[key]) list.push({ y, draw: () => renderer.sprite(sprites[key], x, y) });
    list.push({ y: V.fountain.y + 10, draw: drawFountain });
    list.push({ y: V.chief.y, draw: drawChief });
    list.push({ y: V.windmill.y, draw: drawWindmill }, { y: V.pot.y, draw: drawPot });
    list.push({ y: V.marketArch.y - 230, draw: () => drawArchPost(-230) }, { y: V.marketArch.y + 230, draw: () => drawArchPost(230) });
    if (hwActive()) { list.push({ y: V.hwPortal.y, draw: drawHwPortal }); HW_PUMPKINS.forEach(([px, py], i) => list.push({ y: py, draw: () => drawPumpkin(ctx, px, py - 12, 12 + (i % 3) * 2, w.time + i, Math.sin(w.time + i) * 0.04, undefined, undefined, !(fxAmount() > 0.5)) })); }
    for (const l of LOTS) { const lot = app.market.lots[l.n]; if (lot) list.push({ y: l.y, draw: () => drawStall(l, lot) }); }
    for (const b of app.live.boxesIn('village')) list.push({ y: b.y, draw: () => drawBox(b) });
    list.push({ y: w.me.y, draw: () => { drawPets(w.me, teamOf(app.store.get())); drawPerson(w.me, true); } });
    for (const r of w.remote.values()) list.push({ y: r.y, draw: () => { drawPets(r, r.p.pets); drawPerson(r, false); } });
    list.sort((a, b) => a.y - b.y);
    for (const o of list) o.draw();
    // v10.1 dusk: lamps, windows, the forge and the portal light the village; clouds drift their shadows over it
    drawLanternStrings();
    for (const b of w.fx.butterflies.list) { const f = FLOWER_BEDS[b.i % FLOWER_BEDS.length]; drawButterfly(ctx, b.x, b.y - 30 + Math.sin(b.t * 3 + b.ph) * 8, b.t, ['#ffd24a', '#7ad0ff', '#ff9ad0', '#ffffff'][b.i % 4]); void f; }
    w.fx.petals.draw(ctx);
    w.fx.fireworks.draw(ctx);
    if (fxAmount() > 0.5) w.fx.light.draw(renderer, villageLights(), { dark: hwActive() ? 'rgba(26,12,48,0.34)' : 'rgba(22,18,46,0.28)' }); else w.fx.light.hide();
    drawBirds(); drawArchTop();
    app.particles.draw(ctx);
    tag(w.me, true);
    for (const r of w.remote.values()) tag(r, false);
    // highlight the current interaction target
    if (w.target?.kind === 'player') { const r = w.target.r; ctx.strokeStyle = 'rgba(245,212,138,0.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(r.x, r.y, 30, 11, 0, 0, Math.PI * 2); ctx.stroke(); }
    renderer.screenSpace();
    if (app.vignette) ctx.drawImage(app.vignette, 0, 0, v.w, v.h);
  }

  // ------------------------------------------------------------ v10.1 ambience
  function makeFx() {
    const amt = fxAmount();
    return {
      light: createLighting(), fireworks: createFireworks(audio), fwWait: 1.5,
      butterflies: createWanderers(Math.round(10 * amt) + 2, { x0: 400, x1: 1700, y0: 480, y1: 1150 }, 50),
      petals: createFall(Math.round(30 * amt), ['#ffc8dc', '#ffe0ea', '#ffb0c8', '#fff0f4']),
      clouds: Array.from({ length: 4 }, (_, i) => ({ x: Math.random() * V.w, y: 300 + i * 260, r: 340 + Math.random() * 200, v: 14 + Math.random() * 10 })),
      ghosts: Array.from({ length: 3 }, (_, i) => ({ a: (i / 3) * Math.PI * 2 })),
    };
  }
  function updateFx(dt) {
    const F = w.fx, amt = fxAmount();
    F.butterflies.update(dt); F.petals.update(dt, viewRect(renderer)); F.fireworks.update(dt);
    for (const c of F.clouds) { c.x += c.v * dt; if (c.x - c.r > V.w) c.x = -c.r; }
    // the event fills the sky over the portal (and now and then over the plaza) with fireworks
    if (hwActive()) {
      F.fwWait -= dt;
      if (F.fwWait <= 0) { F.fwWait = rand(1.6, 3.6); F.fireworks.launch(V.hwPortal.x + rand(-160, 160), V.hwPortal.y - 120, rand(320, 520)); if (Math.random() < 0.4) F.fireworks.launch(V.fountain.x + rand(-300, 300), V.fountain.y - 60, rand(300, 480)); }
      for (const g of F.ghosts) g.a += dt * 0.8;
      if (Math.random() < dt * 10 * amt) { const a = Math.random() * Math.PI * 2; app.particles.spawn({ x: V.hwPortal.x + Math.cos(a) * 160, y: V.hwPortal.y - 100 + Math.sin(a) * 120, vx: -Math.cos(a) * 150, vy: -Math.sin(a) * 110, life: 0.9, size: 3, size2: 0.2, color: Math.random() < 0.5 ? '#c86aff' : '#ff9a3a', drag: 0.2, glow: true }); }
    }
    // chimney smoke and the fountain's spray
    if (Math.random() < dt * 5 * amt) { const [hx, hy] = HOUSES[(Math.random() * HOUSES.length) | 0]; app.particles.spawn({ x: hx + 52, y: hy - 196, vx: rand(4, 18), vy: rand(-36, -20), life: 3.2, size: 7, size2: 18, color: 'rgba(200,200,210,0.32)', drag: 0.2 }); }
    if (Math.random() < dt * 22 * amt) { const a = rand(-0.5, 0.5) - Math.PI / 2; app.particles.spawn({ x: V.fountain.x + rand(-6, 6), y: V.fountain.y - 110, vx: Math.cos(a) * 140, vy: Math.sin(a) * 140, life: 0.9, size: 2.6, size2: 1, color: '#cfeaff', drag: 0.1, grav: 380, glow: true }); }
  }
  function villageLights() {
    const t = w.time, L = [];
    for (const [key, x, y] of DECOR) if (key === 'lantern') L.push({ x: x + 33, y: y - 110, r: 200, col: '#ffcf8a', ga: 0.34 + 0.05 * Math.sin(t * 7 + x) });
    for (const [hx, hy] of HOUSES) L.push({ x: hx, y: hy - 40, r: 210, col: '#ffb860', ga: 0.24 + 0.05 * Math.sin(t * 3 + hx) });
    L.push({ x: V.chief.x + 75, y: V.chief.y - 40, r: 230, col: '#ff8a3a', ga: 0.32 + 0.08 * Math.sin(t * 5) });
    L.push({ x: V.fountain.x, y: V.fountain.y - 30, r: 300, col: '#9fd8ff', ga: 0.22 });
    L.push({ x: V.pot.x, y: V.pot.y - 60, r: 200, col: '#7affd8', ga: 0.24 });
    if (hwActive()) { L.push({ x: V.hwPortal.x, y: V.hwPortal.y - 100, r: 420, col: '#c86aff', ga: 0.4 + 0.08 * Math.sin(t * 4) }); for (const [px, py] of HW_PUMPKINS) L.push({ x: px, y: py - 10, r: 110, col: '#ff9a3a', ga: 0.26 }); }
    for (const ry of MARKET.rows) for (let seg = 0; seg < 4; seg++) for (let k = 1; k <= 3; k++) L.push({ x: 2200 + seg * 510 + k * 127, y: ry - 140, r: 130, col: '#ffcf6a', ga: 0.3 });
    L.push({ x: w.me.x, y: w.me.y - 40, r: 230, a: 0.8 });
    for (const r of w.remote.values()) L.push({ x: r.x, y: r.y - 40, r: 180, a: 0.6 });
    for (const c of w.fx.clouds) L.push({ x: c.x, y: c.y, r: c.r, shade: 0.35 });
    return L.concat(w.fx.fireworks.lights());
  }
  // paper lanterns strung over the market rows, swaying
  function drawLanternStrings() {
    const t = w.time;
    for (const ry of MARKET.rows) for (let seg = 0; seg < 4; seg++) for (let k = 1; k <= 3; k++) {
      const x = 2200 + seg * 510 + k * 127, y = ry - 156 + 34 * 4 * (k / 4) * (1 - k / 4) + 6, sw = Math.sin(t * 2 + k + seg) * 3;
      ctx.strokeStyle = '#2a1a10'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + sw, y + 10); ctx.stroke();
      ctx.fillStyle = ['#e0402a', '#ffb03a', '#e0402a'][k - 1]; ctx.strokeStyle = '#2a1a10'; ctx.beginPath(); ctx.ellipse(x + sw, y + 22, 9, 12, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = 'rgba(255,240,160,0.75)'; ctx.beginPath(); ctx.ellipse(x + sw, y + 22, 4, 8, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#2a1a10'; ctx.fillRect(x + sw - 5, y + 9, 10, 3); ctx.fillRect(x + sw - 5, y + 33, 10, 3);
    }
  }
  // ------------------------------------------------------------ v10 market street, windmill, portal, boxes
  function drawStall(l, lot) {
    const img = app.stallImg(lot.design);
    if (img) ctx.drawImage(img, l.x - 64, l.y - 138, 128, 144);
    // up to three wares on the counter
    lot.items.slice(0, 3).forEach((x, i) => { const ic = app.itemIconImg?.(x.id); if (ic) ctx.drawImage(ic, l.x - 40 + i * 28, l.y - 60, 26, 26); });
    ctx.font = '700 13px "Bai Jamjuree", system-ui'; ctx.textAlign = 'center'; ctx.lineWidth = 4; ctx.strokeStyle = '#120c09';
    ctx.fillStyle = app.market.mine?.lot === l.n ? '#9fe0a0' : '#ffe2a8';
    const t = `ซุ้มของ ${lot.owner}`;
    ctx.strokeText(t, l.x, l.y - 146); ctx.fillText(t, l.x, l.y - 146);
    if (w.target?.kind === 'lot' && w.target.lot.n === l.n) { ctx.strokeStyle = 'rgba(245,212,138,0.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(l.x, l.y + 6, 56, 14, 0, 0, Math.PI * 2); ctx.stroke(); }
  }
  function drawArchPost(dy) {
    const x = V.marketArch.x, y = V.marketArch.y + dy;
    // a long pennant waving from the top of the post
    const t = w.time; ctx.fillStyle = dy < 0 ? '#c2412f' : '#2f6f86'; ctx.strokeStyle = '#120c09'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x, y - 300); for (let i = 0; i <= 8; i++) ctx.lineTo(x + i * 14, y - 300 + Math.sin(t * 5 - i * 0.7) * (2 + i * 1.2) + i * 1.5); for (let i = 8; i >= 0; i--) ctx.lineTo(x + i * 14, y - 278 - i * 1.2 + Math.sin(t * 5 - i * 0.7) * (2 + i * 1.2)); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#5a3a22'; ctx.fillRect(x - 3, y - 310, 6, 50);
    ctx.fillStyle = '#5a3a22'; ctx.strokeStyle = '#120c09'; ctx.lineWidth = 3;
    ctx.fillRect(x - 12, y - 260, 24, 260); ctx.strokeRect(x - 12, y - 260, 24, 260);
    ctx.fillStyle = '#8a5a32'; ctx.beginPath(); ctx.roundRect(x - 20, y - 10, 40, 14, 4); ctx.fill(); ctx.stroke();
  }
  function drawArchTop() {
    const x = V.marketArch.x, y0 = V.marketArch.y - 230, y1 = V.marketArch.y + 230;
    ctx.save(); ctx.translate(x, (y0 + y1) / 2 - 250);
    ctx.fillStyle = '#7a2a1a'; ctx.strokeStyle = '#120c09'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.roundRect(-34, -210, 68, 420, 10); ctx.fill(); ctx.stroke();
    ctx.rotate(-Math.PI / 2); ctx.font = '400 30px "Chonburi", serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#ffd08a'; ctx.fillText('ถนนตลาดทางแยกถ่าน', 0, 10);
    ctx.restore();
  }
  // หม้อปรุงทุกสรรพสิ่ง: a copper still with three coloured pipes; each pipe bubbles in turn
  function drawPot() {
    const { x, y } = V.pot, t = w.time;
    ctx.save(); ctx.translate(x, y);
    ctx.fillStyle = '#3a2a1a'; ctx.fillRect(-46, -8, 92, 10);
    const g = ctx.createLinearGradient(-50, -90, 50, 0); g.addColorStop(0, '#e08a4a'); g.addColorStop(1, '#8a4a22');
    ctx.fillStyle = g; ctx.strokeStyle = '#120c09'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.ellipse(0, -46, 46, 40, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#5a2a12'; ctx.beginPath(); ctx.ellipse(0, -82, 30, 9, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    const cols = ['#7affd8', '#ff7ab8', '#ffd24a'];
    cols.forEach((c, i) => {
      const px = -30 + i * 30;
      ctx.strokeStyle = '#a86a3a'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(px * 0.5, -84); ctx.quadraticCurveTo(px, -130, px * 1.6, -120); ctx.stroke();
      const k = ((t * 0.7 + i / 3) % 1);
      ctx.fillStyle = c; ctx.globalAlpha = 1 - k; ctx.beginPath(); ctx.arc(px * 1.6, -124 - k * 40, 4 + k * 5, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1;
    });
    ctx.restore();
    ctx.font = '700 14px "Bai Jamjuree", system-ui'; ctx.textAlign = 'center'; ctx.lineWidth = 4; ctx.strokeStyle = '#120c09'; ctx.fillStyle = '#7affd8';
    ctx.strokeText('หม้อปรุงทุกสรรพสิ่ง', x, y - 168); ctx.fillText('หม้อปรุงทุกสรรพสิ่ง', x, y - 168);
    if (w.target?.kind === 'pot') { ctx.strokeStyle = 'rgba(245,212,138,0.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(x, y, 54, 14, 0, 0, Math.PI * 2); ctx.stroke(); }
  }
  function drawWindmill() {
    const { x, y } = V.windmill;
    ctx.fillStyle = '#c8b090'; ctx.strokeStyle = '#120c09'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(x - 46, y); ctx.lineTo(x - 26, y - 170); ctx.lineTo(x + 26, y - 170); ctx.lineTo(x + 46, y); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#7a3a22'; ctx.beginPath(); ctx.moveTo(x - 36, y - 168); ctx.lineTo(x, y - 214); ctx.lineTo(x + 36, y - 168); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#5a3a22'; ctx.fillRect(x - 12, y - 46, 24, 46);
    const a = w.time * 0.9;
    ctx.save(); ctx.translate(x, y - 176); ctx.rotate(a);
    for (let i = 0; i < 4; i++) { ctx.rotate(Math.PI / 2); ctx.fillStyle = '#efe4cc'; ctx.strokeStyle = '#120c09'; ctx.lineWidth = 2; ctx.beginPath(); ctx.rect(8, -10, 108, 22); ctx.fill(); ctx.stroke(); ctx.beginPath(); ctx.moveTo(8, 1); ctx.lineTo(116, 1); ctx.stroke(); }
    ctx.fillStyle = '#5a3a22'; ctx.beginPath(); ctx.arc(0, 0, 10, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.restore();
  }
  // flags strung over every walkway of the market, swaying
  function drawBunting() {
    const cols = ['#c2412f', '#e0b45a', '#2f6f86', '#5a8a3a', '#8a3a7a'];
    for (const ry of MARKET.rows) {
      const y = ry - 156;
      for (let seg = 0; seg < 4; seg++) {
        const x0 = 2200 + seg * 510, x1 = x0 + 500, sag = 34;
        ctx.strokeStyle = 'rgba(40,30,20,0.9)'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(x0, y); ctx.quadraticCurveTo((x0 + x1) / 2, y + sag * 2, x1, y); ctx.stroke();
        for (let i = 1; i < 14; i++) {
          const t = i / 14, fx = x0 + (x1 - x0) * t, fy = y + sag * 4 * t * (1 - t) * 1.0, sw = Math.sin(w.time * 2.4 + i + seg + ry * 0.01) * 4;
          ctx.fillStyle = cols[(i + seg) % cols.length]; ctx.beginPath(); ctx.moveTo(fx - 9, fy); ctx.lineTo(fx + 9, fy); ctx.lineTo(fx + sw, fy + 20); ctx.closePath(); ctx.fill();
        }
      }
    }
  }
  function drawBirds() {
    for (let i = 0; i < 7; i++) {
      const k = ((w.time * 60 + i * 610) % (V.w + 800)) - 400, bx = k, by = 120 + Math.sin(w.time * 0.6 + i * 1.7) * 50 + i * 18, f = Math.sin(w.time * 9 + i) * 6;
      ctx.strokeStyle = 'rgba(30,24,20,0.8)'; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.moveTo(bx - 12, by - f); ctx.quadraticCurveTo(bx - 5, by - 6, bx, by); ctx.quadraticCurveTo(bx + 5, by - 6, bx + 12, by - f); ctx.stroke();
    }
  }
  // ประตูมิติแห่งโลกฮาโลวีน: a hanging ring of jack-o'-lanterns around a violet whirl, the countdown written above it
  function drawHwPortal() {
    const { x, y } = V.hwPortal, t = w.time;
    if (fxAmount() > 0.5) { drawRuneCircle(ctx, x, y, 150, t, '#c86aff'); drawBeam(ctx, x, y - 120, 70, 700, t, '#c86aff'); }
    if (Math.sin(t * 3.7) > 0.7) drawArc(ctx, x - 60, y - 200, x + 60 * Math.sin(t), y - 30, '#e0b0ff', 8, 16);
    for (const g of w.fx.ghosts) { const gx = x + Math.cos(g.a) * 150, gy = y - 100 + Math.sin(g.a) * 60; if (Math.sin(g.a) < 0) drawGhost(ctx, gx, gy, t + g.a, Math.cos(g.a + Math.PI / 2) < 0 ? -0.55 : 0.55, 0.55); }
    ctx.save(); ctx.translate(x, y - 100);
    const g = ctx.createRadialGradient(0, 0, 6, 0, 0, 96); g.addColorStop(0, '#ffd27a'); g.addColorStop(0.35, '#b04aff'); g.addColorStop(1, 'rgba(30,10,40,0.9)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, 0, 70, 96, 0, 0, Math.PI * 2); ctx.fill();
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 5; i++) { ctx.strokeStyle = i % 2 ? 'rgba(255,140,40,0.55)' : 'rgba(190,100,255,0.55)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(0, 0, 20 + i * 11, 30 + i * 14, t * (i % 2 ? 1.4 : -1.1), 0.3, 5.4); ctx.stroke(); }
    ctx.globalCompositeOperation = 'source-over';
    ctx.strokeStyle = '#1a0a1a'; ctx.lineWidth = 8; ctx.beginPath(); ctx.ellipse(0, 0, 76, 102, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = '#4a2a14'; ctx.lineWidth = 4; ctx.stroke();
    for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2 + Math.sin(t) * 0.04; drawPumpkin(ctx, Math.cos(a) * 80, Math.sin(a) * 106, 13, t + i, Math.sin(t * 2 + i) * 0.2, undefined, undefined, !(fxAmount() > 0.5)); }
    ctx.restore();
    if (Math.random() < 0.3) app.particles.spawn({ x: x + (Math.random() - 0.5) * 120, y: y - 100 + (Math.random() - 0.5) * 160, vx: 0, vy: -30, life: 1, size: 3, size2: 0.4, color: Math.random() < 0.5 ? '#ff9a3a' : '#c86aff', drag: 0.4, glow: true });
    for (const g of w.fx.ghosts) { const gx = x + Math.cos(g.a) * 150, gy = y - 100 + Math.sin(g.a) * 60; if (Math.sin(g.a) >= 0) drawGhost(ctx, gx, gy, t + g.a, Math.cos(g.a + Math.PI / 2) < 0 ? -0.55 : 0.55, 0.7); }
    const c = countdownParts(hwLeftMs());
    ctx.font = '400 17px "Chonburi", serif'; ctx.textAlign = 'center'; ctx.lineWidth = 5; ctx.strokeStyle = '#120c09'; ctx.fillStyle = '#ff9a3a';
    ctx.strokeText('ประตูมิติแห่งโลกฮาโลวีน', x, y - 250); ctx.fillText('ประตูมิติแห่งโลกฮาโลวีน', x, y - 250);
    ctx.font = '800 15px "Bai Jamjuree", system-ui'; ctx.fillStyle = '#ffe2a8';
    const tt = `เหลือเวลา ${c.d} วัน ${c.h} ชม. ${c.m} นาที ${c.s} วินาที`;
    ctx.strokeText(tt, x, y - 226); ctx.fillText(tt, x, y - 226);
    if (w.target?.kind === 'hw') { ctx.strokeStyle = 'rgba(245,212,138,0.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(x, y, 80, 20, 0, 0, Math.PI * 2); ctx.stroke(); }
  }
  const drawBox = (b) => drawGiftBox(ctx, b, w.time);

  // the chief breathes, turns toward a nearby hero, and his forge glows
  function drawChief() {
    const c = V.chief, spr = sprites.v_chief;
    if (!spr) return;
    const fx = c.x + 120, fy = c.y - 40;
    const g = ctx.createRadialGradient(fx - 45, fy, 2, fx - 45, fy, 70);
    g.addColorStop(0, `rgba(255,150,70,${(0.35 + 0.12 * Math.sin(w.time * 5)).toFixed(3)})`); g.addColorStop(1, 'rgba(255,120,50,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(fx - 45, fy, 70, 0, Math.PI * 2); ctx.fill();
    const face = w.me.x < c.x ? -1 : 1, breathe = 1 + Math.sin(w.time * 2) * 0.015;
    ctx.save(); ctx.translate(c.x, c.y); ctx.scale(face, breathe); ctx.drawImage(spr.canvas, -spr.ax, -spr.ay, spr.w, spr.h); ctx.restore();
    if (Math.random() < 0.08) app.particles.spawn({ x: fx - 45 + (Math.random() - 0.5) * 30, y: fy + 4, vx: (Math.random() - 0.5) * 30, vy: -60 - Math.random() * 40, life: 0.7, size: 2, size2: 0.4, color: '#ffcf5a', drag: 0.8, glow: true });
    ctx.font = '700 15px "Bai Jamjuree", system-ui, sans-serif'; ctx.textAlign = 'center';
    ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(20,12,9,0.85)'; ctx.fillStyle = '#ffd08a';
    ctx.strokeText('หัวหน้าหมู่บ้าน', c.x, c.y - 178); ctx.fillText('หัวหน้าหมู่บ้าน', c.x, c.y - 178);
    if (w.target?.kind === 'chief') { ctx.strokeStyle = 'rgba(245,212,138,0.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(c.x, c.y, 36, 12, 0, 0, Math.PI * 2); ctx.stroke(); }
  }

  function drawFountain() {
    renderer.sprite(sprites.v_fountain, V.fountain.x, V.fountain.y + 10);
    // v10.1 ripples spreading over the basin
    for (let i = 0; i < 3; i++) { const k = (w.time * 0.5 + i / 3) % 1; ctx.strokeStyle = `rgba(220,240,255,${0.5 * (1 - k)})`; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.ellipse(V.fountain.x - 10, V.fountain.y - 18, 14 + k * 70, 4 + k * 14, 0, 0, Math.PI * 2); ctx.stroke(); }
    // water shimmer
    ctx.fillStyle = `rgba(191,227,255,${0.15 + 0.1 * Math.sin(w.time * 3)})`;
    ctx.beginPath(); ctx.ellipse(V.fountain.x - 10, V.fountain.y - 18, 60, 12, 0, 0, Math.PI * 2); ctx.fill();
  }

  return {
    enter() {
      app.particles.clear();
      app.refreshHeroSprites();
      app.market.refresh(true); app.live.poll();
      const at = { ...V.spawn };
      w = {
        time: 0, sendAcc: 0, heartbeat: 0, lastKey: '', target: null, walkTo: null, bubbles: new Map(), remote: new Map(),
        me: { x: at.x + (Math.random() - 0.5) * 360, y: at.y + (Math.random() - 0.5) * 60, flip: false, moving: false, walkT: 0, dashT: 0, dashCd: 0, vx: 0, petX: at.x - 50, petY: at.y }, marketAcc: 99, fx: makeFx(),
        unsub: [],
      };
      w.unsub.push(app.online.on('chat', (line) => { if (line.ch === 'village' || line.ch === 'party') w.bubbles.set(line.me ? 'me' : line.peer, { text: line.text, t: w.time }); }));
      renderer.ctx.canvas.addEventListener('pointerdown', onPointer);
      renderer.cam.x = w.me.x; renderer.cam.y = w.me.y;
      input.setEnabled(true); input.reset();
      app.hud.showVillage();
      audio.music('village');
      publishMe(true);
    },
    exit() {
      w?.fx?.light.hide();
      if (w) for (const u of w.unsub) u();
      renderer.ctx.canvas.removeEventListener('pointerdown', onPointer);
      input.setEnabled(false); app.hud.hide(); app.hud.setMode('dungeon'); audio.stopMusic();
      w = null;
    },
    update, render,
    get world() { return w; },
    // read-only view for tests
    snapshot() {
      if (!w) return null;
      return { me: { x: Math.round(w.me.x), y: Math.round(w.me.y) }, remote: [...w.remote.values()].map((r) => ({ peer: r.peer, name: r.p.name, x: Math.round(r.x), y: Math.round(r.y), race: r.p.race, weapon: r.p.weapon })), target: w.target?.kind || null, lot: w.target?.lot?.n || null, bubbles: w.bubbles.size, lots: Object.keys(app.market.lots).length, boxes: app.live.boxesIn('village').length };
    },
    teleport(x, y) { if (w && !blocked(x, y)) { w.me.x = x; w.me.y = y; } },
  };
}
