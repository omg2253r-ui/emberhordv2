// v10.2 the abilities of the twenty Halloween pets (kinds 'hw*', data/hwPets2.js) and the glow each one always wears.
// Called from battle/pets.js cast(); every hit goes through world.petStrike, the pictures into world.sk.fx (the same
// effect list the skills use) so they look like the rest of the event.
import { nearestEnemy } from './moves.js';
import { addBuff } from './buffs.js';
import { glowSprite } from '../scenes/ambientFx.js';
import '../battle/skillVfx2.js';

const TAU = Math.PI * 2;
const alive = (w) => w.enemies.filter((e) => !e.dead && !(e.spawning > 0) && !e.untargetable && e.type?.ai !== 'egypt_glyph');
const near = (w, x, y, r) => alive(w).filter((e) => Math.hypot(e.x - x, e.y - y) < r + (e.r || 20));
const fx = (w, o) => w.sk?.fx.add(o);
const isBoss = (e) => !!(e.type?.boss || e.boss);
const later = (w, t, fn) => { if (w.sk) w.sk.act({ max: t + 0.5, step: (dt, a) => { if (a.t >= t) { fn(); return false; } return true; } }); else fn(); };
const heal = (w, p, pct) => { if (p.dead || p.hp >= p.maxHp) return; const n = Math.max(1, Math.round(p.maxHp * pct)); p.hp = Math.min(p.maxHp, p.hp + n); w.fx.number(p.x, p.y - 96, `+${n}`, 'heal'); };
const strongest = (w, x, y, r) => near(w, x, y, r).sort((a, b) => (b.hp || 0) - (a.hp || 0))[0] || null;

export const HW_PET_ABIL = {
  hwvine(pet, w, v, h) {
    const ts = near(w, pet.x, pet.y, v.range).slice(0, v.count);
    if (!ts.length) return h.wait();
    for (const e of ts) { fx(w, { type: 'tether', a: pet, b: e, el: 'nature', dur: v.stun + 0.2, waves: 5, amp: 6, lift: 20, lift2: 20 }); w.petStrike(e, v.power, { stun: v.stun, kx: 0, ky: 0 }); }
    w.sfx?.('swing'); pet.glow = 1; return true;
  },
  hwmoth(pet, w, v, h) {
    const p = w.player;
    if (!near(w, p.x, p.y, v.r + 120).length && p.hp >= p.maxHp) return h.wait(0.6);
    fx(w, { type: 'rainfx', x: pet.x, y: pet.y, r: v.r, el: 'holy', dur: 1.2, n: 24 });
    for (const e of near(w, pet.x, pet.y, v.r)) w.petStrike(e, 0.05, { slow: v.slow, slowT: 2.5, kx: 0, ky: 0 });
    heal(w, p, v.healPct); pet.glow = 1; return true;
  },
  hwscare(pet, w, v, h) {
    const t = nearestEnemy(w, pet, 420);
    if (!t) return h.wait(0.6);
    const x = pet.x, y = pet.y;
    fx(w, { type: 'emblem', x, y, r: v.r, el: 'pumpkin', dur: v.duration, sym: 'pumpkin', spin: 0.6 });
    fx(w, { type: 'sym', mode: 'rise', sym: 'wizhat', el: 'pumpkin', x, y: y - 70, size: 44, dur: v.duration });
    if (w.sk) w.sk.act({ max: v.duration + 0.2, step: (dt, a) => {
      for (const e of near(w, x, y, v.r * 1.3)) if (!isBoss(e) && !e.peer) { const ang = Math.atan2(y - e.y, x - e.x); e.vx = (e.vx || 0) + Math.cos(ang) * v.pull * dt; e.vy = (e.vy || 0) + Math.sin(ang) * v.pull * dt; }
      a.acc = (a.acc || 0) + dt; if (a.acc >= 0.5) { a.acc = 0; for (const e of near(w, x, y, v.r)) w.petStrike(e, v.power, { kx: 0, ky: 0 }); }
      return a.t < v.duration;
    } });
    w.sfx?.('telegraph'); pet.glow = 1; return true;
  },
  hwspore(pet, w, v, h) {
    if (!near(w, pet.x, pet.y, v.r + 160).length) return h.wait(0.6);
    const x = pet.x, y = pet.y, p = w.player;
    fx(w, { type: 'field', x, y, r: v.r, el: 'poison', dur: v.duration });
    fx(w, { type: 'ringsyms', x, y, r: v.r * 0.6, el: 'poison', dur: v.duration, sym: 'skull', n: 4, lift: 40, size: 22, spin: 0.8 });
    if (w.sk) w.sk.act({ max: v.duration + 0.2, step: (dt, a) => {
      a.acc = (a.acc || 0) + dt; a.hacc = (a.hacc || 0) + dt;
      if (a.acc >= 0.5) { a.acc = 0; for (const e of near(w, x, y, v.r)) w.petStrike(e, v.power, { kx: 0, ky: 0 }); }
      if (a.hacc >= 1) { a.hacc = 0; if (Math.hypot(p.x - x, p.y - y) < v.r) heal(w, p, v.healPct); }
      return a.t < v.duration;
    } });
    pet.glow = 1; return true;
  },
  hwpumpbomb(pet, w, v, h) {
    const t = nearestEnemy(w, pet, v.range);
    if (!t) return h.wait();
    const x = t.x, y = t.y;
    fx(w, { type: 'lobfx', x: pet.x, y: pet.y - 20, x2: x, y2: y, dur: 0.5, h: 150, sym: 'pumpkin', el: 'pumpkin', size: 34 });
    later(w, 0.5, () => { fx(w, { type: 'shock', x, y, r: v.r, el: 'pumpkin', dur: 0.4 }); fx(w, { type: 'sym', mode: 'pop', sym: 'pumpkin', el: 'pumpkin', x, y: y - 26, size: 40, dur: 0.4 }); for (const e of near(w, x, y, v.r)) w.petStrike(e, v.power, { burn: true, kx: 0, ky: 0 }); w.sfx?.('hit'); });
    pet.glow = 1; return true;
  },
  hwflames(pet, w, v, h) {
    const t = nearestEnemy(w, pet, v.range);
    if (!t) return h.wait();
    const base = Math.atan2(t.y - 30 - h.from.y, t.x - pet.x);
    for (let i = 0; i < v.count; i++) w.firePlayerShot({ kind: 'orb', x: h.from.x, y: h.from.y, angle: base + (i - (v.count - 1) / 2) * 0.35, speed: 480, r: 8, power: v.power, src: 'pet', homing: 4.5, life: 1.5, burn: true, tint: ['255,184,74', '#fff1c2'] });
    w.sfx?.('cast'); pet.glow = 1; return true;
  },
  hwgaze(pet, w, v, h) {
    const t = strongest(w, pet.x, pet.y, v.range);
    if (!t) return h.wait();
    fx(w, { type: 'tether', a: { x: h.from.x, y: h.from.y + 40 }, b: t, el: 'arcane', dur: 0.6, waves: 2, amp: 2, lift: 40 });
    fx(w, { type: 'sym', mode: 'pop', sym: 'eye', el: 'arcane', x: t.x, y: t.y - (t.r || 24) * 2 - 40, size: 44, dur: 1 });
    fx(w, { type: 'mark', x: t.x, y: t.y, el: 'arcane', dur: v.markT, follow: t, h: (t.r || 24) * 2 + 60 });
    w.petStrike(t, 0.2, { stun: v.stun, mark: v.mark, markT: v.markT, kx: 0, ky: 0 });
    w.sfx?.('telegraph'); pet.glow = 1; return true;
  },
  hwtea(pet, w, v, h) {
    const p = w.player;
    if (p.dead || (!alive(w).length && p.hp >= p.maxHp)) return h.wait(0.6);
    heal(w, p, v.healPct); addBuff(p, 'haste', v.haste, v.duration);
    fx(w, { type: 'halo', x: p.x, y: p.y, el: 'holy', dur: 1.2, follow: p, sym: 'drop' });
    w.sfx?.('potion'); pet.glow = 1; return true;
  },
  hwpeck(pet, w, v, h) {
    const ts = near(w, pet.x, pet.y, v.range).sort((a, b) => Math.hypot(a.x - pet.x, a.y - pet.y) - Math.hypot(b.x - pet.x, b.y - pet.y)).slice(0, v.count);
    if (!ts.length) return h.wait();
    let px = h.from.x, py = h.from.y;
    ts.forEach((e, i) => later(w, i * 0.16, () => { if (e.dead) return; fx(w, { type: 'sym', mode: 'fly', sym: 'raven', el: 'shadow', x: px, y: py, x2: e.x, y2: e.y - 30, size: 30, dur: 0.15 }); px = e.x; py = e.y - 30; w.petStrike(e, v.power, { kx: 0, ky: 0 }); }));
    w.sfx?.('swing'); pet.glow = 1; return true;
  },
  hwsoul(pet, w, v, h) {
    const t = nearestEnemy(w, pet, v.range);
    if (!t) return h.wait();
    fx(w, { type: 'sym', mode: 'fly', sym: 'ghost', el: 'spirit', x: h.from.x, y: h.from.y, x2: t.x, y2: t.y - 30, size: 30, dur: 0.35, h: 40 });
    later(w, 0.35, () => { if (!t.dead) w.petStrike(t, v.power, { kx: 0, ky: 0 }); const p = w.player; fx(w, { type: 'sym', mode: 'fly', sym: 'ghost', el: 'spirit', x: t.x, y: t.y - 30, x2: p.x, y2: p.y - 50, size: 24, dur: 0.4, h: 30 }); later(w, 0.4, () => heal(w, p, v.healPct)); });
    pet.glow = 1; return true;
  },
  hwspin(pet, w, v, h) {
    const p = w.player;
    if (!near(w, p.x, p.y, v.r + 150).length) return h.wait(0.5);
    const sc = fx(w, { type: 'sym', mode: 'agent', sym: 'scythe', el: 'steel', x: p.x, y: p.y, size: 54, dur: v.duration + 0.3, halo: 0.6 });
    if (w.sk && sc) w.sk.act({ max: v.duration + 0.2, step: (dt, a) => {
      const ang = a.t * 9; sc.x = p.x + Math.cos(ang) * v.r * 0.8; sc.y = p.y - 30 + Math.sin(ang) * v.r * 0.45; sc.rot = ang + Math.PI / 2;
      a.acc = (a.acc || 0) + dt; if (a.acc >= 0.3) { a.acc = 0; for (const e of near(w, p.x, p.y, v.r)) w.petStrike(e, v.power, { kx: 0, ky: 0 }); }
      if (a.t >= v.duration) { sc.gone = sc.t; sc.dur = sc.t + 0.3; return false; }
      return true;
    } });
    w.sfx?.('swing'); pet.glow = 1; return true;
  },
  hwreap(pet, w, v, h) {
    const ts = near(w, pet.x, pet.y, v.range);
    if (!ts.length) return h.wait();
    const low = ts.find((e) => !isBoss(e) && !e.peer && e.maxHp && e.hp / e.maxHp <= v.below);
    const t = low || ts[0];
    fx(w, { type: 'sym', mode: 'pop', sym: 'scythe', el: 'spirit', x: t.x, y: t.y - 50, size: 56, dur: 0.5, spin: 8 });
    if (low) { fx(w, { type: 'sym', mode: 'rise', sym: 'ghost', el: 'spirit', x: t.x, y: t.y - 80, size: 40, dur: 0.9 }); w.petStrike(t, 99, { kx: 0, ky: 0 }); }
    else w.petStrike(t, v.power, { kx: 0, ky: 0 });
    w.sfx?.('crit'); pet.glow = 1; return true;
  },
  hwcrumb(pet, w, v, h) {
    if (!alive(w).length) return h.wait(0.6);
    const x = pet.x, y = pet.y;
    fx(w, { type: 'sym', mode: 'pop', sym: 'candy', el: 'candy', x, y: y - 14, size: 28, dur: v.life });
    if (w.sk) w.sk.act({ max: v.life + 0.2, step: (dt, a) => {
      if (a.t > 0.4 && near(w, x, y, v.r * 0.7).length) { fx(w, { type: 'shock', x, y, r: v.r, el: 'candy', dur: 0.35 }); for (const e of near(w, x, y, v.r)) w.petStrike(e, v.power, { slow: v.slow, slowT: 2, kx: 0, ky: 0 }); w.sfx?.('hit'); return false; }
      return a.t < v.life;
    } });
    pet.glow = 1; return true;
  },
  hwsticky(pet, w, v, h) {
    const t = nearestEnemy(w, pet, v.range);
    if (!t) return h.wait();
    const a = Math.atan2(t.y - pet.y, t.x - pet.x);
    pet.dash = { t: 0, dur: 0.22, x0: pet.x, y0: pet.y, x1: t.x, y1: t.y, a, target: t, hit: false, onHit: () => {
      const x = t.x, y = t.y;
      for (let i = 0; i < v.count; i++) { const ang = (i / v.count) * TAU + 0.4, x2 = x + Math.cos(ang) * 90, y2 = y + Math.sin(ang) * 60; fx(w, { type: 'lobfx', x, y: y - 20, x2, y2, dur: 0.35, h: 80, sym: 'candy', el: 'candy', size: 24 }); later(w, 0.35, () => { fx(w, { type: 'shock', x: x2, y: y2, r: v.r, el: 'candy', dur: 0.3 }); for (const e of near(w, x2, y2, v.r)) w.petStrike(e, v.power, { slow: 0.6, slowT: 1.5, kx: 0, ky: 0 }); }); }
      w.petStrike(t, v.power, { kx: 0, ky: 0 });
    } };
    pet.flip = Math.cos(a) < 0; pet.glow = 1; return true;
  },
  hwsugar(pet, w, v, h) {
    const p = w.player;
    if (!alive(w).length) return h.wait(0.6);
    addBuff(p, 'speed', v.speed, v.duration); addBuff(p, 'crit', v.crit, v.duration);
    fx(w, { type: 'ringsyms', x: p.x, y: p.y, r: 60, el: 'candy', dur: 1.2, sym: 'candy', n: 6, lift: 80, size: 22, spin: 4 });
    fx(w, { type: 'halo', x: p.x, y: p.y, el: 'candy', dur: 1.2, follow: p });
    w.sfx?.('gold'); pet.glow = 1; return true;
  },
  hwshell(pet, w, v, h) {
    const p = w.player;
    if (!near(w, p.x, p.y, 360).length) return h.wait(0.6);
    const amt = Math.round(p.maxHp * v.shieldPct);
    if (p.shield < amt) { p.shield = amt; p.shieldMax = amt; }
    p.shieldT = Math.max(p.shieldT, v.duration);
    fx(w, { type: 'dome', x: p.x, y: p.y, el: 'candy', dur: 1.2, r: 58, follow: p });
    fx(w, { type: 'shock', x: pet.x, y: pet.y, r: v.r, el: 'candy', dur: 0.45, band: 30 }); fx(w, { type: 'crack', x: pet.x, y: pet.y, r: v.r, el: 'candy', dur: 1, n: 6 });
    for (const e of near(w, pet.x, pet.y, v.r)) { const a = Math.atan2(e.y - pet.y, e.x - pet.x); w.petStrike(e, v.power, { kx: Math.cos(a) * 220, ky: Math.sin(a) * 220 }); }
    w.shake?.(5, 0.2); w.sfx?.('slam'); pet.glow = 1; return true;
  },
  hwdecoy(pet, w, v, h) {
    const t = nearestEnemy(w, w.player, 460);
    if (!t) return h.wait(0.6);
    const x = (w.player.x + t.x) / 2, y = (w.player.y + t.y) / 2;
    fx(w, { type: 'sym', mode: 'rise', sym: 'mirror', el: 'ice', x, y: y - 50, size: 64, dur: v.duration + 0.2, halo: 1.2 });
    if (w.sk) w.sk.act({ max: v.duration + 0.3, step: (dt, a) => {
      for (const e of near(w, x, y, 320)) if (!isBoss(e) && !e.peer) { const ang = Math.atan2(y - e.y, x - e.x); e.vx = (e.vx || 0) + Math.cos(ang) * v.pull * dt; e.vy = (e.vy || 0) + Math.sin(ang) * v.pull * dt; }
      if (a.t >= v.duration) { fx(w, { type: 'flash', x, y: y - 30, r: v.r, el: 'ice', dur: 0.35, rays: 12 }); fx(w, { type: 'shock', x, y, r: v.r, el: 'ice', dur: 0.45 }); for (const e of near(w, x, y, v.r)) w.petStrike(e, v.power, { kx: 0, ky: 0 }); w.sfx?.('shatter'); return false; }
      return true;
    } });
    pet.glow = 1; return true;
  },
  hwhex(pet, w, v, h) {
    const ts = near(w, pet.x, pet.y, v.range).slice(0, v.count);
    if (!ts.length) return h.wait();
    for (const e of ts) { fx(w, { type: 'sym', mode: 'pop', sym: 'hex', el: 'hex', x: e.x, y: e.y - (e.r || 24) * 2 - 30, size: 34, dur: 0.8 }); w.petStrike(e, 0.1, { mark: v.mark, markT: v.markT, slow: v.slow, slowT: v.markT, kx: 0, ky: 0 }); }
    w.sfx?.('cast'); pet.glow = 1; return true;
  },
  hwsweep(pet, w, v, h) {
    const t = nearestEnemy(w, pet, v.len);
    if (!t) return h.wait();
    const a = Math.atan2(t.y - pet.y, t.x - pet.x), x0 = pet.x, y0 = pet.y, x1 = x0 + Math.cos(a) * v.len, y1 = y0 + Math.sin(a) * v.len;
    fx(w, { type: 'path', x: x0, y: y0, x2: x1, y2: y1, w: v.width, el: 'sun', dur: 0.6, grow: 0.25 });
    fx(w, { type: 'sym', mode: 'fly', sym: 'broom', el: 'sun', x: x0, y: y0 - 30, x2: x1, y2: y1 - 30, size: 40, dur: 0.25 });
    for (const e of alive(w)) { const rx = e.x - x0, ry = e.y - y0, along = rx * Math.cos(a) + ry * Math.sin(a), side = Math.abs(-rx * Math.sin(a) + ry * Math.cos(a)); if (along > 0 && along < v.len && side < v.width + (e.r || 20)) w.petStrike(e, v.power, { kx: Math.cos(a) * 260, ky: Math.sin(a) * 260 }); }
    pet.dash = { t: 0, dur: 0.25, x0, y0, x1, y1, a, target: null, hit: false };
    w.sfx?.('dash'); pet.glow = 1; return true;
  },
  hwtome(pet, w, v, h) {
    const p = w.player, foes = near(w, pet.x, pet.y, 420);
    if (!foes.length && p.hp >= p.maxHp) return h.wait(0.6);
    const pick = !foes.length ? 2 : Math.floor(Math.random() * 3);
    fx(w, { type: 'sym', mode: 'pop', sym: pick === 0 ? 'ember' : pick === 1 ? 'star' : 'heart', el: pick === 0 ? 'fire' : pick === 1 ? 'ice' : 'holy', x: h.from.x, y: h.from.y - 40, size: 40, dur: 0.8 });
    if (pick === 0) { const t = foes[0]; fx(w, { type: 'shock', x: t.x, y: t.y, r: v.r, el: 'fire', dur: 0.45 }); fx(w, { type: 'flash', x: t.x, y: t.y - 30, r: v.r, el: 'fire', dur: 0.3, rays: 12 }); for (const e of near(w, t.x, t.y, v.r)) w.petStrike(e, v.power, { burn: true, kx: 0, ky: 0 }); }
    else if (pick === 1) { fx(w, { type: 'shock', x: pet.x, y: pet.y, r: v.r * 1.6, el: 'ice', dur: 0.5 }); for (const e of near(w, pet.x, pet.y, v.r * 1.6)) w.petStrike(e, v.power * 0.4, { slow: v.slow, slowT: 3, kx: 0, ky: 0 }); }
    else { heal(w, p, v.healPct); fx(w, { type: 'halo', x: p.x, y: p.y, el: 'holy', dur: 1.2, follow: p, sym: 'heart' }); }
    w.sfx?.('cast'); pet.glow = 1; return true;
  },
};

// the glow every Halloween pet keeps around it (drawn under its body)
export function drawHwPetAura(ctx, pet, z, t) {
  const A = pet.pet.aura; if (!A) return;
  const x = pet.x, y = pet.y - z - 20, col = A.col, k = A.k;
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  const g = glowSprite(col);
  ctx.globalAlpha = 0.35 + 0.12 * Math.sin(t * 3 + pet.slot); ctx.drawImage(g, x - 40, y - 40, 80, 80);
  for (let i = 0; i < 7; i++) {
    const s = Math.sin(i * 91.7 + pet.slot) * 0.5 + 0.5, q = (t * (0.4 + s * 0.4) + s) % 1, ang = i * 0.9 + t * (k === 'souls' || k === 'arcs' ? 2.2 : 0.7);
    const px = x + Math.cos(ang) * (16 + s * 16), py = y + 10 - q * 46 + Math.sin(ang) * 6;
    ctx.globalAlpha = (1 - q) * 0.85;
    if (k === 'leaves' || k === 'pages' || k === 'feathers') { ctx.fillStyle = col; ctx.save(); ctx.translate(px, py); ctx.rotate(t * 3 + i); ctx.fillRect(-3, -1.5, 6, 3); ctx.restore(); }
    else if (k === 'candy' || k === 'stripes' || k === 'sparkle') { ctx.fillStyle = i % 2 ? col : '#ffffff'; ctx.beginPath(); ctx.arc(px, py, 2 + s * 1.5, 0, TAU); ctx.fill(); }
    else if (k === 'runes') { ctx.strokeStyle = col; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(px - 3, py); ctx.lineTo(px + 3, py); ctx.moveTo(px, py - 3); ctx.lineTo(px, py + 3); ctx.stroke(); }
    else if (k === 'eyes') { ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(px, py, 3, 1.6, 0, 0, TAU); ctx.fill(); }
    else { ctx.drawImage(g, px - 5, py - 5, 10, 10); }
  }
  ctx.restore();
}
