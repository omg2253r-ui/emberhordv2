// v10 brewing transactions (pure: state in → new state out) and the potion buffs computeStats applies.
import { cloneState } from '../core/state.js';
import { getItem, ITEMS } from '../data/items.js';
import { countItem, removeItem, addInPlace, canAdd } from './inventory.js';
import { judgeHw, judgeAll, mergeInputs, HW_BREW_COST, ALL_BREW_COST, BREW_ACTIVE, applyEffect, EFFECTS, HERBS, SECRET_POTION, allRecipes } from '../data/brewing.js';
import { hwActive } from '../data/halloween.js';

// the buffs still running now
export function activeBrews(state, now = Date.now()) {
  return (state.buffs?.brew || []).filter((b) => b.until > now && getItem(b.id)?.brew).map((b) => ({ ...b, def: getItem(b.id) }));
}
// computeStats calls this last: every running potion changes the finished numbers
export function applyBrews(stats, state, now = Date.now()) {
  stats.candyMult = 1;
  for (const b of activeBrews(state, now)) applyEffect(stats, b.def.brew.eff, b.def.brew.v);
  return stats;
}

// drink one potion from the bag
export function drinkPotion(state, id, now = Date.now()) {
  const def = getItem(id);
  if (!def || (!def.brew && !def.secretCurse)) return { ok: false, reason: 'not_potion' };
  if (countItem(state, id) <= 0) return { ok: false, reason: 'none' };
  const r = removeItem(state, id, 1);
  if (!r.ok) return r;
  const next = r.state;
  next.buffs ||= { luckUntil: 0, brew: [], curse: 0 };
  next.buffs.brew = (next.buffs.brew || []).filter((b) => b.until > now);
  if (def.secretCurse) { next.buffs.curse = 1; return { ok: true, state: next, secret: true }; }
  // the same effect replaces the old one; past the limit the one ending soonest makes room
  next.buffs.brew = next.buffs.brew.filter((b) => getItem(b.id)?.brew?.eff !== def.brew.eff);
  if (next.buffs.brew.length >= BREW_ACTIVE) { next.buffs.brew.sort((a, b) => a.until - b.until); next.buffs.brew.shift(); }
  next.buffs.brew.push({ id, until: now + def.brew.min * 60000 });
  return { ok: true, state: next, effect: EFFECTS[def.brew.eff].fmt(def.brew.v), minutes: def.brew.min };
}

// a pending secret-potion curse is used up when a dungeon starts: returns { state, curse: bool }
export function takePendingCurse(state) {
  if (!state.buffs?.curse) return { state, curse: false };
  const next = cloneState(state); next.buffs.curse = 0;
  return { state: next, curse: true };
}

function payInputs(state, inputs, cost) {
  if (state.gold < cost) return { ok: false, reason: 'gold' };
  for (const x of inputs) if (countItem(state, x.id) < x.qty) return { ok: false, reason: 'missing', id: x.id };
  let cur = state;
  for (const x of inputs) { const r = removeItem(cur, x.id, x.qty); if (!r.ok) return { ok: false, reason: 'missing', id: x.id }; cur = r.state; }
  const next = cur === state ? cloneState(state) : cur;
  next.gold -= cost;
  return { ok: true, state: next };
}

// หม้อปรุงยาปีศาจ (event only). rng: () => [0,1)
export function brewHalloween(state, raw, rnd, now = Date.now()) {
  if (!hwActive(now)) return { ok: false, reason: 'event_over' };
  const inputs = mergeInputs(raw);
  if (!inputs.length) return { ok: false, reason: 'empty' };
  if (inputs.length > 4) return { ok: false, reason: 'too_many' };
  if (inputs.some((x) => !HERBS[x.id])) return { ok: false, reason: 'not_herb' };
  const j = judgeHw(inputs);
  const paid = payInputs(state, inputs, HW_BREW_COST);
  if (!paid.ok) return paid;
  const next = paid.state;
  next.brew.brews += 1;
  let out = null, kind = j.kind;
  if (j.kind === 'exact') { next.brew.known[j.recipe] = 1; if (rnd() < j.chance) out = j.out; }
  else if (j.kind === 'near') { if (rnd() < j.secret) { out = SECRET_POTION.id; kind = 'secret'; } else if (rnd() < j.chance) out = j.out; }
  else if (j.kind === 'secret') { if (rnd() < j.chance) out = SECRET_POTION.id; }
  if (out) {
    if (!canAdd(next, out, 1)) return { ok: false, reason: 'bag_full' };
    addInPlace(next, out, 1);
  }
  return { ok: true, state: next, out, kind, judge: j };
}

// หม้อปรุงทุกสรรพสิ่ง (permanent)
export function brewAll(state, raw, rnd) {
  const inputs = mergeInputs(raw);
  if (!inputs.length) return { ok: false, reason: 'empty' };
  if (inputs.length > 4) return { ok: false, reason: 'too_many' };
  for (const x of inputs) { const d = getItem(x.id); if (!d || d.secretCurse || x.id === 'p_hw_cross') return { ok: false, reason: 'not_allowed', id: x.id }; }
  // gear that is worn cannot go in (only what is in the bag)
  const j = judgeAll(inputs, ITEMS);
  const paid = payInputs(state, inputs, ALL_BREW_COST);
  if (!paid.ok) return paid;
  const next = paid.state;
  next.brew.brews += 1;
  if (j.kind === 'exact') next.brew.known[j.recipe] = 1;
  const out = rnd() < j.chance ? j.out : null;
  if (out) { if (!canAdd(next, out, 1)) return { ok: false, reason: 'bag_full' }; addInPlace(next, out, 1); }
  return { ok: true, state: next, out, kind: j.kind, judge: j };
}
export { allRecipes, judgeHw, judgeAll };
