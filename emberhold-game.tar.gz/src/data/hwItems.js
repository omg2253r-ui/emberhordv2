// v10 Halloween event items. Every event weapon has its OWN moveset (combo, charged, dash, branch) and its own model
// (art/hwArt.js, art.hw = true). Rarity 'limited' (ลิมิเต็ด ฮาโลวีน) sits above mythic: these weapons are stronger
// than every secret weapon — the secret Muramasa included — by design (v10 request).
// Muramasa itself stays a secret (mythic) blade: it only drops from the Wrathful Witch at the end of the wizard's quest,
// and deals half damage in PvP (pvpHalf).
const arc = (range, deg) => ({ shape: 'arc', range, arc: deg });
const circ = (r, forward = 0) => ({ shape: 'circle', r, forward });
const proj = (kind, speed, r, o = {}) => ({ shape: 'proj', kind, speed, r, pierce: 0, count: 1, spread: 0, ...o });
const rush = (dist, width) => ({ shape: 'rush', dist, width });
const zone = (r, delay, reach) => ({ shape: 'zone', r, delay, reach });
const mv = (name, anim, t, power, hit, extra = {}) => ({ name, anim, windup: t[0], active: t[1], recover: t[2], cancel: t[3], power, hit, ...extra });
const W = (id, wtype, name, rarity, src, stats, art, desc, moves, extra = {}) => ({ id, wtype, name, category: 'weapon', rarity, src, stats, art: { hw: true, ...art }, desc, moves, event: 'hw', ...extra });

export const HW_WEAPONS = Object.freeze({
  // ปืนใหญ่ฟักทองคลั่ง — every shot is a pumpkin that bursts where it lands (blast); the charged shot is a pumpkin bomb
  w_hw_pumpkin_cannon: W('w_hw_pumpkin_cannon', 'staff', 'ปืนใหญ่ฟักทองคลั่ง', 'limited', 'hw', { atk: 112, crit: 0.14, critMult: 0.6, hp: 90 },
    { form: 'cannon', body: '#e06a1a', glow: '#ffcf5a', trim: '#2a1a10' },
    'ปืนใหญ่ที่บรรจุฟักทองแทนลูกเหล็ก ลูกที่ยิงออกไประเบิดเป็นเมล็ดไฟกระจายรอบจุดตก', {
      combo: [
        mv('ฟักทองระเบิด', 'cast', [0.06, 0.05, 0.2, 0.36], 0.75, proj('pumpkin', 760, 13), { blast: 70 }),
        mv('ฟักทองคู่', 'cast', [0.06, 0.05, 0.2, 0.36], 0.55, proj('pumpkin', 760, 12, { count: 2, spread: 14 }), { blast: 60 }),
        mv('ลูกฟักทองยักษ์', 'castBig', [0.12, 0.06, 0.32, 0.6], 1.3, proj('pumpkin', 620, 22, { pierce: 1 }), { blast: 110, shake: 4 }),
      ],
      charged: mv('ระเบิดฟักทองแม่', 'castBig', [0.08, 0.1, 0.42, 0.7], 2.6, zone(170, 0.4, 340), { burn: true, stun: 0.5, shake: 9 }),
      dash: mv('ยิงถอยหลัง', 'cast', [0.02, 0.05, 0.22, 0.45], 1.1, proj('pumpkin', 900, 14, { count: 3, spread: 36 }), { blast: 60, hop: 60 }),
      branch: mv('ฝนฟักทอง', 'castBig', [0.1, 0.06, 0.34, 0.65], 0.6, proj('pumpkin', 520, 12, { count: 7, spread: 120 }), { blast: 70, burn: true }),
    }),
  // ดาบลายฟักทองอสูร — carving slashes leave burning vines; the charged move throws a grinning jack-o'-lantern wave
  w_hw_pumpkin_blade: W('w_hw_pumpkin_blade', 'sword', 'ดาบลายฟักทองอสูร', 'limited', 'hw', { atk: 118, crit: 0.2, critMult: 0.7, hp: 100, def: 8 },
    { form: 'pumpkinblade', blade: '#e06a1a', edge: '#ffcf5a', glow: '#ff8a1f', vine: '#3a6a2a' },
    'ใบดาบสลักลายฟักทองหน้ายิ้ม ทุกรอยฟันทิ้งเถาวัลย์ติดไฟไว้บนตัวศัตรู', {
      combo: [
        mv('แกะสลักซ้าย', 'slash', [0.06, 0.07, 0.18, 0.34], 1.05, arc(104, 130), { kb: 150, step: 16, burn: true }),
        mv('แกะสลักขวา', 'slashUp', [0.06, 0.07, 0.18, 0.34], 1.05, arc(104, 130), { kb: 150, step: 16, mark: 0.08 }),
        mv('เถาวัลย์รัด', 'thrust', [0.06, 0.07, 0.2, 0.36], 1.15, arc(132, 44), { kb: 90, step: 26, slow: 0.4 }),
        mv('หน้ายิ้มผ่าซีก', 'overhead', [0.12, 0.1, 0.34, 0.7], 2.0, arc(124, 160), { kb: 320, step: 30, burn: true, hitStop: 0.08, shake: 6 }),
      ],
      charged: mv('คลื่นหน้ายิ้ม', 'spin', [0.06, 0.1, 0.32, 0.6], 2.2, proj('grin', 820, 26, { pierce: 99, count: 3, spread: 34 }), { burn: true, shake: 6 }),
      dash: mv('ฟันทะลุเถา', 'thrust', [0.02, 0.1, 0.22, 0.45], 1.7, rush(220, 44), { kb: 220, burn: true }),
      branch: mv('สวนฟักทองวงกลม', 'spin', [0.07, 0.14, 0.3, 0.6], 0.8, circ(140), { multi: 3, kb: 100, burn: true, hitStop: 0.06 }),
    }),
  // เคียวยมทูตนิลกาฬ — reaps: big arcs, the third swing pulls enemies in; charged = a ring of scythes around the hero
  w_hw_reaper_scythe: W('w_hw_reaper_scythe', 'scythe', 'เคียวยมทูตนิลกาฬ', 'limited', 'hw', { atk: 126, crit: 0.16, critMult: 0.8, hp: 120 },
    { form: 'reaper', blade: '#1a1a24', shaft: '#2a1a14', glow: '#b8f0ff', edge: '#e8f4ff' },
    'เคียวดำที่ยมทูตใช้เกี่ยววิญญาณ ไม่มีแสงใดสะท้อนบนใบมีดนี้ นอกจากแสงของวิญญาณที่ถูกเกี่ยวไป', {
      combo: [
        mv('เกี่ยววิญญาณ', 'slash', [0.08, 0.09, 0.22, 0.4], 1.2, arc(160, 150), { kb: 160, step: 14 }),
        mv('เกี่ยวย้อน', 'slashUp', [0.08, 0.09, 0.22, 0.4], 1.2, arc(160, 150), { kb: -180, step: 14, mark: 0.1 }),
        mv('ดึงสู่ความตาย', 'spin', [0.1, 0.14, 0.3, 0.6], 1.5, circ(180), { kb: -260, multi: 2, hitStop: 0.07, shake: 5 }),
      ],
      charged: mv('วงล้อยมทูต', 'overhead', [0.08, 0.12, 0.44, 0.75], 3.0, circ(220), { multi: 3, stun: 0.6, kb: 300, shake: 10, hitStop: 0.1, critBonus: 0.2 }),
      dash: mv('ก้าวผ่านความตาย', 'thrust', [0.02, 0.14, 0.26, 0.5], 1.8, rush(260, 60), { kb: 200, teleport: 'behind', forceCrit: true }),
      branch: mv('เคียวพันดวง', 'spin', [0.06, 0.12, 0.3, 0.6], 0.6, proj('soul', 520, 14, { count: 8, spread: 315, homing: 2, pierce: 1 }), { mark: 0.12 }),
    }),
  // ไม้กวาดแม่มดหลอกตา — bolts are bats that chase; the charged move drops a bubbling hex cauldron on the ground
  w_hw_witch_broom: W('w_hw_witch_broom', 'staff', 'ไม้กวาดแม่มดหลอกตา', 'limited', 'hw', { atk: 110, crit: 0.15, critMult: 0.6, hp: 160 },
    { form: 'broom', wood: '#3a2418', orb: '#b86aff', trim: '#e0b45a', bristle: '#c8a050' },
    'ไม้กวาดที่แม่มดขี่ข้ามดวงจันทร์ ทุกครั้งที่ชี้ ค้างคาวจะบินออกมาตามคำสั่ง', {
      combo: [
        mv('ค้างคาวไล่ล่า', 'cast', [0.06, 0.05, 0.2, 0.36], 0.7, proj('bat', 640, 10, { count: 2, spread: 22, homing: 3.5 })),
        mv('ค้างคาวสามตัว', 'cast', [0.06, 0.05, 0.2, 0.36], 0.55, proj('bat', 640, 10, { count: 3, spread: 30, homing: 3.5 })),
        mv('กวาดคำสาป', 'castBig', [0.1, 0.08, 0.3, 0.6], 1.2, circ(130, 40), { slow: 0.45, mark: 0.1, kb: 200 }),
      ],
      charged: mv('หม้อคำสาปเดือด', 'castBig', [0.08, 0.1, 0.42, 0.7], 2.4, zone(160, 0.45, 360), { slow: 0.4, mark: 0.15, shake: 6 }),
      dash: mv('ขี่ไม้กวาดหนี', 'cast', [0.02, 0.05, 0.2, 0.45], 0.9, proj('bat', 700, 10, { count: 5, spread: 80, homing: 3 }), { hop: 80 }),
      branch: mv('ฝูงค้างคาวราตรี', 'castBig', [0.12, 0.06, 0.34, 0.65], 0.45, proj('bat', 520, 9, { count: 10, spread: 330, homing: 4 })),
    }),
  // ปืนคู่ฟักทองสาปสิบห้า — two pistols, alternating shots; every hit lays one of the fifteen witch curses at random
  w_hw_twin_pistols: W('w_hw_twin_pistols', 'dagger', 'ปืนคู่ฟักทองสาปสิบห้า', 'limited', 'hw:lure', { atk: 134, crit: 0.22, critMult: 0.8, spd: 0.06 },
    { form: 'pistol', body: '#2a1a24', glow: '#ff8a1f', trim: '#e0b45a', off: { body: '#3a1a2a' } },
    'ปืนคู่ที่แม่มดจอมล่อลวงซ่อนไว้ใต้กระโปรง ลูกกระสุนฟักทองทุกนัดพกคำสาปหนึ่งในสิบห้าแบบไปฝังในเป้าหมาย', {
      combo: [
        mv('ยิงซ้าย', 'stab', [0.03, 0.04, 0.1, 0.26], 0.55, proj('pumpkin', 980, 9), { curse: true }),
        mv('ยิงขวา', 'stabB', [0.03, 0.04, 0.1, 0.26], 0.55, proj('pumpkin', 980, 9), { curse: true }),
        mv('ยิงซ้าย', 'stab', [0.03, 0.04, 0.1, 0.26], 0.6, proj('pumpkin', 980, 9), { curse: true }),
        mv('ยิงคู่ไขว้', 'cross', [0.05, 0.05, 0.24, 0.5], 0.7, proj('pumpkin', 1000, 10, { count: 4, spread: 24 }), { curse: true, shake: 2 }),
      ],
      charged: mv('ระดมยิงสิบห้าคำสาป', 'throw', [0.05, 0.05, 0.34, 0.65], 0.6, proj('pumpkin', 900, 10, { count: 15, spread: 160 }), { curse: true, shake: 5 }),
      dash: mv('กลิ้งยิง', 'stab', [0.02, 0.06, 0.2, 0.45], 1.4, proj('pumpkin', 1100, 11, { count: 2, spread: 8, pierce: 2 }), { curse: true, forceCrit: true }),
      branch: mv('วงกระสุนผีหลอก', 'cross', [0.05, 0.1, 0.28, 0.55], 0.5, proj('pumpkin', 760, 9, { count: 10, spread: 330 }), { curse: true }),
    }),
  // หอกลูกกวาดเกลียวคลั่ง — a spinning candy-cane lance: long pokes, a drilling charge and a sugar-rush dash
  w_hw_candy_lance: W('w_hw_candy_lance', 'spear', 'หอกลูกกวาดเกลียวคลั่ง', 'limited', 'hw', { atk: 116, crit: 0.18, critMult: 0.65, spd: 0.05, hp: 80 },
    { form: 'candycane', shaft: '#ffffff', trim: '#e0303a', glow: '#ffd8e8' },
    'หอกลูกกวาดเกลียวแดงขาว ยิ่งหมุนยิ่งแหลม แทงทีเดียวศัตรูหวานจนหยุดเดิน', {
      combo: [
        mv('จิ้มลูกกวาด', 'thrust', [0.05, 0.06, 0.16, 0.32], 0.9, arc(170, 26), { kb: 120, step: 18 }),
        mv('จิ้มคู่', 'thrust', [0.05, 0.06, 0.16, 0.32], 0.55, arc(170, 30), { multi: 2, kb: 90, step: 18 }),
        mv('กวาดน้ำตาล', 'slash', [0.08, 0.08, 0.22, 0.4], 1.1, arc(160, 170), { kb: 200, step: 10, slow: 0.4 }),
        mv('สว่านเกลียว', 'thrust', [0.1, 0.14, 0.3, 0.6], 0.55, arc(210, 24), { multi: 4, kb: 260, step: 30, hitStop: 0.06, shake: 4 }),
      ],
      charged: mv('ลูกกวาดทะลวงฟ้า', 'thrust', [0.06, 0.12, 0.36, 0.65], 2.7, proj('candy', 1200, 18, { pierce: 99 }), { critBonus: 0.25, shake: 6 }),
      dash: mv('น้ำตาลพุ่ง', 'thrust', [0.02, 0.14, 0.24, 0.5], 1.6, rush(280, 46), { kb: 240, slow: 0.4 }),
      branch: mv('ขนมหมุนวน', 'spin', [0.06, 0.14, 0.3, 0.6], 0.7, circ(150), { multi: 3, kb: 120, slow: 0.5 }),
    }),
  // คาตานะมุรามาสะ — the secret blade (half power in PvP). Stained with ghost-fire, but the pure white of the steel still
  // shows through. Its moves are draws and cuts that leave a trail of white petals.
  w_hw_muramasa: W('w_hw_muramasa', 'katana', 'คาตานะมุรามาสะ', 'mythic', 'hw:wrath', { atk: 100, crit: 0.22, critMult: 0.7, spd: 0.05 },
    { form: 'muramasa', blade: '#f6f4f2', edge: '#ffffff', stain: '#7a1a3a', glow: '#ff6a8a', guard: '#1a1014', grip: '#3a0a14', wrap: '#e8e0d8' },
    'ดาบคาตานะที่ถูกสาปโดยแม่มดแห่งความโกรธเกรี้ยว ใบดาบเปื้อนคราบสีม่วงแดงเหมือนหมึกอาถรรพ์ แต่ใต้คราบยังเห็นสีขาวบริสุทธิ์ของเหล็กกล้าดั้งเดิม (ลดพลังครึ่งหนึ่งตอน PvP)', {
      combo: [
        mv('กลีบขาวแรก', 'slash', [0.04, 0.06, 0.14, 0.32], 0.9, arc(112, 110), { kb: 100, step: 16 }),
        mv('คราบสาปย้อน', 'slashUp', [0.04, 0.06, 0.14, 0.32], 0.95, arc(112, 110), { kb: 100, step: 16, mark: 0.1 }),
        mv('แทงหิมะ', 'thrust', [0.04, 0.06, 0.15, 0.32], 1.0, arc(140, 40), { kb: 140, step: 26 }),
        mv('จันทร์โลหิต', 'overhead', [0.08, 0.08, 0.3, 0.65], 1.9, arc(126, 180), { kb: 260, step: 20, hitStop: 0.07, shake: 5 }),
      ],
      charged: mv('ชักดาบมุรามาสะ', 'iai', [0.03, 0.18, 0.32, 0.6], 3.2, rush(280, 52), { kb: 220, critBonus: 0.3, hitStop: 0.1, shake: 7 }),
      dash: mv('กลีบพายุ', 'slash', [0.02, 0.08, 0.2, 0.45], 1.5, arc(130, 200), { kb: 200, step: 40, critBonus: 0.3 }),
      branch: mv('หมื่นกลีบขาว', 'iai', [0.05, 0.14, 0.3, 0.6], 0.6, proj('petal', 820, 10, { count: 9, spread: 90, pierce: 2 }), { mark: 0.1 }),
    }, { secret: true, pvpHalf: true, noCraft: true }),
});

// ------------------------------------------------------------------ armour, wings, charms
const A = (id, name, stats, art, desc) => ({ id, name, category: 'armor', rarity: 'limited', src: 'hw', event: 'hw', stats, art: { kind: 'forge', hw: true, ...art }, desc });
const G = (id, name, stats, art, desc) => ({ id, name, category: 'wings', rarity: 'limited', src: 'hw', event: 'hw', stats, art: { hw: true, ...art }, desc });
export const HW_GEAR = Object.freeze({
  a_hw_jack_plate: A('a_hw_jack_plate', 'เกราะราชาแจ็กโอแลนเทิร์น', { def: 46, hp: 260, atk: 10 },
    { main: '#d8641a', trim: '#2a1a10', accent: '#ffcf5a', chest: 'pumpkin', emblem: 'jack', shoulder: 'pumpkin', skirt: 'tatters', arm: 'vine' },
    'เกราะที่แกะจากฟักทองยักษ์อายุร้อยปี แข็งยิ่งกว่าเหล็ก ข้างในยังมีเทียนที่ไม่เคยดับ'),
  a_hw_witch_robe: A('a_hw_witch_robe', 'อาภรณ์แม่มดราตรี', { def: 36, hp: 220, crit: 0.08, critMult: 0.2 },
    { main: '#3a1a4a', trim: '#9a5aff', accent: '#e0b45a', chest: 'stitched', emblem: 'hourglass', shoulder: 'batwing', skirt: 'witchhem', arm: 'cuff' },
    'ชุดคลุมเย็บปะด้วยด้ายเงินจันทร์ ใครสวมจะได้ยินเสียงกระซิบคาถาตลอดเวลา'),
  a_hw_reaper_shroud: A('a_hw_reaper_shroud', 'ผ้าห่อวิญญาณยมทูต', { def: 40, hp: 240, spd: 0.05 },
    { main: '#1a1a24', trim: '#8a90a0', accent: '#b8f0ff', chest: 'shroud', emblem: 'skull', shoulder: 'tatter', skirt: 'tatters', arm: 'wrap' },
    'ผ้าห่อที่ยมทูตถอดทิ้งไว้ ขอบผ้าปลิวเองแม้ไม่มีลม'),
  wg_hw_bat: G('wg_hw_bat', 'ปีกค้างคาวราตรี', { spd: 0.08, crit: 0.06, hp: 80 }, { kind: 'hwbat', main: '#2a1a2a', trim: '#ff5a7a', glow: '#ff8aa8' },
    'ปีกหนังบางที่กางได้กว้างกว่าตัว บินโฉบในความมืดโดยไม่มีเสียง'),
  wg_hw_lantern: G('wg_hw_lantern', 'ปีกวิญญาณโคมฟักทอง', { hp: 140, def: 10, spd: 0.05 }, { kind: 'hwlantern', main: '#bfe8ff', trim: '#ff8a1f', glow: '#ffcf5a' },
    'ปีกหมอกวิญญาณที่มีโคมฟักทองแขวนอยู่ที่ปลายปีกทั้งสองข้าง'),
  wg_hw_bone6: G('wg_hw_bone6', 'ปีกกระดูกหกปีกจักรพรรดิ', { atk: 14, crit: 0.08, spd: 0.07, hp: 100 }, { kind: 'hwbone', main: '#efe4cc', trim: '#ffe89a', glow: '#fff3c4' },
    'ปีกโครงกระดูกหกปีกของจักรพรรดิสวรรค์ ยังมีแสงสวรรค์หลงเหลืออยู่ในข้อกระดูก'),
  c_hw_candy_heart: { id: 'c_hw_candy_heart', name: 'หัวใจลูกกวาดต้องสาป', category: 'charm', rarity: 'limited', src: 'hw', event: 'hw', stats: { hp: 120, atk: 14, crit: 0.1 },
    art: { hw: true, kind: 'candyheart', main: '#e0303a', trim: '#ffd8e8' }, desc: 'ลูกกวาดรูปหัวใจที่ยังเต้นตุบๆ อยู่ในมือ' },
  // the mask of the floor-80 god: it does NOTHING, and says so
  c_hw_spite_mask: { id: 'c_hw_spite_mask', name: 'หน้ากากแห่งความเคียดแค้น', category: 'charm', rarity: 'unknown', src: 'hw:alchemy', event: 'hw', stats: {}, cosmetic: true,
    art: { hw: true, kind: 'spitemask', main: '#f5efe6', trim: '#3a1a4a' },
    desc: 'ดรอปจากทศพักตร์มารผู้ "ตีไม่ตาย" — ใช่ ตัวที่คุณตีจนมือหงิกเมื่อชั้น 80 นั่นแหละ ค่าพลัง: ไม่มี ความสามารถ: ไม่มี สิ่งที่มันมอบให้: ความรู้สึกว่าเอาชนะได้แล้วจริงๆ (มั้ง) ใส่ได้ทั้งเป็นเครื่องราง หรือติ๊ก "สวมหน้ากากทับชุด" ในหน้าอุปกรณ์เพื่อใส่ซ้อนกับสกินทุกอย่าง' },
  p_hw_cross: { id: 'p_hw_cross', name: 'ไม้กางเขนพ่อมด', category: 'consumable', rarity: 'legendary', src: 'hw:wizard', event: 'hw', sellPrice: 0,
    art: { hw: true, kind: 'cross', main: '#efe4cc', trim: '#e0b45a', glow: '#fff3c4' },
    desc: 'กันตายได้ 1 ครั้ง ใช้ได้เฉพาะในดันเจี้ยนลับของพ่อมดเท่านั้น (ทำงานเองตอนเลือดหมด)' },
});

// the wizard's crystals live in the run's artifact bag (see battle/hwCoop.js), not in the save
