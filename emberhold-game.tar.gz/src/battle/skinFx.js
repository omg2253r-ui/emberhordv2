// v10.2 the living effects of weapon skins (อีปิค and up) and the hit effects of เลเจนด์ and up.
// Auras are drawn around the hero every frame in every scene (village, hunts, PvP); colours come from the skin's own
// palette, so the same effect never looks the same on two weapons. Glows use cached sprites (cheap on phones).
import { glowSprite, hexA } from '../scenes/ambientFx.js';
import { SKIN_TIERS } from '../data/skins.js';
import { registerFx } from './skillVfx.js';

const TAU = Math.PI * 2;
const G = (ctx, x, y, r, col, a = 1) => { ctx.globalAlpha = a; ctx.drawImage(glowSprite(col), x - r, y - r, r * 2, r * 2); ctx.globalAlpha = 1; };
const dot = (ctx, x, y, r, col) => { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); };
const star4 = (ctx, x, y, r, col) => { ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(x, y - r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.quadraticCurveTo(x, y, x, y + r); ctx.quadraticCurveTo(x, y, x - r, y); ctx.quadraticCurveTo(x, y, x, y - r); ctx.fill(); };
function feather(ctx, x, y, a, s, col) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(a); ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(0, -10 * s); ctx.quadraticCurveTo(5 * s, -2 * s, 0, 10 * s); ctx.quadraticCurveTo(-5 * s, -2 * s, 0, -10 * s); ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(0, -9 * s); ctx.lineTo(0, 9 * s); ctx.stroke(); ctx.restore();
}

// x, y: the hero's feet · P: palette [blade, edge, metal, grip, glow, gem]
export const AURAS = {
  // ---------------------------------------------------------------- อีปิค
  ember_rise(ctx, x, y, t, P) { for (let i = 0; i < 10; i++) { const k = (t * 0.7 + i / 10) % 1, px = x + Math.sin(i * 2.7 + t * 2) * 26, py = y - 20 - k * 110; G(ctx, px, py, 10 * (1 - k) + 3, P[4], 0.8 * (1 - k)); dot(ctx, px, py, 2, P[1]); } G(ctx, x, y - 6, 46, P[4], 0.25); },
  frost_mote(ctx, x, y, t, P) { for (let i = 0; i < 7; i++) { const a = t * 0.8 + i * TAU / 7, r = 40 + Math.sin(t * 2 + i) * 6; const px = x + Math.cos(a) * r, py = y - 60 + Math.sin(a) * r * 0.4; G(ctx, px, py, 9, P[4], 0.7); ctx.save(); ctx.translate(px, py); ctx.rotate(t + i); ctx.strokeStyle = P[1]; ctx.lineWidth = 1.4; for (let k = 0; k < 3; k++) { ctx.rotate(Math.PI / 3); ctx.beginPath(); ctx.moveTo(-5, 0); ctx.lineTo(5, 0); ctx.stroke(); } ctx.restore(); } },
  leaf_spiral(ctx, x, y, t, P) { for (let i = 0; i < 9; i++) { const k = (t * 0.45 + i / 9) % 1, a = k * TAU * 1.5 + i; const px = x + Math.cos(a) * (18 + k * 30), py = y - k * 120; ctx.globalAlpha = 1 - k; feather(ctx, px, py, a * 2, 0.7, i % 2 ? P[4] : P[5]); } ctx.globalAlpha = 1; },
  spark_coil(ctx, x, y, t, P) { ctx.strokeStyle = hexA(P[4], 0.8); ctx.lineWidth = 2; ctx.beginPath(); for (let k = 0; k <= 40; k++) { const a = k * 0.5 + t * 6, py = y - k * 3; const px = x + Math.cos(a) * 22; k ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.stroke(); for (let i = 0; i < 3; i++) { const a = t * 6 + i * 2; G(ctx, x + Math.cos(a) * 22, y - ((t * 90 + i * 40) % 120), 10, P[1], 0.9); } },
  // ---------------------------------------------------------------- เลเจนด์
  thunder_coil(ctx, x, y, t, P) {
    G(ctx, x, y - 60, 70, P[4], 0.22);
    for (let b = 0; b < 2; b++) { const a0 = t * 2.4 + b * Math.PI; ctx.strokeStyle = b ? P[1] : P[4]; ctx.lineWidth = 2.2; ctx.beginPath(); let px = x + Math.cos(a0) * 34, py = y - 10; ctx.moveTo(px, py); for (let k = 1; k < 9; k++) { px = x + Math.cos(a0 + k * 0.6) * 34 + (Math.random() - 0.5) * 10; py = y - 10 - k * 13; ctx.lineTo(px, py); } ctx.stroke(); }
    if (Math.sin(t * 7) > 0.85) { ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x - 30, y - 130); for (let k = 0; k < 6; k++) ctx.lineTo(x - 30 + k * 12, y - 130 + (k % 2 ? 14 : -4)); ctx.stroke(); }
  },
  flame_wings(ctx, x, y, t, P) {
    for (const side of [-1, 1]) for (let f = 0; f < 5; f++) { const k = f / 5, fl = Math.sin(t * 8 + f) * 4; ctx.fillStyle = hexA(f % 2 ? P[4] : P[5], 0.55 - k * 0.07); ctx.beginPath(); ctx.moveTo(x + side * 8, y - 80); ctx.quadraticCurveTo(x + side * (40 + f * 10), y - 120 - f * 8 + fl, x + side * (54 + f * 9), y - 70 + f * 6); ctx.quadraticCurveTo(x + side * (30 + f * 6), y - 76, x + side * 8, y - 70); ctx.fill(); }
    G(ctx, x, y - 82, 40, P[4], 0.35);
  },
  tidal_orbit(ctx, x, y, t, P) { for (let r = 0; r < 2; r++) { ctx.strokeStyle = hexA(r ? P[1] : P[4], 0.7); ctx.lineWidth = 3 - r; ctx.beginPath(); for (let k = 0; k <= 48; k++) { const a = (k / 48) * TAU; const rr = 46 + r * 10 + Math.sin(a * 5 + t * (4 + r * 2)) * 5; const px = x + Math.cos(a) * rr, py = y - 54 + Math.sin(a) * rr * 0.35; k ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.stroke(); } for (let i = 0; i < 6; i++) { const k = (t * 1.2 + i / 6) % 1; G(ctx, x + Math.cos(i * 1.1 + t) * 46, y - 54 - k * 50, 8, P[4], 1 - k); } },
  // ---------------------------------------------------------------- เทพ
  halo_feather(ctx, x, y, t, P) {
    ctx.strokeStyle = hexA(P[4], 0.95); ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(x, y - 150 + Math.sin(t * 2) * 3, 22, 6, 0, 0, TAU); ctx.stroke(); G(ctx, x, y - 150, 34, P[4], 0.5);
    for (let i = 0; i < 9; i++) { const k = (t * 0.35 + i / 9) % 1; ctx.globalAlpha = Math.min(1, (1 - k) * 1.5); feather(ctx, x + Math.sin(i * 2.3 + t) * 54, y - 170 + k * 170, Math.sin(t * 2 + i) * 0.8, 0.9, i % 3 ? '#ffffff' : P[4]); }
    ctx.globalAlpha = 1;
    for (let i = 0; i < 6; i++) { const a = t * 0.6 + i * TAU / 6; ctx.strokeStyle = hexA(P[4], 0.25); ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(x, y - 80); ctx.lineTo(x + Math.cos(a) * 90, y - 80 + Math.sin(a) * 50); ctx.stroke(); }
  },
  sun_crown(ctx, x, y, t, P) { const cy = y - 150; G(ctx, x, cy, 60, P[5], 0.5); for (let i = 0; i < 12; i++) { const a = t * 0.8 + i * TAU / 12, l = 20 + (i % 2) * 12 + Math.sin(t * 4 + i) * 4; ctx.strokeStyle = hexA(i % 2 ? P[4] : P[1], 0.9); ctx.lineWidth = 2.4; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * 12, cy + Math.sin(a) * 12); ctx.lineTo(x + Math.cos(a) * l, cy + Math.sin(a) * l); ctx.stroke(); } dot(ctx, x, cy, 9, '#fffbe0'); for (let i = 0; i < 5; i++) { const k = (t * 0.6 + i / 5) % 1; G(ctx, x + Math.sin(i * 2 + t) * 30, y - k * 120, 7, P[4], 1 - k); } },
  moon_veil(ctx, x, y, t, P) { ctx.fillStyle = hexA(P[4], 0.15); for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(x - 50 - i * 6, y - 150); ctx.bezierCurveTo(x - 60, y - 60 + Math.sin(t * 1.5 + i) * 10, x + 60, y - 60 - Math.sin(t * 1.5 + i) * 10, x + 50 + i * 6, y - 150); ctx.lineTo(x + 40, y); ctx.lineTo(x - 40, y); ctx.closePath(); ctx.fill(); } ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(x + 30, y - 160, 12, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(10,10,30,0.9)'; ctx.beginPath(); ctx.arc(x + 35, y - 163, 10, 0, TAU); ctx.fill(); G(ctx, x + 30, y - 160, 30, P[4], 0.5); for (let i = 0; i < 8; i++) star4(ctx, x + Math.cos(i * 0.8 + t * 0.3) * 60, y - 90 + Math.sin(i * 1.7 + t) * 50, 3 + (Math.sin(t * 4 + i) + 1) * 1.5, '#ffffff'); },
  // ---------------------------------------------------------------- เทพนิยาย
  dragon_wisp(ctx, x, y, t, P) {
    const pts = []; for (let k = 0; k < 22; k++) { const a = t * 1.6 - k * 0.22; pts.push([x + Math.cos(a) * (58 - k * 0.6), y - 70 + Math.sin(a * 1.0) * 30 - Math.sin(a * 2) * 20]); }
    for (let k = pts.length - 1; k >= 0; k--) { const [px, py] = pts[k], s = (1 - k / pts.length); G(ctx, px, py, 10 * s + 3, P[4], 0.5); dot(ctx, px, py, 5 * s + 1.5, k % 3 ? P[5] : P[1]); }
    const [hx, hy] = pts[0]; dot(ctx, hx, hy, 8, P[1]); ctx.fillStyle = '#ffffff'; dot(ctx, hx + 3, hy - 2, 1.8, '#ff2a2a'); ctx.strokeStyle = P[4]; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(hx, hy - 6); ctx.lineTo(hx - 8, hy - 16); ctx.moveTo(hx + 3, hy - 6); ctx.lineTo(hx + 2, hy - 18); ctx.stroke();
  },
  phoenix_tail(ctx, x, y, t, P) { G(ctx, x, y - 90, 70, P[4], 0.3); for (let i = 0; i < 7; i++) { const sway = Math.sin(t * 3 + i * 0.5) * 18; ctx.strokeStyle = hexA(i % 2 ? P[5] : P[4], 0.75); ctx.lineWidth = 3.5 - i * 0.3; ctx.beginPath(); ctx.moveTo(x, y - 90); ctx.bezierCurveTo(x - 30 + sway, y - 40, x + 40 - i * 10 + sway, y - 10, x - 20 + i * 12 + sway, y + 14); ctx.stroke(); G(ctx, x - 20 + i * 12 + sway, y + 14, 8, P[1], 0.8); } for (let i = 0; i < 6; i++) { const k = (t + i / 6) % 1; G(ctx, x + Math.sin(i * 3 + t * 2) * 40, y - 100 - k * 60, 10 * (1 - k), P[5], 1 - k); } },
  fairy_ring(ctx, x, y, t, P) { for (let i = 0; i < 6; i++) { const a = t * 1.3 + i * TAU / 6, px = x + Math.cos(a) * 56, py = y - 70 + Math.sin(a) * 26 + Math.sin(t * 5 + i) * 6; const f = Math.abs(Math.sin(t * 16 + i)); ctx.fillStyle = hexA(P[1], 0.7); ctx.beginPath(); ctx.ellipse(px - 5 * f, py, 6 * f + 1, 4, -0.5, 0, TAU); ctx.ellipse(px + 5 * f, py, 6 * f + 1, 4, 0.5, 0, TAU); ctx.fill(); G(ctx, px, py, 12, P[4], 0.9); dot(ctx, px, py, 2.4, '#ffffff'); for (let k = 1; k < 5; k++) G(ctx, x + Math.cos(a - k * 0.12) * 56, y - 70 + Math.sin(a - k * 0.12) * 26, 5 - k, P[5], 0.6 - k * 0.12); } },
  // ---------------------------------------------------------------- จักรวาล
  planet_orbit(ctx, x, y, t, P) { const cx = x, cy = y - 70; ctx.strokeStyle = hexA(P[4], 0.35); ctx.lineWidth = 1; for (const r of [40, 60, 80]) { ctx.beginPath(); ctx.ellipse(cx, cy, r, r * 0.32, 0, 0, TAU); ctx.stroke(); } [[40, 1.8, 5, P[5]], [60, 1.1, 8, P[4]], [80, 0.7, 6, P[1]]].forEach(([r, sp, s, c], i) => { const a = t * sp + i * 2; const px = cx + Math.cos(a) * r, py = cy + Math.sin(a) * r * 0.32; G(ctx, px, py, s * 3, c, 0.6); dot(ctx, px, py, s, c); if (i === 1) { ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.ellipse(px, py, s * 2, s * 0.6, -0.4, 0, TAU); ctx.stroke(); } }); G(ctx, cx, cy, 20, '#fff3c4', 0.6); },
  galaxy_disc(ctx, x, y, t, P) { const cx = x, cy = y - 72; for (let arm = 0; arm < 3; arm++) for (let k = 0; k < 18; k++) { const r = k * 4.2, a = t * 1.2 + arm * TAU / 3 + k * 0.32; const px = cx + Math.cos(a) * r, py = cy + Math.sin(a) * r * 0.42; ctx.globalAlpha = 1 - k / 18; dot(ctx, px, py, 2.2 - k * 0.08, k % 4 ? P[4] : '#ffffff'); } ctx.globalAlpha = 1; G(ctx, cx, cy, 34, P[5], 0.6); G(ctx, cx, cy, 12, '#ffffff', 0.9); },
  star_rain(ctx, x, y, t, P) { for (let i = 0; i < 10; i++) { const k = (t * 0.8 + i / 10) % 1, px = x - 50 + ((i * 37) % 100) + k * 30, py = y - 200 + k * 190; ctx.strokeStyle = hexA(P[4], 1 - k); ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(px - 12, py - 18); ctx.lineTo(px, py); ctx.stroke(); star4(ctx, px, py, 4, '#ffffff'); } G(ctx, x, y, 50, P[4], 0.25); },
  // ---------------------------------------------------------------- คอสมิค
  nebula_cloud(ctx, x, y, t, P) { for (let i = 0; i < 7; i++) { const a = t * 0.4 + i * 0.9; G(ctx, x + Math.cos(a) * 46, y - 80 + Math.sin(a * 1.3) * 34, 40, [P[4], P[5], P[1]][i % 3], 0.32); } for (let i = 0; i < 14; i++) star4(ctx, x + Math.cos(i * 2.1 + t * 0.2) * 70, y - 80 + Math.sin(i * 1.3) * 60, 1.5 + Math.abs(Math.sin(t * 3 + i)) * 2.5, '#ffffff'); },
  comet_trail(ctx, x, y, t, P) { for (let c = 0; c < 3; c++) { const a = t * (1.4 + c * 0.3) + c * 2.1; for (let k = 0; k < 14; k++) { const aa = a - k * 0.07; const px = x + Math.cos(aa) * (60 + c * 12), py = y - 80 + Math.sin(aa) * (34 + c * 6); G(ctx, px, py, 10 - k * 0.6, c % 2 ? P[5] : P[4], 0.7 - k * 0.045); } const px = x + Math.cos(a) * (60 + c * 12), py = y - 80 + Math.sin(a) * (34 + c * 6); dot(ctx, px, py, 3.5, '#ffffff'); } },
  black_hole(ctx, x, y, t, P) { const cx = x + 44, cy = y - 130; for (let k = 0; k < 4; k++) { ctx.strokeStyle = hexA(k % 2 ? P[5] : P[4], 0.6 - k * 0.1); ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(cx, cy, 26 + k * 6, 8 + k * 2, -0.3, t * (2 - k * 0.3), t * (2 - k * 0.3) + 4.5); ctx.stroke(); } dot(ctx, cx, cy, 11, '#000000'); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, cy, 12, 0, TAU); ctx.stroke(); for (let i = 0; i < 8; i++) { const k = (t * 0.9 + i / 8) % 1, a = i * 0.8 + k * 3; G(ctx, cx + Math.cos(a) * 80 * (1 - k), cy + Math.sin(a) * 50 * (1 - k), 5, P[4], k); } },
  // ---------------------------------------------------------------- ซีเคร็ต
  glitch(ctx, x, y, t, P) {
    const seed = Math.floor(t * 12);
    for (let i = 0; i < 6; i++) { const r = Math.sin(seed * 12.9898 + i * 78.233) * 43758.5453, f = r - Math.floor(r); const w = 16 + f * 50, h = 3 + (i % 3) * 3; ctx.fillStyle = i % 3 === 0 ? 'rgba(255,42,90,0.75)' : i % 3 === 1 ? 'rgba(90,255,224,0.7)' : 'rgba(255,255,255,0.85)'; ctx.fillRect(x - 40 + f * 60, y - 160 + ((f * 997) % 150), w, h); }
    ctx.font = '900 14px monospace'; ctx.textAlign = 'center'; ctx.fillStyle = `rgba(255,42,90,${0.6 + 0.4 * Math.sin(t * 9)})`; ctx.fillText('???', x + Math.sin(t * 3) * 34, y - 170);
    ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = 1; ctx.strokeRect(x - 42 + Math.sin(seed) * 3, y - 150, 84, 150);
    G(ctx, x - 3, y - 70, 50, '#ff2a5a', 0.25); G(ctx, x + 3, y - 70, 50, '#5affe0', 0.25);
  },
  void_eye(ctx, x, y, t, P) { const cy = y - 165, open = 0.5 + 0.5 * Math.max(0, Math.sin(t * 0.9)); G(ctx, x, cy, 50, P[1], 0.45); ctx.fillStyle = '#000000'; ctx.beginPath(); ctx.ellipse(x, cy, 26, 13 * open + 1, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = P[1]; ctx.lineWidth = 2; ctx.stroke(); dot(ctx, x + Math.sin(t * 1.3) * 8, cy, 6 * open + 0.5, P[4]); dot(ctx, x + Math.sin(t * 1.3) * 8, cy, 2.4 * open, '#ffffff'); for (let i = 0; i < 6; i++) { const a = t * 0.5 + i * TAU / 6; ctx.strokeStyle = hexA(P[1], 0.5); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * 30, cy + Math.sin(a) * 16); ctx.lineTo(x + Math.cos(a) * (50 + Math.sin(t * 3 + i) * 8), cy + Math.sin(a) * 30); ctx.stroke(); } },
};

// the coloured ring under the feet of a skin of อีปิค or better (its tier colour)
export function drawTierRing(ctx, x, y, t, tier) {
  const T = SKIN_TIERS[tier]; if (!T || tier < 3) return;
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.strokeStyle = hexA(T.col, 0.55 + 0.2 * Math.sin(t * 3)); ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(x, y, 34 + (tier - 3) * 2, 11, 0, 0, TAU); ctx.stroke();
  if (tier >= 6) { ctx.setLineDash([4, 6]); ctx.lineDashOffset = -t * 20; ctx.beginPath(); ctx.ellipse(x, y, 44 + (tier - 3) * 2, 14, 0, 0, TAU); ctx.stroke(); ctx.setLineDash([]); }
  ctx.restore();
}
export function drawSkinAura(ctx, x, y, t, sk, scale = 1) {
  if (!sk?.aura || !AURAS[sk.aura]) return;
  ctx.save();
  if (scale !== 1) { ctx.translate(x, y); ctx.scale(scale, scale); ctx.translate(-x, -y); }
  drawTierRing(ctx, x, y, t, sk.t);
  ctx.globalCompositeOperation = sk.aura === 'glitch' || sk.aura === 'black_hole' || sk.aura === 'void_eye' ? 'source-over' : 'lighter';
  AURAS[sk.aura](ctx, x, y, t, sk.pal);
  ctx.restore();
}

// ------------------------------------------------------------------ hit effects (เลเจนด์ and up)
// pushed into the skill-effect runtime of the battle scenes (w.sk.fx) so they draw and expire with everything else
export function skinHit(w, e, combat) {
  if (!combat?.hit || !w?.sk?.fx || !e) return;
  const now = w.time || 0;
  if (now - (w.lastSkinHit || -9) < 0.07) return;
  w.lastSkinHit = now;
  w.sk.fx.add({ type: 'skinhit', kind: combat.hit, x: e.x, y: e.y - (e.r || 24) * 0.8, col: combat.col, col2: combat.col2, dur: combat.hit === 'glitchcut' ? 0.45 : 0.4, a: Math.random() * TAU });
}
// the drawing of one hit effect (called by battle/skillVfx.js)
export function drawSkinHit(ctx, e, k) {
  const { x, y, col, col2 } = e, inv = 1 - k;
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  switch (e.kind) {
    case 'fork': for (let b = 0; b < 4; b++) { const a = e.a + b * TAU / 4; ctx.strokeStyle = hexA(b % 2 ? col2 : col, inv); ctx.lineWidth = 2.4 * inv + 0.6; ctx.beginPath(); let px = x, py = y; ctx.moveTo(px, py); for (let s = 1; s <= 4; s++) { px = x + Math.cos(a + (s % 2 ? 0.3 : -0.3)) * s * 14 * (0.6 + k); py = y + Math.sin(a + (s % 2 ? 0.3 : -0.3)) * s * 14 * (0.6 + k); ctx.lineTo(px, py); } ctx.stroke(); } G(ctx, x, y, 40 * inv + 10, col, inv); break;
    case 'cross': { const r = 20 + k * 40; ctx.strokeStyle = hexA('#ffffff', inv); ctx.lineWidth = 6 * inv + 1; ctx.beginPath(); ctx.moveTo(x, y - r); ctx.lineTo(x, y + r * 0.7); ctx.moveTo(x - r * 0.6, y - r * 0.25); ctx.lineTo(x + r * 0.6, y - r * 0.25); ctx.stroke(); G(ctx, x, y, r * 1.4, col, inv * 0.9); ctx.strokeStyle = hexA(col, inv); ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke(); break; }
    case 'fang': for (const s of [-1, 1]) { ctx.strokeStyle = hexA(s > 0 ? col : col2, inv); ctx.lineWidth = 5 * inv + 1; ctx.beginPath(); ctx.arc(x, y + s * 4, 26 + k * 16, s > 0 ? Math.PI * 1.1 : 0.1, s > 0 ? Math.PI * 1.9 : Math.PI - 0.1); ctx.stroke(); } for (let i = 0; i < 4; i++) { const a = Math.PI * (1.2 + i * 0.2); ctx.fillStyle = hexA('#ffffff', inv); ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * 28, y + Math.sin(a) * 28); ctx.lineTo(x + Math.cos(a) * 14, y + Math.sin(a) * 14 + 6); ctx.lineTo(x + Math.cos(a + 0.12) * 28, y + Math.sin(a + 0.12) * 28); ctx.fill(); } G(ctx, x, y, 44, col, inv * 0.7); break;
    case 'starburst': for (let i = 0; i < 8; i++) { const a = e.a + i * TAU / 8, r = 12 + k * 46; star4(ctx, x + Math.cos(a) * r, y + Math.sin(a) * r, 6 * inv + 1, i % 2 ? col : '#ffffff'); } star4(ctx, x, y, 22 * inv + 4, '#ffffff'); G(ctx, x, y, 50 * inv + 10, col2, inv); break;
    case 'nebula': for (let i = 0; i < 5; i++) { const a = e.a + i * 1.3; G(ctx, x + Math.cos(a) * k * 36, y + Math.sin(a) * k * 26, 30 * inv + 8, [col, col2, '#ffffff'][i % 3], inv * 0.8); } ctx.strokeStyle = hexA(col2, inv); ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(x, y, 20 + k * 50, 8 + k * 18, e.a, 0, TAU); ctx.stroke(); break;
    case 'glitchcut': { ctx.globalCompositeOperation = 'source-over'; const n = 5; for (let i = 0; i < n; i++) { const off = (Math.sin((e.a + i) * 91.7) * 0.5) * 50; ctx.fillStyle = i % 2 ? `rgba(255,42,90,${inv})` : `rgba(90,255,224,${inv})`; ctx.fillRect(x - 40 + off * k, y - 30 + i * 12, 80 * inv + 10, 4); } ctx.fillStyle = `rgba(255,255,255,${inv})`; ctx.font = '900 16px monospace'; ctx.textAlign = 'center'; ctx.fillText(k < 0.5 ? '???' : 'ERR', x, y - 30 - k * 20); ctx.strokeStyle = `rgba(0,0,0,${inv})`; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x - 50, y + 20); ctx.lineTo(x + 50, y - 30); ctx.stroke(); ctx.strokeStyle = `rgba(255,255,255,${inv})`; ctx.lineWidth = 1.2; ctx.stroke(); break; }
    default: break;
  }
  ctx.restore();
}
export const AURA_KINDS = Object.keys(AURAS);

registerFx('skinhit', 'air', (ctx, e) => drawSkinHit(ctx, e, Math.min(1, e.t / e.dur)));
