// v10.2 the tricks of the worn Halloween artifacts in battle. The scenes call hwaEvent(world, kind, …) at a kill, a hit,
// a hurt, a dash and a skill cast; the skill runtime calls the 'tick'. Damage goes through world.playerStrike with
// src 'proc' (never re-triggers hit tricks); pictures go into world.sk.fx like the skills.
import { SK } from './skillCast.js';
import { addBuff } from './buffs.js';
import { gainUlt } from './ultimate.js';

const within = (...a) => SK.within(...a), nearest = (...a) => SK.nearest(...a);   // lazy: skillCast imports this file too
const strike = (w, e, power, ex = {}) => (e && !e.dead ? w.playerStrike?.(e, power, { src: 'proc', kx: 0, ky: 0, ...ex }) : null);
const fx = (w, o) => w.sk?.fx.add(o);
function boom(w, x, y, r, power, el, sym, ex = {}) {
  fx(w, { type: 'shock', x, y, r, el, dur: 0.4, band: 18 });
  if (sym) fx(w, { type: 'sym', mode: 'pop', sym, el, x, y: y - 30, size: 46, dur: 0.45 });
  for (const e of within(w, x, y, r)) strike(w, e, power, ex);
}
const ready = (S, key, now, cd) => { if ((S[key] || -99) + cd > now) return false; S[key] = now; return true; };
const chance = (c) => Math.random() < Math.min(0.95, c);

export function hwaEvent(w, kind, a, b) {
  const p = w?.player;
  if (!p || p.dead || !p.hwa?.length || !w.sk) return;
  const S = (p.hwaS ||= { n: 0, souls: 0, stack: 0, t: {} });
  const now = w.time || 0;
  for (const { id, def, k } of p.hwa) {
    const pr = def.proc, el = def.el;
    if (pr.on === 'lowhp' && kind === 'tick') {
      if (p.hp > p.maxHp * pr.below) continue;
      if (pr.regen) { S.t[id + 'r'] = (S.t[id + 'r'] || 0) + p.maxHp * pr.regen * k * a; if (S.t[id + 'r'] >= 1) { const n = Math.floor(S.t[id + 'r']); S.t[id + 'r'] -= n; p.hp = Math.min(p.maxHp, p.hp + n); } }
      if (pr.buff) addBuff(p, pr.buff, pr.v * k, 0.5);
      if (pr.bats && ready(S.t, id, now, pr.cd || 20)) {
        fx(w, { type: 'ringsyms', x: p.x, y: p.y, r: 70, el, dur: 1, sym: 'bat', n: pr.bats, lift: 70, flap: 14, size: 30 });
        for (const e of within(w, p.x, p.y, 260).slice(0, pr.bats)) { strike(w, e, pr.power * k); p.hp = Math.min(p.maxHp, p.hp + Math.round(p.maxHp * 0.02)); fx(w, { type: 'sym', mode: 'fly', sym: 'bat', el, x: p.x, y: p.y - 60, x2: e.x, y2: e.y - 40, size: 30, dur: 0.35, flap: 14 }); }
        w.fx?.callout?.(p.x, p.y - 130, def.name, '#ff4a5a');
      }
      continue;
    }
    if (pr.on !== kind) continue;
    if (kind === 'kill') {
      const e = a;
      if (pr.buff) addBuff(p, pr.buff, pr.v * k, pr.t);
      if (pr.cdr) for (const s of w.skills || []) if (s && s.cd > 0) s.cd = Math.max(0, s.cd - pr.cdr * k);
      if (pr.stack) { S.stack = Math.min(pr.max, S.stack + 1); addBuff(p, 'dmg', S.stack * pr.stack * k, 999); }
      if (pr.souls) S.souls = Math.min(pr.souls, S.souls + 1);
      if (!e) continue;
      if (pr.power && pr.r && chance((pr.chance || 1) * k)) boom(w, e.x, e.y, pr.r, pr.power * k, el, def.sym, { burn: true });
      if (pr.stun && chance(pr.chance * k)) { fx(w, { type: 'sym', mode: 'rise', sym: 'tomb', el, x: e.x, y: e.y - 26, size: 50, dur: 1 }); for (const f of within(w, e.x, e.y, pr.r)) strike(w, f, 0.1, { stun: pr.stun }); }
      if (pr.puddle) { fx(w, { type: 'field', x: e.x, y: e.y, r: pr.r, el, dur: pr.puddle }); const x = e.x, y = e.y; w.sk.act({ max: pr.puddle + 0.2, step: (dt, s) => { s.acc = (s.acc || 0) + dt; if (s.acc >= 0.5) { s.acc = 0; for (const f of within(w, x, y, pr.r)) strike(w, f, pr.power * k); } return s.t < pr.puddle; } }); }
      if (id === 'hwa_trick_box' && chance(pr.chance * k)) {
        const roll = Math.floor(Math.random() * 3);
        fx(w, { type: 'sym', mode: 'pop', sym: 'gift', el, x: e.x, y: e.y - 60, size: 50, dur: 0.8 });
        if (roll === 0) { const n = Math.round(p.maxHp * 0.06); p.hp = Math.min(p.maxHp, p.hp + n); w.fx?.number(p.x, p.y - 100, `+${n}`, 'heal'); }
        else if (roll === 1 && w.hwTreat) w.hwTreat(e);
        else gainUlt(w, 10);
      }
    } else if (kind === 'hit' || kind === 'crit') {
      const e = a;
      if (!e) continue;
      if (pr.heal && ready(S.t, id, now, pr.gap || 0.3)) { const n = Math.max(1, Math.round(p.maxHp * pr.heal * k)); p.hp = Math.min(p.maxHp, p.hp + n); }
      if (pr.every) { S.t[id + 'n'] = (S.t[id + 'n'] || 0) + 1; if (S.t[id + 'n'] % pr.every === 0) { strike(w, e, 0.05, { mark: pr.mark * k, markT: pr.t }); fx(w, { type: 'mark', x: e.x, y: e.y, el, dur: pr.t, follow: e, h: (e.r || 24) * 2 + 50 }); } }
      if (pr.slow && chance(pr.chance * k)) { strike(w, e, 0.02, { slow: pr.slow, slowT: pr.t }); fx(w, { type: 'sym', mode: 'pop', sym: 'spider', el, x: e.x, y: e.y - 50, size: 30, dur: 0.5 }); }
      if (pr.power && pr.chance && !pr.stun && ready(S.t, id + 'p', now, pr.gap || 0.2) && chance(pr.chance * k)) {
        if (pr.r) boom(w, e.x, e.y, pr.r, pr.power * k, el, def.sym);
        else { fx(w, { type: 'sym', mode: 'fly', sym: 'raven', el, x: p.x, y: p.y - 120, x2: e.x, y2: e.y - 40, size: 34, dur: 0.25 }); strike(w, e, pr.power * k); }
      }
      if (pr.stun && chance(pr.chance * k)) strike(w, e, 0.02, { stun: pr.stun });
    } else if (kind === 'hurt') {
      const att = a;
      if (pr.cd && !ready(S.t, id, now, pr.cd / Math.max(1, k))) continue;
      if (pr.mark && att && chance(pr.chance * k)) { strike(w, att, 0.05, { mark: pr.mark, markT: pr.t }); fx(w, { type: 'sym', mode: 'pop', sym: 'doll', el, x: att.x, y: att.y - 70, size: 40, dur: 0.7 }); }
      if (pr.power && chance((pr.chance || 1) * k)) { boom(w, p.x, p.y, pr.r, pr.power * k, el, def.sym); fx(w, { type: 'flash', x: p.x, y: p.y - 30, r: pr.r, el, dur: 0.3, rays: 12 }); }
      if (pr.kb && chance(pr.chance * k)) { fx(w, { type: 'sym', mode: 'pop', sym: 'pumpkin', el, x: p.x, y: p.y - 140, size: 44, dur: 0.6 }); for (const e of within(w, p.x, p.y, pr.r)) { const ang = Math.atan2(e.y - p.y, e.x - p.x); strike(w, e, 0.1, { stun: pr.stun, kx: Math.cos(ang) * pr.kb, ky: Math.sin(ang) * pr.kb }); } }
      if (pr.slow && !pr.chance) { fx(w, { type: 'shock', x: p.x, y: p.y, r: pr.r, el, dur: 0.45 }); for (const e of within(w, p.x, p.y, pr.r)) strike(w, e, 0.05, { slow: pr.slow, slowT: pr.t }); }
      // the soul jar answers when the hero is about to fall
      if (pr.souls) continue;
    } else if (kind === 'tick') {
      const every = (pr.every || 5) / Math.max(1, k * 0.8 + 0.2);
      S.t[id + 'k'] = (S.t[id + 'k'] || 0) + a;
      if (S.t[id + 'k'] < every) continue;
      S.t[id + 'k'] = 0;
      if (pr.ward) { if (!(p.ward > 0)) { p.ward = pr.ward; fx(w, { type: 'sym', mode: 'float', sym: 'feather', el, x: p.x, y: p.y - 140, size: 34, dur: 1 }); } }
      else if (pr.zap) { const t = nearest(w, p.x, p.y, pr.r); if (t) { fx(w, { type: 'bolt', x: p.x + 30, y: p.y - 110, x2: t.x, y2: t.y - 30, el, dur: 0.2 }); strike(w, t, pr.zap * k, { burn: true }); } }
      else if (pr.stun) { fx(w, { type: 'sym', mode: 'pop', sym: 'bell', el, x: p.x, y: p.y - 140, size: 44, dur: 0.7 }); fx(w, { type: 'shock', x: p.x, y: p.y, r: pr.r, el, dur: 0.5, band: 14 }); for (const e of within(w, p.x, p.y, pr.r)) strike(w, e, 0.05, { stun: pr.stun }); }
      else if (pr.power) { const t = nearest(w, p.x, p.y, pr.r); if (t) { fx(w, { type: 'sym', mode: 'fly', sym: 'ghost', el, x: p.x, y: p.y - 80, x2: t.x, y2: t.y - 40, size: 34, dur: 0.4, h: 40 }); const tt = t; w.sk.act({ max: 0.6, step: (dt, s) => { if (s.t >= 0.4) { strike(w, tt, pr.power * k); return false; } return true; } }); } }
    } else if (kind === 'dash') {
      if (pr.power) boom(w, p.x, p.y, pr.r, pr.power * k, el, 'broom');
      if (pr.buff && chance(pr.chance * k)) { addBuff(p, pr.buff, pr.v, pr.t); fx(w, { type: 'sym', mode: 'float', sym: 'cat', el, x: p.x, y: p.y - 130, size: 34, dur: 0.8 }); }
      if (pr.iframes) p.iframes = Math.max(p.iframes || 0, 0.3 + pr.iframes * k);
    } else if (kind === 'cast') {
      const entry = a;
      if (pr.n) { const ts = within(w, p.x, p.y, 520).slice(0, pr.n); ts.forEach((t, i) => { fx(w, { type: 'sym', mode: 'fly', sym: 'bone', el, x: p.x, y: p.y - 60, x2: t.x, y2: t.y - 30, size: 26, dur: 0.3 + i * 0.04, spin: 12 }); const tt = t; w.sk.act({ max: 1, step: (dt, s) => { if (s.t >= 0.3 + i * 0.04) { strike(w, tt, pr.power * k); return false; } return true; } }); }); }
      if (pr.refund && entry && chance(pr.chance * k)) { entry.cd *= 1 - pr.refund; fx(w, { type: 'sym', mode: 'pop', sym: 'eye', el, x: p.x, y: p.y - 140, size: 40, dur: 0.6 }); }
    }
  }
}
// the soul jar: called from damagePlayer before the hero would drop too low
export function hwaGuard(w, p) {
  const S = p.hwaS;
  if (!S || !p.hwa?.length || p.dead) return;
  const jar = p.hwa.find((x) => x.def.proc.souls);
  if (!jar || S.souls < 5 || p.hp > p.maxHp * 0.2) return;
  S.souls -= 5;
  const n = Math.round(p.maxHp * 0.18 * jar.k);
  p.hp = Math.min(p.maxHp, p.hp + n);
  w.fx?.number(p.x, p.y - 110, `+${n}`, 'heal');
  w.sk?.fx.add({ type: 'ringsyms', x: p.x, y: p.y, r: 60, el: 'spirit', dur: 1, sym: 'ghost', n: 5, lift: 70, size: 28, spin: -3 });
  w.sk?.fx.add({ type: 'sym', mode: 'pop', sym: 'flask', el: 'spirit', x: p.x, y: p.y - 150, size: 50, dur: 0.8 });
}
