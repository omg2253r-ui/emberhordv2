// Stage select with enemy list and drop odds per kill.
import { h, glyph, itemImg, pct } from '../dom.js';
import { INFINITE, entriesLeft } from '../../data/infinite.js';
import { towerProgress, towerLock, TOWER, GODS } from '../../data/tower.js';
import { STAGES } from '../../data/stages.js';
import { getEnemy } from '../../data/enemies.js';
import { DUNGEONS } from '../../data/dungeons.js';
import { dungeonEnemies } from '../../systems/dungeon.js';
import { loreProgress } from '../../systems/story.js';
import { dropOdds } from '../../systems/loot.js';
import { isStageUnlocked } from '../../systems/progression.js';
import { tipTarget } from '../itemTip.js';

export function createStagesPanel(app) {
  return {
    id: 'stages', title: 'ออกล่า', icon: 'map',
    render(body) {
      const st = app.store.get();
      const o = app.online;
      const others = o.peers.length, inVillage = o.peers.filter((x) => x.p.zone === 'village').length;
      const onlineCard = h('article', { class: `stage online-zone ${o.online ? '' : 'locked'}`, 'data-stage': 'village' },
        h('div', { class: 'stage-top' },
          h('h3', {}, 'หมู่บ้านทางแยกถ่าน'),
          h('span', { class: `chip ${o.online ? 'ok' : 'warn'}` }, glyph('globe'), o.online ? `ออนไลน์ ${others + 1} คน` : 'ออฟไลน์')),
        h('p', { class: 'muted', style: { margin: 0, fontSize: 'var(--step--1)' } }, 'ลานกลางที่นักล่าทุกคนมาเจอกัน คุยกัน เพิ่มเพื่อน ตั้งปาร์ตี้ และท้าดวล 1v1 แบบชนะ 2 ใน 3 ยก'),
        h('div', { class: 'stage-facts' },
          h('span', { class: 'chip' }, glyph('people'), `ในหมู่บ้าน ${inVillage} คน`),
          h('span', { class: 'chip' }, glyph('friend'), `เพื่อน ${Object.keys(st.social.friends).length}`),
          h('span', { class: 'chip' }, glyph('duel'), `ดวล ชนะ ${st.pvp.wins} · แพ้ ${st.pvp.losses}`)),
        o.online
          ? (o.canSend() ? null : h('div', { class: 'notice' }, 'บัญชีนี้ดูได้อย่างเดียว: เดินและเห็นคนอื่นได้ แต่ส่งแชทหรือคำขอไม่ได้ ขอสิทธิ์ผู้ร่วมโต้ตอบจากเจ้าของเกม'))
          : h('div', { class: 'notice' }, o.reason),
        h('button', { class: 'btn primary', type: 'button', 'data-action': 'enter-village', disabled: !o.online, onclick: () => app.enterVillage() }, glyph('globe'), 'เข้าหมู่บ้าน'));
      const zonesCleared = Object.keys(st.zones.cleared).length;
      const riftCard = h('article', { class: 'stage online-zone rift', 'data-stage': 'zones' },
        h('div', { class: 'stage-top' }, h('h3', {}, 'ประตูมิติ · ดันเจี้ยนรวม'), h('span', { class: 'chip ok' }, `พิชิต ${zonesCleared}/10 โซน`)),
        h('p', { class: 'muted', style: { margin: 0, fontSize: 'var(--step--1)' } }, 'สิบโซนที่ไม่ซ้ำกันทั้งกลไก มอนสเตอร์ และบอส ลุยคนเดียวหรือเปิดคณะสำรวจให้คนอื่นเข้าร่วมได้ถึง 4 คน บอสทุกตัวมีอาวุธระดับตำนาน'),
        h('button', { class: 'btn primary', type: 'button', 'data-action': 'open-zones', onclick: () => app.openZones() }, glyph('door'), 'เปิดประตูมิติ'));
      const infLock = app.infiniteLock();
      const left = entriesLeft(st);
      const owned = Object.keys(st.artifacts?.owned || {}).length;
      const infCard = h('article', { class: `stage online-zone infinite ${infLock ? 'locked' : ''}`, 'data-stage': 'infinite' },
        h('div', { class: 'stage-top' }, h('h3', {}, glyph('infinity'), 'รอยแยกไร้สิ้นสุด'),
          h('span', { class: `chip ${left ? 'ok' : ''}`, 'data-entries': left }, `สิทธิ์วันนี้ ${left}/${INFINITE.entriesPerDay}`)),
        h('p', { class: 'muted', style: { margin: 0, fontSize: 'var(--step--1)' } }, 'คลื่นศัตรูไม่มีที่สิ้นสุด ทุก 5 คลื่นรอยแยกเปลี่ยนดินแดนและมีผู้พิทักษ์ ได้เฉพาะเหรียญและอาร์ติแฟกต์ ตายหรือออกเมื่อไหร่ก็รับรางวัลที่สะสมไว้ทั้งหมด'),
        h('div', { class: 'inf-meta' }, h('span', {}, glyph('crown'), `สถิติ ${st.infinite?.best || 0} คลื่น`), h('span', {}, glyph('cosmos'), `อาร์ติแฟกต์ ${owned} ชนิด`)),
        h('div', { class: 'zone-actions' },
          h('button', { class: 'btn', type: 'button', 'data-action': 'open-cosmos', onclick: () => app.openCosmos() }, glyph('cosmos'), 'จักรวาลอาร์ติแฟกต์'),
          h('button', { class: 'btn primary', type: 'button', 'data-action': 'start-infinite', disabled: !!infLock, title: infLock || '', onclick: () => app.startInfinite() }, glyph(infLock ? 'lock' : 'infinity'), infLock || 'เข้ารอยแยก')));
      const tp = towerProgress(st), tLock = towerLock(st);
      const towerCard = h('article', { class: `stage online-zone tower ${tLock ? 'locked' : ''}`, 'data-stage': 'tower' },
        h('div', { class: 'stage-top' }, h('h3', {}, glyph('skull'), 'หอคอยขุมนรก 100 ชั้น'), h('span', { class: 'chip ok' }, `ชั้น ${tp.best}/${TOWER.floors}${tp.asc ? ` · ขุมลึก ${tp.asc}` : ''}`)),
        h('p', { class: 'muted', style: { margin: 0, fontSize: 'var(--step--1)' } }, 'ลุยคนเดียว ทุกชั้นมีศัตรูและคำสาปไม่ซ้ำกัน ทุก 10 ชั้นมีเทพแห่งขุมนรกที่สู้ตัวต่อตัวและเรียกสมุน ผ่านชั้น 100 แล้วจะเปิดขุมที่ลึกกว่าไม่มีที่สิ้นสุด'),
        h('div', { class: 'inf-meta' }, h('span', {}, glyph('skull'), `เทพที่ปราบ ${Object.keys(tp.gods).length}/${GODS.length}`), h('span', {}, glyph('crown'), `ปีนแล้ว ${tp.runs} ครั้ง`)),
        h('button', { class: 'btn primary', type: 'button', 'data-action': 'open-tower', disabled: !!tLock, title: tLock || '', onclick: () => app.openTower() }, glyph(tLock ? 'lock' : 'skull'), tLock || 'เข้าหอคอย'));
      body.replaceChildren(
        h('div', { class: 'eyebrow zone-head' }, 'โซนออนไลน์'), onlineCard, riftCard,
        h('div', { class: 'eyebrow zone-head' }, 'โหมดพิเศษ'), towerCard, infCard,
        h('button', { class: 'btn gold book-btn', type: 'button', 'data-action': 'open-bestiary', onclick: () => app.openBestiary() }, glyph('skull'), 'สมุดบอส · ดูบอสทั้งหมด แพทเทิร์น และของดรอป'),
        h('div', { class: 'eyebrow zone-head' }, 'เนื้อเรื่อง · ป่าหนาม'),
        ...STAGES.map((stage) => {
        const open = isStageUnlocked(st, stage);
        const clears = st.progress.clears[stage.id] || 0;
        const dg = DUNGEONS[stage.id];
        const foeIds = dungeonEnemies(dg);
        const lp = loreProgress(st, stage.id);
        const traps = new Set(dg.rooms.flatMap((r) => (r.traps || []).map((t) => t.kind)));
        const trapNames = { spikes: 'หนามพื้น', dart: 'ป้อมยิงหนาม', vent: 'ช่องไฟ', rocks: 'หินถล่ม' };
        const lvlGap = stage.recommendedLevel - st.player.level;
        return h('article', { class: `stage ${open ? '' : 'locked'}`, 'data-stage': stage.id },
          h('div', { class: 'stage-top' },
            h('h3', {}, stage.name),
            h('span', { class: `chip ${lvlGap > 1 ? 'warn' : ''}` }, `แนะนำเลเวล ${stage.recommendedLevel}`),
            clears ? h('span', { class: 'chip ok' }, glyph('check'), `ผ่านแล้ว ${clears} ครั้ง`) : null),
          h('p', { class: 'muted', style: { margin: 0, fontSize: 'var(--step--1)' } }, stage.desc),
          h('div', { class: 'stage-facts' },
            h('span', { class: 'chip' }, glyph('door'), `${dg.rooms.length} ห้อง`),
            h('span', { class: 'chip' }, glyph('book'), `เอกสาร ${lp.found}/${lp.total}`),
            h('span', { class: 'chip warn' }, `กับดัก: ${[...traps].map((k) => trapNames[k]).join(' · ')}`)),
          h('div', { class: 'foes' }, foeIds.map((id) => {
            const e = getEnemy(id);
            return h('div', { class: 'foe' },
              h('b', {}, e.name, e.boss ? ' (บอส)' : ''),
              h('span', { class: 'muted num' }, `ทอง ${e.gold[0]}–${e.gold[1]}`),
              h('div', { class: 'odds' }, dropOdds(e.drops).sort((a, b) => b.chance - a.chance).map((o) =>
                tipTarget(h('span', {}, itemImg(o.id), h('span', { class: 'num' }, pct(o.chance, o.chance < 0.1 ? 1 : 0))), o.id, { chance: o.chance }))));
          })),
          h('small', { class: 'faint' }, 'ตัวเลขคือโอกาสที่ไอเทมนั้นดรอปต่อการกำจัดศัตรูหนึ่งตัว · กดค้างที่ไอเทมเพื่อดูว่าคืออะไร ใช้ทำอะไร และขายได้เท่าไหร่'),
          open
            ? h('button', { class: 'btn primary', type: 'button', 'data-action': 'start-stage', onclick: () => app.startBattle(stage.id) }, glyph('sword'), clears ? 'ล่าอีกครั้ง' : 'ออกล่า')
            : h('button', { class: 'btn', type: 'button', disabled: true }, glyph('lock'), `ผ่าน ${STAGES.find((s) => s.id === stage.requires)?.name} ก่อน`));
      }));
    },
  };
}
