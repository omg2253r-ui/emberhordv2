// v10.2 the Halloween artifact altar (a tab of the candy shop): the three worn relics, the chest, the whole set of 30,
// and the twenty Halloween pets that only drop in the Halloween lands (where, and how often).
import { h, glyph, itemImg, fmt } from './dom.js';
import { svgDataUri } from '../art/icons.js';
import { SYM } from '../art/symbols.js';
import { elOf } from '../battle/skillVfx.js';
import { rarityOf } from '../data/rarity.js';
import { HW_ARTIFACTS, HWA_IDS, HWA_SLOTS, HWA_CHEST, HWA_LEVEL_MAX, HWA_RARITY_W, HWA_DROP, hwaStatMult, hwaProcMult } from '../data/hwArtifacts.js';
import { hwaLevel, buyHwaChest, wearHwArtifact, removeHwArtifact } from '../systems/hwArtifacts.js';
import { bonusText } from '../data/jobs.js';
import { PETS_HW2 } from '../data/hwPets2.js';
import { getZone } from '../data/zones.js';
import { petValues } from '../data/pets.js';
import { hwActive } from '../data/halloween.js';

const ICONS = new Map();
export function hwaIconUri(id) {
  if (!ICONS.has(id)) {
    const a = HW_ARTIFACTS[id], c = elOf(a.el), rc = rarityOf(a.rarity).color;
    ICONS.set(id, svgDataUri(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><radialGradient id="g" cx="0.5" cy="0.4" r="0.7"><stop offset="0" stop-color="${c.glow}"/><stop offset="0.6" stop-color="#2a1430"/><stop offset="1" stop-color="#0b0812"/></radialGradient></defs>
      <path d="M32 2 L58 16 L58 48 L32 62 L6 48 L6 16 Z" fill="url(#g)" stroke="${rc}" stroke-width="2.6"/><path d="M32 7 L54 19 L54 45 L32 57 L10 45 L10 19 Z" fill="none" stroke="${rc}" stroke-opacity="0.45" stroke-width="1"/>
      <g transform="translate(10 10) scale(0.69)">${(SYM[a.sym] || SYM.star)(c)}</g></svg>`));
  }
  return ICONS.get(id);
}
const icon = (id, cls = 'hwa-img') => h('img', { class: cls, src: hwaIconUri(id), alt: HW_ARTIFACTS[id].name, draggable: 'false' });
const odds = (() => { const tot = HWA_IDS.reduce((a, id) => a + HWA_RARITY_W[HW_ARTIFACTS[id].rarity], 0); return (id) => HWA_RARITY_W[HW_ARTIFACTS[id].rarity] / tot; })();

export function relicTab(app, rerender) {
  const st = app.store.get();
  const act = (r, msg) => { if (!r.ok) { app.toast({ candy: 'แคนดี้ไม่พอ', full: `วางได้ ${HWA_SLOTS} ชิ้น`, event_over: 'กิจกรรมฮาโลวีนจบแล้ว' }[r.reason] || 'ทำไม่ได้', 'warn'); app.audio.play('error'); return false; } app.store.commit(r.state, { reason: 'hwa' }); if (msg) app.toast(msg, 'ok'); app.audio.play('click'); rerender(); return true; };
  const slots = h('div', { class: 'hwa-altar' }, ...Array.from({ length: HWA_SLOTS }, (_, i) => {
    const id = st.hwa.on[i];
    return h('div', { class: `hwa-slot ${id ? 'on' : ''}`, 'data-hwa-slot': i },
      id ? icon(id) : h('span', { class: 'hwa-empty' }, glyph('lock')),
      h('b', {}, id ? HW_ARTIFACTS[id].name : 'ช่องว่าง'), id ? h('small', { class: 'muted' }, `Lv.${hwaLevel(st, id)}`) : h('small', { class: 'muted' }, 'แตะอาร์ติแฟกต์ด้านล่างเพื่อวาง'),
      id ? h('button', { class: 'btn small', type: 'button', onclick: () => act(removeHwArtifact(app.store.get(), id)) }, 'ถอด') : null);
  }));
  const chest = h('div', { class: 'hwa-chest' },
    h('div', { class: 'hwa-chest-art' }, glyph('skull')),
    h('div', {}, h('b', {}, HWA_CHEST.name), h('small', { class: 'muted' }, `สุ่ม 1 ใน 30 ชิ้น (ยิ่งหายากยิ่งออกยาก) ได้ซ้ำเลเวลขึ้น สูงสุด Lv.${HWA_LEVEL_MAX} · ตกจากมอนสเตอร์ในดันฮาโลวีน ${(HWA_DROP.mob * 100).toFixed(1)}% และบอส ${Math.round(HWA_DROP.boss * 100)}%`)),
    h('button', { class: `btn ${(st.candy || 0) >= HWA_CHEST.price && hwActive() ? 'gold' : ''}`, type: 'button', 'data-action': 'hwa-chest', disabled: !hwActive(), onclick: () => {
      const r = buyHwaChest(app.store.get(), () => app.rng.next());
      if (act(r)) { const a = HW_ARTIFACTS[r.id]; app.audio.play('legendary'); app.toast(r.maxed ? `${a.name} เลเวลเต็มแล้ว ได้แคนดี้ ${r.candy}` : `ได้ ${a.name}${r.lvl > 1 ? ` (Lv.${r.lvl})` : ''}!`, 'loot', null, { rarity: a.rarity }); }
    } }, itemImg('candy'), fmt(HWA_CHEST.price)));
  const list = h('div', { class: 'hwa-grid' }, ...HWA_IDS.map((id) => {
    const a = HW_ARTIFACTS[id], lv = hwaLevel(st, id), on = st.hwa.on.includes(id), rar = rarityOf(a.rarity);
    return h('div', { class: `hwa-card r-${rar.id} ${lv ? '' : 'locked'} ${on ? 'on' : ''}`, 'data-hwa': id },
      icon(id), h('b', { class: 'rc-text' }, lv ? a.name : `${a.name}`), h('small', { class: 'rc-text' }, `${rar.name}${lv ? ` · Lv.${lv}` : ' · ยังไม่มี'} · ${(odds(id) * 100).toFixed(1)}%`),
      h('small', {}, bonusText(Object.fromEntries(Object.entries(a.fx).map(([k, v]) => [k, v * hwaStatMult(lv || 1)])))),
      h('small', { class: 'muted' }, a.desc(hwaProcMult(lv || 1))),
      lv ? (on ? h('button', { class: 'btn small', type: 'button', onclick: () => act(removeHwArtifact(app.store.get(), id)) }, 'ถอด') : h('button', { class: 'btn small primary', type: 'button', 'data-action': 'hwa-wear', onclick: () => act(wearHwArtifact(app.store.get(), id), `วาง ${a.name} บนแท่นบูชา`) }, 'วาง')) : null);
  }));
  const owned = HWA_IDS.filter((id) => hwaLevel(st, id)).length;
  return [h('div', { class: 'notice' }, `อาร์ติแฟกต์ฮาโลวีน 30 ชิ้น มีเฉพาะช่วงกิจกรรม วางบนแท่นบูชาได้ ${HWA_SLOTS} ชิ้น · แต่ละชิ้นมีค่าสถานะและความสามารถพิเศษของตัวเองในการต่อสู้`), slots, chest,
    h('div', { class: 'eyebrow' }, `สะสมแล้ว ${owned}/${HWA_IDS.length}`), list];
}

export function hwPetDropCards(app) {
  const st = app.store.get();
  return [h('div', { class: 'eyebrow' }, 'สัตว์เลี้ยงที่ตกจากบอสในดันฮาโลวีนเท่านั้น (20 ตัว)'),
    h('div', { class: 'hw-grid' }, ...Object.values(PETS_HW2).map((p) => {
      const own = st.pets.owned[p.id], v = petValues(p, own?.stars || 1);
      return h('div', { class: `hw-card r-${p.rarity}`, 'data-pet': p.id },
        h('div', { class: 'hw-prev hw-anim fx-float' }, h('img', { class: 'item-img', alt: p.name, src: app.petUri(p.id) })),
        h('b', {}, own ? p.name : p.name), h('small', { class: 'muted' }, `${p.role} · ${p.ability.name}`), h('small', {}, p.text(v)),
        h('span', { class: `chip ${own ? 'ok' : 'warn'}` }, own ? `มีแล้ว ${'★'.repeat(own.stars)}` : `บอส${getZone(p.zone)?.name || ''} ${(p.chance * 100).toFixed(1)}%`));
    }))];
}
