// v10 Halloween attack patterns. Same world API as the land bosses (see battle/zoneBehaviours.js), plus the event's own:
//   strike / shoot accept `cu` (one of the fifteen curses, data/halloween.js) and `clash` (the Light Guardian's blows)
//   world.hw — the run's Halloween state (battle/hwCoop.js): chess board, mirror trap, dark-guardian cycles, ally …
// Every boss here plays differently: the reaper grows with the damage it takes and the time spent, the Luring Witch
// dodges and curses, the Deceiver lies with her warnings, the five guardians each have a mechanic nobody else has.
import { BEHAVIOURS } from './enemies.js';
import { CURSE_IDS, getCurse } from '../data/halloween.js';

const TAU = Math.PI * 2;
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const toward = (e, p) => Math.atan2(p.y - e.y, p.x - e.x);
function steer(e, angle, speed, dt, k = 6) { const f = Math.min(1, dt * k); e.vx += (Math.cos(angle) * speed - e.vx) * f; e.vy += (Math.sin(angle) * speed - e.vy) * f; }
const stop = (e, dt, k = 8) => steer(e, 0, 0, dt, k);
function setState(e, s) { e.state = s; e.t = 0; e.ai.step = 0; e.hitThisAttack = false; }
const warn = (e, k) => { e.warn = Math.max(0, Math.min(1, k)); };
function inArena(world, x, y, pad = 110) { const A = world.arena; return { x: Math.max(pad, Math.min(A.w - pad, x)), y: Math.max(pad + 40, Math.min(A.h - pad, y)) }; }
const angDiff = (a, b) => { let d = a - b; while (d > Math.PI) d -= TAU; while (d < -Math.PI) d += TAU; return d; };
const rnd = (world) => world.rng.next();
const pick = (world, list) => list[Math.floor(rnd(world) * list.length)];
const randomPlayer = (world) => { const ps = world.players; return ps.length ? ps[Math.floor(rnd(world) * ps.length)] : world.player; };
function tryContact(e, world, mult = 1, extra = 0, kb = 300) {
  if (e.hitThisAttack) return;
  const p = world.player; if (!p || p.dead) return;
  if (dist(e, p) <= e.r + (p.r || 20) + extra) { const a = toward(e, p); if (world.hitPlayer(e, mult, Math.cos(a) * kb, Math.sin(a) * kb)) e.hitThisAttack = true; }
}
// parryable melee in an arc (every player inside is struck on their own side)
function meleeArc(e, world, dir, range, arc, mult, kb = 360, extra = null) {
  const prev = world.player;
  for (const t of world.players) {
    if (!t || t.dead) continue;
    if (Math.hypot(t.x - e.x, t.y - e.y) > range + (t.r || 20) || Math.abs(angDiff(Math.atan2(t.y - e.y, t.x - e.x), dir)) > arc / 2) continue;
    world.player = t;
    const a = Math.atan2(t.y - e.y, t.x - e.x);
    world.hitPlayer(e, mult, Math.cos(a) * kb, Math.sin(a) * kb, false, extra);
  }
  world.player = prev;
}
const arcTell = (world, e, dir, range, arc, dur, tone) => world.strike({ shape: 'cone', x: e.x, y: e.y - 10, angle: dir, r: range, arc, dur, mult: 0, owner: e, tone });
function phaseOf(e, cuts = [0.66, 0.33]) { const f = e.hp / e.maxHp; return f > cuts[0] ? 1 : f > cuts[1] ? 2 : 3; }
function phaseChange(e, world, lines, onEnter) {
  const ph = phaseOf(e);
  if (ph !== e.ai.phase) { if (e.ai.phase) { world.announce(lines[ph] || ''); world.sfx('roar'); world.shake(12, 0.6); onEnter?.(ph); } e.ai.phase = ph; }
  return ph;
}
function blinkTo(e, world, x, y, col = '#c86aff') {
  world.particles.burst(e.x, e.y - 40, 26, { color: [col, '#ffffff'], speedMin: 80, speedMax: 300, life: 0.5, size: 4, drag: 3, glow: true });
  const q = inArena(world, x, y); e.x = q.x; e.y = q.y; e.vx = e.vy = 0;
  world.particles.burst(e.x, e.y - 40, 26, { color: [col, '#ffffff'], speedMin: 80, speedMax: 300, life: 0.5, size: 4, drag: 3, glow: true });
  world.sfx('blink');
}
const say = (world, e, text, col = '#ffcf5a') => world.fx.callout?.(e.x, e.y - (e.r || 30) * 2 - 70, text, col);
// a potion lobbed at a spot: the bottle flies, then the curse splashes in a circle
function lobCurse(world, e, x, y, r, dur, mult, curse) {
  const c = getCurse(curse);
  world.shoot(e, { x: e.x, y: e.y - 60, angle: Math.atan2(y - e.y + 60, x - e.x), speed: Math.max(160, dist({ x, y }, { x: e.x, y: e.y - 60 }) / dur), r: 12, mult: 0, kind: 'hwpotion', life: dur, tintCol: c.col });
  world.strike({ shape: 'circle', x, y, r, dur, mult, owner: e, tone: 'hex', cu: curse });
}

// ===================================================================== monsters
Object.assign(BEHAVIOURS, {
  hw_none(e) { e.vx = 0; e.vy = 0; },
  hw_static(e) { e.vx = 0; e.vy = 0; },
  // แมนเดรก: hides in the soil, pops up next to someone and screams (a wide ring)
  hw_mandrake(e, dt, world) {
    const P = e.type.ai_params, p = world.player;
    if (e.state === 'idle') { setState(e, 'hide'); e.untargetable = true; e.hidden = 0.8; }
    if (e.state === 'hide') {
      steer(e, toward(e, p), 210, dt, 5);
      if (e.t > P.hide && dist(e, p) < 220) { setState(e, 'pop'); e.untargetable = false; e.hidden = 0; world.sfx('spawn'); world.strike({ shape: 'ring', x: e.x, y: e.y, r: P.ring, inner: 40, dur: P.scream, mult: 0.9, owner: e, tone: 'spore', chill: 0.8 }); }
      else if (e.t > P.hide * 3) { setState(e, 'pop'); e.untargetable = false; e.hidden = 0; }
    } else if (e.state === 'pop') {
      stop(e, dt, 10); warn(e, e.t / P.scream);
      if (e.t > P.scream) { e.warn = 0; say(world, e, 'กรี๊ดดดด!', '#b8ff8a'); world.shake(4, 0.2); setState(e, 'rest'); }
    } else if (e.state === 'rest') { stop(e, dt, 5); if (e.t > 1.6) { setState(e, 'hide'); e.untargetable = true; e.hidden = 0.8; } }
  },
  // งูเถาวัลย์: slithers in an S, then lunges in a straight line and leaves thorns
  hw_vine(e, dt, world) {
    const P = e.type.ai_params, p = world.player;
    if (e.state === 'idle') setState(e, 'slither');
    if (e.state === 'slither') {
      steer(e, toward(e, p) + Math.sin(world.time * 5 + e.id) * 0.9, e.type.speed, dt, 6);
      if (e.t > 1.4 && dist(e, p) < 420) { setState(e, 'aim'); e.ai.dir = toward(e, p); world.strike({ shape: 'line', x: e.x, y: e.y - 10, angle: e.ai.dir, len: P.lunge * 0.45, width: 40, dur: P.windup, mult: 0, owner: e, tone: 'poison' }); world.sfx('telegraph'); }
    } else if (e.state === 'aim') { stop(e, dt, 12); warn(e, e.t / P.windup); if (e.t > P.windup) { e.warn = 0; setState(e, 'lunge'); } }
    else if (e.state === 'lunge') {
      e.vx = Math.cos(e.ai.dir) * P.lunge; e.vy = Math.sin(e.ai.dir) * P.lunge; tryContact(e, world, 1.1);
      if (e.t > 0.42) { world.pool({ x: e.x, y: e.y, r: 50, dur: 3, kind: 'poison', mult: 0.25, owner: e }); setState(e, 'rest'); }
    } else if (e.state === 'rest') { stop(e, dt, 6); if (e.t > 0.9) setState(e, 'slither'); }
  },
  // เห็ดแม่มด: blinks around and leaves spore puffs that slow
  hw_witchcap(e, dt, world) {
    const P = e.type.ai_params, p = world.player;
    if (e.state === 'idle') setState(e, 'walk');
    if (e.state === 'walk') {
      steer(e, toward(e, p) + 1.3, e.type.speed, dt, 3);
      if (e.t > P.blink) { setState(e, 'cast'); }
    } else if (e.state === 'cast') {
      stop(e, dt, 10);
      if (e.ai.step === 0) { e.ai.step = 1; for (let i = 0; i < P.spores; i++) { const a = rnd(world) * TAU, d = 60 + rnd(world) * 160; world.strike({ shape: 'circle', x: p.x + Math.cos(a) * d * 0.5, y: p.y + Math.sin(a) * d * 0.5, r: 70, dur: 0.9 + i * 0.15, mult: 0.7, owner: e, tone: 'spore', then: { pool: { kind: 'web', r: 60, dur: 3, mult: 0 } } }); } world.sfx('cast'); }
      warn(e, e.t / 0.9);
      if (e.t > 1.3) { e.warn = 0; blinkTo(e, world, p.x + (rnd(world) - 0.5) * 600, p.y + (rnd(world) - 0.5) * 400, '#b86aff'); setState(e, 'walk'); }
    }
  },
  // ปีศาจฟักทอง: hop, hop, bite; when it pops it scatters burning seeds
  hw_imp(e, dt, world) {
    const P = e.type.ai_params, p = world.player;
    if (e.state === 'idle') setState(e, 'hop');
    if (e.state === 'hop') {
      if (e.ai.step === 0) { e.ai.dir = toward(e, p) + (rnd(world) - 0.5) * 0.6; e.ai.step = 1; }
      const k = e.t / P.hop; e.ai.z = Math.sin(Math.min(1, k) * Math.PI) * 40;
      e.vx = Math.cos(e.ai.dir) * e.type.speed * 1.6; e.vy = Math.sin(e.ai.dir) * e.type.speed * 1.6;
      if (k >= 1) { e.ai.z = 0; setState(e, dist(e, p) < 90 ? 'bite' : 'land'); }
    } else if (e.state === 'land') { stop(e, dt, 12); if (e.t > 0.25) setState(e, 'hop'); }
    else if (e.state === 'bite') {
      stop(e, dt, 10); warn(e, e.t / 0.4);
      if (e.t > 0.4 && e.ai.step === 0) { e.ai.step = 1; e.warn = 0; steer(e, toward(e, p), 500, 1, 1); tryContact(e, world, P.bite, 20); world.sfx('swing'); }
      if (e.t > 0.9) setState(e, 'hop');
    }
  },
  // ผีโคม: fades out (cannot be hit), drifts, fades in and fires three wisps
  hw_ghost(e, dt, world) {
    const P = e.type.ai_params, p = world.player;
    if (e.state === 'idle') setState(e, 'fade');
    if (e.state === 'fade') {
      e.hidden = Math.min(0.85, e.t * 1.5); e.untargetable = e.hidden > 0.5;
      steer(e, toward(e, p) + 1.6, e.type.speed, dt, 3);
      if (e.t > P.phase) { setState(e, 'show'); }
    } else if (e.state === 'show') {
      e.hidden = Math.max(0, 0.85 - e.t * 2.5); e.untargetable = false; stop(e, dt, 6); warn(e, e.t / 0.6);
      if (e.t > 0.6 && e.ai.step === 0) { e.ai.step = 1; e.warn = 0; const a = toward(e, p); for (let i = 0; i < P.volley; i++) world.shoot(e, { x: e.x, y: e.y - 40, angle: a + (i - 1) * 0.25, speed: 330, r: 11, mult: 0.8, kind: 'hwsoul', homing: 0.6, life: 3.5 }); world.sfx('cast'); }
      if (e.t > 1.4) setState(e, 'fade');
    }
  },
  // ฝูงค้างคาว: circles, then a telegraphed dive through the target and scatter
  hw_bats(e, dt, world) {
    const P = e.type.ai_params, p = world.player;
    if (e.state === 'idle') { setState(e, 'circle'); e.ai.a = rnd(world) * TAU; }
    if (e.state === 'circle') {
      e.ai.a += dt * 1.8; const tx = p.x + Math.cos(e.ai.a) * 260, ty = p.y + Math.sin(e.ai.a) * 180;
      steer(e, Math.atan2(ty - e.y, tx - e.x), e.type.speed * 1.4, dt, 4);
      if (e.t > 2.2) { setState(e, 'aim'); e.ai.dir = toward(e, p); world.strike({ shape: 'line', x: e.x, y: e.y - 20, angle: e.ai.dir, len: P.dive * 0.7, width: 56, dur: P.windup, mult: 0, owner: e, tone: 'shadow' }); world.sfx('telegraph'); }
    } else if (e.state === 'aim') { stop(e, dt, 12); warn(e, e.t / P.windup); if (e.t > P.windup) { e.warn = 0; setState(e, 'dive'); world.sfx('dash'); } }
    else if (e.state === 'dive') { e.vx = Math.cos(e.ai.dir) * P.dive; e.vy = Math.sin(e.ai.dir) * P.dive; tryContact(e, world, 1.0, 10); if (e.t > 0.7) setState(e, 'circle'); }
  },
  // โครงกระดูกลูกกวาด: keeps distance and lobs candy bones; reassembles once (revive)
  hw_skeleton(e, dt, world) {
    const P = e.type.ai_params, p = world.player;
    if (e.state === 'ash') { stop(e, dt, 10); e.untargetable = e.t < 1.4; if (e.t > 1.4) { e.hp = Math.round(e.maxHp * 0.5); say(world, e, 'ประกอบร่าง!', '#ffd8e8'); setState(e, 'keep'); } return; }
    if (e.state === 'idle') setState(e, 'keep');
    if (e.state === 'keep') {
      const d = dist(e, p); steer(e, toward(e, p) + (d < 260 ? Math.PI : 0.5), e.type.speed, dt, 4);
      if (e.t > P.throwEvery) { setState(e, 'throw'); }
    } else if (e.state === 'throw') {
      stop(e, dt, 10); warn(e, e.t / 0.45);
      if (e.t > 0.45 && e.ai.step === 0) { e.ai.step = 1; e.warn = 0; const a = toward(e, p); for (const o of [-0.2, 0, 0.2]) world.shoot(e, { x: e.x, y: e.y - 50, angle: a + o, speed: 380, r: 12, mult: 0.85, kind: 'hwbone', life: 2.6 }); world.sfx('swing'); }
      if (e.t > 0.9) setState(e, 'keep');
    }
  },
  // ดวงวิญญาณ: drifts at you; touching it — or killing it close — bursts a ring
  hw_soulwisp(e, dt, world) {
    const p = world.player;
    steer(e, toward(e, p), e.type.speed, dt, 2);
    if (e.state === 'idle') setState(e, 'drift');
    if (dist(e, p) < 60 || e.t > 9) { world.strike({ shape: 'circle', x: e.x, y: e.y, r: 90, dur: 0.6, mult: 0.8, owner: e, tone: 'soul' }); world.killEnemy(e, false); }
  },
  // เยลลี่กัมดรอป: bounces around the arena like a ball
  hw_gumdrop(e, dt, world) {
    if (e.state === 'idle') { setState(e, 'bounce'); e.ai.dir = rnd(world) * TAU; }
    e.vx = Math.cos(e.ai.dir) * e.type.speed * 1.8; e.vy = Math.sin(e.ai.dir) * e.type.speed * 1.8;
    const A = world.arena; if (e.x < 90 || e.x > A.w - 90) e.ai.dir = Math.PI - e.ai.dir; if (e.y < 130 || e.y > A.h - 80) e.ai.dir = -e.ai.dir;
    e.ai.z = Math.abs(Math.sin(world.time * 6 + e.id)) * 26;
    tryContact(e, world, 0.7, 6, 260); if (e.hitThisAttack && e.t > 1) { e.hitThisAttack = false; e.t = 0; }
  },
  hw_illusion(e, dt, world) {
    // a copy of the Deceiver: drifts and fires a hex, then vanishes after a while
    const p = world.player;
    steer(e, toward(e, p) + 1.4, e.type.speed * 0.6, dt, 3);
    if (e.state === 'idle') setState(e, 'drift');
    if (e.t > 1.8) { e.t = 0; world.shoot(e, { x: e.x, y: e.y - 50, angle: toward(e, p), speed: 360, r: 12, mult: 0.7, kind: 'hwhex', life: 3 }); }
    e.ai.life = (e.ai.life || 0) + dt; if (e.ai.life > 12) world.killEnemy(e, false);
  },
  hw_shadow_fake(e, dt, world) {
    // a shadow of the dark guardian: copies its slash with a telegraph, then fades in 10 s
    const p = world.player;
    if (e.state === 'idle') setState(e, 'chase');
    if (e.state === 'chase') { steer(e, toward(e, p), e.type.speed, dt, 5); if (dist(e, p) < 150 && e.t > 0.6) { setState(e, 'slash'); e.ai.dir = toward(e, p); arcTell(world, e, e.ai.dir, 150, 2.2, 0.6, 'dark'); } }
    else if (e.state === 'slash') { stop(e, dt, 10); warn(e, e.t / 0.6); if (e.t > 0.6 && e.ai.step === 0) { e.ai.step = 1; e.warn = 0; meleeArc(e, world, e.ai.dir, 150, 2.2, 0.9); } if (e.t > 1.1) setState(e, 'chase'); }
    e.ai.life = (e.ai.life || 0) + dt; if (e.ai.life > 14) world.killEnemy(e, false);
  },
});

// ===================================================================== bosses
Object.assign(BEHAVIOURS, {
  // ------------------------------------------------------------ ต้นไม้พันปี: roots in lines, seed bombs, vine snakes
  hw_treant(e, dt, world) {
    const P = e.type.ai_params, p = world.player;
    const ph = phaseChange(e, world, { 2: 'รากไม้ทั้งสวนตื่นขึ้น!', 3: 'ต้นไม้พันปีโกรธจัด!' }, () => { for (let i = 0; i < 2; i++) world.spawnEnemy('hw_vine_snake', e.x + (i ? 160 : -160), e.y + 80); });
    const k = ph === 3 ? 0.75 : ph === 2 ? 0.88 : 1;
    if (e.state === 'idle') setState(e, 'walk');
    if (e.state === 'walk') { steer(e, toward(e, p), e.type.speed, dt, 2); if (e.t > 1.6 * k) setState(e, pick(world, ['roots', 'seeds', 'slam', ph >= 2 ? 'grove' : 'roots'])); }
    else if (e.state === 'roots') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; for (let i = 0; i < P.roots; i++) { const a = toward(e, p) + (i - (P.roots - 1) / 2) * 0.28; world.strike({ shape: 'line', x: e.x, y: e.y, angle: a, len: 760, width: 46, dur: (0.8 + i * 0.12) * k, mult: 1.1, owner: e, tone: 'earth' }); } world.sfx('telegraph'); }
      warn(e, e.t / 0.8); if (e.t > 1.6 * k) { e.warn = 0; setState(e, 'walk'); }
    } else if (e.state === 'seeds') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; for (let i = 0; i < P.seeds + ph; i++) { const t = randomPlayer(world); const at = inArena(world, t.x + (rnd(world) - 0.5) * 300, t.y + (rnd(world) - 0.5) * 220); world.strike({ shape: 'circle', x: at.x, y: at.y, r: 80, dur: (1 + i * 0.1) * k, mult: 1.0, owner: e, tone: 'spore', meteor: true, then: { pool: { kind: 'poison', r: 60, dur: 3, mult: 0.25 } } }); } world.sfx('cast'); }
      if (e.t > 2 * k) setState(e, 'walk');
    } else if (e.state === 'slam') {
      stop(e, dt, 9);
      if (e.ai.step === 0) { e.ai.step = 1; world.strike({ shape: 'circle', x: e.x, y: e.y, r: 230, dur: 1.0 * k, mult: 1.4, owner: e, tone: 'earth', kb: 500 }); world.sfx('telegraph'); }
      warn(e, e.t / k); if (e.t > 1.5 * k) { e.warn = 0; world.shake(10, 0.4); setState(e, 'walk'); }
    } else if (e.state === 'grove') {
      // the whole floor but a few safe circles erupts
      stop(e, dt, 9);
      if (e.ai.step === 0) {
        e.ai.step = 1; const A = world.arena;
        for (let x = 160; x < A.w - 100; x += 220) for (let y = 220; y < A.h - 80; y += 200) if (rnd(world) > 0.28) world.strike({ shape: 'circle', x, y, r: 100, dur: 1.5 * k, mult: 1.2, owner: e, tone: 'earth' });
        world.announce('หาวงที่ไม่มีรากโผล่!'); world.sfx('roar');
      }
      if (e.t > 2.1 * k) setState(e, 'walk');
    }
  },

  // ------------------------------------------------------------ แจ็กโอแลนเทิร์น: scythe swipes, pumpkin bombs, vine whips,
  // and the mirror world (battle/hwCoop.js runs the duel on the trapped player's side)
  hw_jack(e, dt, world) {
    const P = e.type.ai_params, p = world.player;
    const ph = phaseChange(e, world, { 2: 'แจ็กหัวเราะ… กระจกเริ่มแตกร้าว', 3: 'ฟักทองลุกเป็นไฟทั้งหลัง!' }, () => { for (let i = 0; i < 2; i++) world.spawnEnemy('hw_pumpkin_imp', e.x + (i ? 140 : -140), e.y + 60); });
    const k = ph === 3 ? 0.72 : ph === 2 ? 0.86 : 1;
    e.ai.mirrorT = (e.ai.mirrorT ?? P.mirrorEvery * 0.55) - dt;
    if (e.state === 'idle') setState(e, 'stalk');
    if (e.state === 'stalk') {
      steer(e, toward(e, p), e.type.speed, dt, 3);
      if (e.t > 1.1 * k) {
        if (e.ai.mirrorT <= 0 && !world.hw?.mirrorBusy) { setState(e, 'illusion'); }
        else setState(e, dist(e, p) < 200 ? 'swipes' : pick(world, ['bombs', 'whips', 'swipes', ph >= 2 ? 'laugh' : 'bombs']));
      }
    } else if (e.state === 'swipes') {
      const tel = 0.55 * k;
      if (e.ai.step === 0) { e.ai.dir = toward(e, p); arcTell(world, e, e.ai.dir, 210, 2.4, tel, 'pumpkin'); world.sfx('telegraph'); e.ai.step = 1; e.ai.n = 0; }
      stop(e, dt, 9); warn(e, e.t / tel);
      if (e.t >= tel) {
        meleeArc(e, world, e.ai.dir, 210, 2.4, 1.3, 380); world.sfx('swing'); e.warn = 0; e.ai.n += 1; steer(e, e.ai.dir, 380, 1, 1);
        if (e.ai.n >= (ph >= 2 ? 3 : 2)) setState(e, 'rest'); else { e.t = 0; e.ai.dir = toward(e, p); arcTell(world, e, e.ai.dir, 210, 2.4, tel * 0.85, 'pumpkin'); }
      }
    } else if (e.state === 'bombs') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; const n = 4 + ph; for (let i = 0; i < n; i++) { const t = i < world.players.length ? world.players[i] : randomPlayer(world); const at = inArena(world, t.x + (rnd(world) - 0.5) * 240, t.y + (rnd(world) - 0.5) * 180); const d = 0.9 + i * 0.12; world.shoot(e, { x: e.x, y: e.y - 80, angle: Math.atan2(at.y - e.y + 80, at.x - e.x), speed: Math.max(200, Math.hypot(at.x - e.x, at.y - e.y + 80) / d), r: 16, mult: 0, kind: 'hwpumpkin', life: d }); world.strike({ shape: 'circle', x: at.x, y: at.y, r: 90, dur: d * k, mult: 1.1, owner: e, tone: 'pumpkin', fire: true, then: { pool: { kind: 'fire', r: 60, dur: 2.5, mult: 0.3 } } }); } world.sfx('cast'); }
      if (e.t > 1.9 * k) setState(e, 'rest');
    } else if (e.state === 'whips') {
      stop(e, dt, 9);
      if (e.ai.step === 0) { e.ai.step = 1; const n = ph === 3 ? 8 : 6, off = rnd(world) * TAU; for (let i = 0; i < n; i++) world.strike({ shape: 'line', x: e.x, y: e.y, angle: off + (i / n) * TAU, len: 620, width: 44, dur: 0.9 * k, mult: 1.0, owner: e, tone: 'poison' }); world.sfx('telegraph'); }
      warn(e, e.t / (0.9 * k)); if (e.t > 1.3 * k) { e.warn = 0; setState(e, 'rest'); }
    } else if (e.state === 'laugh') {
      stop(e, dt, 9);
      if (e.ai.step === 0) { e.ai.step = 1; say(world, e, 'ฮ่า ฮ่า ฮ่า!', '#ffcf5a'); world.sfx('roar'); for (let i = 0; i < 2; i++) world.spawnEnemy('hw_pumpkin_imp', e.x + (i ? 120 : -120), e.y + 40); }
      if (e.t > 1.0) setState(e, 'rest');
    } else if (e.state === 'illusion') {
      // the mirror world: one hero is pulled into a room of mirrors to fight their own reflection
      stop(e, dt, 9);
      if (e.ai.step === 0) { e.ai.step = 1; const t = randomPlayer(world); world.announce(`แจ็กดึง ${t.name || 'คุณ'} เข้าโลกกระจก!`); world.mirrorTrap?.(t, e); e.ai.mirrorT = P.mirrorEvery * k; world.sfx('godIntro'); }
      e.invuln = 0; warn(e, 0.5);
      if (e.t > 2.2) { e.warn = 0; setState(e, 'rest'); }
    } else if (e.state === 'rest') { stop(e, dt, 5); if (e.t > 0.7 * k) setState(e, 'stalk'); }
  },

  // ------------------------------------------------------------ ยมทูต: grows with the damage it takes and the time it lives
  hw_reaper(e, dt, world) {
    const p = world.player;
    e.ai.life = (e.ai.life || 0) + dt;
    const rage = Math.min(2, (1 - e.hp / e.maxHp) * 1.1 + e.ai.life / 150);
    e.ai.rage = rage;
    e.baseAtk ??= e.atk; e.atk = Math.round(e.baseAtk * (1 + 0.55 * rage));
    const k = 1 - 0.28 * Math.min(1, rage / 1.4);
    const lv = rage >= 1.4 ? 5 : rage >= 1.0 ? 4 : rage >= 0.7 ? 3 : rage >= 0.35 ? 2 : 1;
    if (lv !== e.ai.lv) {
      if (e.ai.lv) { world.announce(['', '', 'ยมทูตตื่นขึ้น: นาฬิกาแห่งความตาย', 'ยมทูตตื่นขึ้น: มือจากหลุมศพ', 'ยมทูตตื่นขึ้น: ตราประทับความตาย', 'ยมทูตตื่นเต็มที่: สุริยคราสแห่งวิญญาณ'][lv]); world.sfx('roar'); world.shake(10, 0.5); }
      e.ai.lv = lv;
    }
    if (e.state === 'idle') setState(e, 'drift');
    if (e.state === 'drift') {
      steer(e, toward(e, p) + Math.sin(world.time * 1.3) * 0.6, e.type.speed, dt, 3);
      e.ai.z = 20 + Math.sin(world.time * 2) * 10;
      if (e.t > 1.0 * k) {
        const pool = ['reap', 'throw', 'souls', 'blink'];
        if (lv >= 2) pool.push('clock', 'clock'); if (lv >= 3) pool.push('graves', 'graves'); if (lv >= 4) pool.push('mark'); if (lv >= 5) pool.push('eclipse');
        setState(e, dist(e, p) < 180 && rnd(world) < 0.5 ? 'reap' : pick(world, pool));
      }
    } else if (e.state === 'reap') {
      const tel = 0.6 * k;
      if (e.ai.step === 0) { e.ai.dir = toward(e, p); arcTell(world, e, e.ai.dir, 240, 2.8, tel, 'soul'); world.sfx('telegraph'); e.ai.step = 1; }
      stop(e, dt, 9); warn(e, e.t / tel);
      if (e.t >= tel && e.ai.step === 1) { e.ai.step = 2; e.warn = 0; meleeArc(e, world, e.ai.dir, 240, 2.8, 1.4, 420); world.sfx('swing'); world.particles.burst(e.x, e.y - 40, 30, { color: ['#b8f0ff', '#14141c'], speedMin: 120, speedMax: 380, life: 0.5, size: 4, drag: 3, glow: true }); }
      if (e.t > tel + 0.5) setState(e, 'drift');
    } else if (e.state === 'throw') {
      // the scythe flies out along a line and comes back the same way
      stop(e, dt, 9);
      if (e.ai.step === 0) { e.ai.step = 1; e.ai.dir = toward(e, p); world.strike({ shape: 'line', x: e.x, y: e.y - 20, angle: e.ai.dir, len: 700, width: 70, dur: 0.8 * k, mult: 1.1, owner: e, tone: 'soul' }); world.strike({ shape: 'line', x: e.x, y: e.y - 20, angle: e.ai.dir, len: 700, width: 70, dur: 1.7 * k, mult: 1.1, owner: e, tone: 'soul' }); world.shoot(e, { x: e.x, y: e.y - 40, angle: e.ai.dir, speed: 700 / (0.8 * k), r: 26, mult: 0, kind: 'hwscythe', life: 0.8 * k }); world.sfx('swing'); }
      if (e.ai.step === 1 && e.t > 0.8 * k) { e.ai.step = 2; const bx = e.x + Math.cos(e.ai.dir) * 700, by = e.y - 20 + Math.sin(e.ai.dir) * 700; world.shoot(e, { x: bx, y: by, angle: e.ai.dir + Math.PI, speed: 700 / (0.9 * k), r: 26, mult: 0, kind: 'hwscythe', life: 0.9 * k }); }
      if (e.t > 1.9 * k) setState(e, 'drift');
    } else if (e.state === 'souls') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; const n = Math.min(4, 1 + lv); for (let i = 0; i < n; i++) world.spawnEnemy('hw_soul_wisp', e.x + Math.cos(i / n * TAU) * 120, e.y + Math.sin(i / n * TAU) * 90); world.sfx('spawn'); }
      if (e.t > 0.8) setState(e, 'drift');
    } else if (e.state === 'blink') {
      if (e.ai.step === 0) { e.ai.step = 1; const t = randomPlayer(world); blinkTo(e, world, t.x - Math.cos(toward(e, t)) * 160, t.y - Math.sin(toward(e, t)) * 100, '#b8f0ff'); }
      if (e.t > 0.25) setState(e, 'reap');
    } else if (e.state === 'clock') {
      // นาฬิกาแห่งความตาย: a hand of death sweeps around him twice, from 12 o'clock
      stop(e, dt, 9);
      if (e.ai.step === 0) { e.ai.step = 1; world.announce('นาฬิกาแห่งความตาย: วิ่งตามเข็มนาฬิกา!'); const steps = 24, start = -Math.PI / 2, dir = rnd(world) < 0.5 ? 1 : -1; for (let i = 0; i < steps; i++) world.strike({ shape: 'line', x: e.x, y: e.y, angle: start + dir * (i / 12) * TAU * 0.5 * 2, len: 760, width: 46, dur: (0.9 + i * 0.12) * k, mult: 0.9, owner: e, tone: 'soul' }); world.sfx('telegraph'); }
      if (e.t > (0.9 + 24 * 0.12) * k + 0.2) setState(e, 'drift');
    } else if (e.state === 'graves') {
      // มือจากหลุมศพ: a checkerboard of hands, then the other half
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; const A = world.arena, c = 150; for (let gx = 0; gx * c < A.w - 120; gx++) for (let gy = 0; gy * c < A.h - 160; gy++) { const x = 100 + gx * c + c / 2, y = 140 + gy * c + c / 2; if (x > A.w - 60 || y > A.h - 40) continue; world.strike({ shape: 'rect', x: x - c / 2, y: y - c / 2, w: c, h: c, dur: ((gx + gy) % 2 ? 1.0 : 1.9) * k, mult: 1.0, owner: e, tone: 'shadow' }); } world.sfx('telegraph'); }
      if (e.t > 2.2 * k) setState(e, 'drift');
    } else if (e.state === 'mark') {
      // ตราประทับความตาย: one hero is marked; the mark lands where they stand 2 s later (others should keep away)
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; e.ai.tgt = randomPlayer(world); world.announce(`ตราประทับความตายบน ${e.ai.tgt.name || 'คุณ'}! ออกห่างเพื่อน`); world.sfx('godIntro'); }
      if (e.ai.step === 1 && e.t > 1.2) { e.ai.step = 2; const t = e.ai.tgt; world.strike({ shape: 'circle', x: t.x, y: t.y, r: 200, dur: 0.9, mult: 1.5, owner: e, tone: 'blood', pierce: true }); }
      if (e.t > 2.4) setState(e, 'drift');
    } else if (e.state === 'eclipse') {
      // สุริยคราสแห่งวิญญาณ: the field goes dark and a ring of scythes closes in on the centre
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; world.darkPulse(4); world.announce('สุริยคราสแห่งวิญญาณ!'); const A = world.arena, cx = A.w / 2, cy = A.h / 2 + 20; for (let i = 0; i < 5; i++) world.strike({ shape: 'ring', x: cx, y: cy, r: 760 - i * 130, inner: 640 - i * 130, dur: (1 + i * 0.45) * k, mult: 1.0, owner: e, tone: 'soul' }); world.strike({ shape: 'circle', x: cx, y: cy, r: 130, dur: (1 + 5 * 0.45) * k, mult: 1.3, owner: e, tone: 'blood' }); world.sfx('roar'); }
      if (e.t > (1.2 + 5 * 0.45) * k) setState(e, 'drift');
    }
  },

  // ------------------------------------------------------------ แม่มดจอมล่อลวง: dodges, mocks, curses (15 kinds)
  hw_lure(e, dt, world) {
    const p = world.player;
    const ph = phaseChange(e, world, { 2: 'แม่มดหัวเราะคิกคัก: "เพิ่งจะเริ่มเองนะจ๊ะ~"', 3: 'แม่มดเทยาทั้งตู้!' }, () => { for (let i = 0; i < 3; i++) world.spawnEnemy('hw_gumdrop', e.x + (i - 1) * 120, e.y + 60); });
    const k = ph === 3 ? 0.75 : ph === 2 ? 0.88 : 1;
    const TAUNTS = ['ตีไม่โดนหรอกจ้า~', 'ช้าจังเลยน้า', 'อุ๊ย พลาดอีกแล้ว!', 'มาเล่นกันอีกสิ~', 'คำสาปนี้เหมาะกับเธอนะ', 'ฮิๆ หัวร้อนแล้วเหรอ', 'ลองยานี้ดูไหม?'];
    // the annoying part: whoever gets close, she skips away (with a cooldown so she can be caught)
    e.ai.skipCd = Math.max(0, (e.ai.skipCd || 0) - dt);
    if (e.state !== 'mock' && e.ai.skipCd <= 0 && world.players.some((t) => dist(e, t) < 120)) {
      e.ai.skipCd = 2.4 * k; const away = toward(p, e);
      blinkTo(e, world, e.x + Math.cos(away) * 380, e.y + Math.sin(away) * 260, '#ff9ac8'); say(world, e, pick(world, TAUNTS), '#ff9ac8');
      if (e.state === 'walk') e.t = 0;
    }
    if (e.state === 'idle') setState(e, 'walk');
    if (e.state === 'walk') {
      steer(e, toward(e, p) + Math.PI / 2 * (Math.sin(world.time) > 0 ? 1 : -1), e.type.speed * 0.7, dt, 3);
      if (e.t > 1.1 * k) setState(e, pick(world, ['potions', 'potions', 'rain', 'mock', 'swap', ph >= 2 ? 'ring' : 'potions']));
    } else if (e.state === 'potions') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; const n = 3 + ph; for (let i = 0; i < n; i++) { const t = i < world.players.length ? world.players[i] : randomPlayer(world); const at = inArena(world, t.x + (rnd(world) - 0.5) * 140, t.y + (rnd(world) - 0.5) * 120); lobCurse(world, e, at.x, at.y, 85, (0.85 + i * 0.12) * k, 0.6, pick(world, CURSE_IDS)); } world.sfx('cast'); }
      if (e.t > 1.6 * k) setState(e, 'walk');
    } else if (e.state === 'rain') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; world.announce('ฝนยาสาป!'); const A = world.arena; for (let i = 0; i < 10 + ph * 2; i++) { const at = inArena(world, 120 + rnd(world) * (A.w - 240), 180 + rnd(world) * (A.h - 300)); lobCurse(world, e, at.x, at.y, 80, (1.0 + i * 0.07) * k, 0.55, pick(world, CURSE_IDS)); } world.sfx('roar'); }
      if (e.t > 2.2 * k) setState(e, 'walk');
    } else if (e.state === 'mock') {
      // she stops to laugh at you — the one moment she does not dodge (and takes extra damage: hwCoop reads e.mockT)
      stop(e, dt, 10);
      if (e.ai.step === 0) { e.ai.step = 1; say(world, e, pick(world, TAUNTS), '#ff9ac8'); world.sfx('summon'); e.mockT = 2.2; e.ai.skipCd = 2.6; }
      e.mockT = Math.max(0, (e.mockT || 0) - dt);
      if (e.t > 2.2) { e.mockT = 0; setState(e, 'walk'); }
    } else if (e.state === 'swap') {
      // she trades places with a hero (and leaves a curse where she stood)
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; e.ai.tgt = randomPlayer(world); world.strike({ shape: 'circle', x: e.ai.tgt.x, y: e.ai.tgt.y, r: 70, dur: 0.7 * k, mult: 0, owner: e, tone: 'candy' }); }
      if (e.ai.step === 1 && e.t > 0.7 * k) { e.ai.step = 2; const t = e.ai.tgt, ox = e.x, oy = e.y; blinkTo(e, world, t.x, t.y, '#ff9ac8'); world.strike({ shape: 'circle', x: ox, y: oy, r: 90, dur: 0.8, mult: 0.6, owner: e, tone: 'hex', cu: pick(world, CURSE_IDS) }); say(world, e, 'สลับที่กันหน่อยนะ~', '#ff9ac8'); }
      if (e.t > 1.6 * k) setState(e, 'walk');
    } else if (e.state === 'ring') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; const n = 15; for (let i = 0; i < n; i++) { const a = i / n * TAU; const at = inArena(world, e.x + Math.cos(a) * 300, e.y + Math.sin(a) * 220); lobCurse(world, e, at.x, at.y, 70, 1.0 * k, 0.5, CURSE_IDS[i]); } world.announce('วงคำสาปสิบห้า! ยืนตรงกลางให้ทัน'); }
      if (e.t > 1.6 * k) setState(e, 'walk');
    }
  },

  // ------------------------------------------------------------ แม่มดจอมหลอกลวง: warnings that lie, illusions, reversals
  // Her health is exactly 1,000,000 and never runs out: at zero she is stunned (battle/hwCoop.js opens the ??? portal).
  hw_deceiver(e, dt, world) {
    const p = world.player;
    if (e.hwStunned) { e.vx = e.vy = 0; e.warn = 0; e.state = 'stunned'; return; }
    const f = e.hp / e.maxHp, k = f < 0.3 ? 0.72 : f < 0.65 ? 0.86 : 1;
    if (e.state === 'idle') setState(e, 'glide');
    if (e.state === 'glide') {
      steer(e, toward(e, p) + 1.2, e.type.speed * 0.6, dt, 3); e.ai.z = 26 + Math.sin(world.time * 2.4) * 8;
      if (e.t > 1.1 * k) setState(e, pick(world, ['liars', 'liars', 'illusions', 'reverse', 'mirrorbolts', 'swapsafe']));
    } else if (e.state === 'liars') {
      // six circles; only half are real. The fake ones fade out early — the real ones stay to the end.
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; for (let i = 0; i < 6; i++) { const t = randomPlayer(world); const at = inArena(world, t.x + (rnd(world) - 0.5) * 420, t.y + (rnd(world) - 0.5) * 300); const real = i % 2 === 0; world.strike({ shape: 'circle', x: at.x, y: at.y, r: 110, dur: real ? 1.3 * k : 0.85 * k, mult: real ? 1.2 : 0, owner: e, tone: 'hex' }); } say(world, e, 'วงไหนจริงล่ะ?', '#c86aff'); world.sfx('telegraph'); }
      if (e.t > 1.7 * k) setState(e, 'glide');
    } else if (e.state === 'illusions') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; const alive = world.enemiesOf?.('hw_illusion')?.filter((x) => !x.dead).length || 0; for (let i = alive; i < 3; i++) world.spawnEnemy('hw_illusion', e.x + Math.cos(i * 2.1) * 260, e.y + Math.sin(i * 2.1) * 180); blinkTo(e, world, e.x + (rnd(world) - 0.5) * 500, e.y + (rnd(world) - 0.5) * 300); world.sfx('spawn'); }
      if (e.t > 0.9) setState(e, 'glide');
    } else if (e.state === 'reverse') {
      // a big cone in front… that turns around and lands BEHIND her instead
      stop(e, dt, 9);
      if (e.ai.step === 0) { e.ai.step = 1; e.ai.dir = toward(e, p); world.strike({ shape: 'cone', x: e.x, y: e.y, angle: e.ai.dir, r: 420, arc: 1.6, dur: 0.7 * k, mult: 0, owner: e, tone: 'hex' }); world.strike({ shape: 'cone', x: e.x, y: e.y, angle: e.ai.dir + Math.PI, r: 420, arc: 1.6, dur: 1.25 * k, mult: 1.3, owner: e, tone: 'hex' }); say(world, e, 'หลอกเล่นน่ะ!', '#c86aff'); }
      if (e.t > 1.6 * k) setState(e, 'glide');
    } else if (e.state === 'mirrorbolts') {
      // hexes fly out, stop, and come back from where they stopped
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; e.ai.base = rnd(world) * TAU; for (let i = 0; i < 12; i++) world.shoot(e, { x: e.x, y: e.y - 40, angle: e.ai.base + i / 12 * TAU, speed: 420, r: 12, mult: 0.8, kind: 'hwhex', life: 1.0 }); world.sfx('cast'); }
      if (e.ai.step === 1 && e.t > 1.0) { e.ai.step = 2; for (let i = 0; i < 12; i++) { const a = e.ai.base + i / 12 * TAU; world.shoot(e, { x: e.x + Math.cos(a) * 420, y: e.y - 40 + Math.sin(a) * 420, angle: a + Math.PI + 0.25, speed: 420, r: 12, mult: 0.8, kind: 'hwhex', life: 2.0 }); } }
      if (e.t > 2.2) setState(e, 'glide');
    } else if (e.state === 'swapsafe') {
      // two halves of the floor: the one she points at is "safe"… then she swaps them
      stop(e, dt, 9);
      if (e.ai.step === 0) { e.ai.step = 1; const A = world.arena; e.ai.left = rnd(world) < 0.5; world.strike({ shape: 'rect', x: e.ai.left ? A.w / 2 : 60, y: 80, w: A.w / 2 - 60, h: A.h - 120, dur: 0.8 * k, mult: 0, owner: e, tone: 'hex' }); say(world, e, e.ai.left ? 'ซ้ายปลอดภัยนะ~' : 'ขวาปลอดภัยนะ~', '#c86aff'); }
      if (e.ai.step === 1 && e.t > 0.8 * k) { e.ai.step = 2; const A = world.arena; world.announce('สลับข้าง!'); world.strike({ shape: 'rect', x: e.ai.left ? 60 : A.w / 2, y: 80, w: A.w / 2 - 60, h: A.h - 120, dur: 1.0 * k, mult: 1.2, owner: e, tone: 'hex' }); }
      if (e.t > 2.0 * k) setState(e, 'glide');
    }
  },

  // ------------------------------------------------------------ พ่อมด (NPC) and the God of Creation (ally)
  hw_wizard(e, dt) { e.vx = e.vy = 0; e.ai.z = 10 + Math.sin(e.t * 2) * 6; },
  hw_wizard_ally(e, dt, world) {
    // fights beside the heroes: beams at the Wrathful Witch (damage is dealt by hwCoop on the host), sometimes heals everyone
    const foe = world.enemies.find((x) => !x.dead && x.type.id === 'hw_witch_wrath');
    const near = world.players[0] || world.player;
    if (near) steer(e, toward(e, { x: near.x - 120, y: near.y - 80 }), Math.min(220, dist(e, near)), dt, 2);
    e.ai.z = 40 + Math.sin(world.time * 2) * 8;
    e.ai.cd = (e.ai.cd ?? 2) - dt; e.ai.heal = (e.ai.heal ?? 9) - dt;
    if (foe && e.ai.cd <= 0) { e.ai.cd = 2.4; world.hw?.allyBeam?.(e, foe); }
    if (e.ai.heal <= 0) { e.ai.heal = 11; world.hw?.allyHeal?.(e); }
  },

  // ------------------------------------------------------------ 1. ผู้พิทักษ์แห่งความมืด: find the real one among the copies,
  // then break the pillar in the pillar chamber while shadows hunt you. Five cycles; each pillar takes a fifth of its health.
  hw_g_dark(e, dt, world) {
    const p = world.player, H = world.hw;
    e.ai.cycle ??= 0;
    if (e.state === 'idle') { setState(e, 'clones'); }
    if (e.state === 'clones') {
      e.hidden = 0; e.untargetable = false; e.hwReveal = true;
      if (e.ai.step === 0) {
        e.ai.step = 1;
        for (const c of world.enemiesOf('hw_g_dark_clone')) if (!c.dead) world.killEnemy(c, false);
        const n = 3 + Math.min(2, e.ai.cycle);
        const spots = Array.from({ length: n + 1 }, (_, i) => { const a = (i / (n + 1)) * TAU + rnd(world); return inArena(world, world.arena.w / 2 + Math.cos(a) * 380, world.arena.h / 2 + Math.sin(a) * 260); });
        const mine = Math.floor(rnd(world) * spots.length);
        spots.forEach((s, i) => { if (i === mine) blinkTo(e, world, s.x, s.y, '#7a3aff'); else { const c = world.spawnEnemy('hw_g_dark_clone', s.x, s.y); if (c) { c.clone = true; c.spawning = 0.2; c.ai.master = e.id; } } });
        world.announce(`ร่างแยกแห่งความมืด (รอบ ${e.ai.cycle + 1}/5) — ตัวจริงมีเงาบนพื้น`); world.sfx('godIntro');
      }
      // every copy and the real one cast the same spell together
      e.ai.cast = (e.ai.cast ?? 1.4) - dt;
      if (e.ai.cast <= 0) {
        e.ai.cast = 2.2;
        const all = [e, ...world.enemiesOf('hw_g_dark_clone').filter((c) => !c.dead)];
        const kind = pick(world, ['line', 'nova', 'orb']);
        for (const c of all) {
          const t = randomPlayer(world), a = Math.atan2(t.y - c.y, t.x - c.x);
          if (kind === 'line') world.strike({ shape: 'line', x: c.x, y: c.y - 10, angle: a, len: 640, width: 50, dur: 0.95, mult: 0.9, owner: e, tone: 'dark' });
          else if (kind === 'nova') world.strike({ shape: 'circle', x: c.x, y: c.y, r: 170, dur: 1.0, mult: 0.9, owner: e, tone: 'dark' });
          else world.shoot(c === e ? e : e, { x: c.x, y: c.y - 50, angle: a, speed: 340, r: 13, mult: 0.8, kind: 'hwhex', life: 3, homing: 0.4 });
        }
        world.sfx('cast');
      }
      for (const c of world.enemiesOf('hw_g_dark_clone')) if (!c.dead) { c.vx = c.vy = 0; c.ai.z = e.ai.z = 10 + Math.sin(world.time * 2) * 6; }
      e.vx = e.vy = 0;
      if (e.ai.revealed) { e.ai.revealed = false; setState(e, 'chamber'); }
    } else if (e.state === 'chamber') {
      // the pillar chamber: the guardian is gone from the room, a pillar of dark power stands somewhere — break it
      if (e.ai.step === 0) {
        e.ai.step = 1; e.hidden = 1; e.untargetable = true; e.hwReveal = false;
        for (const c of world.enemiesOf('hw_g_dark_clone')) if (!c.dead) world.killEnemy(c, false);
        const A = world.arena, side = rnd(world) < 0.5;
        const at = inArena(world, side ? A.w * 0.2 : A.w * 0.8, A.h * (0.3 + rnd(world) * 0.4));
        const pil = world.spawnEnemy('hw_g_pillar', at.x, at.y); if (pil) { pil.ai.master = e.id; e.ai.pillar = pil.id; }
        if (H) H.chamber = e.ai.cycle + 1;
        world.announce(`ห้องเสาค้ำจุน ${e.ai.cycle + 1}/5 — ทำลายเสา! ร่างเงาจะขัดขวาง`); world.sfx('roar');
      }
      e.ai.fake = (e.ai.fake ?? 1) - dt;
      if (e.ai.fake <= 0) { e.ai.fake = 3.6 - Math.min(1.6, e.ai.cycle * 0.3); const t = randomPlayer(world); world.spawnEnemy('hw_shadow_fake', t.x + (rnd(world) - 0.5) * 500, t.y + (rnd(world) - 0.5) * 300); }
      const pil = world.enemies.find((x) => x.id === e.ai.pillar);
      if (!pil || pil.dead) {
        e.ai.cycle += 1; if (H) H.chamber = 0;
        for (const f of world.enemiesOf('hw_shadow_fake')) if (!f.dead) world.killEnemy(f, false);
        const target = Math.round(e.maxHp * (1 - e.ai.cycle / 5));
        e.hidden = 0; e.untargetable = false;
        if (e.ai.cycle >= 5) { world.hw?.finish?.(e); return; }
        world.damageEnemy(e, { amount: Math.max(1, e.hp - target), crit: false }, 0, 0, { src: 'pillar' });
        world.announce(`เสาพัง! ความมืดอ่อนลง (${e.ai.cycle}/5)`);
        setState(e, 'clones');
      }
    }
  },
  hw_g_dark_clone(e, dt) { e.vx = 0; e.vy = 0; },

  // ------------------------------------------------------------ 2. ผู้พิทักษ์แห่งปัญญา: a chessboard; the pieces move by the
  // real rules of chess (pawn, knight, bishop, rook, queen, king) and every square they cross costs 10% of your health.
  hw_g_wisdom(e, dt, world) {
    const p = world.player, B = world.hw?.board;
    if (!B) return;
    const ph = phaseChange(e, world, { 2: 'ผู้พิทักษ์แห่งปัญญา: "เปิดเกมกลางกระดาน"', 3: 'ผู้พิทักษ์แห่งปัญญา: "รุกจน!"' });
    const k = ph === 3 ? 0.75 : ph === 2 ? 0.88 : 1;
    if (e.state === 'idle') { setState(e, 'think'); e.ai.first = true; }
    if (e.state === 'think') {
      // the guardian stays on its own square at the top edge and moves along it
      const want = { x: B.x0 + B.cell * (0.5 + Math.max(0, Math.min(7, Math.floor((p.x - B.x0) / B.cell)))), y: B.y0 - 30 };
      steer(e, Math.atan2(want.y - e.y, want.x - e.x), Math.min(e.type.speed, dist(e, want) * 3), dt, 4);
      if (e.t > (e.ai.first ? 0.8 : 1.5 * k)) {
        e.ai.first = false;
        const pieces = world.enemies.filter((x) => !x.dead && x.type.chess).length;
        const pool = pieces < 3 + ph ? ['drop', 'drop'] : [];
        pool.push('checkmate', 'stalemate', ph >= 2 ? 'promote' : 'checkmate', ph >= 2 ? 'gambit' : 'drop', ph >= 3 ? 'castle' : 'stalemate');
        setState(e, pick(world, pool));
      }
    } else if (e.state === 'drop') {
      // pieces fall from the sky onto squares near the heroes (the landing square hurts)
      stop(e, dt, 8);
      if (e.ai.step === 0) {
        e.ai.step = 1;
        const kinds = ph === 1 ? ['pawn', 'pawn', 'knight', 'bishop', 'rook'] : ph === 2 ? ['pawn', 'knight', 'bishop', 'rook', 'queen'] : ['knight', 'bishop', 'rook', 'queen', 'king'];
        for (let i = 0; i < 2 + (ph > 1 ? 1 : 0); i++) {
          const t = randomPlayer(world), c = B.cellOf(t.x + (rnd(world) - 0.5) * B.cell * 3, t.y + (rnd(world) - 0.5) * B.cell * 3);
          if (B.occupied(c.col, c.row)) continue;
          const at = B.center(c.col, c.row);
          world.strike({ shape: 'rect', x: at.x - B.cell / 2, y: at.y - B.cell / 2, w: B.cell, h: B.cell, dur: 1.0 * k, mult: 0.01, pct: 0.1, pierce: true, owner: e, tone: 'chess' });
          const kind = pick(world, kinds), pc = world.spawnEnemy(`hw_chess_${kind}`, at.x, at.y);
          if (pc) { pc.spawning = 1.0 * k; pc.ai.col = c.col; pc.ai.row = c.row; pc.ai.side = rnd(world) < 0.5 ? 1 : -1; }
        }
        world.sfx('telegraph');
      }
      if (e.t > 1.3 * k) setState(e, 'think');
    } else if (e.state === 'checkmate') {
      // the row and the column of every hero light up, then strike (like a rook and a queen meeting on your square)
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; for (const t of world.players) { const c = B.cellOf(t.x, t.y); const r = B.rect(c.col, c.row); world.strike({ shape: 'rect', x: B.x0, y: r.y, w: B.cell * 8, h: B.cell, dur: 1.15 * k, mult: 0.01, pct: 0.1, pierce: true, owner: e, tone: 'chess' }); world.strike({ shape: 'rect', x: r.x, y: B.y0, w: B.cell, h: B.cell * 8, dur: 1.15 * k, mult: 0.01, pct: 0.1, pierce: true, owner: e, tone: 'chess' }); } world.announce('รุก! หลบออกจากแถวและคอลัมน์'); world.sfx('telegraph'); }
      if (e.t > 1.5 * k) setState(e, 'think');
    } else if (e.state === 'stalemate') {
      // stalemate: twelve squares freeze — standing on them chills you in place
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; for (let i = 0; i < 12 + ph * 2; i++) { const col = Math.floor(rnd(world) * 8), row = Math.floor(rnd(world) * 8); const r = B.rect(col, row); world.strike({ shape: 'rect', x: r.x, y: r.y, w: B.cell, h: B.cell, dur: 1.2 * k, mult: 0.01, pct: 0.1, pierce: true, chill: 1.2, owner: e, tone: 'ice' }); } world.sfx('cast'); }
      if (e.t > 1.5 * k) setState(e, 'think');
    } else if (e.state === 'promote') {
      // every pawn that is still on the board is promoted to a queen
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; let n = 0; for (const pw of world.enemiesOf('hw_chess_pawn')) if (!pw.dead) { const q = world.spawnEnemy('hw_chess_queen', pw.x, pw.y); if (q) { q.ai.col = pw.ai.col; q.ai.row = pw.ai.row; q.spawning = 0.3; } world.killEnemy(pw, false); n++; } world.announce(n ? `เลื่อนขั้น! เบี้ย ${n} ตัวกลายเป็นควีน` : 'ผู้พิทักษ์ครุ่นคิด…'); }
      if (e.t > 0.8) setState(e, 'think');
    } else if (e.state === 'gambit') {
      // a sacrifice: one piece explodes, hurting the 3×3 squares around it
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; const list = world.enemies.filter((x) => !x.dead && x.type.chess); const v = list.length ? pick(world, list) : null; if (v) { const r = B.rect(v.ai.col - 1, v.ai.row - 1); world.strike({ shape: 'rect', x: r.x, y: r.y, w: B.cell * 3, h: B.cell * 3, dur: 1.0 * k, mult: 0.01, pct: 0.1, pierce: true, owner: e, tone: 'blood' }); e.ai.victim = v.id; world.announce('แกมบิท! หมากระเบิด'); } }
      if (e.ai.step === 1 && e.t > 1.0 * k) { e.ai.step = 2; const v = world.enemies.find((x) => x.id === e.ai.victim); if (v && !v.dead) world.killEnemy(v, false); }
      if (e.t > 1.3 * k) setState(e, 'think');
    } else if (e.state === 'castle') {
      // castling: the guardian swaps places with a rook (and the rook's old square strikes)
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; const rk = world.enemiesOf('hw_chess_rook').find((x) => !x.dead); if (rk) { const ox = e.x, oy = e.y; blinkTo(e, world, rk.x, rk.y - 40, '#5fb0ff'); rk.x = ox; rk.y = Math.max(B.y0 + B.cell / 2, oy + 60); const c = B.cellOf(rk.x, rk.y); rk.ai.col = c.col; rk.ai.row = c.row; world.announce('เข้าป้อม!'); } }
      if (e.t > 0.8) setState(e, 'think');
    }
  },
  // a chess piece: waits, shows its path, then slides along it. It always picks the legal move that ends closest to a hero.
  hw_chess(e, dt, world) {
    const B = world.hw?.board;
    if (!B) return;
    e.vx = e.vy = 0;
    if (e.state === 'idle') { setState(e, 'wait'); e.ai.wait = 0.6 + rnd(world) * 1.2; }
    if (e.state === 'wait') {
      if (e.t > e.ai.wait) {
        const mv = B.bestMove(e, world.players);
        if (!mv) { e.t = 0; return; }
        e.ai.path = mv.path; e.ai.to = mv.to;
        for (const c of mv.path) { const r = B.rect(c.col, c.row); world.strike({ shape: 'rect', x: r.x, y: r.y, w: B.cell, h: B.cell, dur: 0.95, mult: 0.01, pct: 0.1, pierce: true, owner: e, tone: 'chess' }); }
        setState(e, 'show'); world.sfx('telegraph');
      }
    } else if (e.state === 'show') {
      warn(e, e.t / 0.95);
      if (e.t > 0.95) { e.warn = 0; setState(e, 'slide'); e.ai.from = { x: e.x, y: e.y }; }
    } else if (e.state === 'slide') {
      const to = B.center(e.ai.to.col, e.ai.to.row), k = Math.min(1, e.t / 0.3);
      e.ai.z = e.type.chess === 'knight' ? Math.sin(k * Math.PI) * 60 : 0;
      e.x = e.ai.from.x + (to.x - e.ai.from.x) * k; e.y = e.ai.from.y + (to.y - e.ai.from.y) * k;
      if (k >= 1) { e.ai.col = e.ai.to.col; e.ai.row = e.ai.to.row; e.ai.z = 0; world.sfx('slam'); setState(e, 'wait'); e.ai.wait = (e.type.chess === 'pawn' ? 1.6 : e.type.chess === 'king' ? 1.4 : 2.0) + rnd(world) * 0.8; }
    }
  },

  // ------------------------------------------------------------ 3. ผู้พิทักษ์แห่งแสงสว่าง: charges, leaps, twin hammers on chains.
  // Its hammer blows can be CLASHED: if you attack at the same moment, a 5-second duel of button presses starts (hwCoop).
  hw_g_light(e, dt, world) {
    const p = world.player;
    const ph = phaseChange(e, world, { 2: 'แสงสว่างไม่รู้จักถอย!', 3: 'ผู้พิทักษ์แห่งแสงลุกโชน!' });
    const k = ph === 3 ? 0.72 : ph === 2 ? 0.86 : 1;
    if (e.hwClashT > 0) { e.hwClashT -= dt; e.vx = e.vy = 0; e.warn = 0; return; }       // frozen in a clash
    if (e.state === 'idle') setState(e, 'rush');
    if (e.state === 'rush') {
      steer(e, toward(e, p), e.type.speed * 1.2, dt, 5);
      if (dist(e, p) < 170) setState(e, 'hammers');
      else if (e.t > 1.2 * k) setState(e, pick(world, ['leap', 'charge', 'throw', ph >= 2 ? 'chainspin' : 'leap', ph >= 3 ? 'judgment' : 'charge']));
    } else if (e.state === 'hammers') {
      // a three-blow combo; each blow is parryable — and clashable
      const tel = 0.48 * k;
      if (e.ai.step === 0) { e.ai.dir = toward(e, p); arcTell(world, e, e.ai.dir, 190, 2.2, tel, 'holy'); world.sfx('telegraph'); e.ai.step = 1; e.ai.n = 0; }
      stop(e, dt, 9); warn(e, e.t / tel);
      if (e.t >= tel) {
        meleeArc(e, world, e.ai.dir, 190, 2.2, 1.35, 420, { clash: true, ownerId: e.id }); world.sfx('swing'); e.warn = 0; e.ai.n += 1; steer(e, e.ai.dir, 520, 1, 1);
        if (e.ai.n >= 3) setState(e, 'rest'); else { e.t = 0; e.ai.dir = toward(e, p); arcTell(world, e, e.ai.dir, 190, 2.2, tel * 0.85, 'holy'); }
      }
    } else if (e.state === 'leap') {
      if (e.ai.step === 0) { e.ai.step = 1; e.ai.at = { x: p.x, y: p.y }; e.ai.from = { x: e.x, y: e.y }; world.strike({ shape: 'circle', x: p.x, y: p.y, r: 190, dur: 0.85 * k, mult: 1.4, owner: e, tone: 'holy', kb: 520 }); world.sfx('telegraph'); }
      const q = Math.min(1, e.t / (0.85 * k)); e.x = e.ai.from.x + (e.ai.at.x - e.ai.from.x) * q; e.y = e.ai.from.y + (e.ai.at.y - e.ai.from.y) * q; e.ai.z = Math.sin(q * Math.PI) * 180; e.vx = e.vy = 0;
      if (q >= 1 && e.ai.step === 1) { e.ai.step = 2; e.ai.z = 0; world.shake(12, 0.4); for (let i = 1; i <= 3; i++) world.strike({ shape: 'ring', x: e.x, y: e.y, r: 190 + i * 110, inner: 120 + i * 110, dur: 0.2 + i * 0.25, mult: 0.9, owner: e, tone: 'holy' }); }
      if (e.t > 1.6 * k) setState(e, 'rest');
    } else if (e.state === 'charge') {
      if (e.ai.step === 0) { e.ai.step = 1; e.ai.dir = toward(e, p); world.strike({ shape: 'line', x: e.x, y: e.y - 10, angle: e.ai.dir, len: 900, width: e.r * 2.4, dur: 0.6 * k, mult: 1.3, owner: e, tone: 'holy', kb: 520 }); world.sfx('telegraph'); }
      if (e.ai.step === 1) { stop(e, dt, 12); warn(e, e.t / (0.6 * k)); if (e.t > 0.6 * k) { e.ai.step = 2; e.t = 0; e.warn = 0; world.sfx('roar'); } }
      else { e.vx = Math.cos(e.ai.dir) * 1500; e.vy = Math.sin(e.ai.dir) * 1500; if (e.t > 0.6) { e.vx *= 0.1; e.vy *= 0.1; setState(e, ph >= 2 ? 'hammers' : 'rest'); } }
    } else if (e.state === 'throw') {
      // both hammers are thrown along lines, then yanked back on their chains
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; for (const o of [-0.35, 0.35]) { const a = toward(e, p) + o; world.strike({ shape: 'line', x: e.x, y: e.y - 20, angle: a, len: 640, width: 60, dur: 0.75 * k, mult: 1.0, owner: e, tone: 'holy' }); world.strike({ shape: 'line', x: e.x, y: e.y - 20, angle: a, len: 640, width: 60, dur: 1.5 * k, mult: 1.0, owner: e, tone: 'holy' }); world.shoot(e, { x: e.x, y: e.y - 40, angle: a, speed: 640 / (0.75 * k), r: 20, mult: 0, kind: 'hwhammer', life: 0.75 * k }); } world.sfx('swing'); }
      if (e.t > 1.7 * k) setState(e, 'rest');
    } else if (e.state === 'chainspin') {
      // the hammers swing round on their chains: a growing spiral of hits around it
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; world.announce('โซ่ค้อนหมุนวน!'); for (let i = 0; i < 10; i++) world.strike({ shape: 'cone', x: e.x, y: e.y, angle: i * 0.75, r: 300 + i * 18, arc: 0.9, dur: (0.6 + i * 0.16) * k, mult: 0.9, owner: e, tone: 'holy' }); world.sfx('roar'); }
      if (e.t > (0.8 + 10 * 0.16) * k) setState(e, 'rest');
    } else if (e.state === 'judgment') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; for (const t of world.players) for (let i = 0; i < 3; i++) world.strike({ shape: 'circle', x: t.x + (rnd(world) - 0.5) * 60 * i, y: t.y + (rnd(world) - 0.5) * 60 * i, r: 80, dur: (0.8 + i * 0.3) * k, mult: 1.0, owner: e, tone: 'holy', meteor: true }); world.sfx('telegraph'); }
      if (e.t > 1.8 * k) setState(e, 'rest');
    } else if (e.state === 'rest') { stop(e, dt, 6); if (e.t > 0.55 * k) setState(e, 'rush'); }
  },

  // ------------------------------------------------------------ 4. เทพผู้พิทักษ์แห่งการแปรธาตุ: dodges, casts wide spells of every
  // element, silences skills for 5 s (announced every time), and calls the floor-80 god of masks (immortal) to its side.
  hw_g_alchemy(e, dt, world) {
    const p = world.player;
    const ph = phaseChange(e, world, { 2: 'การแปรธาตุขั้นที่สอง: ธาตุผสม', 3: 'ศิลานักปราชญ์ลุกโชน!' });
    const k = ph === 3 ? 0.74 : ph === 2 ? 0.88 : 1;
    if (!e.ai.masks && e.t > 0.5) { e.ai.masks = true; world.hw?.summonMasks?.(e); }
    e.ai.dodgeCd = Math.max(0, (e.ai.dodgeCd || 0) - dt);
    if (e.ai.dodgeCd <= 0 && world.players.some((t) => dist(e, t) < 140)) { e.ai.dodgeCd = 2.2; const a = toward(p, e); blinkTo(e, world, e.x + Math.cos(a) * 320, e.y + Math.sin(a) * 240, '#6fe08a'); }
    if (e.state === 'idle') setState(e, 'float');
    if (e.state === 'float') {
      steer(e, toward(e, p) + Math.PI * 0.6, e.type.speed * 0.5, dt, 3); e.ai.z = 22 + Math.sin(world.time * 3) * 8;
      if (e.t > 1.1 * k) setState(e, pick(world, ['wheel', 'fire', 'ice', 'storm', 'silence', ph >= 2 ? 'transmute' : 'wheel', ph >= 3 ? 'prism' : 'fire']));
    } else if (e.state === 'wheel') {
      // eight elements in turn around the arena
      stop(e, dt, 8);
      if (e.ai.step === 0) {
        e.ai.step = 1; const A = world.arena, cx = A.w / 2, cy = A.h / 2 + 20;
        const els = [['fire', 'fire'], ['ice', 'ice'], ['poison', 'poison'], ['volt', null], ['wind', null], ['earth', null], ['holy', null], ['dark', null]];
        els.forEach(([tone, pool], i) => { const a = i / 8 * TAU + rnd(world) * 0.4; world.strike({ shape: 'circle', x: cx + Math.cos(a) * 380, y: cy + Math.sin(a) * 260, r: 150, dur: (0.8 + i * 0.22) * k, mult: 1.0, owner: e, tone, chill: tone === 'ice' ? 1 : 0, then: pool ? { pool: { kind: pool, r: 90, dur: 3, mult: 0.25 } } : undefined }); });
        world.strike({ shape: 'circle', x: cx, y: cy, r: 120, dur: (0.8 + 8 * 0.22) * k, mult: 1.2, owner: e, tone: 'sun' });
        world.announce('วงล้อธาตุทั้งแปด'); world.sfx('cast');
      }
      if (e.t > (1.2 + 8 * 0.22) * k) setState(e, 'float');
    } else if (e.state === 'fire') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; const a = toward(e, p); for (let i = 0; i < 7; i++) world.shoot(e, { x: e.x, y: e.y - 50, angle: a + (i - 3) * 0.16, speed: 420, r: 13, mult: 0.9, kind: 'hwfire', life: 3, fire: true }); world.strike({ shape: 'cone', x: e.x, y: e.y, angle: a, r: 380, arc: 0.9, dur: 0.9 * k, mult: 1.0, owner: e, tone: 'fire', fire: true }); world.sfx('cast'); }
      if (e.t > 1.3 * k) setState(e, 'float');
    } else if (e.state === 'ice') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; for (const t of world.players) world.strike({ shape: 'circle', x: t.x, y: t.y, r: 120, dur: 1.0 * k, mult: 0.9, chill: 1.4, owner: e, tone: 'ice', then: { pool: { kind: 'ice', r: 100, dur: 3, mult: 0 } } }); world.sfx('cast'); }
      if (e.t > 1.4 * k) setState(e, 'float');
    } else if (e.state === 'storm') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; const A = world.arena; for (let i = 0; i < 5; i++) { const vertical = i % 2 === 0, f = (i + 0.5) / 5; world.strike({ shape: 'line', ...(vertical ? { x: 60 + f * (A.w - 120), y: 80, angle: Math.PI / 2, len: A.h - 120 } : { x: 60, y: 110 + f * (A.h - 180), angle: 0, len: A.w - 120 }), width: 54, dur: (0.8 + i * 0.25) * k, mult: 1.0, owner: e, tone: 'volt' }); } world.gust(rnd(world) * TAU, 1.5, 220); world.sfx('telegraph'); }
      if (e.t > 2.2 * k) setState(e, 'float');
    } else if (e.state === 'silence') {
      // seals skills for 5 seconds: everyone hit hears it (hwCoop shows "ห้ามใช้สกิล 5 วินาที")
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; world.announce('ผนึกเวท! วงม่วงจะห้ามใช้สกิล 5 วินาที'); for (const t of world.players) world.strike({ shape: 'circle', x: t.x, y: t.y, r: 150, dur: 1.1 * k, mult: 0.5, silence: 5, owner: e, tone: 'shadow' }); world.sfx('telegraph'); }
      if (e.t > 1.5 * k) setState(e, 'float');
    } else if (e.state === 'transmute') {
      // turns every pool on the floor into fire, then a burst of light
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; world.announce('แปรธาตุ! บ่อทุกบ่อกลายเป็นไฟ'); world.hw?.transmutePools?.(); const A = world.arena; for (let i = 0; i < 6; i++) world.strike({ shape: 'circle', x: 200 + rnd(world) * (A.w - 400), y: 200 + rnd(world) * (A.h - 320), r: 110, dur: (0.9 + i * 0.1) * k, mult: 1.0, owner: e, tone: 'sun', then: { pool: { kind: 'fire', r: 80, dur: 3, mult: 0.3 } } }); }
      if (e.t > 1.6 * k) setState(e, 'float');
    } else if (e.state === 'prism') {
      // a prism of light splits into rotating beams
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; const off = rnd(world) * TAU; for (let s = 0; s < 3; s++) for (let i = 0; i < 6; i++) world.strike({ shape: 'line', x: e.x, y: e.y, angle: off + i / 6 * TAU + s * 0.26, len: 760, width: 40, dur: (0.8 + s * 0.45) * k, mult: 0.9, owner: e, tone: 'holy' }); world.sfx('cast'); }
      if (e.t > 2.1 * k) setState(e, 'float');
    }
  },

  // ------------------------------------------------------------ 5. จักรพรรดิสวรรค์: six skeletal wings, sword and shield.
  // Guards its front and counters; borrows every guardian's art (clones, chess, hammers, elements — never the masks);
  // calls Halloween monsters that drop candy; heals whenever a hero falls (hwCoop); heroes rise again until the last falls.
  hw_emperor(e, dt, world) {
    const p = world.player;
    const ph = phaseChange(e, world, { 2: 'จักรพรรดิกางปีกทั้งหก!', 3: 'จักรพรรดิสวรรค์: "ความจริงแท้คือข้า"' });
    const k = ph === 3 ? 0.74 : ph === 2 ? 0.87 : 1;
    e.guarding = e.state === 'guard' || e.state === 'walk';
    e.ai.face = toward(e, p);
    e.ai.summon = (e.ai.summon ?? 6) - dt;
    if (e.ai.summon <= 0) { e.ai.summon = 12 - ph * 2; const n = world.enemies.filter((x) => !x.dead && (x.type.id === 'hw_emp_imp' || x.type.id === 'hw_emp_ghost')).length; for (let i = n; i < 2 + ph; i++) world.spawnEnemy(i % 2 ? 'hw_emp_ghost' : 'hw_emp_imp', e.x + (rnd(world) - 0.5) * 500, e.y + (rnd(world) - 0.5) * 300); world.sfx('spawn'); }
    if (e.state === 'idle') setState(e, 'walk');
    if (e.state === 'walk') {
      steer(e, toward(e, p), e.type.speed, dt, 3);
      if (e.t > 1.0 * k) setState(e, dist(e, p) < 200 ? pick(world, ['sword', 'guard']) : pick(world, ['clones', 'chess', 'hammer', 'elements', 'sword', 'judgment']));
    } else if (e.state === 'guard') {
      // shield up: blows from the front glance off (guardFront); one that lands answers with a counter slash
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; say(world, e, 'โล่สวรรค์', '#ffe89a'); }
      if (e.ai.countered) { e.ai.countered = false; setState(e, 'counter'); }
      else if (e.t > 1.6) setState(e, 'sword');
    } else if (e.state === 'counter') {
      stop(e, dt, 9);
      if (e.ai.step === 0) { e.ai.step = 1; e.ai.dir = toward(e, p); arcTell(world, e, e.ai.dir, 230, 3.0, 0.35, 'holy'); }
      if (e.t > 0.35 && e.ai.step === 1) { e.ai.step = 2; meleeArc(e, world, e.ai.dir, 230, 3.0, 1.6, 480); world.sfx('swing'); say(world, e, 'สวนกลับ!', '#ffe89a'); }
      if (e.t > 0.9) setState(e, 'walk');
    } else if (e.state === 'sword') {
      const tel = 0.5 * k;
      if (e.ai.step === 0) { e.ai.dir = toward(e, p); arcTell(world, e, e.ai.dir, 220, 2.4, tel, 'holy'); e.ai.step = 1; e.ai.n = 0; world.sfx('telegraph'); }
      stop(e, dt, 9); warn(e, e.t / tel);
      if (e.t >= tel) { meleeArc(e, world, e.ai.dir, 220, 2.4, 1.3, 400); world.sfx('swing'); e.warn = 0; e.ai.n += 1; if (e.ai.n >= 2 + (ph > 1 ? 1 : 0)) setState(e, 'walk'); else { e.t = 0; e.ai.dir = toward(e, p); arcTell(world, e, e.ai.dir, 220, 2.4, tel * 0.85, 'holy'); } }
    } else if (e.state === 'clones') {
      // borrowed from the dark guardian: four shadows cast with it at once
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; for (let i = 0; i < 4; i++) { const a = i / 4 * TAU; const at = inArena(world, e.x + Math.cos(a) * 300, e.y + Math.sin(a) * 200); world.strike({ shape: 'line', x: at.x, y: at.y, angle: Math.atan2(p.y - at.y, p.x - at.x), len: 600, width: 50, dur: 1.0 * k, mult: 1.0, owner: e, tone: 'dark' }); world.particles.burst(at.x, at.y - 60, 20, { color: ['#7a3aff', '#14101c'], speedMin: 60, speedMax: 200, life: 0.6, size: 4, drag: 3 }); } world.sfx('cast'); }
      if (e.t > 1.4 * k) setState(e, 'walk');
    } else if (e.state === 'chess') {
      // borrowed from the wisdom guardian: rook and bishop lines through every hero (10% of health each)
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; for (const t of world.players) { world.strike({ shape: 'line', x: 60, y: t.y, angle: 0, len: world.arena.w - 120, width: 70, dur: 1.0 * k, mult: 0.01, pct: 0.1, pierce: true, owner: e, tone: 'chess' }); world.strike({ shape: 'line', x: t.x - 600, y: t.y - 600, angle: Math.PI / 4, len: 1700, width: 70, dur: 1.2 * k, mult: 0.01, pct: 0.1, pierce: true, owner: e, tone: 'chess' }); } world.sfx('telegraph'); }
      if (e.t > 1.5 * k) setState(e, 'walk');
    } else if (e.state === 'hammer') {
      // borrowed from the light guardian: a leap onto the target
      if (e.ai.step === 0) { e.ai.step = 1; e.ai.at = { x: p.x, y: p.y }; e.ai.from = { x: e.x, y: e.y }; world.strike({ shape: 'circle', x: p.x, y: p.y, r: 200, dur: 0.9 * k, mult: 1.3, owner: e, tone: 'holy', kb: 500 }); }
      const q = Math.min(1, e.t / (0.9 * k)); e.x = e.ai.from.x + (e.ai.at.x - e.ai.from.x) * q; e.y = e.ai.from.y + (e.ai.at.y - e.ai.from.y) * q; e.ai.z = Math.sin(q * Math.PI) * 160; e.vx = e.vy = 0;
      if (e.t > 1.5 * k) { e.ai.z = 0; setState(e, 'walk'); }
    } else if (e.state === 'elements') {
      // borrowed from the alchemy guardian: three elements on everyone, and a sealing circle
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; for (const t of world.players) { world.strike({ shape: 'circle', x: t.x, y: t.y, r: 120, dur: 0.9 * k, mult: 0.9, owner: e, tone: 'fire', fire: true, then: { pool: { kind: 'fire', r: 70, dur: 2.5, mult: 0.25 } } }); world.strike({ shape: 'circle', x: t.x, y: t.y, r: 150, dur: 1.6 * k, mult: 0.5, owner: e, tone: 'shadow', silence: ph >= 2 ? 3 : 0 }); } world.sfx('cast'); }
      if (e.t > 1.9 * k) setState(e, 'walk');
    } else if (e.state === 'judgment') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; world.announce('ปีกทั้งหกฟาดลง!'); for (let i = 0; i < 6; i++) world.strike({ shape: 'cone', x: e.x, y: e.y, angle: i / 6 * TAU + world.time, r: 520, arc: 0.55, dur: (0.8 + i * 0.12) * k, mult: 1.1, owner: e, tone: 'holy' }); world.sfx('roar'); }
      if (e.t > 1.7 * k) setState(e, 'walk');
    }
  },

  // ------------------------------------------------------------ แม่มดแห่งความโกรธเกรี้ยว: a barrage of fireballs and meteors —
  // many, fast and hard to dodge, but each one is light. Read the rhythm.
  hw_wrath(e, dt, world) {
    const p = world.player;
    const ph = phaseChange(e, world, { 2: 'แม่มดกรีดร้องด้วยความแค้น!', 3: 'ไฟแค้นเผาทั้งฟ้า!' });
    const k = ph === 3 ? 0.76 : ph === 2 ? 0.88 : 1;
    if (e.state === 'idle') setState(e, 'hover');
    if (e.state === 'hover') {
      steer(e, toward(e, p) + 1.4, e.type.speed * 0.6, dt, 3); e.ai.z = 34 + Math.sin(world.time * 2.6) * 10;
      if (e.t > 0.8 * k) setState(e, pick(world, ['stream', 'meteors', 'spiral', 'rhythm', ph >= 2 ? 'walls' : 'stream', ph >= 2 ? 'rain' : 'meteors']));
    } else if (e.state === 'stream') {
      // a sweeping fan of fireballs from the staff
      stop(e, dt, 8);
      e.ai.n ??= 0; const every = 0.06 * k, total = 22 + ph * 4;
      if (e.ai.step === 0) { e.ai.step = 1; e.ai.base = toward(e, p) - 0.8; e.ai.n = 0; }
      while (e.ai.n < total && e.t >= e.ai.n * every) { const a = e.ai.base + 1.6 * (e.ai.n / total) + Math.sin(e.ai.n) * 0.05; world.shoot(e, { x: e.x, y: e.y - 70, angle: a, speed: 520, r: 11, mult: 0.45, kind: 'hwfire', life: 2.6, fire: true }); e.ai.n += 1; }
      if (e.t > total * every + 0.4) { e.ai.n = 0; setState(e, 'hover'); }
    } else if (e.state === 'meteors') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; for (let i = 0; i < 14 + ph * 3; i++) { const t = randomPlayer(world); const at = inArena(world, t.x + (rnd(world) - 0.5) * 520, t.y + (rnd(world) - 0.5) * 380); world.strike({ shape: 'circle', x: at.x, y: at.y, r: 62, dur: (0.65 + i * 0.07) * k, mult: 0.5, owner: e, tone: 'fire', fire: true, meteor: true }); } world.sfx('roar'); }
      if (e.t > (0.9 + 17 * 0.07) * k) setState(e, 'hover');
    } else if (e.state === 'spiral') {
      stop(e, dt, 8);
      e.ai.n ??= 0; const every = 0.05 * k, total = 48;
      if (e.ai.step === 0) { e.ai.step = 1; e.ai.n = 0; e.ai.base = rnd(world) * TAU; }
      while (e.ai.n < total && e.t >= e.ai.n * every) { for (const s of [0, Math.PI]) world.shoot(e, { x: e.x, y: e.y - 60, angle: e.ai.base + e.ai.n * 0.31 + s, speed: 300, r: 10, mult: 0.4, kind: 'hwbluefire', life: 3.4 }); e.ai.n += 1; }
      if (e.t > total * every + 0.3) { e.ai.n = 0; setState(e, 'hover'); }
    } else if (e.state === 'rhythm') {
      // pulses on a beat: dash through each ring right after it lands
      stop(e, dt, 9);
      if (e.ai.step === 0) { e.ai.step = 1; world.announce('จังหวะไฟ: พุ่งผ่านวงหลังวงระเบิด'); for (let i = 0; i < 6; i++) world.strike({ shape: 'ring', x: e.x, y: e.y, r: 260 + i * 70, inner: 190 + i * 70, dur: (0.6 + i * 0.4) * k, mult: 0.55, owner: e, tone: 'fire', fire: true }); world.sfx('telegraph'); }
      if (e.t > (0.9 + 6 * 0.4) * k) setState(e, 'hover');
    } else if (e.state === 'walls') {
      // walls of fire with one gap each, coming one after another
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; const A = world.arena; for (let i = 0; i < 4; i++) { const y = 140 + (i + 0.5) / 4 * (A.h - 220), gap = 160 + rnd(world) * (A.w - 320); world.strike({ shape: 'line', x: 60, y, angle: 0, len: Math.max(0, gap - 110), width: 60, dur: (0.8 + i * 0.5) * k, mult: 0.6, owner: e, tone: 'fire', fire: true }); world.strike({ shape: 'line', x: gap + 110, y, angle: 0, len: Math.max(0, A.w - 60 - gap - 110), width: 60, dur: (0.8 + i * 0.5) * k, mult: 0.6, owner: e, tone: 'fire', fire: true }); } world.sfx('telegraph'); }
      if (e.t > (1 + 4 * 0.5) * k) setState(e, 'hover');
    } else if (e.state === 'rain') {
      stop(e, dt, 8);
      if (e.ai.step === 0) { e.ai.step = 1; world.darkPulse(2.5); const A = world.arena; for (let i = 0; i < 30; i++) world.strike({ shape: 'circle', x: 100 + rnd(world) * (A.w - 200), y: 150 + rnd(world) * (A.h - 240), r: 54, dur: (0.7 + rnd(world) * 1.6) * k, mult: 0.45, owner: e, tone: 'fire', fire: true, meteor: true }); world.announce('ฝนอุกกาบาต!'); }
      if (e.t > 2.6 * k) setState(e, 'hover');
    }
  },
});
