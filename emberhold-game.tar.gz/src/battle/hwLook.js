// v10 the living look of the Halloween gear on any hero (mine and other players'): the never-ending effect of an event
// weapon or its skin, and the spite mask worn over everything. Drawn after the hero, in world space.
import { BASE_FX } from '../data/halloween.js';
import { getSkinAny } from '../data/skins.js';
import { wornSkinId } from '../systems/skins.js';
import { drawSkinAura, drawTierRing } from './skinFx.js';
import { getItem } from '../data/items.js';
import { drawPumpkin } from '../art/hwShots.js';

const TAU = Math.PI * 2;
function glow(ctx, x, y, r, col, a) {
  const g = ctx.createRadialGradient(x, y, 1, x, y, r); g.addColorStop(0, hexA(col, a)); g.addColorStop(1, hexA(col, 0));
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
}
function hexA(hex, a) { const n = parseInt(String(hex).slice(1, 7), 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; }
// orbiting dots / rising sparks around a point: the building blocks of every effect
function orbit(ctx, x, y, t, n, r, col, size, speed = 1, squash = 0.45) {
  for (let i = 0; i < n; i++) { const a = t * speed + i * TAU / n; const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r * squash; glow(ctx, px, py, size * 3, col, 0.5); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(px, py, size, 0, TAU); ctx.fill(); }
}
function rise(ctx, x, y, t, n, w, hgt, col, size, seed = 0) {
  for (let i = 0; i < n; i++) { const k = ((t * 0.6 + i / n + seed) % 1); const px = x + Math.sin(i * 7.1 + seed * 3) * w + Math.sin(t * 3 + i) * 4, py = y - k * hgt; ctx.globalAlpha = (1 - k) * 0.9; glow(ctx, px, py, size * 3, col, 0.6); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(px, py, size * (1 - k * 0.5), 0, TAU); ctx.fill(); }
  ctx.globalAlpha = 1;
}
function miniBat(ctx, x, y, t, col = '#1a0a14', eye = '#ff5a7a', s = 1) {
  const f = Math.sin(t * 30) * s;
  ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x - 6 * s, y - 6 * f - 2, x - 11 * s, y - f); ctx.lineTo(x - 6 * s, y + 3); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + 6 * s, y - 6 * f - 2, x + 11 * s, y - f); ctx.lineTo(x + 6 * s, y + 3); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.ellipse(x, y, 2.6 * s, 3.6 * s, 0, 0, TAU); ctx.fill(); ctx.fillStyle = eye; ctx.fillRect(x - 1.6, y - 1.6, 1.2, 1.2); ctx.fillRect(x + 0.4, y - 1.6, 1.2, 1.2);
}
const FX = {
  pumpkinsmoke: (ctx, x, y, t) => { rise(ctx, x + 10, y - 60, t, 6, 16, 70, '#ffb648', 2.6); },
  moonglow: (ctx, x, y, t) => { glow(ctx, x, y - 70, 70, '#bfe3ff', 0.18 + 0.06 * Math.sin(t * 2)); orbit(ctx, x, y - 60, t, 3, 46, '#e8f4ff', 2.6, 1.2); },
  ectoplasm: (ctx, x, y, t) => { rise(ctx, x, y - 20, t, 10, 22, 90, '#9fff7a', 3); },
  goldpumpkins: (ctx, x, y, t) => { for (let i = 0; i < 3; i++) { const a = t * 1.4 + i * TAU / 3; drawPumpkin(ctx, x + Math.cos(a) * 50, y - 60 + Math.sin(a) * 18, 7, t, a, '#e0b45a', '#fff3c4'); } },
  embers: (ctx, x, y, t) => { rise(ctx, x, y - 30, t, 9, 20, 80, '#ff8a1f', 2.2); },
  vines: (ctx, x, y, t) => { ctx.strokeStyle = 'rgba(106,255,90,0.6)'; ctx.lineWidth = 2.4; for (let i = 0; i < 3; i++) { ctx.beginPath(); for (let k = 0; k <= 12; k++) { const a = t * 1.5 + i * 2.1 + k * 0.4; const px = x + Math.cos(a) * (24 + k * 2), py = y - 10 - k * 8 + Math.sin(a) * 6; if (k) ctx.lineTo(px, py); else ctx.moveTo(px, py); } ctx.stroke(); } },
  bluefire: (ctx, x, y, t) => { for (let i = 0; i < 7; i++) { const k = (t * 0.9 + i / 7) % 1; glow(ctx, x + Math.sin(i * 2.3 + t * 4) * 22, y - k * 110, 14 * (1 - k) + 4, '#5ae0ff', 0.7 * (1 - k)); } },
  grins: (ctx, x, y, t) => { for (let i = 0; i < 2; i++) { const a = t * 1.8 + i * Math.PI; const px = x + Math.cos(a) * 44, py = y - 70 + Math.sin(a) * 16; ctx.strokeStyle = 'rgba(255,184,72,0.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(px, py, 9, 0.3, Math.PI - 0.3); ctx.stroke(); ctx.fillStyle = '#ffb648'; ctx.fillRect(px - 6, py - 5, 3, 3); ctx.fillRect(px + 3, py - 5, 3, 3); } },
  gravefog: (ctx, x, y, t) => { for (let i = 0; i < 5; i++) glow(ctx, x + Math.sin(t * 0.8 + i * 1.3) * 36, y - 4 + Math.cos(t + i) * 4, 34, '#d8e0f0', 0.18); },
  bloodmoon: (ctx, x, y, t) => { glow(ctx, x, y - 70, 80, '#ff2a3a', 0.15 + 0.08 * Math.sin(t * 3)); rise(ctx, x, y - 20, t, 6, 18, 70, '#ff4a4a', 2); },
  souls: (ctx, x, y, t) => { orbit(ctx, x, y - 60, t, 4, 52, '#b8f0ff', 3, 1.6); },
  purplemist: (ctx, x, y, t) => { for (let i = 0; i < 6; i++) glow(ctx, x + Math.sin(t * 1.2 + i) * 30, y - 30 - ((t * 20 + i * 15) % 70), 20, '#c88aff', 0.25); },
  bats: (ctx, x, y, t) => { for (let i = 0; i < 3; i++) { const a = t * 2.2 + i * TAU / 3; miniBat(ctx, x + Math.cos(a) * 52, y - 70 + Math.sin(a) * 22, t + i); } },
  stardust: (ctx, x, y, t) => { for (let i = 0; i < 8; i++) { const k = (t * 0.5 + i / 8) % 1; const px = x + Math.cos(i * 0.8 + t) * 40 * (1 - k), py = y - 110 + k * 90; ctx.fillStyle = `rgba(255,243,160,${1 - k})`; ctx.font = '700 10px serif'; ctx.fillText('✦', px, py); } },
  candycane: (ctx, x, y, t) => { ctx.save(); ctx.translate(x, y - 60); ctx.rotate(t); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 4; ctx.setLineDash([6, 6]); ctx.beginPath(); ctx.ellipse(0, 0, 48, 20, 0, 0, TAU); ctx.stroke(); ctx.strokeStyle = '#e0303a'; ctx.lineDashOffset = 6; ctx.stroke(); ctx.restore(); },
  webs: (ctx, x, y, t) => { ctx.strokeStyle = 'rgba(232,232,255,0.55)'; ctx.lineWidth = 1.2; const cx = x + 30, cy = y - 110 + Math.sin(t * 2) * 4; for (let k = 1; k <= 3; k++) { ctx.beginPath(); ctx.arc(cx, cy, k * 7, 0, TAU); ctx.stroke(); } for (let a = 0; a < 6; a++) { ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a) * 22, cy + Math.sin(a) * 22); ctx.stroke(); } ctx.beginPath(); ctx.moveTo(cx, cy - 22); ctx.lineTo(cx, cy - 60); ctx.stroke(); },
  curses: (ctx, x, y, t) => { const cols = ['#9a8ad0', '#ff7ad8', '#8ad04a', '#5ae0ff', '#ffd84a']; for (let i = 0; i < 5; i++) { const a = t * 1.3 + i * TAU / 5; glow(ctx, x + Math.cos(a) * 46, y - 60 + Math.sin(a) * 18, 9, cols[i], 0.8); } },
  sugar: (ctx, x, y, t) => { for (let i = 0; i < 8; i++) { const k = (t * 0.7 + i / 8) % 1; ctx.fillStyle = ['#ffffff', '#ff9ac8', '#5ae0ff', '#ffd84a'][i % 4]; ctx.save(); ctx.translate(x + Math.sin(i * 3 + t) * 30, y - 120 + k * 110); ctx.rotate(t * 4 + i); ctx.fillRect(-3, -1, 6, 2); ctx.restore(); } },
  cocoa: (ctx, x, y, t) => { rise(ctx, x, y - 20, t, 7, 20, 80, '#c88a5a', 3); },
  rainbow: (ctx, x, y, t) => { const cols = ['#ff5a7a', '#ffb648', '#ffd84a', '#8ad04a', '#5ae0ff', '#9a5aff']; cols.forEach((c, i) => { ctx.strokeStyle = hexA(c, 0.55); ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y - 30, 50 + i * 4, Math.PI + 0.3 + Math.sin(t) * 0.1, TAU - 0.3 + Math.sin(t) * 0.1); ctx.stroke(); }); },
  muramasa: (ctx, x, y, t) => { for (let i = 0; i < 6; i++) { const k = (t * 0.45 + i / 6) % 1; ctx.save(); ctx.translate(x + Math.sin(i * 2 + t) * 40, y - 110 + k * 110); ctx.rotate(t * 2 + i); ctx.fillStyle = `rgba(255,250,250,${1 - k})`; ctx.beginPath(); ctx.ellipse(0, 0, 5, 2.4, 0, 0, TAU); ctx.fill(); ctx.restore(); } glow(ctx, x, y - 60, 40, '#ff6a8a', 0.1); },
  sakura: (ctx, x, y, t) => { for (let i = 0; i < 8; i++) { const k = (t * 0.4 + i / 8) % 1; ctx.save(); ctx.translate(x + Math.sin(i * 2.3 + t) * 44, y - 120 + k * 120); ctx.rotate(t * 2 + i); ctx.fillStyle = `rgba(255,170,190,${1 - k})`; ctx.beginPath(); ctx.ellipse(0, 0, 5, 2.6, 0, 0, TAU); ctx.fill(); ctx.restore(); } },
  ink: (ctx, x, y, t) => { for (let i = 0; i < 5; i++) { const k = (t * 0.6 + i / 5) % 1; ctx.fillStyle = `rgba(60,20,120,${0.6 * (1 - k)})`; ctx.beginPath(); ctx.arc(x + Math.sin(i * 2 + t * 2) * 26, y - 30 - k * 80, 8 * (1 - k) + 3, 0, TAU); ctx.fill(); } },
};
// look: { w: weapon id, sk: skin id (v10.2; any weapon), mk: mask on }
export function drawHwAura(ctx, x, y, look, t, scale = 1) {
  if (!look) return;
  const def = look.w ? getItem(look.w) : null;
  const sk0 = look.sk ? getSkinAny(look.sk) : null, sk = sk0 && def && sk0.wid === def.id ? sk0 : null;
  let fx = null;
  if (sk && !sk.event) drawSkinAura(ctx, x, y, t, sk, scale);        // v10.2: skins of every weapon (อีปิค and up)
  if (def?.event === 'hw') { fx = sk ? sk.fx : BASE_FX[def.id]; if (sk) drawTierRing(ctx, x, y, t, sk.t); }
  if (fx && FX[fx]) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; FX[fx](ctx, x, y, t); ctx.restore(); if (fx === 'bats' || fx === 'webs' || fx === 'ink') FX[fx](ctx, x, y, t); }
  if (look.mk) drawSpiteMask(ctx, x, y, scale, look.flip);
}
// the spite mask over the hero's face (heroDraw puts the head ~118 px above the feet at scale 0.95)
export function drawSpiteMask(ctx, x, y, scale = 0.95, flip = false) {
  const hx = x + (flip ? -4 : 4) * scale, hy = y - 122 * scale;
  ctx.save(); ctx.translate(hx, hy); ctx.scale(scale * (flip ? -1 : 1), scale);
  ctx.fillStyle = '#f5efe6'; ctx.strokeStyle = '#1a100c'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.ellipse(0, 0, 15, 18, 0, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#0b0810'; ctx.beginPath(); ctx.ellipse(-6, -3, 4.4, 2.6, -0.2, 0, TAU); ctx.ellipse(6, -3, 4.4, 2.6, 0.2, 0, TAU); ctx.fill();
  ctx.fillStyle = '#ff5a9a'; ctx.beginPath(); ctx.arc(-6, -3, 1.2, 0, TAU); ctx.arc(6, -3, 1.2, 0, TAU); ctx.fill();
  ctx.strokeStyle = '#1a100c'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(-7, 9); ctx.quadraticCurveTo(0, 4, 7, 9); ctx.stroke();
  ctx.strokeStyle = '#3a1a4a'; ctx.beginPath(); ctx.moveTo(0, -18); ctx.lineTo(0, -10); ctx.stroke();
  ctx.restore();
}
// my own look from the save
export function myHwLook(st, flip = false) {
  const w = st.equipment.weapon?.id;
  return { w, sk: wornSkinId(st, w), mk: !!st.hw?.mask, flip };
}
export const FX_KINDS = Object.keys(FX);
