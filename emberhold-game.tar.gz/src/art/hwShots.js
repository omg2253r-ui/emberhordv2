// v10 Halloween projectiles, drawn straight on the canvas (they spin, flicker and trail — no two look alike).
// Player shots (battle/playerShots.js) and monster shots (battle/strikes.js) both look here first.
const TAU = Math.PI * 2;

// halo = false: no glow of its own (scenes with a light map light it there, which is much cheaper)
function pumpkin(ctx, x, y, r, t, rot, col = '#e8701a', glow = '#ffcf5a', halo = true) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot);
  if (halo) {
    ctx.globalCompositeOperation = 'lighter';
    const g = ctx.createRadialGradient(0, 0, 1, 0, 0, r * 2.2); g.addColorStop(0, glow + 'aa'); g.addColorStop(1, glow + '00');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, r * 2.2, 0, TAU); ctx.fill();
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.lineWidth = Math.max(1.5, r * 0.14); ctx.strokeStyle = '#1a0e08';
  for (const [dx, w] of [[-r * 0.45, 0.55], [r * 0.45, 0.55], [0, 0.6]]) { ctx.fillStyle = dx ? shadeHex(col, 0.85) : col; ctx.beginPath(); ctx.ellipse(dx, 0, r * w, r * 0.9, 0, 0, TAU); ctx.fill(); ctx.stroke(); }
  ctx.fillStyle = '#3a6a2a'; ctx.beginPath(); ctx.moveTo(-r * 0.12, -r * 0.85); ctx.lineTo(r * 0.18, -r * 1.25); ctx.lineTo(r * 0.24, -r * 0.8); ctx.closePath(); ctx.fill(); ctx.stroke();
  const flick = 0.75 + 0.25 * Math.sin(t * 30 + x);
  ctx.fillStyle = `rgba(255,${200 + 40 * flick | 0},90,${flick})`;
  ctx.beginPath(); ctx.moveTo(-r * 0.45, -r * 0.2); ctx.lineTo(-r * 0.15, -r * 0.2); ctx.lineTo(-r * 0.3, -r * 0.45); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(r * 0.45, -r * 0.2); ctx.lineTo(r * 0.15, -r * 0.2); ctx.lineTo(r * 0.3, -r * 0.45); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(-r * 0.5, r * 0.15); for (let i = 0; i <= 6; i++) ctx.lineTo(-r * 0.5 + i * r / 6, r * (i % 2 ? 0.5 : 0.25)); ctx.lineTo(r * 0.5, r * 0.15); ctx.closePath(); ctx.fill();
  ctx.restore();
}
function shadeHex(hex, f) { const n = parseInt(hex.slice(1), 16); const c = (v) => Math.max(0, Math.min(255, Math.round(v * f))); return `rgb(${c((n >> 16) & 255)},${c((n >> 8) & 255)},${c(n & 255)})`; }

function soul(ctx, s, t, col = '#b8f0ff') {
  const a = Math.atan2(s.vy || 0, s.vx || 1);
  ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(a);
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 5; i++) { ctx.globalAlpha = 0.5 - i * 0.09; ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(-i * s.r * 0.9, Math.sin(t * 12 + i) * 3, s.r * (1 - i * 0.12), s.r * 0.6 * (1 - i * 0.12), 0, 0, TAU); ctx.fill(); }
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(s.r * 0.2, 0, s.r * 0.55, 0, TAU); ctx.fill();
  ctx.fillStyle = '#1a2a3a'; ctx.beginPath(); ctx.arc(s.r * 0.35, -s.r * 0.18, 1.6, 0, TAU); ctx.arc(s.r * 0.35, s.r * 0.18, 1.6, 0, TAU); ctx.fill();
  ctx.restore();
}
function bat(ctx, s, t, col = '#2a1424', eye = '#ff5a7a') {
  const a = Math.atan2(s.vy || 0, s.vx || 1), flap = Math.sin(t * 34 + s.x * 0.05);
  ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(a + Math.PI / 2);
  ctx.fillStyle = col; ctx.strokeStyle = '#05030a'; ctx.lineWidth = 1.4;
  const W = s.r * 2.2, H = s.r * (0.6 + 0.6 * Math.abs(flap));
  for (const sg of [-1, 1]) {
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(sg * W * 0.5, -H * 1.4, sg * W, -H * 0.2 * flap);
    ctx.lineTo(sg * W * 0.75, H * 0.4); ctx.lineTo(sg * W * 0.5, H * 0.1); ctx.lineTo(sg * W * 0.3, H * 0.5); ctx.closePath(); ctx.fill(); ctx.stroke();
  }
  ctx.beginPath(); ctx.ellipse(0, 0, s.r * 0.45, s.r * 0.7, 0, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.fillStyle = eye; ctx.beginPath(); ctx.arc(-2, -s.r * 0.3, 1.5, 0, TAU); ctx.arc(2, -s.r * 0.3, 1.5, 0, TAU); ctx.fill();
  ctx.restore();
}
function grin(ctx, s, t) {
  const a = Math.atan2(s.vy || 0, s.vx || 1);
  ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(a);
  ctx.globalCompositeOperation = 'lighter';
  ctx.strokeStyle = 'rgba(255,160,40,0.85)'; ctx.lineWidth = 6;
  ctx.beginPath(); ctx.arc(-s.r * 0.6, 0, s.r * 1.3, -1.1, 1.1); ctx.stroke();
  ctx.strokeStyle = 'rgba(255,230,140,0.9)'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(-s.r * 0.6, 0, s.r * 1.3, -1.1, 1.1); ctx.stroke();
  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = '#1a0e08';
  for (let i = -2; i <= 2; i++) { const yy = i * s.r * 0.36; ctx.beginPath(); ctx.moveTo(s.r * 0.55, yy - 4); ctx.lineTo(s.r * 0.75, yy); ctx.lineTo(s.r * 0.55, yy + 4); ctx.fill(); }
  ctx.restore();
}
function candy(ctx, s, t) {
  const a = Math.atan2(s.vy || 0, s.vx || 1), L = s.r * 3;
  ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(a);
  ctx.lineCap = 'round'; ctx.strokeStyle = '#1a0e08'; ctx.lineWidth = s.r * 0.9 + 3;
  ctx.beginPath(); ctx.moveTo(-L, 0); ctx.lineTo(L * 0.4, 0); ctx.stroke();
  ctx.strokeStyle = '#ffffff'; ctx.lineWidth = s.r * 0.9; ctx.beginPath(); ctx.moveTo(-L, 0); ctx.lineTo(L * 0.4, 0); ctx.stroke();
  ctx.strokeStyle = '#e0303a'; ctx.lineWidth = s.r * 0.4;
  for (let x = -L + ((t * 220) % 14); x < L * 0.4; x += 14) { ctx.beginPath(); ctx.moveTo(x, -s.r * 0.45); ctx.lineTo(x + 6, s.r * 0.45); ctx.stroke(); }
  ctx.fillStyle = '#ffd8e8'; ctx.strokeStyle = '#1a0e08'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(L * 0.4, -s.r * 0.8); ctx.lineTo(L * 0.4 + s.r * 1.6, 0); ctx.lineTo(L * 0.4, s.r * 0.8); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.restore();
}
function petal(ctx, s, t) {
  ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(t * 9 + s.x * 0.01);
  ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = 'rgba(255,106,138,0.35)'; ctx.beginPath(); ctx.arc(0, 0, s.r * 1.8, 0, TAU); ctx.fill();
  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = '#fffafa'; ctx.strokeStyle = '#7a1a3a'; ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.ellipse(0, 0, s.r * 1.2, s.r * 0.55, 0, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#ff6a8a'; ctx.beginPath(); ctx.ellipse(-s.r * 0.4, 0, s.r * 0.35, s.r * 0.2, 0, 0, TAU); ctx.fill();
  ctx.restore();
}
// monster shots
function potion(ctx, s, t) {
  const col = s.tintCol || '#9a5aff';
  ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(t * 8);
  ctx.globalCompositeOperation = 'lighter'; const g = ctx.createRadialGradient(0, 0, 1, 0, 0, s.r * 2.4); g.addColorStop(0, col + 'aa'); g.addColorStop(1, col + '00'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, s.r * 2.4, 0, TAU); ctx.fill();
  ctx.globalCompositeOperation = 'source-over';
  ctx.strokeStyle = '#1a0e08'; ctx.lineWidth = 2;
  ctx.fillStyle = '#d9e4e6'; ctx.beginPath(); ctx.arc(0, s.r * 0.25, s.r * 0.95, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.fillStyle = col; ctx.beginPath(); ctx.arc(0, s.r * 0.35, s.r * 0.75, 0.2, Math.PI - 0.2); ctx.fill();
  ctx.fillStyle = '#a87848'; ctx.fillRect(-s.r * 0.3, -s.r * 1.2, s.r * 0.6, s.r * 0.6); ctx.strokeRect(-s.r * 0.3, -s.r * 1.2, s.r * 0.6, s.r * 0.6);
  ctx.restore();
}
function fireball(ctx, s, t, col = '#ff6a1a') {
  const a = Math.atan2(s.vy || 0, s.vx || 1);
  ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(a);
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 6; i++) { ctx.fillStyle = i < 2 ? '#fff3c4' : col; ctx.globalAlpha = 0.65 - i * 0.09; ctx.beginPath(); ctx.ellipse(-i * s.r * 0.7, Math.sin(t * 25 + i * 2) * 2, s.r * (1.1 - i * 0.12), s.r * (0.85 - i * 0.1), 0, 0, TAU); ctx.fill(); }
  ctx.restore();
}
function scythe(ctx, s, t) {
  ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(t * 16);
  ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = 'rgba(184,240,255,0.35)'; ctx.lineWidth = 8; ctx.beginPath(); ctx.arc(0, 0, s.r * 1.4, 0, TAU); ctx.stroke();
  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = '#14141c'; ctx.strokeStyle = '#b8f0ff'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(s.r * 1.6, -s.r * 1.4, s.r * 0.2, -s.r * 1.8); ctx.quadraticCurveTo(s.r * 0.9, -s.r * 0.8, 0, 0); ctx.fill(); ctx.stroke();
  ctx.strokeStyle = '#3a2a20'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(-s.r * 0.6, s.r * 1.2); ctx.stroke();
  ctx.restore();
}
function bone(ctx, s, t) {
  ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(t * 14);
  ctx.strokeStyle = '#1a0e08'; ctx.lineWidth = 2; ctx.fillStyle = '#ffd8e8';
  ctx.fillRect(-s.r, -s.r * 0.25, s.r * 2, s.r * 0.5); ctx.strokeRect(-s.r, -s.r * 0.25, s.r * 2, s.r * 0.5);
  for (const sx of [-1, 1]) for (const sy of [-1, 1]) { ctx.beginPath(); ctx.arc(sx * s.r, sy * s.r * 0.3, s.r * 0.32, 0, TAU); ctx.fill(); ctx.stroke(); }
  ctx.fillStyle = '#e0303a'; ctx.fillRect(-s.r * 0.6, -s.r * 0.25, s.r * 0.25, s.r * 0.5); ctx.fillRect(s.r * 0.3, -s.r * 0.25, s.r * 0.25, s.r * 0.5);
  ctx.restore();
}
function hexOrb(ctx, s, t, col = '#c86aff') {
  ctx.save(); ctx.translate(s.x, s.y);
  ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createRadialGradient(0, 0, 1, 0, 0, s.r * 2); g.addColorStop(0, '#ffffff'); g.addColorStop(0.35, col); g.addColorStop(1, col + '00');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, s.r * 2, 0, TAU); ctx.fill();
  ctx.strokeStyle = col; ctx.lineWidth = 1.5; ctx.rotate(t * 4);
  ctx.beginPath(); for (let i = 0; i < 6; i++) { const a = i / 6 * TAU; ctx.lineTo(Math.cos(a) * s.r * 1.5, Math.sin(a) * s.r * 1.5); } ctx.closePath(); ctx.stroke();
  ctx.restore();
}
function hammer(ctx, s, t) {
  ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(t * 13);
  ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = 'rgba(255,232,154,0.3)'; ctx.beginPath(); ctx.arc(0, 0, s.r * 1.8, 0, TAU); ctx.fill();
  ctx.globalCompositeOperation = 'source-over';
  ctx.strokeStyle = '#1a0e08'; ctx.lineWidth = 2;
  ctx.fillStyle = '#8a6a3a'; ctx.fillRect(-2.5, -s.r * 1.2, 5, s.r * 2.2); ctx.strokeRect(-2.5, -s.r * 1.2, 5, s.r * 2.2);
  ctx.fillStyle = '#fff3c4'; ctx.fillRect(-s.r * 0.9, -s.r * 1.3, s.r * 1.8, s.r * 0.9); ctx.strokeRect(-s.r * 0.9, -s.r * 1.3, s.r * 1.8, s.r * 0.9);
  ctx.restore();
}

export const HW_SHOTS = {
  pumpkin: (ctx, s, t) => pumpkin(ctx, s.x, s.y, s.r, t, t * 10 + (s.x || 0) * 0.01),
  soul: (ctx, s, t) => soul(ctx, s, t),
  bat: (ctx, s, t) => bat(ctx, s, t),
  grin: (ctx, s, t) => grin(ctx, s, t),
  candy: (ctx, s, t) => candy(ctx, s, t),
  petal: (ctx, s, t) => petal(ctx, s, t),
  // monster kinds
  hwpotion: (ctx, s, t) => potion(ctx, s, t),
  hwfire: (ctx, s, t) => fireball(ctx, s, t),
  hwbluefire: (ctx, s, t) => fireball(ctx, s, t, '#3ad0ff'),
  hwscythe: (ctx, s, t) => scythe(ctx, s, t),
  hwbone: (ctx, s, t) => bone(ctx, s, t),
  hwhex: (ctx, s, t) => hexOrb(ctx, s, t),
  hwlight: (ctx, s, t) => hexOrb(ctx, s, t, '#ffe89a'),
  hwhammer: (ctx, s, t) => hammer(ctx, s, t),
  hwpumpkin: (ctx, s, t) => pumpkin(ctx, s.x, s.y, s.r, t, t * 8, '#c84a10', '#ff8a1f'),
  hwsoul: (ctx, s, t) => soul(ctx, s, t, '#9fffd8'),
  hwbat: (ctx, s, t) => bat(ctx, s, t, '#1a0a14', '#ffcf5a'),
};
export { pumpkin as drawPumpkin };
