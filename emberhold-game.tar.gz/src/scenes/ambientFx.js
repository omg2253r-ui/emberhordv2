// v10.1 บรรยากาศ: shared ambient effects for the hub scenes (village, Halloween world) — a light map (darkness with
// holes where lamps burn, plus coloured glow), fireworks, lightning, ghosts, bats, crows, butterflies, falling leaves,
// cloud shadows, rune circles, light rays and twinkling stars. Everything scales with the graphics quality setting.
import { getQuality } from '../config/quality.js';

const TAU = Math.PI * 2;
export const fxAmount = () => { const q = getQuality(); return q.id === 'low' ? 0.35 : q.id === 'medium' ? 0.7 : 1; };
export const rand = (a, b) => a + Math.random() * (b - a);

export function toScreen(r, x, y) {
  const c = r.cam, v = r.view;
  return { x: (x - c.x) * c.zoom + v.w / 2 + c.ox, y: (y - c.y) * c.zoom + v.h / 2 + c.oy };
}
export function onScreen(r, x, y, pad = 200) {
  const p = toScreen(r, x, y), v = r.view;
  return p.x > -pad && p.y > -pad && p.x < v.w + pad && p.y < v.h + pad;
}

// ------------------------------------------------------------------ cached sprites (gradients are drawn once)
const spriteCache = new Map();
function cached(key, w, h, paint) {
  let c = spriteCache.get(key);
  if (!c) { c = document.createElement('canvas'); c.width = w; c.height = h; paint(c.getContext('2d'), w, h); spriteCache.set(key, c); }
  return c;
}
// a soft round glow of one colour (or black for holes in the darkness)
export function glowSprite(col, a = 1) {
  return cached(`g${col}${a}`, 128, 128, (g) => { const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, hexA(col, a)); gr.addColorStop(0.5, hexA(col, a * 0.55)); gr.addColorStop(1, hexA(col, 0)); g.fillStyle = gr; g.fillRect(0, 0, 128, 128); });
}
export function drawGlow(ctx, x, y, r, col, a = 1) { ctx.globalAlpha = a; ctx.drawImage(glowSprite(col), x - r, y - r, r * 2, r * 2); ctx.globalAlpha = 1; }

// ------------------------------------------------------------------ light map
// lights: [{ x, y, r, a?, col?, ga? }] in world units. dark: the colour of the night. Drawn in screen space at a third
// of the resolution (it is soft anyway), then each coloured light adds a glow.
// The light map is a small canvas laid over the game canvas as its own page element: the browser stretches and blends
// it while compositing, which costs far less than drawing it into the game canvas every frame.
export function createLighting() {
  if (typeof document === 'undefined') return { draw() {}, hide() {} };
  const cv = document.createElement('canvas');
  cv.className = 'light-map'; cv.setAttribute('aria-hidden', 'true');
  Object.assign(cv.style, { position: 'absolute', inset: '0', width: '100%', height: '100%', pointerEvents: 'none', display: 'none' });
  const g = cv.getContext('2d');
  let placed = false;
  return {
    draw(renderer, lights, { dark = 'rgba(10,6,24,0.5)', flash = 0 } = {}) {
      if (!placed) { const scene = renderer.ctx.canvas; scene.insertAdjacentElement('afterend', cv); placed = true; }
      cv.style.display = 'block';
      const v = renderer.view, z = renderer.cam.zoom, s = 0.3;
      const W = Math.max(1, Math.ceil(v.w * s)), H = Math.max(1, Math.ceil(v.h * s));
      if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
      g.globalCompositeOperation = 'source-over'; g.globalAlpha = 1; g.clearRect(0, 0, W, H); g.fillStyle = dark; g.fillRect(0, 0, W, H);
      const hole = glowSprite('#000000'), glow = getQuality().glow, vis = [];
      g.globalCompositeOperation = 'destination-out';
      for (const l of lights) {
        const p = toScreen(renderer, l.x, l.y), r = l.r * z * s, x = p.x * s, y = p.y * s;
        if (x < -r || y < -r || x > W + r || y > H + r) continue;
        vis.push([l, x, y, r]);
        if (!l.glowOnly && !l.shade) { g.globalAlpha = Math.min(1, l.a ?? 1); g.drawImage(hole, x - r, y - r, r * 2, r * 2); }
      }
      if (glow) {
        g.globalCompositeOperation = 'lighter';
        for (const [l, x, y, r] of vis) {
          if (l.shade || !(l.col || l.img)) continue;
          g.globalAlpha = Math.min(1, (l.ga ?? 0.22) * 0.9);
          if (l.img) { g.save(); g.translate(x, y); g.rotate(l.rot || 0); g.drawImage(l.img, -r, -r, r * 2, r * 2); g.restore(); }
          else { const rr = r * 0.8; g.drawImage(glowSprite(l.col), x - rr, y - rr, rr * 2, rr * 2); }
        }
      }
      // cloud shadows and other soft darkness ({ shade: alpha })
      g.globalCompositeOperation = 'source-over';
      for (const [l, x, y, r] of vis) if (l.shade) { g.globalAlpha = l.shade; g.drawImage(hole, x - r, y - r * 0.6, r * 2, r * 1.2); }
      g.globalAlpha = 1;
      if (flash > 0) { g.fillStyle = `rgba(220,230,255,${Math.min(0.8, flash)})`; g.fillRect(0, 0, W, H); }
    },
    hide() { cv.style.display = 'none'; },
  };
}
// the light-ray sprite (for a light's { img })
export function raysSprite(col, n = 14) {
  return cached(`rys${col}${n}`, 256, 256, (g) => { g.translate(128, 128); for (let i = 0; i < n; i++) { g.rotate(TAU / n); const gr = g.createLinearGradient(0, 0, 128, 0); gr.addColorStop(0, hexA(col, 1)); gr.addColorStop(1, hexA(col, 0)); g.fillStyle = gr; g.beginPath(); g.moveTo(0, 0); g.lineTo(128, -12); g.lineTo(128, 12); g.closePath(); g.fill(); } });
}
export function hexA(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

// ------------------------------------------------------------------ fireworks
// launch(x, y, kind) sends a rocket up from (x, y); it bursts at its peak as a ring, a peony, a willow or a heart.
const FW_COLS = [['#ff8a1f', '#ffd27a'], ['#c86aff', '#f0d0ff'], ['#7aff6a', '#e0ffd0'], ['#ff5a7a', '#ffd0dc'], ['#5ae0ff', '#e0fbff'], ['#ffd34a', '#fff6c0']];
export function createFireworks(audio = null) {
  const rockets = [], sparks = [];
  return {
    launch(x, y, peak = 380, kind = null, col = null) {
      rockets.push({ x, y, vx: rand(-30, 30), vy: -Math.sqrt(2 * 520 * peak), t: 0, kind: kind || ['ring', 'peony', 'willow', 'heart', 'crackle'][(Math.random() * 5) | 0], col: col || FW_COLS[(Math.random() * FW_COLS.length) | 0], trail: [] });
      audio?.play?.('dash', { power: 0.4 });
    },
    update(dt) {
      for (let i = rockets.length - 1; i >= 0; i--) {
        const r = rockets[i];
        r.t += dt; r.vy += 520 * dt; r.x += r.vx * dt; r.y += r.vy * dt;
        r.trail.push([r.x, r.y]); if (r.trail.length > 6) r.trail.shift();
        if (r.vy >= -20) { burst(r); rockets.splice(i, 1); }
      }
      for (let i = sparks.length - 1; i >= 0; i--) {
        const s = sparks[i];
        s.life -= dt; if (s.life <= 0) { sparks.splice(i, 1); continue; }
        s.vy += (s.g ?? 60) * dt; s.vx *= 1 - s.drag * dt; s.vy *= 1 - s.drag * dt;
        s.px = s.x; s.py = s.y; s.x += s.vx * dt; s.y += s.vy * dt;
      }
    },
    draw(ctx) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      for (const r of rockets) {
        ctx.strokeStyle = r.col[1]; ctx.lineWidth = 3; ctx.beginPath();
        r.trail.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(r.x, r.y, 4, 0, TAU); ctx.fill();
      }
      for (const s of sparks) {
        const k = Math.max(0, s.life / s.max), tw = s.twinkle ? (Math.sin(s.life * 40) > 0 ? 1 : 0.2) : 1;
        ctx.strokeStyle = k > 0.5 ? s.c2 : s.c1; ctx.globalAlpha = k * tw; ctx.lineWidth = s.w * (0.5 + k * 0.6);
        ctx.beginPath(); ctx.moveTo(s.px ?? s.x, s.py ?? s.y); ctx.lineTo(s.x, s.y); ctx.stroke();
      }
      ctx.restore();
    },
    get busy() { return rockets.length + sparks.length; },
    // flashes of light the scene adds to its light map
    lights() { return sparks.length ? burstsLit : []; },
  };
  function burst(r) {
    const n = Math.round((r.kind === 'willow' ? 70 : 56) * fxAmount()) + 12;
    const [c1, c2] = r.col;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU + rand(-0.04, 0.04);
      let sp = r.kind === 'ring' ? 260 : rand(80, 280), vx = Math.cos(a) * sp, vy = Math.sin(a) * sp;
      if (r.kind === 'heart') { const t = a; const hx = 16 * Math.sin(t) ** 3, hy = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)); vx = hx * 15; vy = hy * 15; }
      sparks.push({ x: r.x, y: r.y, vx, vy, life: r.kind === 'willow' ? rand(1.8, 2.6) : rand(1, 1.6), max: 2, c1, c2, w: r.kind === 'willow' ? 2 : 2.6, drag: r.kind === 'willow' ? 1.6 : 1.1, g: r.kind === 'willow' ? 140 : 70, twinkle: r.kind === 'crackle' });
    }
    burstsLit.length = 0; burstsLit.push({ x: r.x, y: r.y, r: 420, a: 0.7, col: c1, ga: 0.35, until: performance.now() + 500 });
    setTimeout(() => { burstsLit.length = 0; }, 450);
    audio?.play?.('slam', { power: 0.35 });
  }
}
const burstsLit = [];

// ------------------------------------------------------------------ lightning across the sky
export function createLightning(audio = null) {
  let wait = rand(14, 30), bolt = null, flash = 0;
  return {
    update(dt, x0, x1, top, bottom) {
      wait -= dt; flash = Math.max(0, flash - dt * 2.4);
      if (bolt) { bolt.t -= dt; if (bolt.t <= 0) bolt = null; }
      if (wait <= 0) {
        wait = rand(16, 36);
        const x = rand(x0, x1), pts = [[x, top]];
        let cx = x, cy = top;
        while (cy < bottom) { cx += rand(-60, 60); cy += rand(30, 70); pts.push([cx, Math.min(bottom, cy)]); }
        const fork = pts.slice(2, 4).map(([fx, fy]) => [[fx, fy], [fx + rand(-120, 120), fy + rand(60, 140)]]);
        bolt = { pts, fork, t: 0.35 }; flash = 0.55;
        setTimeout(() => audio?.play?.('slam', { power: 1.4 }), 380);
      }
    },
    draw(ctx) {
      if (!bolt) return;
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      for (const [w, c] of [[10, 'rgba(160,140,255,0.35)'], [4, 'rgba(220,220,255,0.9)'], [1.6, '#fff']]) {
        ctx.strokeStyle = c; ctx.lineWidth = w; ctx.beginPath();
        bolt.pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
        for (const [[ax, ay], [bx, by]] of bolt.fork) { ctx.moveTo(ax, ay); ctx.lineTo(bx, by); }
        ctx.stroke();
      }
      ctx.restore();
    },
    get flash() { return flash; },
  };
}

// ------------------------------------------------------------------ creatures and drifting things
export function drawGhost(ctx, x, y, t, s = 1, alpha = 0.7, tint = '#e8f0ff') {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.globalAlpha = alpha;
  ctx.fillStyle = tint; ctx.beginPath(); ctx.moveTo(-22, 10); ctx.bezierCurveTo(-26, -40, 26, -40, 22, 10);
  for (let i = 0; i <= 4; i++) { const hx = 22 - i * 11, hy = 10 + Math.sin(t * 6 + i) * 5 + (i % 2 ? 8 : 0); ctx.lineTo(hx, hy); }
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#1a1030'; ctx.beginPath(); ctx.ellipse(-8, -14, 4, 6, 0, 0, TAU); ctx.ellipse(8, -14, 4, 6, 0, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(0, -2, 4, 5 + Math.sin(t * 3) * 2, 0, 0, TAU); ctx.fill();
  ctx.restore();
}
export function drawBat(ctx, x, y, t, s = 1, col = '#07040c') {
  const f = Math.sin(t * 22) * 8 * s;
  ctx.fillStyle = col; ctx.beginPath();
  ctx.moveTo(x, y); ctx.quadraticCurveTo(x - 10 * s, y - 8 * s - f, x - 20 * s, y - f); ctx.lineTo(x - 13 * s, y + 3 * s); ctx.lineTo(x - 8 * s, y + 1 * s);
  ctx.lineTo(x, y + 5 * s); ctx.lineTo(x + 8 * s, y + 1 * s); ctx.lineTo(x + 13 * s, y + 3 * s); ctx.lineTo(x + 20 * s, y - f); ctx.quadraticCurveTo(x + 10 * s, y - 8 * s - f, x, y);
  ctx.fill();
}
export function drawCrow(ctx, x, y, flap, flip = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(flip, 1);
  ctx.fillStyle = '#0c0a12';
  ctx.beginPath(); ctx.ellipse(0, -8, 9, 6, -0.2, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.arc(8, -14, 4.5, 0, TAU); ctx.fill();
  ctx.fillStyle = '#c8a040'; ctx.beginPath(); ctx.moveTo(12, -15); ctx.lineTo(18, -13); ctx.lineTo(12, -12); ctx.fill();
  ctx.fillStyle = '#ff3a3a'; ctx.beginPath(); ctx.arc(9, -15, 1.1, 0, TAU); ctx.fill();
  ctx.fillStyle = '#0c0a12'; ctx.beginPath(); ctx.moveTo(-8, -8); ctx.lineTo(-16, -4); ctx.lineTo(-8, -4); ctx.fill();
  if (flap) { ctx.beginPath(); ctx.moveTo(-2, -10); ctx.lineTo(-10, -26 - flap * 6); ctx.lineTo(4, -12); ctx.fill(); }
  ctx.strokeStyle = '#2a2420'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(-2, -3); ctx.lineTo(-2, 0); ctx.moveTo(2, -3); ctx.lineTo(2, 0); ctx.stroke();
  ctx.restore();
}
export function drawButterfly(ctx, x, y, t, col) {
  const f = Math.abs(Math.sin(t * 14));
  ctx.save(); ctx.translate(x, y);
  ctx.fillStyle = col;
  ctx.beginPath(); ctx.ellipse(-5 * f, -3, 6 * f + 1, 5, -0.4, 0, TAU); ctx.ellipse(5 * f, -3, 6 * f + 1, 5, 0.4, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(-4 * f, 3, 4 * f + 1, 3.4, 0.3, 0, TAU); ctx.ellipse(4 * f, 3, 4 * f + 1, 3.4, -0.3, 0, TAU); ctx.fill();
  ctx.fillStyle = '#1a1410'; ctx.fillRect(-0.8, -6, 1.6, 11);
  ctx.restore();
}
export function drawLeaf(ctx, x, y, rot, col) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot);
  ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(0, -7); ctx.quadraticCurveTo(6, -2, 0, 7); ctx.quadraticCurveTo(-6, -2, 0, -7); ctx.fill();
  ctx.strokeStyle = 'rgba(40,20,10,0.5)'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(0, -6); ctx.lineTo(0, 6); ctx.stroke();
  ctx.restore();
}
// a magic circle on the ground: an outer ring of runes and an inner star turning the other way (each drawn once, then
// only rotated)
function runeRing(col, r) {
  const R = Math.ceil(r) + 8;
  return cached(`rr${col}${R}`, R * 2, R * 2, (g) => {
    g.translate(R, R); g.strokeStyle = hexA(col, 0.8); g.lineWidth = 3;
    g.beginPath(); g.arc(0, 0, r, 0, TAU); g.stroke(); g.lineWidth = 1.6; g.beginPath(); g.arc(0, 0, r * 0.82, 0, TAU); g.stroke();
    for (let i = 0; i < 16; i++) { g.rotate(TAU / 16); g.beginPath(); g.moveTo(r * 0.84, -5); g.lineTo(r * 0.96, 0); g.lineTo(r * 0.84, 5); g.moveTo(r * 0.9, -7); g.lineTo(r * 0.9, 7); g.stroke(); }
    const gr = g.createRadialGradient(0, 0, 0, 0, 0, r); gr.addColorStop(0, hexA(col, 0.22)); gr.addColorStop(1, hexA(col, 0)); g.fillStyle = gr; g.beginPath(); g.arc(0, 0, r, 0, TAU); g.fill();
  });
}
function runeStar(col, r) {
  const R = Math.ceil(r) + 4;
  return cached(`rs${col}${R}`, R * 2, R * 2, (g) => {
    g.translate(R, R); g.strokeStyle = hexA(col, 0.6); g.lineWidth = 2;
    g.beginPath(); for (let i = 0; i <= 5; i++) { const a = (i * 2 * TAU) / 5 - Math.PI / 2; const px = Math.cos(a) * r, py = Math.sin(a) * r; i ? g.lineTo(px, py) : g.moveTo(px, py); } g.stroke();
    g.beginPath(); g.arc(0, 0, r * 0.38, 0, TAU); g.stroke();
  });
}
// pre-turned frames: the ring repeats every 1/16 turn and the star every 1/5 turn, so a dozen frames each are enough
// and drawing them is a plain copy (no rotating or squashing every frame)
function runeFrames(kind, col, r, squash) {
  const n = kind === 'ring' ? 12 : 24, period = kind === 'ring' ? TAU / 16 : TAU / 5;
  const key = `rf${kind}${col}${r}${squash}`;
  let fr = spriteCache.get(key);
  if (fr) return fr;
  const src = kind === 'ring' ? runeRing(col, r) : runeStar(col, Math.round(r * 0.78));
  const W = src.width, H = Math.ceil(src.height * squash);
  fr = Array.from({ length: n }, (_, i) => { const c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d'); g.translate(W / 2, H / 2); g.scale(1, squash); g.rotate((i / n) * period); g.drawImage(src, -src.width / 2, -src.height / 2); return c; });
  fr.period = period; spriteCache.set(key, fr);
  return fr;
}
export function drawRuneCircle(ctx, x, y, r, t, col, squash = 0.42) {
  const R = Math.round(r), q = Math.round(squash * 100) / 100;
  const ring = runeFrames('ring', col, R, q), star = runeFrames('star', col, R, q);
  const pick = (fr, ang) => fr[Math.floor((((ang % fr.period) + fr.period) % fr.period) / fr.period * fr.length) % fr.length];
  const a = pick(ring, t * 0.5), b2 = pick(star, -t * 0.8);
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.drawImage(a, Math.round(x - a.width / 2), Math.round(y - a.height / 2));
  ctx.drawImage(b2, Math.round(x - b2.width / 2), Math.round(y - b2.height / 2));
  ctx.restore();
}
// rotating god rays behind something bright
export function drawRays(ctx, x, y, r, t, col, n = 12, a = 0.18) {
  const R = Math.round(r);
  const c = cached(`ry${col}${R}${n}`, R * 2, R * 2, (g) => {
    g.translate(R, R);
    for (let i = 0; i < n; i++) { g.rotate(TAU / n); const gr = g.createLinearGradient(0, 0, R, 0); gr.addColorStop(0, hexA(col, 1)); gr.addColorStop(1, hexA(col, 0)); g.fillStyle = gr; g.beginPath(); g.moveTo(0, 0); g.lineTo(R, -R * 0.09); g.lineTo(R, R * 0.09); g.closePath(); g.fill(); }
  });
  ctx.save(); ctx.translate(x, y); ctx.rotate(t * 0.15); ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = a * (0.8 + 0.2 * Math.sin(t * 2)); ctx.drawImage(c, -R, -R);
  ctx.restore();
}
// a beam of light rising into the sky
export function drawBeam(ctx, x, y, w, h, t, col) {
  const W = Math.round(w * 2), H = Math.round(h);
  const c = cached(`bm${col}${W}x${H}`, W, H, (g) => { const gr = g.createLinearGradient(0, H, 0, 0); gr.addColorStop(0, hexA(col, 0.5)); gr.addColorStop(1, hexA(col, 0)); g.fillStyle = gr; g.beginPath(); g.moveTo(0, H); g.lineTo(W * 0.3, 0); g.lineTo(W * 0.7, 0); g.lineTo(W, H); g.closePath(); g.fill(); });
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.8 + 0.2 * Math.sin(t * 4); ctx.drawImage(c, Math.round(x - W / 2), Math.round(y - H)); ctx.restore();
}
// crackling arcs of energy between two points
export function drawArc(ctx, x0, y0, x1, y1, col, seg = 8, amp = 18) {
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (const [w, c] of [[5, hexA(col, 0.35)], [1.8, '#ffffff']]) {
    ctx.strokeStyle = c; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x0, y0);
    for (let i = 1; i < seg; i++) { const k = i / seg; ctx.lineTo(x0 + (x1 - x0) * k + rand(-amp, amp), y0 + (y1 - y0) * k + rand(-amp, amp)); }
    ctx.lineTo(x1, y1); ctx.stroke();
  }
  ctx.restore();
}

// a small swarm of wanderers that live inside a rectangle; the scene decides how to draw each
export function createWanderers(n, box, speed = 40) {
  const list = Array.from({ length: n }, (_, i) => ({ i, x: rand(box.x0, box.x1), y: rand(box.y0, box.y1), tx: 0, ty: 0, t: Math.random() * 10, ph: Math.random() * TAU }));
  for (const a of list) { a.tx = rand(box.x0, box.x1); a.ty = rand(box.y0, box.y1); }
  return {
    list,
    update(dt) {
      for (const a of list) {
        a.t += dt;
        const dx = a.tx - a.x, dy = a.ty - a.y, d = Math.hypot(dx, dy);
        if (d < 20) { a.tx = rand(box.x0, box.x1); a.ty = rand(box.y0, box.y1); continue; }
        a.vx = (dx / d) * speed; a.x += a.vx * dt; a.y += (dy / d) * speed * dt;
      }
    },
  };
}
// leaves / petals drifting down across the camera view (world space, recycled)
export function createFall(n, cols) {
  const list = Array.from({ length: n }, () => ({ x: 0, y: 0, vy: rand(30, 70), sw: rand(0.6, 1.6), ph: Math.random() * TAU, rot: Math.random() * TAU, vr: rand(-2, 2), c: cols[(Math.random() * cols.length) | 0], live: false }));
  return {
    update(dt, view) {
      for (const p of list) {
        if (!p.live || p.y > view.y1 + 40) { p.x = rand(view.x0 - 100, view.x1 + 100); p.y = view.y0 - rand(0, 400); p.live = true; }
        p.ph += dt * p.sw; p.y += p.vy * dt; p.x += Math.sin(p.ph) * 40 * dt + 12 * dt; p.rot += p.vr * dt;
      }
    },
    draw(ctx) { for (const p of list) if (p.live) drawLeaf(ctx, p.x, p.y, p.rot, p.c); },
  };
}
// the part of the world the camera sees
export function viewRect(r) {
  const v = r.view, c = r.cam, hw = v.w / 2 / c.zoom, hh = v.h / 2 / c.zoom;
  return { x0: c.x - hw, x1: c.x + hw, y0: c.y - hh, y1: c.y + hh };
}
