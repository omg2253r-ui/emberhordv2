// v10 ข่าวจากเซิร์ฟเวอร์: announcements (top centre), gift-box drops (a big notice on the left), gifts for everyone,
// gifts by mail, and the event end time the game master may move. Polls /api/cloud { op: 'news' } every 30 s while
// the game runs on a site with the server (nothing happens offline). Gift boxes are drawn by the village scenes
// (boxesIn) and opened through the server (claimBox), which rolls the reward — the page never decides it.
import { h, glyph, itemImg, fmt } from '../ui/dom.js';
import { getItem, ITEMS, isEquipment } from '../data/items.js';
import { rarityOf as getRarity } from '../data/rarity.js';
import { setHwEnd } from '../data/halloween.js';
import { cloneState } from '../core/state.js';
import { addInPlace } from '../systems/inventory.js';
import { CANDY_MAX } from '../data/halloween.js';
import { cloudError } from '../net/cloud.js';

const SEEN_KEY = 'emberhold.news.seen';
const POLL_MS = 30_000, MAIL_MS = 120_000;

// the reward (gold / candy / items) of a gift, added to a hero; items that do not fit are reported back
export function grantGift(state, gift) {
  const next = cloneState(state), missed = [];
  next.gold += Math.max(0, gift.gold | 0);
  next.candy = Math.min(CANDY_MAX, (next.candy || 0) + Math.max(0, gift.candy | 0));
  for (const it of gift.items || []) { if (!getItem(it.id)) continue; const r = addInPlace(next, it.id, Math.max(1, it.qty | 0), it.lvl | 0); if (!r.ok) missed.push(it); }
  return { state: next, missed };
}

export function createLive(app) {
  let news = { items: [], cfg: {}, gms: [], boxes: {}, gifts: {} };
  let seen = new Set(), timer = null, mailTimer = null, started = false, opened = new Set();
  try { seen = new Set(JSON.parse(localStorage.getItem(SEEN_KEY) || '[]')); } catch { seen = new Set(); }
  const keepSeen = () => { try { localStorage.setItem(SEEN_KEY, JSON.stringify([...seen].slice(-200))); } catch { /* private mode */ } };
  const listeners = new Set();

  // ---------------------------------------------------------------- overlay (announcement + box notice)
  const ann = h('div', { class: 'live-ann', 'aria-live': 'polite', 'data-live': 'announce' });
  const side = h('div', { class: 'live-side', 'data-live': 'boxes' });
  document.body.append(ann, side);
  let annTimer = 0;
  function announce(text, from = 'ประกาศจากเซิร์ฟเวอร์') {
    ann.replaceChildren(h('div', { class: 'live-ann-card' }, h('small', {}, glyph('talk'), from), h('b', {}, text)));
    ann.classList.remove('show'); void ann.offsetWidth; ann.classList.add('show');
    clearTimeout(annTimer); annTimer = setTimeout(() => ann.classList.remove('show'), 9000);
    app.audio?.play?.('wave');
    // also in chat, so it can be read again
    app.online?.addChat?.({ ch: 'village', peer: 'server', name: from, text, me: false, at: Date.now(), sys: true });
  }
  function boxNotice(text, count) {
    const card = h('div', { class: 'live-box-card' },
      h('div', { class: 'live-box-art' }, ...Array.from({ length: Math.min(5, count) }, (_, i) => h('i', { style: { '--d': `${i * 0.18}s`, '--x': `${(i - 2) * 22}px` } }))),
      h('div', { class: 'live-box-text' }, h('small', {}, 'กล่องแจกจากแอดมินจ้า'), h('b', {}, text), h('span', {}, `${count} กล่อง · รีบไปเก็บก่อนหมด!`)));
    side.append(card);
    setTimeout(() => card.classList.add('out'), 9000);
    setTimeout(() => card.remove(), 9800);
    app.audio?.play?.('legendary');
  }

  // ---------------------------------------------------------------- polling
  async function poll() {
    if (!app.cloud?.available) return;
    const d = await app.cloud.live('news');
    if (!d || d.error) return;
    news = { items: d.items || [], cfg: d.cfg || {}, gms: d.gms || [], boxes: d.boxes || {}, gifts: d.gifts || {} };
    setHwEnd(Number.isFinite(news.cfg.hwEnd) ? news.cfg.hwEnd : null);
    const now = Date.now();
    for (const it of news.items) {
      if (seen.has(it.id)) continue;
      seen.add(it.id);
      if (now - it.at > 15 * 60 * 1000) continue;          // old news is not shouted again
      if (it.kind === 'box') boxNotice(it.text, it.count); else announce(it.text);
    }
    keepSeen();
    for (const [gid, g] of Object.entries(news.gifts)) offerGift(gid, g);
    for (const f of listeners) f(news);
  }
  async function pollMail() {
    if (!app.cloud?.available || !app.cloud.account()) return;
    const d = await app.cloud.live('mail');
    for (const g of d.gifts || []) receive(g, 'ของขวัญจากแอดมินส่งถึงบัญชีของคุณ');
  }
  function receive(g, title) {
    const r = grantGift(app.store.get(), g);
    app.store.commit(r.state, { reason: 'gift' });
    const parts = [g.gold ? `${fmt(g.gold)} ทอง` : '', g.candy ? `${fmt(g.candy)} แคนดี้` : '', ...(g.items || []).map((x) => `${getItem(x.id)?.name || x.id}${x.qty > 1 ? ' ×' + x.qty : ''}`)].filter(Boolean);
    app.toast(`${title}: ${parts.join(' · ')}${g.note ? ` — “${g.note}”` : ''}${r.missed.length ? ' (กระเป๋าเต็ม ของบางชิ้นใส่ไม่ได้)' : ''}`, 'ok');
    app.rerender?.();
  }
  const offered = new Set();
  function offerGift(gid, g) {
    let claimed = false;
    try { claimed = !!localStorage.getItem('emberhold.gift.' + gid); } catch { /* ignore */ }
    if (claimed || offered.has(gid)) return;
    offered.add(gid);
    const card = h('div', { class: 'live-box-card gift', 'data-gift': gid },
      h('div', { class: 'live-box-text' }, h('small', {}, 'ของขวัญสำหรับทุกคน'), h('b', {}, g.note || 'แอดมินแจกของ'),
        h('span', {}, [g.gold ? `${fmt(g.gold)} ทอง` : '', g.candy ? `${fmt(g.candy)} แคนดี้` : '', ...(g.items || []).map((x) => getItem(x.id)?.name || '')].filter(Boolean).join(' · ')),
        h('button', { class: 'btn gold', type: 'button', 'data-action': 'claim-gift', onclick: async (e) => {
          e.currentTarget.disabled = true;
          const d = await app.cloud.live('gift_all', identity());
          if (d.gift || d.error === 'claimed') { try { localStorage.setItem('emberhold.gift.' + gid, '1'); } catch { /* ignore */ } }
          if (d.gift) receive(d.gift, 'รับของขวัญแล้ว'); else app.toast(cloudError(d.error), 'warn');
          card.remove();
        } }, glyph('star'), 'รับของขวัญ')));
    side.append(card);
  }
  function identity() {
    const id = app.online?.net?.ident;
    return id ? { uid: id.uid, ukey: id.ukey, name: app.store.get().story.name } : {};
  }

  // ---------------------------------------------------------------- gift boxes in the world
  // [{ batch, idx, x, y, at }] for boxes nobody opened yet, in this zone ('village' | 'halloween')
  function boxesIn(zone) {
    const out = [];
    for (const [batch, b] of Object.entries(news.boxes)) {
      if ((b.zone || 'village') !== zone) continue;
      (b.pts || []).forEach(([x, y], idx) => { if (!b.got?.includes(idx) && !opened.has(`${batch}:${idx}`)) out.push({ batch, idx, x, y, at: b.at, from: b.from }); });
    }
    return out;
  }
  let claiming = false;
  async function claimBox(box) {
    if (claiming) return;
    claiming = true;
    const d = await app.cloud.live('box_claim', { ...identity(), batch: box.batch, idx: box.idx });
    claiming = false;
    opened.add(`${box.batch}:${box.idx}`);
    if (!d.item) { app.toast(d.error === 'session' ? 'ต้องออนไลน์ (หรือเข้าสู่ระบบบัญชี) จึงจะเปิดกล่องได้' : cloudError(d.error), 'warn'); return; }
    const r = grantGift(app.store.get(), { items: [{ id: d.item, qty: 1 }] });
    app.store.commit(r.state, { reason: 'gm-box' });
    openGacha(app, d.item, box.from, r.missed.length > 0);
  }

  return {
    start() {
      if (started) return; started = true;
      poll(); pollMail();
      timer = setInterval(poll, POLL_MS);
      mailTimer = setInterval(pollMail, MAIL_MS);
    },
    poll, pollMail, announce, boxNotice,
    get news() { return news; },
    isGm: (peer) => news.gms.includes(peer),
    boxesIn, claimBox,
    on(f) { listeners.add(f); return () => listeners.delete(f); },
    stop() { clearInterval(timer); clearInterval(mailTimer); started = false; },
  };
}

// ---------------------------------------------------------------- the gift-box reel (กาชา)
// A strip of 40 legendary-and-up icons slides under a golden needle and slows down on the real reward (chosen by
// the server before the animation starts), then the box bursts in the reward's rarity colour.
export function openGacha(app, itemId, from = 'แอดมิน', bagFull = false) {
  const def = getItem(itemId), rar = getRarity(def?.rarity);
  const pool = Object.values(ITEMS).filter((d) => isEquipment(d) && ['legendary', 'mythic', 'limited'].includes(d.rarity) && !d.secret);
  const N = 40, STOP = 33;
  const reel = Array.from({ length: N }, (_, i) => (i === STOP ? def : pool[Math.floor(Math.random() * pool.length)]));
  const strip = h('div', { class: 'gacha-strip' }, ...reel.map((d) => h('div', { class: `gacha-cell r-${d.rarity}` }, itemImg(d.id))));
  const reveal = h('div', { class: 'gacha-reveal' });
  let close;
  const content = h('div', { class: 'modal panel gacha', 'data-modal': 'gacha', 'data-item': itemId },
    h('div', { class: 'eyebrow', style: { textAlign: 'center' } }, 'กล่องแจกจากแอดมินจ้า'),
    h('h2', {}, 'เปิดกล่อง!'),
    h('div', { class: 'gacha-window' }, h('div', { class: 'gacha-needle' }), strip),
    reveal,
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', 'data-action': 'gacha-done', onclick: () => close() }, 'เก็บเข้ากระเป๋า')));
  close = app.modal(content);
  const CELL = 92;
  requestAnimationFrame(() => {
    const win = content.querySelector('.gacha-window');
    const centre = (win?.clientWidth || 360) / 2 - CELL / 2;
    strip.style.transform = 'translateX(0px)';
    void strip.offsetWidth;
    strip.style.transition = 'transform 4.2s cubic-bezier(0.12, 0.8, 0.14, 1)';
    strip.style.transform = `translateX(${-(STOP * CELL - centre) + (Math.random() - 0.5) * 30}px)`;
    let ticks = 0;
    const tick = setInterval(() => { if (++ticks > 26) clearInterval(tick); app.audio?.play?.('click'); }, 150);
    setTimeout(() => {
      clearInterval(tick);
      strip.style.transition = 'transform 0.35s ease-out';
      strip.style.transform = `translateX(${-(STOP * CELL - centre)}px)`;
      content.classList.add('done');
      content.style.setProperty('--rc', rar?.color || '#f2b544');
      reveal.replaceChildren(...[h('div', { class: `gacha-prize r-${def.rarity}` }, itemImg(itemId), h('div', {}, h('small', { class: 'rc-text' }, rar?.name || ''), h('b', {}, def.name))),
        bagFull ? h('div', { class: 'notice warn' }, 'กระเป๋าเต็ม! ของชิ้นนี้ใส่ไม่ได้ ทำที่ว่างก่อนเปิดกล่องครั้งต่อไป') : null].filter(Boolean));
      app.audio?.play?.('legendary');
    }, 4300);
  });
  return close;
}
