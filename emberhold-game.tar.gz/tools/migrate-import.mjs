// Step 2: send the exported Netlify accounts to the Cloudflare Worker (POST /api/migrate). See UPDATE-migrate-th.md.
//   MIGRATE_KEY=<the secret you set on the Worker>  node tools/migrate-import.mjs netlify-cloud-export.json --dry     (preview, writes nothing)
//   MIGRATE_KEY=...                                  node tools/migrate-import.mjs netlify-cloud-export.json           (really import)
// Options: --url https://emberhold.omg2253r.workers.dev   (default)    Safe to run again: accounts already imported are left alone.
import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';

// post(body) → parsed JSON answer of /api/migrate
export async function importRecords(records, post, { dry = false, batch = 8, log = () => {} } = {}) {
  const counts = {}, taken = [], bad = [], saves = {};
  for (let i = 0; i < records.length; i += batch) {
    const d = await post({ dry, records: records.slice(i, i + batch) });
    if (!d || !d.ok) throw new Error('เซิร์ฟเวอร์ตอบผิดปกติ: ' + JSON.stringify(d).slice(0, 200));
    for (const r of d.results) {
      counts[r.status] = (counts[r.status] || 0) + 1;
      if (r.save) saves[r.save] = (saves[r.save] || 0) + 1;
      if (r.status === 'name_taken') taken.push(r.name);
      if (r.status === 'invalid') bad.push(r.name);
    }
    log(`  ${Math.min(i + batch, records.length)}/${records.length}`);
  }
  return { counts, saves, taken, bad };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const args = process.argv.slice(2);
  const file = args.find((a) => !a.startsWith('--') && a !== args[args.indexOf('--url') + 1]) || 'netlify-cloud-export.json';
  const dry = args.includes('--dry');
  const base = (args.includes('--url') ? args[args.indexOf('--url') + 1] : 'https://emberhold.omg2253r.workers.dev').replace(/\/+$/, '');
  const key = process.env.MIGRATE_KEY;
  if (!key) { console.error('ตั้ง MIGRATE_KEY ให้ตรงกับ secret บน Worker ก่อน'); process.exit(1); }
  const { records } = JSON.parse(await readFile(file, 'utf8'));
  console.log(`${dry ? '[ทดลอง ไม่เขียนข้อมูล] ' : ''}ส่ง ${records.length} บัญชีไป ${base}`);
  const post = async (body) => { const r = await fetch(base + '/api/migrate', { method: 'POST', headers: { 'content-type': 'application/json', 'x-migrate-key': key }, body: JSON.stringify(body) }); if (r.status === 404) throw new Error('Worker ยังไม่ได้ตั้ง MIGRATE_KEY (หรือยังไม่ได้ deploy เวอร์ชันใหม่)'); if (r.status === 401) throw new Error('MIGRATE_KEY ไม่ตรงกับบน Worker'); return r.json(); };
  const r = await importRecords(records, post, { dry, log: console.log });
  console.log('\nสรุปบัญชี:', r.counts, '\nสรุปเซฟ:  ', r.saves);
  if (r.taken.length) console.log(`\nชื่อที่ซ้ำกับบัญชีบน Cloudflare (ข้าม ไม่ได้ทับ) ${r.taken.length} ชื่อ:\n  ${r.taken.join(', ')}`);
  if (r.bad.length) console.log(`\nข้อมูลไม่ถูกต้อง (ข้าม) ${r.bad.length}: ${r.bad.join(', ')}`);
  if (dry) console.log('\nนี่คือการทดลอง ยังไม่ได้เขียนอะไร รันอีกครั้งโดยไม่ใส่ --dry เพื่อนำเข้าจริง');
}
