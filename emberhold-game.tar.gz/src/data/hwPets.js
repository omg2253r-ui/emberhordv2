// v10 Halloween companions (candy shop). Each has a body drawn for it alone (art/hwArt.js) and borrows an existing
// ability kind so the battle code (battle/pets.js) already knows how to run it.
import { PETS_V7 } from './pets2.js';
import { PETS_HW2 } from './hwPets2.js';   // v10.2: twenty more that drop in the Halloween lands
const kindOf = (kind) => Object.values(PETS_V7).find((p) => p.ability?.kind === kind);
const make = (id, name, rarity, role, desc, kind, abName, extra = {}) => {
  const b = kindOf(kind);
  if (!b) return null;
  return [id, { id, name, rarity, role, sprite: 'pet_' + id, desc, ability: { ...b.ability, name: abName }, text: b.text, event: 'hw', ...extra }];
};
export const PETS_HW = Object.freeze({ ...Object.fromEntries([
  make('hw_witch_cat', 'แมวดำของแม่มด', 'epic', 'สาปศัตรู', 'แมวดำสวมหมวกแม่มดใบเล็ก ขู่ฟ่อทีไรศัตรูโดนสาปจนช้าลง', 'nova', 'ขู่สาปฟ่อ'),
  make('hw_pumpkin_hopper', 'ฟักทองน้อยกระโดด', 'rare', 'กระแทก', 'ฟักทองยิ้มแป้นที่กระโดดทับศัตรูจนมึน', 'stomp', 'กระโดดทับ'),
  make('hw_lantern_ghost', 'ผีน้อยถือโคม', 'legendary', 'ดูดพลัง', 'ผีน้อยขี้อายที่ถือโคมฟักทอง ดูดพลังศัตรูมาเติมให้เจ้านาย', 'leech', 'โคมดูดวิญญาณ', { flying: true }),
].filter(Boolean)), ...PETS_HW2 });
