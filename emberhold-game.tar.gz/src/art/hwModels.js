// v10 Halloween models. Each event monster is drawn live on the canvas, part by part, so it can breathe, sway, flap,
// flicker and wind up without a sprite sheet. No model here is a recolour of an older monster.
// drawHwModel(ctx, e, t, o) → how tall the model stands (for the marks drawn above it)
//   e: the monster (or its network view) · t: time (s) · o: { alpha, flash, face (-1|1), z }
import { drawPumpkin } from './hwShots.js';

const TAU = Math.PI * 2;
const INK = '#1a100c';
const lit = (ctx, x0, y0, x1, y1, a, b) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); g.addColorStop(0, a); g.addColorStop(1, b); return g; };
function glow(ctx, x, y, r, col, a = 0.5) {
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createRadialGradient(x, y, 1, x, y, r); g.addColorStop(0, hexA(col, a)); g.addColorStop(1, hexA(col, 0));
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); ctx.restore();
}
export function hexA(hex, a) { const n = parseInt(String(hex).slice(1, 7), 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; }
function eyes(ctx, x, y, gap, r, col, t, blinkSeed = 0) {
  const open = (Math.sin(t * 0.7 + blinkSeed) > 0.97) ? 0.15 : 1;
  glow(ctx, x - gap, y, r * 3, col, 0.5); glow(ctx, x + gap, y, r * 3, col, 0.5);
  ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(x - gap, y, r, r * open, 0, 0, TAU); ctx.ellipse(x + gap, y, r, r * open, 0, 0, TAU); ctx.fill();
}
const stroke = (ctx, w = 3) => { ctx.lineWidth = w; ctx.strokeStyle = INK; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke(); };
function path(ctx, pts, close = true) { ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]); if (close) ctx.closePath(); }
// a robe that sways from the shoulders to the hem (tattered: zig-zag hem)
function robe(ctx, top, bottom, wTop, wBot, col, t, tattered = 0, sway = 1) {
  const s = Math.sin(t * 2.2) * 6 * sway;
  ctx.beginPath(); ctx.moveTo(-wTop, top);
  ctx.quadraticCurveTo(-wBot * 0.9 + s, (top + bottom) / 2, -wBot + s, bottom);
  const n = tattered ? 7 : 1;
  for (let i = 1; i <= n; i++) { const x = -wBot + s + (2 * wBot) * (i / n); ctx.lineTo(x - (2 * wBot) / n / 2, bottom + (tattered ? tattered * (0.6 + 0.4 * Math.sin(t * 5 + i)) : 0)); ctx.lineTo(x, bottom); }
  ctx.quadraticCurveTo(wBot * 0.9 + s, (top + bottom) / 2, wTop, top); ctx.closePath();
  ctx.fillStyle = col; ctx.fill(); stroke(ctx);
}
function witchHat(ctx, x, y, w, h, col, band, t, tilt = -0.15) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(tilt + Math.sin(t * 1.6) * 0.04);
  ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(0, 0, w, w * 0.22, 0, 0, TAU); ctx.fill(); stroke(ctx);
  ctx.beginPath(); ctx.moveTo(-w * 0.5, -2); ctx.quadraticCurveTo(-w * 0.2, -h * 0.6, w * 0.35 + Math.sin(t * 2) * 4, -h); ctx.quadraticCurveTo(w * 0.15, -h * 0.5, w * 0.5, -2); ctx.closePath(); ctx.fill(); stroke(ctx);
  ctx.fillStyle = band; ctx.fillRect(-w * 0.48, -w * 0.18 - 4, w * 0.96, 8); ctx.strokeRect(-w * 0.48, -w * 0.18 - 4, w * 0.96, 8);
  ctx.restore();
}
function staff(ctx, x0, y0, x1, y1, wood, orb, t) {
  ctx.strokeStyle = INK; ctx.lineWidth = 9; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
  ctx.strokeStyle = wood; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
  glow(ctx, x1, y1, 30 + Math.sin(t * 6) * 4, orb, 0.6);
  ctx.fillStyle = orb; ctx.beginPath(); ctx.arc(x1, y1, 9, 0, TAU); ctx.fill(); stroke(ctx, 2);
  ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(x1 - 3, y1 - 3, 2.5, 0, TAU); ctx.fill();
}

// ===================================================================== the models
const M = {};
M.mandrake = (ctx, e, t) => {
  const pop = e.hidden > 0.5 ? 0.25 : 1, scream = e.state === 'pop';
  ctx.save(); ctx.scale(1, pop);
  for (const [a, l] of [[-0.5, 34], [0, 40], [0.5, 34]]) { ctx.save(); ctx.translate(0, -58); ctx.rotate(a + Math.sin(t * 3 + a) * 0.1); ctx.fillStyle = '#4a8a2a'; ctx.beginPath(); ctx.ellipse(0, -l / 2, 8, l / 2, 0, 0, TAU); ctx.fill(); stroke(ctx, 2); ctx.restore(); }
  ctx.fillStyle = lit(ctx, -20, -60, 20, 0, '#e8c8a0', '#9a6a3a'); ctx.beginPath(); ctx.moveTo(0, -62); ctx.bezierCurveTo(26, -58, 26, -20, 12, -6); ctx.lineTo(16, 4); ctx.lineTo(4, -2); ctx.lineTo(0, 6); ctx.lineTo(-4, -2); ctx.lineTo(-16, 4); ctx.lineTo(-12, -6); ctx.bezierCurveTo(-26, -20, -26, -58, 0, -62); ctx.fill(); stroke(ctx);
  ctx.fillStyle = INK; ctx.beginPath(); ctx.ellipse(-7, -40, 3, 4, 0, 0, TAU); ctx.ellipse(7, -40, 3, 4, 0, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(0, -26, scream ? 7 : 4, scream ? 10 : 3, 0, 0, TAU); ctx.fill();
  if (scream) for (let i = 1; i <= 3; i++) { ctx.strokeStyle = `rgba(184,255,138,${0.6 - i * 0.15})`; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, -26, 14 + i * 12 + (t * 60) % 12, -0.8, 0.8); ctx.stroke(); ctx.beginPath(); ctx.arc(0, -26, 14 + i * 12 + (t * 60) % 12, Math.PI - 0.8, Math.PI + 0.8); ctx.stroke(); }
  ctx.restore();
  return 70 * pop;
};
M.vineSnake = (ctx, e, t, o) => {
  const n = 9, seg = 14, dir = Math.atan2(e.vy || 0, e.vx || 1);
  ctx.save(); if (o.face < 0) ctx.scale(-1, 1);
  for (let i = n; i >= 0; i--) {
    const x = -i * seg, y = -16 + Math.sin(t * 8 - i * 0.7) * 7;
    ctx.fillStyle = i % 2 ? '#3a6a2a' : '#4a8a3a'; ctx.beginPath(); ctx.arc(x, y, 12 - i * 0.6, 0, TAU); ctx.fill(); stroke(ctx, 2);
    if (i % 2 === 0 && i > 0) { ctx.fillStyle = '#c8e8a0'; path(ctx, [[x - 3, y - 10], [x, y - 18], [x + 3, y - 10]]); ctx.fill(); stroke(ctx, 1.4); }
  }
  ctx.fillStyle = '#5a9a3a'; ctx.beginPath(); ctx.ellipse(10, -18 + Math.sin(t * 8) * 7, 17, 12, 0, 0, TAU); ctx.fill(); stroke(ctx);
  ctx.fillStyle = '#e8ff5a'; ctx.beginPath(); ctx.arc(16, -24 + Math.sin(t * 8) * 7, 3, 0, TAU); ctx.fill();
  ctx.strokeStyle = '#c2412f'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(26, -16 + Math.sin(t * 8) * 7); ctx.lineTo(36, -14); ctx.moveTo(36, -14); ctx.lineTo(40, -18); ctx.moveTo(36, -14); ctx.lineTo(40, -10); ctx.stroke();
  ctx.restore(); void dir;
  return 46;
};
M.witchcap = (ctx, e, t) => {
  const b = Math.sin(t * 4) * 2;
  ctx.fillStyle = lit(ctx, -16, -40, 16, 0, '#efe4cc', '#a89880'); ctx.beginPath(); ctx.moveTo(-14, 0); ctx.lineTo(-11, -40); ctx.lineTo(11, -40); ctx.lineTo(14, 0); ctx.closePath(); ctx.fill(); stroke(ctx);
  ctx.fillStyle = INK; ctx.beginPath(); ctx.arc(-5, -22, 2.4, 0, TAU); ctx.arc(5, -22, 2.4, 0, TAU); ctx.fill();
  ctx.fillStyle = lit(ctx, -40, -80, 40, -40, '#b86aff', '#4a1a6a'); ctx.beginPath(); ctx.moveTo(-44, -38 + b); ctx.quadraticCurveTo(-30, -70 + b, 0, -96 + b); ctx.quadraticCurveTo(14, -78, 30, -84 + b); ctx.quadraticCurveTo(26, -60, 44, -38 + b); ctx.closePath(); ctx.fill(); stroke(ctx);
  ctx.fillStyle = '#ffffff'; for (const [x, y, r] of [[-22, -52, 5], [6, -66, 4], [24, -48, 4.5], [-6, -46, 3]]) { ctx.beginPath(); ctx.arc(x, y + b, r, 0, TAU); ctx.fill(); }
  for (let i = 0; i < 3; i++) glow(ctx, Math.sin(t * 2 + i * 2) * 30, -60 - ((t * 30 + i * 30) % 60), 6, '#e8ff9a', 0.6);
  return 100;
};
M.treant = (ctx, e, t, o) => {
  const sw = Math.sin(t * 1.4) * 0.04;
  ctx.save(); ctx.rotate(sw);
  for (const sx of [-1, 1]) { ctx.fillStyle = '#4a3020'; ctx.beginPath(); ctx.moveTo(sx * 30, -10); ctx.quadraticCurveTo(sx * 70, 0, sx * 84, 6); ctx.lineTo(sx * 60, 8); ctx.quadraticCurveTo(sx * 40, 0, sx * 14, 4); ctx.fill(); stroke(ctx, 2.4); }
  ctx.fillStyle = lit(ctx, -60, -220, 60, 0, '#7a5a3a', '#3a2418'); ctx.beginPath(); ctx.moveTo(-50, 0); ctx.bezierCurveTo(-60, -80, -40, -160, -30, -200); ctx.lineTo(30, -200); ctx.bezierCurveTo(40, -160, 60, -80, 50, 0); ctx.closePath(); ctx.fill(); stroke(ctx, 3.5);
  ctx.strokeStyle = '#2a1810'; ctx.lineWidth = 3; for (const x of [-30, -8, 14, 32]) { ctx.beginPath(); ctx.moveTo(x, -10); ctx.bezierCurveTo(x + 8, -60, x - 8, -120, x + 2, -190); ctx.stroke(); }
  // face carved in the bark
  ctx.fillStyle = '#100804'; ctx.beginPath(); ctx.ellipse(-18, -140, 10, 7, -0.3, 0, TAU); ctx.ellipse(18, -140, 10, 7, 0.3, 0, TAU); ctx.fill();
  eyes(ctx, 0, -140, 18, 4, '#b8ff5a', t, 2);
  ctx.fillStyle = '#100804'; ctx.beginPath(); ctx.moveTo(-22, -104); ctx.quadraticCurveTo(0, -84 - (e.warn || 0) * 14, 22, -104); ctx.quadraticCurveTo(0, -96, -22, -104); ctx.fill();
  // arms: two big branches that rise when it winds up
  const lift = (e.warn || 0) * 0.7;
  for (const sx of [-1, 1]) { ctx.save(); ctx.translate(sx * 40, -150); ctx.rotate(sx * (0.9 - lift) + Math.sin(t * 2 + sx) * 0.08); ctx.fillStyle = '#5a3a22'; ctx.beginPath(); ctx.moveTo(0, -10); ctx.lineTo(sx * 90, -30); ctx.lineTo(sx * 96, -12); ctx.lineTo(sx * 70, -6); ctx.lineTo(sx * 84, 10); ctx.lineTo(0, 12); ctx.closePath(); ctx.fill(); stroke(ctx, 2.6); ctx.restore(); }
  // crown of leaves
  for (let i = 0; i < 9; i++) { const a = -Math.PI / 2 + (i - 4) * 0.32, r = 70 + (i % 3) * 14; ctx.fillStyle = ['#3a6a2a', '#5a8a3a', '#2a4a1a'][i % 3]; ctx.beginPath(); ctx.arc(Math.cos(a) * r * 0.9, -200 + Math.sin(a) * r * 0.6, 34, 0, TAU); ctx.fill(); stroke(ctx, 2.4); }
  for (let i = 0; i < 4; i++) glow(ctx, Math.sin(t + i * 1.7) * 70, -250 + Math.cos(t * 1.3 + i) * 20, 8, '#e8ff9a', 0.5);
  ctx.restore();
  return 280;
};
M.pumpkinImp = (ctx, e, t, o) => {
  const sq = e.state === 'land' ? 0.85 : 1, bite = e.state === 'bite';
  ctx.save(); ctx.scale(1 / sq, sq);
  for (const sx of [-1, 1]) { ctx.strokeStyle = '#2a4a1a'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(sx * 10, -10); ctx.lineTo(sx * 16, 0); ctx.stroke(); }
  drawPumpkin(ctx, 0, -34, 30, t, Math.sin(t * 6) * 0.08, '#e8701a', bite ? '#ff3a1a' : '#ffcf5a');
  // little arms with claws
  for (const sx of [-1, 1]) { ctx.strokeStyle = '#2a4a1a'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(sx * 26, -34); ctx.quadraticCurveTo(sx * 40, -28 - (bite ? 10 : 0), sx * 38, -16); ctx.stroke(); }
  ctx.restore();
  return 74;
};
M.lanternGhost = (ctx, e, t) => {
  const f = Math.sin(t * 3) * 6;
  ctx.save(); ctx.translate(0, -60 + f);
  glow(ctx, 0, 0, 60, '#bfe8ff', 0.35);
  ctx.fillStyle = 'rgba(234,246,255,0.92)'; ctx.beginPath(); ctx.moveTo(-28, 20); ctx.bezierCurveTo(-36, -30, -20, -52, 0, -52); ctx.bezierCurveTo(20, -52, 36, -30, 28, 20);
  for (let i = 0; i < 5; i++) { const x = 28 - (i + 1) * 11.2; ctx.quadraticCurveTo(x + 5.6, 30 + Math.sin(t * 6 + i) * 6, x, 20); }
  ctx.closePath(); ctx.fill(); stroke(ctx, 2.6);
  ctx.fillStyle = '#1a2a3a'; ctx.beginPath(); ctx.ellipse(-10, -22, 5, 8, 0, 0, TAU); ctx.ellipse(10, -22, 5, 8, 0, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(0, -4, 5, 7, 0, 0, TAU); ctx.fill();
  // the lantern in its hand
  ctx.strokeStyle = INK; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(26, 0); ctx.lineTo(40, 10); ctx.stroke();
  const fl = 0.7 + 0.3 * Math.sin(t * 14);
  glow(ctx, 42, 24, 30 * fl, '#ffcf5a', 0.6);
  ctx.fillStyle = '#ff8a1f'; ctx.fillRect(34, 12, 16, 22); ctx.strokeRect(34, 12, 16, 22);
  ctx.fillStyle = `rgba(255,243,196,${fl})`; ctx.fillRect(37, 16, 10, 14);
  ctx.restore();
  return 120;
};
M.batSwarm = (ctx, e, t) => {
  for (let i = 0; i < 7; i++) {
    const a = t * 3 + i * 0.9, r = 18 + (i % 3) * 10, x = Math.cos(a) * r * 1.4, y = -50 + Math.sin(a * 1.3) * r;
    const flap = Math.sin(t * 30 + i * 2);
    ctx.save(); ctx.translate(x, y);
    ctx.fillStyle = '#2a1424';
    for (const sg of [-1, 1]) { ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(sg * 10, -10 * flap - 4, sg * 18, -2 * flap); ctx.lineTo(sg * 12, 4); ctx.lineTo(sg * 6, 2); ctx.closePath(); ctx.fill(); stroke(ctx, 1.4); }
    ctx.beginPath(); ctx.ellipse(0, 0, 4, 6, 0, 0, TAU); ctx.fill(); stroke(ctx, 1.4);
    ctx.fillStyle = '#ff5a7a'; ctx.beginPath(); ctx.arc(-1.5, -2, 1.2, 0, TAU); ctx.arc(1.5, -2, 1.2, 0, TAU); ctx.fill();
    ctx.restore();
  }
  return 90;
};
M.candySkeleton = (ctx, e, t, o) => {
  if (e.state === 'ash') { ctx.fillStyle = '#efe4cc'; for (let i = 0; i < 7; i++) { ctx.save(); ctx.translate((i - 3) * 9, -6 - Math.max(0, (e.t || 0) - 0.4) * 40 * (i % 2)); ctx.rotate(i); ctx.fillRect(-8, -2, 16, 4); ctx.restore(); } return 30; }
  const w = Math.sin(t * 6) * 0.3;
  ctx.strokeStyle = INK; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(-6, -40); ctx.lineTo(-10 + w * 10, 0); ctx.moveTo(6, -40); ctx.lineTo(10 - w * 10, 0); ctx.stroke();
  ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 3.5; ctx.stroke();
  // ribs as candy stripes
  ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.ellipse(0, -60, 18, 22, 0, 0, TAU); ctx.fill(); stroke(ctx, 2.6);
  ctx.strokeStyle = '#e0303a'; ctx.lineWidth = 3; for (const y of [-72, -62, -52]) { ctx.beginPath(); ctx.moveTo(-14, y); ctx.quadraticCurveTo(0, y + 6, 14, y); ctx.stroke(); }
  ctx.save(); ctx.translate(18, -70); ctx.rotate(e.state === 'throw' ? -1.4 + (e.t || 0) * 4 : 0.5 + w * 0.3);
  ctx.strokeStyle = INK; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, 26); ctx.stroke(); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 3.5; ctx.stroke(); ctx.restore();
  ctx.fillStyle = '#fff0f6'; ctx.beginPath(); ctx.arc(0, -98, 17, 0, TAU); ctx.fill(); stroke(ctx, 2.6);
  ctx.fillStyle = INK; ctx.beginPath(); ctx.ellipse(-6, -100, 4.5, 5.5, 0, 0, TAU); ctx.ellipse(6, -100, 4.5, 5.5, 0, 0, TAU); ctx.fill();
  eyes(ctx, 0, -100, 6, 1.8, '#ff7ab8', t, 1);
  ctx.fillStyle = '#e0303a'; ctx.fillRect(-8, -88, 16, 4);
  return 120;
};
M.jack = (ctx, e, t, o) => {
  const wind = e.warn || 0, laugh = e.state === 'laugh' || e.state === 'illusion';
  ctx.save();
  // long coat of vines and rags
  robe(ctx, -150, 0, 34, 66, lit(ctx, -60, -150, 60, 0, '#3a2a4a', '#140c18'), t, 18);
  ctx.strokeStyle = '#3a6a2a'; ctx.lineWidth = 4; for (const x of [-30, 0, 30]) { ctx.beginPath(); ctx.moveTo(x, -150); ctx.bezierCurveTo(x + 20, -110, x - 20, -60, x + 10, -10); ctx.stroke(); }
  for (let i = 0; i < 6; i++) { ctx.fillStyle = '#5a9a3a'; ctx.beginPath(); ctx.ellipse(-30 + i * 12, -130 + (i % 3) * 36, 6, 3, i, 0, TAU); ctx.fill(); }
  // the scythe of death
  ctx.save(); ctx.translate(46, -110); ctx.rotate(-0.4 - wind * 1.2 + Math.sin(t * 1.5) * 0.05);
  ctx.strokeStyle = INK; ctx.lineWidth = 9; ctx.beginPath(); ctx.moveTo(0, 90); ctx.lineTo(0, -120); ctx.stroke(); ctx.strokeStyle = '#4a3020'; ctx.lineWidth = 5; ctx.stroke();
  ctx.fillStyle = lit(ctx, -100, -150, 0, -100, '#d8e0f0', '#3a3a4a'); ctx.beginPath(); ctx.moveTo(0, -118); ctx.bezierCurveTo(-60, -160, -120, -130, -140, -80); ctx.bezierCurveTo(-100, -110, -50, -112, 0, -96); ctx.closePath(); ctx.fill(); stroke(ctx, 3);
  glow(ctx, -70, -118, 50, '#ff8a1f', 0.25 + wind * 0.4);
  ctx.restore();
  // arms
  ctx.strokeStyle = INK; ctx.lineWidth = 10; ctx.beginPath(); ctx.moveTo(24, -140); ctx.lineTo(46, -116); ctx.moveTo(-24, -140); ctx.lineTo(-40, -100); ctx.stroke();
  ctx.strokeStyle = '#2a1a2a'; ctx.lineWidth = 6; ctx.stroke();
  // the pumpkin head (bigger than any other pumpkin here), with a candle that flares when it laughs
  drawPumpkin(ctx, 0, -186, 46, t * (laugh ? 3 : 1), Math.sin(t * 2) * 0.06 + (laugh ? Math.sin(t * 20) * 0.08 : 0), '#e06a1a', laugh ? '#ff3a1a' : '#ffcf5a');
  glow(ctx, 0, -186, 80, '#ff8a1f', 0.25 + (laugh ? 0.3 : 0));
  // a crooked top hat
  ctx.save(); ctx.translate(-4, -228); ctx.rotate(-0.2); ctx.fillStyle = '#1a1424'; ctx.fillRect(-30, -4, 60, 8); ctx.strokeRect(-30, -4, 60, 8); ctx.fillRect(-18, -46, 36, 44); ctx.strokeRect(-18, -46, 36, 44); ctx.fillStyle = '#c2412f'; ctx.fillRect(-18, -14, 36, 8); ctx.restore();
  ctx.restore();
  return 290;
};
M.reaper = (ctx, e, t, o) => {
  const rage = e.ai?.rage || 0, wind = e.warn || 0, z = Math.sin(t * 2) * 8;
  ctx.save(); ctx.translate(0, -20 + z);
  // no legs: a shroud that dissolves into smoke
  for (let i = 0; i < 6; i++) glow(ctx, Math.sin(t * 2 + i) * 30, -10 + i * 4, 30, '#14141c', 0.3);
  robe(ctx, -170, -10, 30, 70, lit(ctx, -70, -170, 70, 0, '#2a2a34', '#05050a'), t, 30, 1.6);
  // the hood with nothing inside but two lights
  ctx.fillStyle = '#14141c'; ctx.beginPath(); ctx.moveTo(-42, -150); ctx.bezierCurveTo(-46, -210, -20, -238, 6, -236); ctx.bezierCurveTo(30, -230, 46, -200, 42, -150); ctx.quadraticCurveTo(0, -140, -42, -150); ctx.fill(); stroke(ctx, 3);
  ctx.fillStyle = '#000000'; ctx.beginPath(); ctx.ellipse(2, -186, 24, 30, 0, 0, TAU); ctx.fill();
  const ec = rage > 1.3 ? '#ff3a3a' : rage > 0.6 ? '#ffcf5a' : '#b8f0ff';
  eyes(ctx, 2, -190, 9, 4 + rage, ec, t, 5);
  // bony hands
  for (const sx of [-1, 1]) { ctx.fillStyle = '#efe4cc'; ctx.beginPath(); ctx.arc(sx * 40, -110 - (sx > 0 ? wind * 20 : 0), 7, 0, TAU); ctx.fill(); stroke(ctx, 2); }
  // the black god-scythe (lights run along its edge as it grows)
  ctx.save(); ctx.translate(40, -110 - wind * 20); ctx.rotate(-0.25 - wind * 1.5);
  ctx.strokeStyle = INK; ctx.lineWidth = 10; ctx.beginPath(); ctx.moveTo(0, 100); ctx.lineTo(0, -140); ctx.stroke(); ctx.strokeStyle = '#14141c'; ctx.lineWidth = 6; ctx.stroke();
  ctx.fillStyle = '#05050a'; ctx.beginPath(); ctx.moveTo(0, -138); ctx.bezierCurveTo(-80, -190, -160, -150, -180, -80); ctx.bezierCurveTo(-130, -126, -60, -128, 0, -112); ctx.closePath(); ctx.fill(); stroke(ctx, 3);
  ctx.strokeStyle = ec; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(-6, -132); ctx.bezierCurveTo(-80, -176, -150, -142, -172, -84); ctx.stroke();
  glow(ctx, -90, -150, 60 + rage * 20, ec, 0.2 + rage * 0.15);
  ctx.restore();
  // the soul chain it carries: small lights orbit it, more with rage
  for (let i = 0; i < 3 + Math.floor(rage * 3); i++) { const a = t * 1.6 + i * 1.3; glow(ctx, Math.cos(a) * 90, -120 + Math.sin(a) * 60, 12, '#9fffd8', 0.7); }
  ctx.restore();
  return 260;
};
M.soulWisp = (ctx, e, t) => {
  const y = -40 + Math.sin(t * 5 + e.id) * 6;
  glow(ctx, 0, y, 34, '#9fffd8', 0.6);
  ctx.fillStyle = 'rgba(234,255,248,0.9)'; ctx.beginPath(); ctx.moveTo(0, y - 18); ctx.bezierCurveTo(16, y - 14, 14, y + 8, 0, y + 14); ctx.quadraticCurveTo(-6, y + 24, -10, y + 30); ctx.quadraticCurveTo(-14, y + 10, -12, y); ctx.bezierCurveTo(-14, y - 12, -8, y - 18, 0, y - 18); ctx.fill();
  ctx.fillStyle = '#1a3a3a'; ctx.beginPath(); ctx.arc(-4, y - 4, 2.2, 0, TAU); ctx.arc(4, y - 4, 2.2, 0, TAU); ctx.fill();
  return 70;
};
// a witch: robe, hat, staff — but each witch has her own silhouette, colours and props
function witch(ctx, e, t, c) {
  const z = c.float ? -18 + Math.sin(t * 2.4) * 8 : 0;
  ctx.save(); ctx.translate(0, z);
  if (c.broom) { ctx.save(); ctx.rotate(-0.08); ctx.strokeStyle = INK; ctx.lineWidth = 8; ctx.beginPath(); ctx.moveTo(-80, -30); ctx.lineTo(70, -46); ctx.stroke(); ctx.strokeStyle = '#6a4a2a'; ctx.lineWidth = 4; ctx.stroke(); ctx.fillStyle = '#c8a050'; ctx.beginPath(); ctx.moveTo(-80, -30); ctx.lineTo(-120, -50); ctx.lineTo(-124, -14); ctx.closePath(); ctx.fill(); stroke(ctx, 2); ctx.restore(); }
  robe(ctx, -120, 0, 24, c.skirt || 56, lit(ctx, -50, -120, 50, 0, c.robe, c.robeDark), t, c.tatter || 0);
  if (c.apron) { ctx.fillStyle = c.apron; ctx.beginPath(); ctx.moveTo(-16, -80); ctx.lineTo(16, -80); ctx.lineTo(24, -16); ctx.lineTo(-24, -16); ctx.closePath(); ctx.fill(); stroke(ctx, 2); ctx.fillStyle = '#e0303a'; for (const [x, y] of [[-8, -60], [8, -46], [-6, -32]]) { ctx.beginPath(); ctx.arc(x, y, 4, 0, TAU); ctx.fill(); } }
  // face
  ctx.fillStyle = c.skin; ctx.beginPath(); ctx.ellipse(0, -140, 20, 24, 0, 0, TAU); ctx.fill(); stroke(ctx, 2.6);
  ctx.fillStyle = c.hair; ctx.beginPath(); ctx.moveTo(-22, -150); ctx.quadraticCurveTo(-34, -110, -26, -86); ctx.lineTo(-16, -118); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.moveTo(22, -150); ctx.quadraticCurveTo(36, -112, 28, -88); ctx.lineTo(16, -118); ctx.closePath(); ctx.fill();
  eyes(ctx, 0, -142, 8, 3, c.eye, t, 3);
  ctx.strokeStyle = INK; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, -130, 7, 0.2, Math.PI - 0.2); ctx.stroke();
  if (c.grin) { ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.moveTo(-6, -129); ctx.lineTo(-3, -125); ctx.lineTo(0, -129); ctx.fill(); }
  witchHat(ctx, 0, -158, 40, c.hatH || 80, c.hat, c.band, t, c.tilt ?? -0.15);
  // staff / prop
  const wind = e.warn || 0;
  if (c.staff) staff(ctx, 26, -10, 40 + wind * 10, -150 - wind * 20, c.wood, c.orb, t);
  if (c.lollipop) { ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(30, -60); ctx.lineTo(44, -130); ctx.stroke(); ctx.save(); ctx.translate(46, -146); ctx.rotate(t * 2); ctx.fillStyle = '#ff7ab8'; ctx.beginPath(); ctx.arc(0, 0, 20, 0, TAU); ctx.fill(); stroke(ctx, 2.4); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 3; ctx.beginPath(); for (let a = 0; a < 12; a += 0.3) ctx.lineTo(Math.cos(a) * a * 1.5, Math.sin(a) * a * 1.5); ctx.stroke(); ctx.restore(); }
  if (c.potions) for (let i = 0; i < 3; i++) { const a = t * 2 + i * 2.1; const px = Math.cos(a) * 54, py = -100 + Math.sin(a) * 26; ctx.fillStyle = c.potions[i]; ctx.beginPath(); ctx.arc(px, py, 7, 0, TAU); ctx.fill(); stroke(ctx, 1.6); ctx.fillStyle = '#a87848'; ctx.fillRect(px - 2, py - 11, 4, 5); }
  if (c.cards) for (let i = 0; i < 4; i++) { const a = t * 1.2 + i * (TAU / 4); ctx.save(); ctx.translate(Math.cos(a) * 60, -110 + Math.sin(a) * 30); ctx.rotate(a); ctx.fillStyle = '#f5efe6'; ctx.fillRect(-7, -10, 14, 20); ctx.strokeRect(-7, -10, 14, 20); ctx.fillStyle = '#7a3aff'; ctx.font = '700 12px serif'; ctx.textAlign = 'center'; ctx.fillText('?', 0, 5); ctx.restore(); }
  if (c.flames) for (let i = 0; i < 8; i++) { const a = t * 3 + i; glow(ctx, Math.cos(a) * 46, -60 - ((t * 70 + i * 20) % 120), 14, '#ff6a1a', 0.6); }
  ctx.restore();
  return 220 - z;
}
M.witchLure = (ctx, e, t) => witch(ctx, e, t, { robe: '#e86a9a', robeDark: '#7a2a4a', skin: '#fde8d8', hair: '#ff9ac8', eye: '#ff5a9a', hat: '#5a2a6a', band: '#ffd8e8', apron: '#fff0f6', grin: true, lollipop: true, potions: ['#9a5aff', '#8ad04a', '#5ae0ff'], skirt: 62, tilt: 0.2 });
M.witchDeceiver = (ctx, e, t) => {
  if (e.state === 'stunned' || e.hwStunned) { ctx.save(); ctx.rotate(Math.sin(t * 3) * 0.06); const h = witch(ctx, e, t, { robe: '#2a1a4a', robeDark: '#0a0614', skin: '#d8d0e8', hair: '#1a1424', eye: '#7a6a8a', hat: '#14101c', band: '#7a3aff', skirt: 58, float: false, tatter: 10 }); for (let i = 0; i < 4; i++) { const a = t * 4 + i * 1.57; ctx.fillStyle = '#ffd84a'; ctx.font = '900 18px system-ui'; ctx.fillText('✦', Math.cos(a) * 30 - 6, -230 + Math.sin(a) * 8); } ctx.restore(); return h; }
  return witch(ctx, e, t, { robe: '#3a1a6a', robeDark: '#120820', skin: '#e8e0f0', hair: '#14101c', eye: '#c86aff', hat: '#1a1028', band: '#c86aff', staff: true, wood: '#2a1a14', orb: '#c86aff', cards: true, skirt: 58, float: true, tatter: 12, hatH: 96 });
};
M.witchWrath = (ctx, e, t) => witch(ctx, e, t, { robe: '#6a0a0a', robeDark: '#1a0202', skin: '#e8c0b0', hair: '#ff3a1a', eye: '#ffcf5a', hat: '#2a0404', band: '#ff6a1a', staff: true, wood: '#1a0a06', orb: '#ff6a1a', flames: true, skirt: 64, float: true, tatter: 22, hatH: 104, tilt: -0.3 });
M.gumdrop = (ctx, e, t) => {
  const s = 1 + Math.sin(t * 12 + e.id) * 0.08;
  ctx.save(); ctx.scale(1 / s, s);
  const col = ['#ff5a7a', '#5ae0ff', '#8ad04a', '#ffd84a'][e.id % 4];
  ctx.fillStyle = lit(ctx, -20, -40, 20, 0, '#ffffff', col); ctx.beginPath(); ctx.moveTo(-22, 0); ctx.bezierCurveTo(-24, -30, -10, -40, 0, -40); ctx.bezierCurveTo(10, -40, 24, -30, 22, 0); ctx.closePath(); ctx.fill(); stroke(ctx, 2.4);
  ctx.fillStyle = '#ffffff'; for (const [x, y] of [[-10, -26], [6, -32], [12, -14], [-4, -12]]) { ctx.fillRect(x, y, 3, 3); }
  ctx.fillStyle = INK; ctx.beginPath(); ctx.arc(-6, -20, 2.4, 0, TAU); ctx.arc(6, -20, 2.4, 0, TAU); ctx.fill();
  ctx.restore();
  return 44;
};
// the lost wizard (an old man in starry robes), and what he becomes: the God of Creation (gold, four arms of light)
M.wizard = (ctx, e, t) => {
  ctx.save(); ctx.translate(0, -10 + Math.sin(t * 2) * 4);
  robe(ctx, -130, 0, 26, 52, lit(ctx, -50, -130, 50, 0, '#2a3a7a', '#0e1430'), t, 0, 0.6);
  ctx.fillStyle = '#fff3a0'; for (let i = 0; i < 9; i++) { const x = Math.sin(i * 7.3) * 34, y = -110 + (i * 13) % 100; ctx.font = '700 10px serif'; ctx.fillText('✦', x - 4, y); }
  ctx.fillStyle = '#efe0d0'; ctx.beginPath(); ctx.ellipse(0, -150, 18, 21, 0, 0, TAU); ctx.fill(); stroke(ctx, 2.4);
  // a long white beard
  ctx.fillStyle = '#f4f4f4'; ctx.beginPath(); ctx.moveTo(-16, -146); ctx.quadraticCurveTo(-22, -100, 0, -70 + Math.sin(t * 2) * 3); ctx.quadraticCurveTo(22, -100, 16, -146); ctx.quadraticCurveTo(0, -136, -16, -146); ctx.fill(); stroke(ctx, 2);
  ctx.fillStyle = INK; ctx.beginPath(); ctx.arc(-6, -152, 2, 0, TAU); ctx.arc(6, -152, 2, 0, TAU); ctx.fill();
  witchHat(ctx, 0, -166, 36, 70, '#1a2a6a', '#fff3a0', t, -0.25);
  staff(ctx, -30, 0, -40, -170, '#6a4a2a', '#9fe8ff', t);
  ctx.restore();
  return 250;
};
M.wizardGod = (ctx, e, t) => {
  ctx.save(); ctx.translate(0, -30 + Math.sin(t * 2) * 6);
  glow(ctx, 0, -120, 160, '#fff3a0', 0.3);
  for (let i = 0; i < 4; i++) { ctx.save(); ctx.translate(0, -120); ctx.rotate(-0.8 + i * 0.53 + Math.sin(t * 2 + i) * 0.08); ctx.strokeStyle = 'rgba(255,243,160,0.7)'; ctx.lineWidth = 8; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -90); ctx.stroke(); glow(ctx, 0, -96, 16, '#ffffff', 0.8); ctx.restore(); }
  robe(ctx, -130, 0, 26, 58, lit(ctx, -50, -130, 50, 0, '#fff3c4', '#e0b45a'), t, 0, 0.6);
  ctx.fillStyle = '#fff8e8'; ctx.beginPath(); ctx.ellipse(0, -150, 18, 21, 0, 0, TAU); ctx.fill(); stroke(ctx, 2.4);
  ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.moveTo(-16, -146); ctx.quadraticCurveTo(-22, -100, 0, -70); ctx.quadraticCurveTo(22, -100, 16, -146); ctx.quadraticCurveTo(0, -136, -16, -146); ctx.fill(); stroke(ctx, 2);
  eyes(ctx, 0, -152, 6, 2.4, '#ffffff', t);
  ctx.strokeStyle = '#ffe89a'; ctx.lineWidth = 4; ctx.beginPath(); ctx.ellipse(0, -186, 30, 8, 0, 0, TAU); ctx.stroke();
  ctx.restore();
  return 260;
};
// 1. darkness: a knight made of shadow with a cracked mirror for a face
M.gDark = (ctx, e, t, o) => {
  ctx.save();
  for (let i = 0; i < 5; i++) glow(ctx, Math.sin(t * 1.5 + i) * 40, -30 - i * 40, 40, '#7a3aff', 0.18);
  robe(ctx, -150, 0, 34, 60, lit(ctx, -60, -150, 60, 0, '#2a1a4a', '#05030a'), t, 22, 1.4);
  ctx.fillStyle = '#1a1028'; path(ctx, [[-40, -150], [-58, -170], [-30, -168]]); ctx.fill(); stroke(ctx, 2); path(ctx, [[40, -150], [58, -170], [30, -168]]); ctx.fill(); stroke(ctx, 2);
  // mirror face
  ctx.fillStyle = lit(ctx, -24, -210, 24, -150, '#d8d0ff', '#4a3a7a'); ctx.beginPath(); ctx.ellipse(0, -182, 26, 32, 0, 0, TAU); ctx.fill(); stroke(ctx, 3);
  ctx.strokeStyle = INK; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(-10, -210); ctx.lineTo(2, -184); ctx.lineTo(-16, -166); ctx.moveTo(2, -184); ctx.lineTo(18, -176); ctx.stroke();
  eyes(ctx, 0, -186, 10, 3.4, '#ff3aff', t, 4);
  // a blade of night in each hand
  for (const sx of [-1, 1]) { ctx.save(); ctx.translate(sx * 44, -96); ctx.rotate(sx * (0.5 + (e.warn || 0) * 0.6)); ctx.fillStyle = '#14101c'; path(ctx, [[-4, 0], [4, 0], [0, -90]]); ctx.fill(); stroke(ctx, 2); ctx.strokeStyle = '#b88aff'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(0, -4); ctx.lineTo(0, -84); ctx.stroke(); ctx.restore(); }
  ctx.restore();
  return 220;
};
M.pillar = (ctx, e, t) => {
  const crack = 1 - e.hp / Math.max(1, e.maxHp);
  glow(ctx, 0, -110, 120, '#7a3aff', 0.35 + 0.15 * Math.sin(t * 4));
  ctx.fillStyle = lit(ctx, -30, -220, 30, 0, '#4a3a6a', '#14101c'); ctx.fillRect(-28, -220, 56, 220); ctx.strokeRect(-28, -220, 56, 220);
  ctx.fillStyle = '#2a1a3a'; ctx.fillRect(-38, -230, 76, 16); ctx.strokeRect(-38, -230, 76, 16); ctx.fillRect(-38, -14, 76, 14); ctx.strokeRect(-38, -14, 76, 14);
  ctx.strokeStyle = '#c88aff'; ctx.lineWidth = 2; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.arc(0, -180 + i * 44, 10, t * 2 + i, t * 2 + i + 4); ctx.stroke(); }
  if (crack > 0.2) { ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-10, -200); ctx.lineTo(6, -150); ctx.lineTo(-8, -100); if (crack > 0.6) { ctx.lineTo(10, -50); ctx.moveTo(6, -150); ctx.lineTo(22, -130); } ctx.stroke(); }
  for (let i = 0; i < 3; i++) glow(ctx, 0, -230 - ((t * 80 + i * 40) % 120), 10, '#c88aff', 0.7);
  return 240;
};
M.shadowFake = (ctx, e, t) => {
  ctx.save(); ctx.globalAlpha *= 0.75;
  robe(ctx, -90, 0, 18, 36, 'rgba(20,12,30,0.9)', t, 14, 1.2);
  ctx.fillStyle = '#05030a'; ctx.beginPath(); ctx.arc(0, -108, 18, 0, TAU); ctx.fill();
  eyes(ctx, 0, -110, 7, 2.6, '#c88aff', t, 6);
  ctx.restore();
  return 130;
};
// 2. wisdom: a sage with an open book, crowned with a floating board
M.gWisdom = (ctx, e, t) => {
  ctx.save(); ctx.translate(0, -16 + Math.sin(t * 2) * 5);
  robe(ctx, -140, 0, 28, 58, lit(ctx, -50, -140, 50, 0, '#e8ecf4', '#6a7a9a'), t, 0, 0.5);
  ctx.strokeStyle = '#1a2438'; ctx.lineWidth = 3; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.moveTo(-40 + i * 8, -20 - i * 30); ctx.lineTo(40 - i * 8, -20 - i * 30); ctx.stroke(); }
  ctx.fillStyle = '#d8e0ec'; ctx.beginPath(); ctx.ellipse(0, -160, 20, 23, 0, 0, TAU); ctx.fill(); stroke(ctx, 2.4);
  ctx.fillStyle = '#1a2438'; ctx.fillRect(-16, -166, 32, 8);
  eyes(ctx, 0, -162, 7, 2.2, '#5fb0ff', t);
  // the open book in one hand, pages turning
  ctx.save(); ctx.translate(-40, -96); ctx.fillStyle = '#5a3a2a'; ctx.fillRect(-26, -4, 52, 30); ctx.strokeRect(-26, -4, 52, 30); ctx.fillStyle = '#fff8e8'; ctx.fillRect(-23, -2, 22, 26); ctx.fillRect(1, -2, 22, 26);
  const pg = (t * 1.5) % 1; ctx.save(); ctx.scale(Math.cos(pg * Math.PI), 1); ctx.fillStyle = '#f4ecd8'; ctx.fillRect(0, -2, 22, 26); ctx.restore(); ctx.restore();
  // a small board circling above its head
  ctx.save(); ctx.translate(0, -210); ctx.rotate(t * 0.6); ctx.scale(1, 0.5);
  for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) { ctx.fillStyle = (r + c) % 2 ? '#1a2438' : '#e8ecf4'; ctx.fillRect(-32 + c * 16, -32 + r * 16, 16, 16); }
  ctx.strokeRect(-32, -32, 64, 64); ctx.restore();
  ctx.restore();
  return 240;
};
// chess pieces: one model, six silhouettes. White marble with blue veins, they bob while they think.
M.chess = (ctx, e, t) => {
  const k = e.type.chess || 'pawn', bob = e.state === 'wait' ? Math.sin(t * 3 + e.id) * 2 : 0;
  ctx.save(); ctx.translate(0, bob);
  const fill = lit(ctx, -24, -110, 24, 0, '#ffffff', '#8aa8c8');
  ctx.fillStyle = fill;
  // base for all
  ctx.beginPath(); ctx.ellipse(0, -6, 26, 9, 0, 0, TAU); ctx.fill(); stroke(ctx, 2.4);
  ctx.fillRect(-20, -18, 40, 12); ctx.strokeRect(-20, -18, 40, 12);
  let top = 60;
  ctx.beginPath();
  if (k === 'pawn') { ctx.moveTo(-12, -18); ctx.quadraticCurveTo(-6, -36, -8, -44); ctx.lineTo(8, -44); ctx.quadraticCurveTo(6, -36, 12, -18); ctx.fill(); stroke(ctx, 2.4); ctx.beginPath(); ctx.arc(0, -54, 13, 0, TAU); ctx.fill(); stroke(ctx, 2.4); top = 70; }
  else if (k === 'rook') { ctx.moveTo(-16, -18); ctx.lineTo(-14, -70); ctx.lineTo(14, -70); ctx.lineTo(16, -18); ctx.fill(); stroke(ctx, 2.4); ctx.beginPath(); path(ctx, [[-20, -70], [-20, -90], [-12, -90], [-12, -82], [-4, -82], [-4, -90], [4, -90], [4, -82], [12, -82], [12, -90], [20, -90], [20, -70]]); ctx.fill(); stroke(ctx, 2.4); top = 96; }
  else if (k === 'bishop') { ctx.moveTo(-14, -18); ctx.quadraticCurveTo(-6, -50, -6, -60); ctx.lineTo(6, -60); ctx.quadraticCurveTo(6, -50, 14, -18); ctx.fill(); stroke(ctx, 2.4); ctx.beginPath(); ctx.ellipse(0, -80, 14, 22, 0, 0, TAU); ctx.fill(); stroke(ctx, 2.4); ctx.beginPath(); ctx.moveTo(-6, -90); ctx.lineTo(6, -74); stroke(ctx, 2.4); ctx.beginPath(); ctx.arc(0, -106, 5, 0, TAU); ctx.fill(); stroke(ctx, 2); top = 116; }
  else if (k === 'knight') { ctx.moveTo(-16, -18); ctx.lineTo(-14, -50); ctx.bezierCurveTo(-24, -70, -10, -100, 10, -98); ctx.lineTo(22, -78); ctx.lineTo(14, -72); ctx.lineTo(6, -76); ctx.lineTo(14, -18); ctx.closePath(); ctx.fill(); stroke(ctx, 2.4); ctx.fillStyle = '#1a2438'; ctx.beginPath(); ctx.arc(4, -86, 2.6, 0, TAU); ctx.fill(); ctx.strokeStyle = '#5fb0ff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-12, -60); ctx.bezierCurveTo(-18, -78, -6, -94, 6, -96); ctx.stroke(); top = 104; }
  else if (k === 'queen') { ctx.moveTo(-16, -18); ctx.quadraticCurveTo(-6, -60, -10, -84); ctx.lineTo(10, -84); ctx.quadraticCurveTo(6, -60, 16, -18); ctx.fill(); stroke(ctx, 2.4); ctx.beginPath(); for (let i = 0; i < 5; i++) { const x = -16 + i * 8; ctx.moveTo(x, -84); ctx.lineTo(x + 4, -104); ctx.lineTo(x + 8, -84); } ctx.fill(); stroke(ctx, 2.4); for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.arc(-12 + i * 8, -106, 3, 0, TAU); ctx.fill(); stroke(ctx, 1.4); } top = 116; }
  else { ctx.moveTo(-16, -18); ctx.quadraticCurveTo(-6, -60, -12, -88); ctx.lineTo(12, -88); ctx.quadraticCurveTo(6, -60, 16, -18); ctx.fill(); stroke(ctx, 2.4); ctx.fillRect(-4, -116, 8, 28); ctx.strokeRect(-4, -116, 8, 28); ctx.fillRect(-12, -108, 24, 8); ctx.strokeRect(-12, -108, 24, 8); top = 122; }
  ctx.strokeStyle = 'rgba(95,176,255,0.6)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(-8, -20); ctx.bezierCurveTo(4, -36, -6, -48, 4, -top + 20); ctx.stroke();
  if (e.warn > 0) glow(ctx, 0, -top / 2, 60, '#5fb0ff', 0.4 * e.warn);
  ctx.restore();
  return top + 10;
};
// 3. light: a giant of white-gold armour, a sun for a head, two hammers on chains
M.gLight = (ctx, e, t) => {
  const wind = e.warn || 0;
  ctx.save();
  glow(ctx, 0, -120, 140, '#fff3a0', 0.25);
  for (const sx of [-1, 1]) { ctx.fillStyle = '#e8dcc0'; ctx.fillRect(sx * 18 - 12, -60, 24, 60); ctx.strokeRect(sx * 18 - 12, -60, 24, 60); }
  ctx.fillStyle = lit(ctx, -60, -170, 60, -60, '#fffaf0', '#c8a050'); ctx.beginPath(); ctx.moveTo(-56, -160); ctx.lineTo(56, -160); ctx.lineTo(40, -60); ctx.lineTo(-40, -60); ctx.closePath(); ctx.fill(); stroke(ctx, 3);
  ctx.fillStyle = '#e0b45a'; ctx.beginPath(); ctx.arc(0, -116, 14, 0, TAU); ctx.fill(); stroke(ctx, 2);
  // sun head with rays
  ctx.save(); ctx.translate(0, -190); ctx.rotate(t * 0.8);
  for (let i = 0; i < 12; i++) { ctx.rotate(TAU / 12); ctx.fillStyle = i % 2 ? '#fff3a0' : '#ffcf5a'; path(ctx, [[-6, -26], [6, -26], [0, -46 - Math.sin(t * 6 + i) * 4]]); ctx.fill(); stroke(ctx, 1.4); }
  ctx.restore();
  ctx.fillStyle = '#fff8e0'; ctx.beginPath(); ctx.arc(0, -190, 26, 0, TAU); ctx.fill(); stroke(ctx, 3);
  ctx.fillStyle = '#c2412f'; ctx.fillRect(-14, -194, 28, 6);
  // twin hammers on chains, swinging
  for (const sx of [-1, 1]) {
    const a = sx * (0.6 + wind * 1.2) + Math.sin(t * 3 + sx) * 0.3;
    const hx = sx * 60 + Math.sin(a) * 70, hy = -120 + Math.cos(a) * 70;
    ctx.strokeStyle = '#8a7a5a'; ctx.lineWidth = 3; ctx.setLineDash([6, 4]); ctx.beginPath(); ctx.moveTo(sx * 56, -140); ctx.lineTo(hx, hy); ctx.stroke(); ctx.setLineDash([]);
    ctx.save(); ctx.translate(hx, hy); ctx.rotate(a); ctx.fillStyle = '#fff3c4'; ctx.fillRect(-22, -14, 44, 28); ctx.strokeRect(-22, -14, 44, 28); ctx.fillStyle = '#e0b45a'; ctx.fillRect(-22, -4, 44, 8); glow(ctx, 0, 0, 30, '#ffe89a', 0.4); ctx.restore();
  }
  if (e.hwClashT > 0) glow(ctx, 0, -120, 200, '#ffffff', 0.5);
  ctx.restore();
  return 240;
};
// 4. alchemy: a hooded alchemist with a flask head and eight element orbs on rings
M.gAlchemy = (ctx, e, t) => {
  ctx.save(); ctx.translate(0, -20 + Math.sin(t * 3) * 6);
  const cols = ['#ff6a1a', '#9fe8ff', '#8ad04a', '#ffe65a', '#c6ecdf', '#c8a060', '#fff3a0', '#7a3aff'];
  for (let i = 0; i < 8; i++) { const a = t * 1.2 + i * (TAU / 8); const x = Math.cos(a) * 80, y = -120 + Math.sin(a) * 30; if (Math.sin(a) < 0) { glow(ctx, x, y, 18, cols[i], 0.6); ctx.fillStyle = cols[i]; ctx.beginPath(); ctx.arc(x, y, 7, 0, TAU); ctx.fill(); stroke(ctx, 1.6); } }
  robe(ctx, -130, 0, 24, 50, lit(ctx, -50, -130, 50, 0, '#2a5a3a', '#0a1a10'), t, 10, 1);
  ctx.strokeStyle = '#e0b45a'; ctx.lineWidth = 2; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(0, -70, 16 + i * 8, t + i, t + i + 3); ctx.stroke(); }
  // the flask head, bubbling
  ctx.fillStyle = 'rgba(216,240,255,0.85)'; ctx.beginPath(); ctx.moveTo(-8, -190); ctx.lineTo(-8, -170); ctx.bezierCurveTo(-34, -160, -34, -124, 0, -122); ctx.bezierCurveTo(34, -124, 34, -160, 8, -170); ctx.lineTo(8, -190); ctx.closePath(); ctx.fill(); stroke(ctx, 2.6);
  ctx.fillStyle = cols[Math.floor(t * 0.8) % 8]; ctx.beginPath(); ctx.moveTo(-26, -146); ctx.bezierCurveTo(-28, -126, 28, -126, 26, -146); ctx.fill();
  for (let i = 0; i < 3; i++) { ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(Math.sin(t * 3 + i * 2) * 10, -140 - ((t * 30 + i * 10) % 30), 2.4, 0, TAU); ctx.fill(); }
  eyes(ctx, 0, -150, 8, 2.6, '#1a3a1a', t);
  ctx.fillStyle = '#a87848'; ctx.fillRect(-9, -198, 18, 10); ctx.strokeRect(-9, -198, 18, 10);
  for (let i = 0; i < 8; i++) { const a = t * 1.2 + i * (TAU / 8); const x = Math.cos(a) * 80, y = -120 + Math.sin(a) * 30; if (Math.sin(a) >= 0) { glow(ctx, x, y, 18, cols[i], 0.6); ctx.fillStyle = cols[i]; ctx.beginPath(); ctx.arc(x, y, 7, 0, TAU); ctx.fill(); stroke(ctx, 1.6); } }
  ctx.restore();
  return 230;
};
// 5. the Heaven Emperor: a crowned skeleton with SIX bone wings, a sword and a tower shield
M.emperor = (ctx, e, t, o) => {
  const wind = e.warn || 0, guard = e.guarding;
  ctx.save();
  glow(ctx, 0, -150, 180, '#fff3c4', 0.18);
  // six skeletal wings, three a side, slowly beating
  for (const sx of [-1, 1]) for (let i = 0; i < 3; i++) {
    ctx.save(); ctx.translate(sx * 20, -170); ctx.rotate(sx * (-0.9 + i * 0.45 + Math.sin(t * 1.8 + i) * 0.08));
    ctx.strokeStyle = INK; ctx.lineWidth = 9; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(sx * 70, -60); ctx.lineTo(sx * 150, -40 - i * 20); ctx.stroke();
    ctx.strokeStyle = '#efe4cc'; ctx.lineWidth = 5; ctx.stroke();
    for (let k = 1; k <= 4; k++) { const fx = sx * (70 + k * 20), fy = -60 + k * 5; ctx.strokeStyle = 'rgba(255,243,196,0.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(fx, fy); ctx.lineTo(fx + sx * 6, fy + 40 + i * 6); ctx.stroke(); }
    glow(ctx, sx * 70, -60, 10, '#ffe89a', 0.8);
    ctx.restore();
  }
  // ribcage and spine
  ctx.strokeStyle = INK; ctx.lineWidth = 8; ctx.beginPath(); ctx.moveTo(0, -60); ctx.lineTo(0, -180); ctx.stroke(); ctx.strokeStyle = '#efe4cc'; ctx.lineWidth = 4; ctx.stroke();
  for (let i = 0; i < 5; i++) { const y = -170 + i * 20, w = 34 - i * 3; ctx.strokeStyle = INK; ctx.lineWidth = 6; ctx.beginPath(); ctx.ellipse(0, y, w, 8, 0, 0.2, Math.PI - 0.2); ctx.stroke(); ctx.strokeStyle = '#efe4cc'; ctx.lineWidth = 3; ctx.stroke(); }
  ctx.fillStyle = '#c8a050'; ctx.fillRect(-28, -64, 56, 14); ctx.strokeRect(-28, -64, 56, 14);
  for (const sx of [-1, 1]) { ctx.strokeStyle = INK; ctx.lineWidth = 7; ctx.beginPath(); ctx.moveTo(sx * 14, -50); ctx.lineTo(sx * 20, 0); ctx.stroke(); ctx.strokeStyle = '#efe4cc'; ctx.lineWidth = 3.5; ctx.stroke(); }
  // skull with a crown of light
  ctx.fillStyle = '#f4ecd8'; ctx.beginPath(); ctx.arc(0, -206, 24, 0, TAU); ctx.fill(); stroke(ctx, 3);
  ctx.fillStyle = INK; ctx.beginPath(); ctx.ellipse(-9, -208, 6, 8, 0, 0, TAU); ctx.ellipse(9, -208, 6, 8, 0, 0, TAU); ctx.fill();
  eyes(ctx, 0, -208, 9, 2.6, '#ffe89a', t);
  ctx.fillStyle = '#e0b45a'; path(ctx, [[-22, -224], [-18, -246], [-8, -232], [0, -254], [8, -232], [18, -246], [22, -224]]); ctx.fill(); stroke(ctx, 2);
  // tower shield (front) and the sword
  ctx.save(); ctx.translate(-40, -110); ctx.rotate(guard ? 0 : -0.2);
  ctx.fillStyle = lit(ctx, -30, -60, 30, 60, '#fffaf0', '#c8a050'); ctx.beginPath(); ctx.moveTo(-26, -54); ctx.lineTo(26, -54); ctx.lineTo(26, 30); ctx.quadraticCurveTo(0, 60, -26, 30); ctx.closePath(); ctx.fill(); stroke(ctx, 3);
  ctx.fillStyle = '#e0b45a'; ctx.fillRect(-4, -46, 8, 70); ctx.fillRect(-20, -18, 40, 8);
  if (guard) glow(ctx, 0, 0, 70, '#ffe89a', 0.35);
  ctx.restore();
  ctx.save(); ctx.translate(46, -120); ctx.rotate(0.3 - wind * 1.6);
  ctx.fillStyle = '#fffaf0'; path(ctx, [[-5, 0], [5, 0], [4, -110], [0, -124], [-4, -110]]); ctx.fill(); stroke(ctx, 2.4); ctx.fillStyle = '#e0b45a'; ctx.fillRect(-18, -2, 36, 8); ctx.strokeRect(-18, -2, 36, 8); glow(ctx, 0, -60, 40, '#fff3c4', 0.2 + wind * 0.4);
  ctx.restore();
  ctx.restore();
  return 270;
};
// the hero's reflection in the mirror world is drawn by battle/hwCoop.js with the hero's own gear

export function drawHwModel(ctx, e, t, o = {}) {
  const fn = M[e.type.model];
  if (!fn) return 0;
  ctx.save();
  ctx.translate(e.x, e.y - (o.z || 0));
  ctx.globalAlpha *= o.alpha ?? 1;
  const face = o.face ?? 1;
  const symmetric = ['batSwarm', 'gumdrop', 'soulWisp', 'pillar', 'chess', 'mandrake', 'witchcap'].includes(e.type.model);
  if (!symmetric && face < 0) ctx.scale(-1, 1);
  const sc = e.type.scale || 1; if (sc !== 1) ctx.scale(sc, sc);
  const h = fn(ctx, e, t, { ...o, face: 1 }) * sc;
  ctx.restore();
  if (o.flash > 0.05) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = Math.min(0.6, o.flash * 0.6); ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.ellipse(e.x, e.y - (o.z || 0) - h * 0.5, (e.r || 24) * 1.1, h * 0.5, 0, 0, TAU); ctx.fill(); ctx.restore(); }
  return h;
}
export const hasHwModel = (e) => !!(e?.type?.model && M[e.type.model]);
