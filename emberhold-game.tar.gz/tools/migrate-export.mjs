// Step 1 of moving the OLD Netlify players to Cloudflare: read every account + save out of Netlify Blobs into one JSON file.
// Run on your own computer (needs network):
//   npm i                                         (installs @netlify/blobs)
//   NETLIFY_SITE_ID=...  NETLIFY_AUTH_TOKEN=...  node tools/migrate-export.mjs [out.json]
// NETLIFY_SITE_ID: Netlify → Site configuration → Site details → "Project ID".  NETLIFY_AUTH_TOKEN: a personal access token
// (User settings → Applications → Personal access tokens). Read-only here: nothing on Netlify is changed or deleted.
// The file holds password HASHES and saves — keep it private and delete it when the import is done.
import { writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';

// kv: { get(key), list(prefix) } — the same interface as netlify/lib/hub.mjs blobsKV()
export async function collectRecords(kv, { log = () => {}, concurrency = 8 } = {}) {
  const keys = await kv.list('acct/');
  const records = [], skipped = [];
  let i = 0;
  const one = async (k) => {
    let acct = null; try { acct = JSON.parse(await kv.get(k)); } catch { /* unreadable */ }
    if (!acct || !acct.uid || !acct.name) { skipped.push(k); return; }
    let save = null; try { const t = await kv.get('save/' + acct.uid); save = t ? JSON.parse(t) : null; } catch { /* no save */ }
    records.push({ acct, save: save && save.save ? { save: save.save, updatedAt: save.updatedAt || 0, at: save.at || 0 } : null });
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, keys.length) || 1 }, async () => { while (i < keys.length) { const k = keys[i++]; await one(k); if (i % 50 === 0) log(`  ${i}/${keys.length}`); } }));
  records.sort((a, b) => (a.acct.created || 0) - (b.acct.created || 0));
  return { records, skipped, total: keys.length };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const siteID = process.env.NETLIFY_SITE_ID, token = process.env.NETLIFY_AUTH_TOKEN;
  if (!siteID || !token) { console.error('ตั้ง NETLIFY_SITE_ID และ NETLIFY_AUTH_TOKEN ก่อน (ดู UPDATE-migrate-th.md)'); process.exit(1); }
  const { getStore } = await import('@netlify/blobs');
  const { blobsKV } = await import('../netlify/lib/hub.mjs');
  const out = process.argv[2] || 'netlify-cloud-export.json';
  console.log('กำลังอ่านบัญชีจาก Netlify Blobs (emberhold-cloud)…');
  const r = await collectRecords(blobsKV(getStore({ name: 'emberhold-cloud', siteID, token, consistency: 'strong' })), { log: console.log });
  await writeFile(out, JSON.stringify({ exportedAt: Date.now(), records: r.records }));
  console.log(`เสร็จ: ${r.records.length} บัญชี (มีเซฟ ${r.records.filter((x) => x.save).length}) ข้าม ${r.skipped.length} → ${out}`);
}
