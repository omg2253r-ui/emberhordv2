// v10.2 cast types: the Halloween and Egypt skills, the five secret skills and the support skills that bless
// everyone near the caster. They register into battle/skillCast.js and follow its rules: damage only through
// C.hit (never on a replay), visuals for everyone. A support cast replayed on a party member's screen blesses that
// player's own hero when it stands in range (world.supportAllies is set by the online party scene, not in duels).
import { registerCast, SK } from './skillCast.js';
import { addBuff, BUFF_KINDS } from './buffs.js';
import { gainUlt } from './ultimate.js';
import { elOf } from './skillVfx.js';
import './skillVfx2.js';

const TAU = Math.PI * 2;
const { live, nearest, within, burst, heal, addField } = SK;
function rnd(seed) { let s = Math.abs(Math.round(seed)) % 233280; return () => ((s = (s * 9301 + 49297) % 233280) / 233280); }
const seedOf = (C) => Math.round(C.tx) * 31 + Math.round(C.ty) * 17 + Math.round(C.x) * 7 + Math.round(C.y);
const cx = (C) => (C.ghost ? C.x : C.p.x), cy = (C) => (C.ghost ? C.y : C.p.y);
const isBoss = (e) => !!(e.type?.boss || e.boss);
const hpFrac = (e) => (e.maxHp ? Math.max(0, e.hp) / e.maxHp : 1);
function pull(w, x, y, r, f, dt) {
  for (const e of within(w, x, y, r)) if (!isBoss(e) && !e.peer) { const ang = Math.atan2(y - e.y, x - e.x); e.vx = (e.vx || 0) + Math.cos(ang) * f * dt; e.vy = (e.vy || 0) + Math.sin(ang) * f * dt; }
}
// `later` runs fn once after t seconds (replays too, so visuals line up)
const later = (C, t, fn) => C.w.sk.act({ max: t + 0.5, step: (dt, a) => { if (a.t >= t) { fn(); return false; } return true; } });
function boom(C, x, y, r, power, ex = {}, kb = 240) {
  C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: 0.45, band: 22 });
  C.fx.add({ type: 'flash', x, y: y - 20, r: r * 0.8, el: C.el, dur: 0.3, rays: 10 });
  burst(C.w, x, y - 20, 18, C.el, { max: 300 });
  if (power > 0) for (const e of within(C.w, x, y, r)) C.hit(e, power, { ...C.push(e, { x, y }, kb), ...ex });
}

// ================================================================== Halloween
registerCast('lob', (C) => {
  const { v, o } = C, n = v.count || o.count || 5, R = rnd(seedOf(C)), sx = cx(C), sy = cy(C) - 40;
  C.w.sfx?.('swing', { power: 1.2 });
  if (!C.ghost) C.p.act = { anim: 'cast', dir: C.a, t: 0, dur: 0.3 };
  for (let i = 0; i < n; i++) {
    const ang = R() * TAU, rr = Math.sqrt(R()) * (o.spread || 110);
    const x2 = C.tx + Math.cos(ang) * rr, y2 = C.ty + Math.sin(ang) * rr * 0.7, fly = (o.fly || 0.55) + R() * 0.15, at = i * (o.stagger ?? 0.09);
    later(C, at, () => {
      C.fx.add({ type: 'lobfx', x: sx, y: sy, x2, y2, dur: fly, h: (o.h || 200) + R() * 60, sym: o.sym, el: C.el, size: o.size || 46, spin: o.spin ?? 7 });
      later(C, fly, () => {
        boom(C, x2, y2, v.radius || 80, v.power, o.burn ? { burn: true } : {}, o.kb ?? 160);
        C.fx.add({ type: 'sym', mode: 'pop', sym: o.pop || o.sym, el: C.el, x: x2, y: y2 - 30, size: (o.size || 46) * 1.2, dur: 0.45 });
        if (o.puddle) addField(C, { x: x2, y: y2, r: (v.radius || 80) * 0.8, dur: o.puddle, tick: 0.5, power: v.power * (o.puddlePow || 0.25), heal: 0, motif: o.motif });
        if (i === n - 1) C.w.shake?.(6, 0.25);
        C.w.sfx?.(o.sound || 'hit');
      });
    });
  }
});

// creatures that hunt the nearest foes on their own (bats, scarabs, little ghosts)
registerCast('swarm', (C) => {
  const { v, o } = C, n = v.count || o.count || 6, dur = v.duration || o.dur || 5, R = rnd(seedOf(C));
  const ox = cx(C), oy = cy(C) - 50;
  C.fx.add({ type: 'flash', x: ox, y: oy, r: 90, el: C.el, dur: 0.35, rays: 12 });
  C.w.sfx?.(o.sound || 'cast', { power: 1.3 });
  const agents = [];
  for (let i = 0; i < n; i++) {
    const ang = (i / n) * TAU;
    agents.push({ x: ox + Math.cos(ang) * 30, y: oy + Math.sin(ang) * 20, vx: Math.cos(ang) * 200, vy: Math.sin(ang) * 120, cd: 0.25 + R() * 0.3, fx: C.fx.add({ type: 'sym', mode: 'agent', sym: o.sym, el: C.el, x: ox, y: oy, size: o.size || 34, dur: dur + 0.4, flap: o.flap || 0, halo: 0.6 }) });
  }
  const speed = o.speed || 420;
  C.w.sk.act({ max: dur + 0.5, step: (dt, a) => {
    const done = a.t >= dur;
    for (const g of agents) {
      g.cd -= dt;
      const t = done ? null : nearest(C.w, g.x, g.y + 30, 600);
      const gx = t ? t.x : (C.ghost ? ox : C.p.x) + Math.cos(a.t * 2 + g.fx.seed) * 80, gy = t ? t.y - 30 : (C.ghost ? oy : C.p.y - 60) + Math.sin(a.t * 2 + g.fx.seed) * 40;
      const ang = Math.atan2(gy - g.y, gx - g.x);
      g.vx += (Math.cos(ang) * speed - g.vx) * Math.min(1, dt * 5); g.vy += (Math.sin(ang) * speed - g.vy) * Math.min(1, dt * 5);
      g.x += g.vx * dt; g.y += g.vy * dt;
      g.fx.x = g.x; g.fx.y = g.y; g.fx.flip = g.vx < 0;
      if (t && g.cd <= 0 && Math.hypot(t.x - g.x, t.y - 30 - g.y) < (t.r || 20) + 26) {
        g.cd = o.gap || 0.45; g.vx = -g.vx * 0.8; g.vy = -g.vy * 0.8 - 120;
        C.fx.add({ type: 'flash', x: t.x, y: t.y - 30, r: 34, el: C.el, dur: 0.18 });
        if (C.hit(t, v.power, { kx: 0, ky: 0 }) && v.heal && !C.ghost) heal(C, v.heal);
      }
    }
    if (done) { for (const g of agents) { g.fx.gone = g.fx.t; g.fx.dur = g.fx.t + 0.3; } return false; }
    return true;
  } });
});

// graves rise around the target, then burst with grasping spirits
registerCast('risers', (C) => {
  const { v, o } = C, n = v.count || o.count || 5, ring = o.ring || 110, dl = o.delay || 0.7;
  C.fx.add({ type: 'emblem', x: C.tx, y: C.ty, r: ring + 40, el: C.el, dur: dl + 0.8, sym: 'hex', spin: 0.3 });
  C.w.sfx?.('slam');
  for (let i = 0; i < n; i++) {
    const ang = (i / n) * TAU + 0.3, x = C.tx + Math.cos(ang) * ring, y = C.ty + Math.sin(ang) * ring * 0.62;
    later(C, i * 0.08, () => { C.fx.add({ type: 'sym', mode: 'rise', sym: o.sym || 'tomb', el: C.el, x, y: y - 26, size: 58, dur: dl + 0.6 - i * 0.08 }); C.fx.add({ type: 'crack', x, y, r: 50, el: C.el, dur: 1, n: 5 }); });
    later(C, dl + i * 0.06, () => {
      C.fx.add({ type: 'sym', mode: 'rise', sym: o.burst || 'ghost', el: C.el, x, y: y - 70, size: 64, dur: 0.8, halo: 1.2 });
      C.fx.add({ type: 'pillar', x, y, w: 36, el: C.el, dur: 0.5, h: 260 });
      for (const e of within(C.w, x, y, v.radius || 80)) C.hit(e, v.power, { kx: 0, ky: -40, stun: v.stun || 0.6 });
      C.w.sfx?.('hit');
    });
  }
  later(C, dl + 0.2, () => C.w.shake?.(7, 0.3));
});

// a giant scythe sweeps around the hero; the weaker a foe, the harder it bites (and the weakest are reaped)
registerCast('reap', (C) => {
  const { v, o } = C, spins = o.spins || 2, r = v.radius || 170, per = o.per || 0.42;
  const sc = C.fx.add({ type: 'sym', mode: 'float', sym: 'scythe', el: C.el, x: cx(C), y: cy(C) - 40, size: r * 0.9, dur: spins * per + 0.3, follow: C.ghost ? null : C.p, fy: -40, halo: 0.4 });
  C.fx.add({ type: 'emblem', x: cx(C), y: cy(C), r, el: C.el, dur: spins * per + 0.4, sym: 'moon', spin: 3, follow: C.ghost ? null : C.p });
  C.w.sfx?.('swing', { power: 1.8 });
  C.w.sk.act({ max: spins * per + 0.4, step: (dt, a) => {
    const x = C.ghost ? C.x : C.p.x, y = C.ghost ? C.y : C.p.y;
    sc.rot = (a.t / per) * TAU; sc.x = x + Math.cos(sc.rot) * r * 0.45; sc.y = y - 40 + Math.sin(sc.rot) * r * 0.3; sc.follow = null;
    const half = Math.floor(a.t / (per / 2));
    if (half !== a.half && half < spins * 2) {
      a.half = half;
      C.fx.add({ type: 'arc', x, y: y - 20, a: sc.rot, r: r * 0.85, arc: Math.PI * 1.1, th: 16, el: C.el, dur: 0.24 });
      C.w.sfx?.('swing');
      for (const e of within(C.w, x, y, r)) {
        const f = hpFrac(e);
        if (!isBoss(e) && !e.peer && f <= (o.exec || 0)) { C.fx.add({ type: 'sym', mode: 'rise', sym: 'ghost', el: C.el, x: e.x, y: e.y - 70, size: 44, dur: 0.8 }); C.hit(e, 99, { forceCrit: true }); continue; }
        C.hit(e, v.power * (1 + (1 - f) * (o.low || 1)), C.push(e, { x, y }, 140));
      }
    }
    return a.t < spins * per;
  } });
});

// a row of ghosts marches forward through everything, shoving foes along
registerCast('march', (C) => {
  const { v, o } = C, n = o.count || 5, dist = v.distance || 520, sp = o.speed || 520, dur = dist / sp, a0 = C.a;
  const nx = -Math.sin(a0), ny = Math.cos(a0), sx = cx(C) - Math.cos(a0) * 40, sy = cy(C) - Math.sin(a0) * 40, gap = o.gap || 46;
  const row = [];
  for (let i = 0; i < n; i++) { const off = (i - (n - 1) / 2) * gap; row.push({ off, fx: C.fx.add({ type: 'sym', mode: 'agent', sym: o.sym || 'ghost', el: C.el, x: sx, y: sy, size: 56, dur: dur + 0.5, flip: Math.cos(a0) < 0, halo: 0.8 }) }); }
  C.fx.add({ type: 'path', x: sx, y: sy, x2: sx + Math.cos(a0) * dist, y2: sy + Math.sin(a0) * dist, w: (n * gap) / 2 + 20, el: C.el, dur: dur + 0.6, grow: dur });
  C.w.sfx?.('telegraph');
  const hitSet = new Set();
  C.w.sk.act({ max: dur + 0.6, step: (dt, a) => {
    const d = Math.min(dist, a.t * sp);
    for (const g of row) { g.fx.x = sx + Math.cos(a0) * d + nx * g.off; g.fx.y = sy + Math.sin(a0) * d + ny * g.off * 0.7 - 50 + Math.sin(a.t * 10 + g.off) * 6; }
    const hx = sx + Math.cos(a0) * d, hy = sy + Math.sin(a0) * d, half = (n * gap) / 2 + 10;
    for (const e of live(C.w)) {
      const rx = e.x - hx, ry = e.y - hy, along = rx * Math.cos(a0) + ry * Math.sin(a0), side = rx * nx + ry * ny;
      if (Math.abs(along) < 50 && Math.abs(side) < half + (e.r || 20)) {
        if (!hitSet.has(e)) { hitSet.add(e); C.hit(e, v.power, { kx: Math.cos(a0) * 300, ky: Math.sin(a0) * 300, slow: v.slow || 0.5, slowT: 2 }); C.fx.add({ type: 'flash', x: e.x, y: e.y - 30, r: 40, el: C.el, dur: 0.2 }); }
        else if (!isBoss(e) && !e.peer) { e.vx = (e.vx || 0) + Math.cos(a0) * 900 * dt; e.vy = (e.vy || 0) + Math.sin(a0) * 900 * dt; }
      }
    }
    if (a.t >= dur) { for (const g of row) { g.fx.gone = g.fx.t; g.fx.dur = g.fx.t + 0.3; } return false; }
    return true;
  } });
});

// a cursed circle on the ground: foes inside take more damage and wither; it detonates at the end
registerCast('curse', (C) => {
  const { v, o } = C, dur = v.duration || o.dur || 4;
  C.fx.add({ type: 'emblem', x: C.tx, y: C.ty, r: v.radius, el: C.el, dur, sym: o.sym || 'hex', spin: 0.6 });
  C.fx.add({ type: 'ringsyms', x: C.tx, y: C.ty, r: v.radius * 0.8, el: C.el, dur, sym: o.ring || 'bat', n: 6, flap: 9, lift: 90, size: 28 });
  addField(C, { x: C.tx, y: C.ty, r: v.radius, dur, tick: 0.5, power: v.power, heal: 0, reduce: 0, pull: o.pull || 0, motif: o.motif, end: (o.end || 0) * v.power });
  C.w.sfx?.('cast', { power: 1.5 });
});

// a howl under a blood moon: foes flee in terror, the hero turns savage
registerCast('howl', (C) => {
  const { v, o } = C, dur = v.duration || 6, x = cx(C), y = cy(C);
  C.fx.add({ type: 'skyicon', x, y, sym: o.sym || 'moon', el: C.el, dur: Math.min(dur, 3), size: 150, h: 300 });
  C.fx.add({ type: 'shock', x, y: y - 10, r: v.radius, el: C.el, dur: 0.6, band: 40 });
  C.fx.add({ type: 'aura', x, y, el: C.el, dur, follow: C.ghost ? null : C.p });
  C.w.sfx?.('roar'); C.w.shake?.(8, 0.4);
  for (const e of within(C.w, x, y, v.radius)) C.hit(e, v.power, { ...C.push(e, { x, y }, 520), stun: v.stun || 0.8 });
  if (C.ghost) return;
  for (const k of ['dmg', 'haste', 'lifesteal', 'speed']) if (v[k]) addBuff(C.p, k, v[k], dur);
});

// a jack-o'-lantern floats beside the hero, spitting homing fire, and bursts when its candle runs out
registerCast('lantern', (C) => {
  const { v, o } = C, dur = v.duration || 7;
  const L = C.fx.add({ type: 'sym', mode: 'agent', sym: o.sym || 'pumpkin', el: C.el, x: cx(C), y: cy(C) - 90, size: 54, dur: dur + 0.4, halo: 1.3 });
  C.fx.add({ type: 'flash', x: cx(C), y: cy(C) - 90, r: 80, el: C.el, dur: 0.3, rays: 10 });
  C.w.sfx?.('cast', { power: 1.2 });
  const tint = SK.tintOf(C.el);
  C.w.sk.act({ max: dur + 0.3, step: (dt, a) => {
    const hx = C.ghost ? C.x : C.p.x, hy = C.ghost ? C.y : C.p.y;
    L.x += (hx - 50 + Math.cos(a.t * 1.7) * 26 - L.x) * Math.min(1, dt * 5); L.y += (hy - 100 + Math.sin(a.t * 3.1) * 10 - L.y) * Math.min(1, dt * 5);
    a.acc = (a.acc || 0) + dt;
    if (a.acc >= (o.gap || 0.7)) {
      a.acc = 0;
      const t = nearest(C.w, L.x, L.y + 60, o.range || 520);
      if (t) {
        C.fx.add({ type: 'flash', x: L.x, y: L.y, r: 36, el: C.el, dur: 0.15 });
        if (!C.ghost) C.w.firePlayerShot({ kind: 'orb', x: L.x, y: L.y, angle: Math.atan2(t.y - 30 - L.y, t.x - L.x), speed: 560, r: 10, power: v.power, src: 'skill', life: 1.4, tint, homing: 5, burn: true });
      }
    }
    if (a.t >= dur) { L.gone = L.t; L.dur = L.t + 0.3; boom(C, L.x, L.y + 50, v.radius || 120, v.power * (o.end || 2), { burn: true }, 260); C.w.sfx?.('slam'); return false; }
    return true;
  } });
});

// ================================================================== Egypt
// a sandstorm that walks forward, pulling and grinding everything it swallows
registerCast('storm', (C) => {
  const { v, o } = C, dur = v.duration || 4, sp = o.speed || 150, a0 = C.a;
  const c = { x: cx(C) + Math.cos(a0) * 60, y: cy(C) + Math.sin(a0) * 40 };
  C.fx.add({ type: 'sandstorm', x: c.x, y: c.y, r: v.radius, el: C.el, dur, follow: c });
  C.fx.add({ type: 'vortex', x: c.x, y: c.y, r: v.radius, el: C.el, dur, follow: c, arms: 4 });
  C.w.sfx?.('cast', { power: 1.4 });
  C.w.sk.act({ max: dur + 0.2, step: (dt, a) => {
    c.x += Math.cos(a0) * sp * dt; c.y += Math.sin(a0) * sp * dt;
    if (C.w.clampBody) { const b = { x: c.x, y: c.y, r: 10 }; C.w.clampBody(b); c.x = b.x; c.y = b.y; }
    pull(C.w, c.x, c.y, v.radius * 1.2, o.pull || 520, dt);
    a.acc = (a.acc || 0) + dt;
    if (a.acc >= 0.4) { a.acc = 0; for (const e of within(C.w, c.x, c.y, v.radius)) C.hit(e, v.power, { kx: 0, ky: 0, slow: v.slow || 0.6, slowT: 1 }); }
    return a.t < dur;
  } });
});

// the sun descends over the target and strikes again and again with rays
registerCast('sunbeam', (C) => {
  const { v, o } = C, n = v.count || o.count || 5, gap = o.gap || 0.32, x = C.tx, y = C.ty;
  C.fx.add({ type: 'skyicon', x, y, sym: o.sym || 'sun', el: C.el, dur: n * gap + 0.9, size: 130, h: 280 });
  C.fx.add({ type: 'rune', x, y, r: v.radius, el: C.el, dur: n * gap + 0.8, sides: 8 });
  C.w.sfx?.('cast', { power: 1.6 });
  for (let i = 0; i < n; i++) later(C, 0.35 + i * gap, () => {
    const t = C.ghost ? null : (within(C.w, x, y, v.radius).sort(() => Math.random() - 0.5)[0]);
    const R = rnd(seedOf(C) + i * 97), px = t ? t.x : x + (R() - 0.5) * v.radius, py = t ? t.y : y + (R() - 0.5) * v.radius * 0.6;
    C.fx.add({ type: 'godray', x: px, y: py, el: C.el, dur: 0.35, w: 34, h: 620 });
    C.fx.add({ type: 'shock', x: px, y: py, r: 70, el: C.el, dur: 0.3 });
    for (const e of within(C.w, px, py, 70)) C.hit(e, v.power, { kx: 0, ky: 0, burn: true });
    C.w.sfx?.('hit');
  });
  later(C, 0.45 + n * gap, () => {
    C.fx.add({ type: 'godray', x, y, el: C.el, dur: 0.6, w: 90, h: 700 });
    boom(C, x, y, v.radius, v.power * (o.final || 2), { burn: true }, 300);
    C.w.shake?.(10, 0.4);
  });
});

// a pyramid rises around the foes, traps them, then collapses
registerCast('pyramid', (C) => {
  const { v, o } = C, hold = v.duration || 2.4, x = C.tx, y = C.ty, r = v.radius;
  C.fx.add({ type: 'pyramidfx', x, y: y + 20, r, el: C.el, dur: hold + 0.6 });
  C.fx.add({ type: 'crack', x, y, r: r * 1.2, el: C.el, dur: hold + 0.6, n: 8 });
  C.w.sfx?.('slam'); C.w.shake?.(6, 0.3);
  for (const e of within(C.w, x, y, r)) C.hit(e, v.power * 0.5, { kx: 0, ky: 0, stun: hold });
  C.w.sk.act({ max: hold + 0.4, step: (dt, a) => {
    pull(C.w, x, y, r * 1.1, 600, dt);
    a.acc = (a.acc || 0) + dt;
    if (a.acc >= 0.5) { a.acc = 0; for (const e of within(C.w, x, y, r)) C.hit(e, v.power * 0.25, { kx: 0, ky: 0 }); }
    if (a.t >= hold) { boom(C, x, y, r * 1.2, v.power * (o.collapse || 1.6), {}, 420); C.w.shake?.(12, 0.45); C.w.sfx?.('shatter'); return false; }
    return true;
  } });
});

// the eye of Horus opens in the sky: every foe in sight is marked and shot at
registerCast('eye', (C) => {
  const { v, o } = C, dur = v.duration || 5, x = cx(C), y = cy(C);
  const eye = C.fx.add({ type: 'skyicon', x, y, sym: 'eye', el: C.el, dur, size: 120, h: 230, follow: C.ghost ? null : C.p });
  C.w.sfx?.('telegraph');
  for (const e of within(C.w, x, y, v.radius)) { C.hit(e, 0.01, { kx: 0, ky: 0, mark: v.mark, markT: dur }); C.fx.add({ type: 'mark', x: e.x, y: e.y, el: C.el, dur, follow: e, h: 100 }); }
  C.w.sk.act({ max: dur + 0.2, step: (dt, a) => {
    a.acc = (a.acc || 0) + dt;
    if (a.acc >= (o.gap || 0.6)) {
      a.acc = 0;
      const ex = eye.x, ey = eye.y - 230;
      const t = nearest(C.w, ex, ey + 230, v.radius);
      if (t) { C.fx.add({ type: 'bolt', x: ex, y: ey, x2: t.x, y2: t.y - 30, el: C.el, dur: 0.22, w: 5 }); C.hit(t, v.power, { kx: 0, ky: 0 }); }
    }
    return a.t < dur;
  } });
});

// the scales of Anubis weigh every heart: the healthier the foe, the heavier the judgement
registerCast('judge', (C) => {
  const { v, o } = C, x = C.tx, y = C.ty;
  C.fx.add({ type: 'emblem', x, y, r: v.radius, el: C.el, dur: 1.4, sym: 'scales', spin: 0 });
  C.fx.add({ type: 'skyicon', x, y, sym: 'scales', el: C.el, dur: 1.3, size: 110, h: 220 });
  C.w.sfx?.('telegraph');
  later(C, 0.7, () => {
    C.w.sfx?.('crit'); C.w.shake?.(8, 0.3);
    for (const e of within(C.w, x, y, v.radius)) {
      C.fx.add({ type: 'godray', x: e.x, y: e.y, el: C.el, dur: 0.4, w: 30, h: 500 });
      if (!isBoss(e) && !e.peer && hpFrac(e) <= (o.exec || 0.2)) { C.hit(e, 99, { forceCrit: true }); continue; }
      C.hit(e, v.power * (0.6 + hpFrac(e) * (o.heavy || 0.9)), { kx: 0, ky: 0 });
    }
  });
});

// bandages lash out, bind foes and drag them together
registerCast('wrap', (C) => {
  const { v, o } = C, n = v.count || 4, x = cx(C), y = cy(C);
  const foes = live(C.w).filter((e) => Math.hypot(e.x - x, e.y - y) < (o.range || 420)).sort((a, b) => Math.hypot(a.x - x, a.y - y) - Math.hypot(b.x - x, b.y - y)).slice(0, n);
  C.fx.add({ type: 'sym', mode: 'pop', sym: 'wrap', el: C.el, x, y: y - 120, size: 60, dur: 0.8 });
  C.w.sfx?.('swing', { power: 1.4 });
  if (!foes.length && C.ghost) for (let i = 0; i < n; i++) { const a = C.a + (i - (n - 1) / 2) * 0.4; C.fx.add({ type: 'tether', x, y, x2: x + Math.cos(a) * 300, y2: y + Math.sin(a) * 200, el: C.el, dur: 0.5, waves: 5 }); }
  for (const e of foes) {
    C.fx.add({ type: 'tether', a: C.ghost ? { x, y } : C.p, b: e, el: C.el, dur: v.stun + 0.2, waves: 6, amp: 5, lift2: 30 });
    C.hit(e, v.power, { kx: 0, ky: 0, stun: v.stun });
  }
  if (C.ghost) return;
  const mx = C.tx, my = C.ty;
  C.w.sk.act({ max: v.stun + 0.2, step: (dt, a) => { for (const e of foes) if (!e.dead && !isBoss(e) && !e.peer) { e.x += (mx - e.x) * Math.min(1, dt * 3); e.y += (my - e.y) * Math.min(1, dt * 3); } return a.t < v.stun; } });
});

// an obelisk of the sun: shoots rays at foes and lends its strength to allies beside it
registerCast('obelisk', (C) => {
  const { v, o } = C, dur = v.duration || 7, x = cx(C) + Math.cos(C.a) * 70, y = cy(C) + Math.sin(C.a) * 40;
  C.fx.add({ type: 'sym', mode: 'rise', sym: 'obelisk', el: C.el, x, y: y - 60, size: 130, dur, halo: 0.6 });
  C.fx.add({ type: 'emblem', x, y, r: o.aura || 200, el: C.el, dur, sym: 'sun', spin: 0.2 });
  C.w.sfx?.('slam');
  C.w.sk.act({ max: dur + 0.2, step: (dt, a) => {
    a.acc = (a.acc || 0) + dt; a.b = (a.b || 0) + dt;
    if (a.acc >= (o.gap || 0.9)) {
      a.acc = 0;
      const t = nearest(C.w, x, y, o.range || 520);
      if (t) { C.fx.add({ type: 'beam', x, y: y - 120, a: Math.atan2(t.y - 30 - (y - 120), t.x - x), len: Math.hypot(t.x - x, t.y - 30 - (y - 120)), w: 12, el: C.el, dur: 0.25 }); C.hit(t, v.power, { kx: 0, ky: 0, burn: true }); }
    }
    if (a.b >= 0.5) { a.b = 0; for (const p of allies(C, x, y, o.aura || 200)) addBuff(p, 'dmg', v.dmg || 0.15, 0.7); }
    return a.t < dur;
  } });
});

// the sphinx asks a riddle: power, healing or time — the answer is chosen when it is cast
registerCast('riddle', (C) => {
  const { v } = C, x = cx(C), y = cy(C);
  if (!C.ghost) C.out = Math.floor(Math.random() * 3);
  const pick = C.out || 0, SYM = ['star', 'heart', 'hourglass'], TXT = ['คำตอบ: พลัง!', 'คำตอบ: ชีวิต!', 'คำตอบ: กาลเวลา!'];
  C.fx.add({ type: 'sym', mode: 'pop', sym: 'sphinx', el: C.el, x, y: y - 140, size: 96, dur: 1.2, halo: 1.1 });
  later(C, 0.55, () => {
    C.fx.add({ type: 'sym', mode: 'pop', sym: SYM[pick], el: C.el, x, y: y - 220, size: 64, dur: 1 });
    C.fx.add({ type: 'label', x, y: y - 40, text: TXT[pick], color: elOf(C.el).glow, dur: 1.1 });
    if (pick === 0) { boom(C, x, y, v.radius, v.power * 2, {}, 420); C.fx.add({ type: 'godray', x, y, el: C.el, dur: 0.5, w: 80 }); C.w.shake?.(10, 0.35); }
    else if (pick === 1) { for (const p of allies(C, x, y, v.radius)) bless(C, p, { heal: 0.22, shield: 0.15 }, 5); boom(C, x, y, v.radius * 0.6, v.power * 0.6); }
    else { for (const p of allies(C, x, y, v.radius)) bless(C, p, { refresh: 0.6, ult: 25, haste: 0.2 }, 5); boom(C, x, y, v.radius * 0.6, v.power * 0.6); }
    C.w.sfx?.(pick === 1 ? 'potion' : 'levelup');
  });
});

// ================================================================== secret
registerCast('blackhole', (C) => {
  const { v, o } = C, dur = v.duration || 3.5, x = C.tx, y = C.ty;
  C.fx.add({ type: 'blackhole', x, y, r: 46, el: C.el, dur: dur + 0.3 });
  C.fx.add({ type: 'vortex', x, y, r: v.radius, el: C.el, dur, arms: 7 });
  C.w.sfx?.('telegraph'); C.w.sfx?.('cast', { power: 2 });
  C.w.sk.act({ max: dur + 0.4, step: (dt, a) => {
    pull(C.w, x, y, v.radius * 1.4, o.pull || 1100, dt);
    a.acc = (a.acc || 0) + dt;
    if (a.acc >= 0.35) { a.acc = 0; for (const e of within(C.w, x, y, v.radius)) C.hit(e, v.power * 0.3, { kx: 0, ky: 0 }); }
    if (a.t >= dur) {
      C.fx.add({ type: 'flash', x, y: y - 70, r: v.radius * 1.6, el: C.el, dur: 0.6, rays: 24 });
      C.fx.add({ type: 'shock', x, y, r: v.radius * 1.6, el: C.el, dur: 0.7, band: 50 });
      C.w.shake?.(16, 0.6); C.w.sfx?.('shatter');
      for (const e of within(C.w, x, y, v.radius * 1.6)) {
        if (!isBoss(e) && !e.peer && hpFrac(e) <= (o.exec || 0.15)) { C.hit(e, 99, { forceCrit: true }); continue; }
        C.hit(e, v.power * (o.collapse || 3), C.push(e, { x, y }, 600));
      }
      return false;
    }
    return true;
  } });
});

registerCast('timestop', (C) => {
  const { v, o } = C, hold = v.stun || 2.5, x = cx(C), y = cy(C);
  C.fx.add({ type: 'timestop', x, y, r: v.radius, el: C.el, dur: hold + 0.3 });
  C.w.sfx?.('blink'); C.w.sfx?.('telegraph');
  const caught = within(C.w, x, y, v.radius);
  for (const e of caught) { C.hit(e, 0.01, { kx: 0, ky: 0, stun: hold }); C.fx.add({ type: 'sym', mode: 'float', sym: 'clock', el: C.el, x: e.x, y: e.y - 110, size: 30, dur: hold, follow: e, fy: -110 }); }
  if (!C.ghost) for (const s of C.w.skills || []) if (s && s.id !== C.skill.id) s.cd *= 1 - (o.refresh || 0.5);
  later(C, hold, () => {
    C.fx.add({ type: 'flash', x, y: y - 30, r: v.radius, el: C.el, dur: 0.5, rays: 20 });
    C.w.shake?.(12, 0.5); C.w.sfx?.('crit');
    for (const e of caught) if (!e.dead) { C.fx.add({ type: 'slashes', x: e.x, y: e.y - 30, el: C.el, dur: 0.35, n: 5, r: 60 }); C.hit(e, v.power, { kx: 0, ky: 0, forceCrit: true }); }
  });
});

registerCast('starfall', (C) => {
  const { v, o } = C, n = v.count || 12, x = C.tx, y = C.ty, R = rnd(seedOf(C));
  C.fx.add({ type: 'rune', x, y, r: v.radius, el: C.el, dur: n * 0.12 + 1.6, sides: 10 });
  C.fx.add({ type: 'ringsyms', x, y, r: v.radius * 0.7, el: C.el, dur: n * 0.12 + 1.4, sym: 'star', n: 8, lift: 260, size: 26, spin: 2 });
  C.w.sfx?.('telegraph');
  for (let i = 0; i < n; i++) {
    const ang = R() * TAU, rr = Math.sqrt(R()) * v.radius, px = x + Math.cos(ang) * rr, py = y + Math.sin(ang) * rr * 0.62;
    later(C, 0.3 + i * 0.12, () => { C.fx.add({ type: 'sym', mode: 'fall', sym: 'star', el: C.el, x: px, y: py - 20, size: 40, dur: 0.55, land: 0.3, h: 520, spin: 6 }); later(C, 0.3, () => boom(C, px, py, 70, v.power, {}, 120)); });
  }
  later(C, 0.5 + n * 0.12, () => {
    C.fx.add({ type: 'sym', mode: 'fall', sym: 'star', el: C.el, x, y: y - 40, size: 150, dur: 0.9, land: 0.45, h: 700, spin: 2, halo: 1.6 });
    later(C, 0.45, () => { boom(C, x, y, v.radius * 1.3, v.power * (o.big || 4), {}, 520); C.fx.add({ type: 'crack', x, y, r: v.radius * 1.2, el: C.el, dur: 1.6, n: 10 }); C.w.shake?.(16, 0.6); C.w.sfx?.('slam'); });
  });
});

registerCast('worldtree', (C) => {
  const { v, o } = C, dur = v.duration || 6, x = cx(C) + Math.cos(C.a) * 40, y = cy(C) + Math.sin(C.a) * 20;
  C.fx.add({ type: 'tree', x, y, el: C.el, dur, h: 280 });
  C.fx.add({ type: 'emblem', x, y, r: v.radius, el: C.el, dur, sym: 'root', spin: 0.15 });
  for (let i = 0; i < 6; i++) C.fx.add({ type: 'spikes', x, y, a: (i / 6) * TAU, len: v.radius, n: 6, el: C.el, dur: 1.4, h: 40 });
  C.w.sfx?.('slam'); C.w.shake?.(8, 0.4);
  for (const e of within(C.w, x, y, v.radius)) C.hit(e, v.power, { kx: 0, ky: 0, stun: v.stun || 1.6 });
  C.w.sk.act({ max: dur + 0.2, step: (dt, a) => {
    a.acc = (a.acc || 0) + dt;
    if (a.acc >= 0.5) {
      a.acc = 0;
      for (const e of within(C.w, x, y, v.radius)) C.hit(e, v.power * 0.3, { kx: 0, ky: 0, slow: 0.5, slowT: 0.6 });
      for (const p of allies(C, x, y, v.radius * 1.2)) bless(C, p, { heal: v.heal || 0.03, regen: 0.01, reduce: 0.2, t: 0.7 }, 0.7, false);
    }
    return a.t < dur;
  } });
});

registerCast('lastember', (C) => {
  const { v, o } = C, dur = v.duration || 8, x = cx(C), y = cy(C);
  C.fx.add({ type: 'sym', mode: 'pop', sym: 'ember', el: C.el, x, y: y - 150, size: 110, dur: 1.2, halo: 1.6 });
  C.fx.add({ type: 'wings', x, y, el: C.el, dur, follow: C.ghost ? null : C.p });
  C.fx.add({ type: 'aura', x, y, el: C.el, dur, follow: C.ghost ? null : C.p });
  boom(C, x, y, v.radius, v.power, { burn: true }, 420);
  C.w.sfx?.('levelup'); C.w.sfx?.('roar'); C.w.shake?.(12, 0.5);
  if (!C.ghost) {
    const p = C.p;
    for (const k of ['dmg', 'haste', 'lifesteal']) if (v[k]) addBuff(p, k, v[k], dur);
    addBuff(p, 'burn', 1, dur);
    p.undyingT = Math.max(p.undyingT || 0, dur);
  }
  later(C, dur, () => { const ex = C.ghost ? x : C.p.x, ey = C.ghost ? y : C.p.y; C.fx.add({ type: 'sym', mode: 'pop', sym: 'ember', el: C.el, x: ex, y: ey - 80, size: 140, dur: 0.8, halo: 2 }); boom(C, ex, ey, v.radius * 1.3, v.power * (o.end || 2.5), { burn: true }, 520); C.w.shake?.(14, 0.5); });
});

// ================================================================== class skills (data/jobs.js)
// iai: a still stance (untouchable), then one flash-step through everything on the line
registerCast('iai', (C) => {
  const { v } = C, a0 = C.a, d = v.distance || 420, x = cx(C), y = cy(C);
  const ex = x + Math.cos(a0) * d, ey = y + Math.sin(a0) * d * 0.8;
  C.fx.add({ type: 'emblem', x, y, r: 70, el: C.el, dur: 0.6, sym: 'moon', spin: 0 });
  C.fx.add({ type: 'sym', mode: 'pop', sym: 'katana', el: C.el, x, y: y - 120, size: 60, dur: 0.5 });
  C.w.sfx?.('charge');
  if (!C.ghost) { C.p.iframes = Math.max(C.p.iframes, 0.9); C.p.rootT = Math.max(C.p.rootT || 0, 0.4); }
  later(C, 0.4, () => {
    const sx = C.ghost ? x : C.p.x, sy = C.ghost ? y : C.p.y;
    const tx = sx + Math.cos(a0) * d, ty = sy + Math.sin(a0) * d * 0.8;
    const b = { x: tx, y: ty, r: 20 }; C.w.clampBody?.(b);
    if (!C.ghost) { C.p.x = b.x; C.p.y = b.y; C.p.vx = 0; C.p.vy = 0; C.p.act = { anim: 'cast', dir: a0, t: 0, dur: 0.3 }; }
    C.fx.add({ type: 'trail', x: sx, y: sy - 30, x2: b.x, y2: b.y - 30, el: C.el, dur: 0.5, w: 26 });
    C.fx.add({ type: 'arc', x: (sx + b.x) / 2, y: (sy + b.y) / 2 - 30, a: a0 + Math.PI / 2, r: d * 0.55, arc: 0.9, th: 10, el: C.el, dur: 0.4 });
    C.fx.add({ type: 'path', x: sx, y: sy, x2: b.x, y2: b.y, w: 40, el: C.el, dur: 0.7, grow: 0.05 });
    C.w.sfx?.('crit'); C.w.shake?.(9, 0.3); C.w.hitStop?.(0.06);
    const len = Math.hypot(b.x - sx, b.y - sy) || 1, ux = (b.x - sx) / len, uy = (b.y - sy) / len;
    for (const e of live(C.w)) {
      const rx = e.x - sx, ry = e.y - sy, along = rx * ux + ry * uy, side = Math.abs(-rx * uy + ry * ux);
      if (along > -20 && along < len + 20 && side < 50 + (e.r || 20)) { later(C, 0.12, () => { C.fx.add({ type: 'slashes', x: e.x, y: e.y - 30, el: C.el, dur: 0.3, n: 3, r: 70 }); C.hit(e, v.power, { forceCrit: true, kx: ux * 200, ky: uy * 200 }); }); }
    }
  });
});

// vanish and reappear behind the weakest foe in reach; a smoke screen stays behind
registerCast('shadowkill', (C) => {
  const { v, o } = C, x = cx(C), y = cy(C);
  C.fx.add({ type: 'field', x, y, r: 110, el: C.el, dur: 2.5 });
  C.fx.add({ type: 'flash', x, y: y - 30, r: 90, el: C.el, dur: 0.3 });
  C.w.sfx?.('blink');
  if (C.ghost) { C.fx.add({ type: 'slashes', x: C.tx, y: C.ty - 30, el: C.el, dur: 0.4, n: 6, r: 80 }); return; }
  const foes = live(C.w).filter((e) => Math.hypot(e.x - x, e.y - y) < (v.range || 460));
  for (const e of within(C.w, x, y, 130)) C.hit(e, 0.2, { kx: 0, ky: 0, slow: 0.5, slowT: 2.5 });
  const t = foes.sort((a, b) => hpFrac(a) - hpFrac(b))[0];
  C.p.iframes = Math.max(C.p.iframes, 0.6);
  if (!t) return;
  const side = Math.cos(C.a) >= 0 ? 1 : -1, b = { x: t.x + side * ((t.r || 20) + 30), y: t.y, r: 20 };
  C.w.clampBody?.(b); C.p.x = b.x; C.p.y = b.y; C.p.flip = side > 0; C.p.vx = C.p.vy = 0;
  C.fx.add({ type: 'slashes', x: t.x, y: t.y - 30, el: C.el, dur: 0.4, n: 6, r: 80 });
  C.fx.add({ type: 'sym', mode: 'pop', sym: 'dagger', el: C.el, x: t.x, y: t.y - 110, size: 50, dur: 0.6 });
  C.w.hitStop?.(0.07); C.w.sfx?.('crit');
  if (!isBoss(t) && !t.peer && hpFrac(t) <= (o.exec || 0.25)) C.hit(t, 99, { forceCrit: true });
  else C.hit(t, v.power, { forceCrit: true, kx: 0, ky: 0 });
});

// tear the souls out of every foe around; they fly back and mend the reaper
registerCast('soulharvest', (C) => {
  const { v } = C, x = cx(C), y = cy(C);
  C.fx.add({ type: 'emblem', x, y, r: v.radius, el: C.el, dur: 1.4, sym: 'skull', spin: 1.5 });
  C.fx.add({ type: 'shock', x, y, r: v.radius, el: C.el, dur: 0.6, band: 40 });
  C.w.sfx?.('roar');
  const foes = within(C.w, x, y, v.radius);
  if (C.ghost && !foes.length) C.fx.add({ type: 'ringsyms', x, y, r: v.radius * 0.6, el: C.el, dur: 1.2, sym: 'ghost', n: 6, lift: 60, size: 30, spin: -3 });
  foes.forEach((e, i) => later(C, 0.05 * i, () => {
    C.hit(e, v.power, { kx: 0, ky: 0 });
    const hx = C.ghost ? x : C.p.x, hy = C.ghost ? y : C.p.y;
    C.fx.add({ type: 'sym', mode: 'fly', sym: 'ghost', el: C.el, x: e.x, y: e.y - 50, x2: hx, y2: hy - 50, size: 34, dur: 0.6, h: 60 });
    if (!C.ghost) later(C, 0.6, () => { if (!C.p.dead) heal(C, v.heal || 0.03); });
  }));
});

// ================================================================== support
// who a blessing reaches: the caster's own hero on the caster's screen; on a party member's screen, their hero
// when it stands in range of the cast (never in duels)
function allies(C, x, y, r) {
  if (!C.ghost) return C.p && !C.p.dead ? [C.p] : [];
  const p = C.w.supportAllies ? C.w.player : null;
  return p && !p.dead && Math.hypot(p.x - x, p.y - y) <= r ? [p] : [];
}
// party members shown on the caster's screen get the same halo, so the caster sees who was reached
function showOnViews(C, x, y, r, sym) {
  if (C.ghost || !C.w.allies?.values) return;
  for (const a of C.w.allies.values()) if (a && a.x != null && !a.dead && Math.hypot(a.x - x, a.y - y) <= r) C.fx.add({ type: 'halo', x: a.x, y: a.y, el: C.el, dur: 1.4, follow: a, sym });
}
export function bless(C, p, eff, dur, show = true) {
  if (!p || p.dead) return;
  const w = C.w, mine = p === w.player;
  const t = eff.t ?? dur;
  if (eff.heal) { const n = Math.max(1, Math.round(p.maxHp * eff.heal)); p.hp = Math.min(p.maxHp, p.hp + n); if (show || n >= p.maxHp * 0.05) w.fx?.number(p.x, p.y - 100, `+${n}`, 'heal'); }
  if (eff.shield) { const n = Math.round(p.maxHp * eff.shield); if (n > (p.shield || 0)) { p.shield = n; p.shieldMax = Math.max(p.shieldMax || 0, n); } p.shieldT = Math.max(p.shieldT || 0, eff.shieldT || dur); }
  for (const k of BUFF_KINDS) if (eff[k]) addBuff(p, k, eff[k], t);
  if (eff.cleanse) { p.rootT = 0; p.flawSlowT = 0; p.exposeT = 0; p.chillT = 0; p.stunT = 0; p.frost = 0; }
  if (eff.ward) p.ward = Math.max(p.ward || 0, eff.ward);
  if (eff.deathWard) { p.deathWard = Math.max(p.deathWard || 0, eff.deathWard); p.deathWardT = Math.max(p.deathWardT || 0, eff.deathWardT || dur); }
  if (eff.undying) p.undyingT = Math.max(p.undyingT || 0, eff.undying);
  if (eff.iframes) p.iframes = Math.max(p.iframes || 0, eff.iframes);
  if (eff.root) p.rootT = Math.max(p.rootT || 0, eff.root);
  if (eff.dodges && p.dodgeMax) p.dodges = p.dodgeMax;
  if (eff.echo) { p.echoN = Math.max(p.echoN || 0, eff.echo); p.echoT = Math.max(p.echoT || 0, dur); p.echoMult = eff.echoMult || 0.5; }
  if (eff.counter) { p.counterT = Math.max(p.counterT || 0, eff.counter); p.counterSkill = { r: 170, power: eff.counterPow || 1.4, el: C.el }; }
  if (eff.rewind && w.sk?.hpBack) { const past = w.sk.hpBack(eff.rewind); if (past > p.hp) { const n = past - p.hp; p.hp = past; w.fx?.number(p.x, p.y - 120, `ย้อน +${n}`, 'heal'); } }
  if (mine && eff.refresh) { for (const s of w.skills || []) if (s && (!C.skill || s.id !== C.skill.id)) s.cd = Math.max(0, s.cd * (1 - eff.refresh)); }
  if (mine && eff.ult) gainUlt(w, eff.ult);
  if (show) w.sk?.fx.add({ type: 'halo', x: p.x, y: p.y, el: C.el, dur: 1.4, follow: p, sym: eff.sym || null });
}

// The support cast. o.mode picks how the blessing travels; o.vis names the picture (SUPVIS below).
//   burst  – everyone in range now          zone  – a lasting area at the caster (re-blesses while inside)
//   aura   – like zone but moves with the caster        object – a placed banner/anchor/well with its own range
//   wave   – a ring rolling outward, each ally blessed once      delay – planted now, blooms later
//   link   – a thread to the nearest party member (or yourself) that keeps both blessed
registerCast('support', (C) => {
  const { v, o } = C, x = cx(C), y = cy(C), r = v.radius || o.r || 260, dur = v.duration || o.dur || 6;
  const eff = { ...(o.eff || {}) };
  for (const k of ['heal', 'shield', 'dmg', 'haste', 'crit', 'speed', 'reduce', 'lifesteal', 'regen', 'ward', 'deathWard', 'refresh', 'ult', 'echo', 'echoMult', 'rewind', 'tickHeal', 'tickRefresh', 'counter', 'counterPow', 'iframes', 'root']) if (v[k] != null) eff[k] = v[k];
  const vis = SUPVIS[o.vis] || SUPVIS.default;
  const mode = o.mode || 'burst';
  const place = o.at === 'target' ? { x: C.tx, y: C.ty } : mode === 'object' ? { x: x + Math.cos(C.a) * 60, y: y + Math.sin(C.a) * 34 } : { x, y };
  vis(C, place.x, place.y, r, dur);
  C.w.sfx?.(o.sound || 'levelup');
  if (!C.ghost) C.p.act = { anim: 'cast', dir: C.a, t: 0, dur: 0.3 };
  const foe = (fx, fy, fr) => { if (o.foe) for (const e of within(C.w, fx, fy, fr)) C.hit(e, v.power || o.foe.power || 0.4, { ...C.push(e, { x: fx, y: fy }, o.foe.kb || 0), stun: o.foe.stun || 0, slow: o.foe.slow || 0, slowT: o.foe.slowT || 1.5, mark: o.foe.mark || v.mark || 0, markT: o.foe.markT || dur }); };
  if (o.single) {   // one marked prey for everyone to hunt
    const t = C.ghost ? null : C.tgt;
    if (t) { C.hit(t, v.power || 0.3, { kx: 0, ky: 0, mark: v.mark || 0.3, markT: dur }); C.fx.add({ type: 'mark', x: t.x, y: t.y, el: C.el, dur, follow: t, h: (t.r || 24) * 2 + 60 }); C.fx.add({ type: 'emblem', x: t.x, y: t.y, r: 70, el: C.el, dur, sym: 'brand', follow: t, spin: 1 }); }
  }
  if (mode === 'burst') {
    for (const p of allies(C, x, y, r)) bless(C, p, eff, dur);
    showOnViews(C, x, y, r, eff.sym);
    foe(x, y, o.foeR || r);
    return;
  }
  if (mode === 'delay') {
    later(C, o.delay || 2.5, () => { for (const p of allies(C, place.x, place.y, r)) bless(C, p, eff, dur); showOnViews(C, place.x, place.y, r, eff.sym); foe(place.x, place.y, o.foeR || r); vis.bloom?.(C, place.x, place.y, r); });
    return;
  }
  if (mode === 'wave') {
    const got = new Set(), hit = new Set(), sp = o.speed || 600, a0 = C.a;
    C.w.sk.act({ max: r / sp + 0.3, step: (dt, a) => {
      const d = a.t * sp;
      const inWave = (px, py) => o.line ? Math.abs((px - x) * Math.cos(a0) + (py - y) * Math.sin(a0) - d) < 50 && Math.abs(-(px - x) * Math.sin(a0) + (py - y) * Math.cos(a0)) < (o.width || 140) : Math.abs(Math.hypot(px - x, py - y) - d) < 50;
      for (const p of allies(C, x, y, r + 60)) if (!got.has(p) && inWave(p.x, p.y)) { got.add(p); bless(C, p, eff, dur); }
      if (!C.ghost && C.w.allies?.values) for (const al of C.w.allies.values()) if (al && !got.has(al) && al.x != null && inWave(al.x, al.y)) { got.add(al); C.fx.add({ type: 'halo', x: al.x, y: al.y, el: C.el, dur: 1.2, follow: al }); }
      if (o.foe) for (const e of live(C.w)) if (!hit.has(e) && inWave(e.x, e.y)) { hit.add(e); C.hit(e, v.power || o.foe.power || 0.4, { ...(o.line ? { kx: Math.cos(a0) * (o.foe.kb || 0), ky: Math.sin(a0) * (o.foe.kb || 0) } : C.push(e, { x, y }, o.foe.kb || 0)), slow: o.foe.slow || 0, slowT: 1.5 }); }
      return d < r;
    } });
    return;
  }
  if (mode === 'link') {
    let mate = null;
    if (!C.ghost && C.w.allies?.values) { let bd = r; for (const al of C.w.allies.values()) if (al && al.x != null && !al.dead) { const d = Math.hypot(al.x - x, al.y - y); if (d < bd) { bd = d; mate = al; } } }
    C.fx.add({ type: 'tether', a: C.ghost ? { x, y } : C.p, b: mate || (C.ghost ? null : { x: x + Math.cos(C.a) * 120, y: y + Math.sin(C.a) * 60 }), x2: x + Math.cos(C.a) * 120, y2: y + Math.sin(C.a) * 60, el: C.el, dur, waves: 4 });
    for (const p of allies(C, x, y, r)) bless(C, p, eff, dur);
    if (mate) C.fx.add({ type: 'halo', x: mate.x, y: mate.y, el: C.el, dur, follow: mate, sym: eff.sym });
    return;
  }
  // zone / aura / object: keep blessing whoever stands inside
  const follow = mode === 'aura' && !C.ghost ? C.p : null;
  const tick = o.tick || 0.5, inner = { ...eff };
  for (const k of BUFF_KINDS) if (inner[k]) inner.t = tick + 0.3;
  delete inner.heal; delete inner.shield; delete inner.ward; delete inner.deathWard;
  const first = { ...eff };
  for (const p of allies(C, place.x, place.y, r)) bless(C, p, first, dur);
  showOnViews(C, place.x, place.y, r, eff.sym);
  C.w.sk.act({ max: dur + 0.3, step: (dt, a) => {
    const px = follow ? follow.x : place.x, py = follow ? follow.y : place.y;
    a.acc = (a.acc || 0) + dt;
    if (a.acc >= tick) {
      a.acc = 0; a.n = (a.n || 0) + 1;
      for (const p of allies(C, px, py, r)) { bless(C, p, inner, tick + 0.3, false); if (eff.tickHeal) bless(C, p, { heal: eff.tickHeal }, 1, false); if (eff.tickRefresh) bless(C, p, { refresh: eff.tickRefresh }, 1, false); }
      if (o.foe && (!o.foeEvery || a.n % o.foeEvery === 0)) { foe(px, py, o.foeR || r); vis.pulse?.(C, px, py, r); }
      if (o.pull) pull(C.w, px, py, r, o.pull, tick);
      vis.tick?.(C, px, py, r, a.n);
    }
    return a.t < dur;
  } });
});

// pictures for the support skills — each one its own
const SUPVIS = {
  default(C, x, y, r) { C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: 0.5 }); C.fx.add({ type: 'rune', x, y, r: 90, el: C.el, dur: 1, sides: 6 }); },
  lullaby(C, x, y, r, d) { C.fx.add({ type: 'notes', x, y, r: r * 0.6, el: C.el, dur: 2.2, n: 12, sym: 'note' }); C.fx.add({ type: 'skyicon', x, y, sym: 'moon', el: C.el, dur: 2, size: 90, h: 220 }); C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: 0.9, band: 40 }); },
  sanctuary(C, x, y, r, d) { C.fx.add({ type: 'emblem', x, y, r, el: C.el, dur: d, sym: 'shield', spin: 0.2 }); C.fx.add({ type: 'pillar', x, y, w: 70, el: C.el, dur: 0.8, h: 520 }); C.fx.add({ type: 'dome', x, y: y + 34, el: C.el, dur: d, r: r * 0.55 }); },
  banner(C, x, y, r, d) { C.fx.add({ type: 'bannerfx', x, y, el: C.el, dur: d, sym: 'banner' }); C.fx.add({ type: 'emblem', x, y, r, el: C.el, dur: d, sym: 'banner', spin: 0.1 }); },
  link(C) { C.fx.add({ type: 'sym', mode: 'pop', sym: 'link', el: C.el, x: cx(C), y: cy(C) - 140, size: 70, dur: 1 }); },
  wind(C, x, y, r) { C.fx.add({ type: 'ringsyms', x, y, r: 70, el: C.el, dur: 1.2, sym: 'feather', n: 6, lift: 50, spin: 5, turn: true }); C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: 0.5, streaks: 20 }); },
  rewind(C, x, y, r) { C.fx.add({ type: 'timestop', x, y, r: r * 0.7, el: C.el, dur: 1.2 }); C.fx.add({ type: 'sym', mode: 'pop', sym: 'hourglass', el: C.el, x, y: y - 150, size: 70, dur: 1.1, spin: -3 }); },
  purify(C, x, y, r) { C.fx.add({ type: 'pillar', x, y, w: 90, el: C.el, dur: 0.9, h: 620 }); C.fx.add({ type: 'rainfx', x, y, r: r * 0.6, el: C.el, dur: 1.2, n: 30 }); C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: 0.6 }); },
  hymn(C, x, y, r, d) { C.fx.add({ type: 'notes', x, y, r: 70, el: C.el, dur: d, n: 8, follow: C.ghost ? null : C.p }); C.fx.add({ type: 'emblem', x, y, r, el: C.el, dur: d, sym: 'note', spin: 1, follow: C.ghost ? null : C.p }); },
  eagle(C, x, y, r) { C.fx.add({ type: 'skyicon', x, y, sym: 'eye', el: C.el, dur: 1.5, size: 90, h: 210 }); C.fx.add({ type: 'ringsyms', x, y, r: r * 0.5, el: C.el, dur: 1.4, sym: 'feather', n: 8, lift: 160, spin: 3, turn: true }); },
  blood(C, x, y, r) { C.fx.add({ type: 'emblem', x, y, r, el: C.el, dur: 1.4, sym: 'brand', spin: 1.2 }); C.fx.add({ type: 'sym', mode: 'pop', sym: 'heart', el: C.el, x, y: y - 140, size: 70, dur: 1 }); burst(C.w, x, y - 40, 40, C.el, { max: 300 }); },
  angel(C, x, y, r, d) { C.fx.add({ type: 'wings', x, y, el: C.el, dur: Math.min(d, 3), follow: C.ghost ? null : C.p }); C.fx.add({ type: 'pillar', x, y, w: 60, el: C.el, dur: 0.8, h: 600 }); },
  refresh(C, x, y, r) { C.fx.add({ type: 'sym', mode: 'pop', sym: 'drop', el: C.el, x, y: y - 140, size: 60, dur: 0.9 }); C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: 0.6, band: 30 }); C.fx.add({ type: 'ringsyms', x, y, r: 60, el: C.el, dur: 1, sym: 'hourglass', n: 3, lift: 90, size: 26, spin: 4 }); },
  spring(C, x, y, r, d) { C.fx.add({ type: 'field', x, y, r, el: C.el, dur: d }); C.fx.add({ type: 'sym', mode: 'rise', sym: 'drop', el: C.el, x, y: y - 50, size: 70, dur: d, halo: 1.2 }); },
  brand(C) { const t = C.ghost ? null : nearest(C.w, C.x, C.y, 600); C.fx.add({ type: 'sym', mode: 'pop', sym: 'brand', el: C.el, x: t ? t.x : C.tx, y: (t ? t.y : C.ty) - 110, size: 60, dur: 1.2 }); },
  rain(C, x, y, r, d) { C.fx.add({ type: 'rainfx', x, y, r, el: C.el, dur: d, n: 60 }); C.fx.add({ type: 'sym', mode: 'float', sym: 'rain', el: C.el, x, y: y - 260, size: 120, dur: d, halo: 1 }); C.fx.add({ type: 'field', x, y, r, el: C.el, dur: d }); },
  mend(C, x, y, r) { C.fx.add({ type: 'path', x, y, x2: x + Math.cos(C.a) * r, y2: y + Math.sin(C.a) * r, w: 140, el: C.el, dur: 1, grow: r / 600 }); C.fx.add({ type: 'sym', mode: 'fly', sym: 'wave', el: C.el, x, y: y - 40, x2: x + Math.cos(C.a) * r, y2: y + Math.sin(C.a) * r - 40, size: 110, dur: r / 600, h: 0 }); },
  stasis(C, x, y, r) { C.fx.add({ type: 'dome', x, y, el: C.el, dur: 2.2, r: 64, follow: C.ghost ? null : C.p }); C.fx.add({ type: 'sym', mode: 'float', sym: 'hourglass', el: C.el, x, y: y - 150, size: 50, dur: 2.2 }); },
  phoenix(C, x, y, r) { C.fx.add({ type: 'sym', mode: 'pop', sym: 'ember', el: C.el, x, y: y - 160, size: 90, dur: 1.2, halo: 1.4 }); C.fx.add({ type: 'ringsyms', x, y, r: r * 0.4, el: C.el, dur: 1.4, sym: 'feather', n: 8, lift: 80, spin: 4, turn: true }); },
  moonwell(C, x, y, r, d) { C.fx.add({ type: 'emblem', x, y, r, el: C.el, dur: d, sym: 'moon', spin: 0.3 }); C.fx.add({ type: 'sym', mode: 'rise', sym: 'drop', el: C.el, x, y: y - 30, size: 50, dur: d }); C.fx.add({ type: 'godray', x, y, el: C.el, dur: d, w: 30, h: 500 }); },
  drum(C, x, y, r, d) { C.fx.add({ type: 'sym', mode: 'float', sym: 'drum', el: C.el, x, y: y - 140, size: 64, dur: d, follow: C.ghost ? null : C.p, fy: -150 }); },
  mirror(C, x, y) { C.fx.add({ type: 'sym', mode: 'pop', sym: 'mirror', el: C.el, x, y: y - 140, size: 70, dur: 1.1 }); C.fx.add({ type: 'dome', x, y, el: C.el, dur: 3, r: 60, follow: C.ghost ? null : C.p }); },
  anchor(C, x, y, r, d) { C.fx.add({ type: 'sym', mode: 'fall', sym: 'anchor', el: C.el, x, y: y - 40, size: 100, dur: d, land: 0.3, h: 500 }); C.fx.add({ type: 'vortex', x, y, r, el: C.el, dur: d, arms: 4 }); later(C, 0.3, () => { C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: 0.5 }); C.w.shake?.(8, 0.3); }); },
  seed(C, x, y) { C.fx.add({ type: 'sym', mode: 'rise', sym: 'seed', el: C.el, x, y: y - 20, size: 40, dur: 2.6 }); C.fx.add({ type: 'rune', x, y, r: 60, el: C.el, dur: 2.6, sides: 5 }); },
  tide(C, x, y, r) { C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: r / 600 + 0.2, band: 50 }); C.fx.add({ type: 'ringsyms', x, y, r: 60, el: C.el, dur: 1, sym: 'wave', n: 6, lift: 20, size: 40, spin: 2 }); },
  oath(C, x, y, r) { C.fx.add({ type: 'sym', mode: 'pop', sym: 'ember', el: C.el, x, y: y - 140, size: 70, dur: 1 }); C.fx.add({ type: 'emblem', x, y, r, el: C.el, dur: 1.3, sym: 'brand', spin: 2 }); burst(C.w, x, y - 30, 40, C.el, { grav: -200 }); },
  starmap(C, x, y, r, d) { C.fx.add({ type: 'emblem', x, y, r, el: C.el, dur: d, sym: 'star', spin: 0.25 }); C.fx.add({ type: 'ringsyms', x, y, r: r * 0.8, el: C.el, dur: d, sym: 'star', n: 7, lift: 200, size: 22, spin: 0.6 }); },
  bulwark(C, x, y, r) { C.fx.add({ type: 'sym', mode: 'rise', sym: 'shield', el: C.el, x, y: y - 60, size: 120, dur: 1.2 }); C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: 0.5, band: 34 }); C.w.shake?.(6, 0.2); },
  echo(C, x, y, r) { C.fx.add({ type: 'notes', x, y, r: r * 0.5, el: C.el, dur: 1.6, n: 10 }); for (let i = 0; i < 3; i++) later(C, i * 0.18, () => C.fx.add({ type: 'shock', x, y, r: r * (0.5 + i * 0.25), el: C.el, dur: 0.5, band: 16 })); },
  oracle(C, x, y) { C.fx.add({ type: 'skyicon', x, y, sym: 'eye', el: C.el, dur: 1.8, size: 100, h: 220 }); C.fx.add({ type: 'ringsyms', x, y, r: 70, el: C.el, dur: 1.6, sym: 'star', n: 3, lift: 60, size: 24, spin: 3 }); },
  ankh(C, x, y, r) { C.fx.add({ type: 'sym', mode: 'pop', sym: 'ankh', el: C.el, x, y: y - 160, size: 96, dur: 1.4, halo: 1.5 }); C.fx.add({ type: 'godray', x, y, el: C.el, dur: 0.9, w: 80 }); C.fx.add({ type: 'emblem', x, y, r, el: C.el, dur: 1.4, sym: 'ankh', spin: 0.3 }); },
  knight(C, x, y, r) { C.fx.add({ type: 'sym', mode: 'pop', sym: 'helm', el: C.el, x, y: y - 150, size: 80, dur: 1.2, halo: 1.2 }); C.fx.add({ type: 'dome', x, y, el: C.el, dur: 2.5, r: 62, follow: C.ghost ? null : C.p }); C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: 0.5, band: 30 }); C.fx.add({ type: 'godray', x, y, el: C.el, dur: 0.6, w: 60 }); },
  paladin(C, x, y, r) { C.fx.add({ type: 'sym', mode: 'fall', sym: 'hammer', el: C.el, x, y: y - 40, size: 120, dur: 0.9, land: 0.3, h: 600, halo: 1.4 }); later(C, 0.3, () => { C.fx.add({ type: 'godray', x, y, el: C.el, dur: 0.6, w: 110 }); C.fx.add({ type: 'crack', x, y, r: r * 0.8, el: C.el, dur: 1.2, n: 9 }); C.w.shake?.(10, 0.35); }); C.fx.add({ type: 'emblem', x, y, r, el: C.el, dur: 1.4, sym: 'shield', spin: 0.4 }); },
  bard(C, x, y, r, d) { C.fx.add({ type: 'notes', x, y, r: 90, el: C.el, dur: d, n: 12, follow: C.ghost ? null : C.p }); C.fx.add({ type: 'sym', mode: 'float', sym: 'lute', el: C.el, x, y: y - 150, size: 60, dur: d, follow: C.ghost ? null : C.p, fy: -150 }); C.fx.add({ type: 'emblem', x, y, r, el: C.el, dur: d, sym: 'note', spin: 0.8, follow: C.ghost ? null : C.p }); },
  chrono(C, x, y, r) { C.fx.add({ type: 'timestop', x, y, r, el: C.el, dur: 1.4 }); C.fx.add({ type: 'ringsyms', x, y, r: 80, el: C.el, dur: 1.4, sym: 'clock', n: 4, lift: 110, size: 34, spin: -4 }); C.fx.add({ type: 'sym', mode: 'pop', sym: 'hourglass', el: C.el, x, y: y - 170, size: 70, dur: 1.2, spin: 3 }); },
  decree(C, x, y, r, d) { C.fx.add({ type: 'bannerfx', x: x - 60, y, el: C.el, dur: d, sym: 'crown' }); C.fx.add({ type: 'skyicon', x, y, sym: 'crown', el: C.el, dur: 2.2, size: 120, h: 260 }); C.fx.add({ type: 'godray', x, y, el: C.el, dur: 1, w: 120, h: 700 }); C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: 0.8, band: 50 }); C.w.shake?.(8, 0.4); },
};
SUPVIS.drum.pulse = (C, x, y, r) => { C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: 0.4, band: 26 }); C.w.sfx?.('slam'); };
SUPVIS.drum.tick = (C, x, y, r, n) => { if (n % 2) C.fx.add({ type: 'shock', x, y, r: r * 0.5, el: C.el, dur: 0.3, band: 10 }); };
SUPVIS.seed.bloom = (C, x, y, r) => { C.fx.add({ type: 'tree', x, y, el: C.el, dur: 1.6, h: 140 }); C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: 0.6, band: 40 }); C.w.sfx?.('potion'); };
SUPVIS.starmap.tick = (C, x, y, r, n) => {
  if (n % 3 || C.ghost) return;
  const t = within(C.w, x, y, r)[0];
  if (t) { C.fx.add({ type: 'sym', mode: 'fall', sym: 'star', el: C.el, x: t.x, y: t.y - 20, size: 36, dur: 0.5, land: 0.25, h: 420 }); later(C, 0.25, () => { if (!t.dead) C.hit(t, C.v.power || 0.6, { kx: 0, ky: 0 }); }); }
};
SUPVIS.anchor.pulse = (C, x, y, r) => C.fx.add({ type: 'shock', x, y, r: r * 0.6, el: C.el, dur: 0.3, band: 12 });
SUPVIS.sanctuary.pulse = (C, x, y, r) => C.fx.add({ type: 'shock', x, y, r, el: C.el, dur: 0.35, band: 10 });

export { allies };
