// v10 ร้านแคนดี้ (the Halloween candy shop). Prices are not hand-picked: they come from how rare and how strong each
// thing is (candyPrice), so a stronger weapon always costs more candy than a weaker one, and the shop shows the value
// (power per 1,000 candy) next to every price.
import { getItem } from './items.js';
import { gearScore } from '../systems/stats.js';
import { HW_SKINS, getSkin } from './halloween.js';
import { PETS_HW } from './hwPets.js';
import { STALL_DESIGNS } from './market.js';
import { HW_POTIONS } from './brewing.js';

const R50 = (v) => Math.round(v / 50) * 50;
// v10.2: limited weapons cost more (about 3–4 days of event play for one); see the patch notes
const BASE = { common: 200, uncommon: 500, rare: 1200, epic: 2500, legendary: 4000, mythic: 9000, limited: 14000, unknown: 0 };
export function powerOf(def) { return Math.round(gearScore(def.stats || {})); }
export function candyPrice(def) {
  if (!def) return 0;
  if (def.brew) { const g = Number(def.id.split('_').pop()) || 1; return R50(120 * Math.pow(g, 1.6)); }
  return R50((BASE[def.rarity] ?? 1000) + powerOf(def) * 25);
}
export function skinPrice(skin) {
  const w = getItem(skin.wid);
  return R50([0, 2000, 4000, 8000][skin.tier] * (1 + powerOf(w) / 2000));
}
const PET_PRICE = { rare: 3000, epic: 5500, legendary: 9000 };

// what the shop sells, by tab. Drop-only items are listed (greyed) so players know where to find them.
export const SHOP_TABS = Object.freeze([
  { id: 'weapons', name: 'อาวุธลิมิเต็ด' }, { id: 'skins', name: 'สกินอาวุธ' }, { id: 'gear', name: 'ชุด · ปีก · เครื่องราง' },
  { id: 'pets', name: 'สัตว์เลี้ยง' }, { id: 'relics', name: 'อาร์ติแฟกต์' }, { id: 'potions', name: 'ยาโพชั่น' }, { id: 'stalls', name: 'ซุ้มฮาโลวีน' },
]);
const SOLD = {
  weapons: ['w_hw_pumpkin_cannon', 'w_hw_witch_broom', 'w_hw_candy_lance', 'w_hw_pumpkin_blade'],
  gear: ['a_hw_jack_plate', 'a_hw_witch_robe', 'a_hw_reaper_shroud', 'wg_hw_bat', 'wg_hw_lantern', 'c_hw_candy_heart'],
};
const DROP_ONLY = {
  weapons: [['w_hw_reaper_scythe', 'ยมทูตเคียวนิลกาฬ 1.2%'], ['w_hw_twin_pistols', 'แม่มดจอมล่อลวง 0.01% (การันตี 1,500 ตัว)'], ['w_hw_muramasa', 'แม่มดแห่งความโกรธเกรี้ยว (ดันเจี้ยนลับ)']],
  gear: [['wg_hw_bone6', 'จักรพรรดิสวรรค์ 8%'], ['c_hw_spite_mask', 'เทพผู้พิทักษ์แห่งการแปรธาตุ (ทุกครั้ง)']],
};
export function shopRows(tab) {
  if (tab === 'weapons' || tab === 'gear') {
    return [
      ...SOLD[tab].map((id) => { const d = getItem(id); return { kind: 'item', id, def: d, price: candyPrice(d), power: powerOf(d) }; }),
      ...DROP_ONLY[tab].map(([id, from]) => { const d = getItem(id); return { kind: 'item', id, def: d, price: 0, dropOnly: from, power: powerOf(d) }; }),
    ];
  }
  if (tab === 'skins') return HW_SKINS.map((s) => ({ kind: 'skin', id: s.id, skin: s, def: getItem(s.wid), price: skinPrice(s) }));
  if (tab === 'pets') return Object.values(PETS_HW).filter((p) => !p.hw2).map((p) => ({ kind: 'pet', id: p.id, pet: p, price: PET_PRICE[p.rarity] || 5000 }));
  if (tab === 'potions') return Object.values(HW_POTIONS).filter((d) => Number(d.id.split('_').pop()) <= 3).map((d) => ({ kind: 'item', id: d.id, def: d, price: candyPrice(d) }));
  if (tab === 'stalls') return STALL_DESIGNS.filter((d) => d.halloween).map((d) => ({ kind: 'stall', id: d.id, design: d, price: d.candy }));
  return [];
}
export { getSkin };
