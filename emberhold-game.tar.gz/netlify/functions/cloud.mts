// Cloud saves: accounts and one save per account, plus the leaderboards. Logic lives in ../lib/cloud.mjs (shared with the local test server).
// By default this site forwards to the Cloudflare Worker so both sites share one set of accounts and rankings (../lib/proxy.mjs);
// set the Netlify env var EMBERHOLD_BACKEND=local to use Netlify Blobs again.
import { getStore } from '@netlify/blobs';
import { blobsKV } from '../lib/hub.mjs';
import { handleCloud } from '../lib/cloud.mjs';
import { blobsDocs } from '../lib/docs.mjs';
import { backendOf, forward } from '../lib/proxy.mjs';

export default async (req: Request, context: { ip?: string }) => {
  const env = process.env;
  if (backendOf(env)) return forward(req, 'cloud', { env, ip: context?.ip });
  return handleCloud(req, blobsKV(getStore({ name: 'emberhold-cloud', consistency: 'strong' })), Date.now(), { ip: context?.ip, docs: blobsDocs(getStore({ name: 'emberhold-live', consistency: 'strong' })), hub: blobsKV(getStore({ name: 'emberhold-hub', consistency: 'strong' })), gmSalt: env.GM_SALT, gmHash: env.GM_HASH });
};

export const config = { path: '/api/cloud' };
