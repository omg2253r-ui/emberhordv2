// v10 Halloween event dungeons and their monsters. They run in the shared co-op scene (scenes/coopScene.js) like the
// portal lands, with their own mechanics in battle/hwCoop.js and their own attack patterns in battle/hwBehaviours.js.
// Every monster has a model of its own, drawn live on the canvas (art/hwModels.js, `model`).
import { zoneStats } from './zoneMath.js';
import { HERB_IDS, HERBS } from './brewing.js';

// ------------------------------------------------------------------ the five event dungeons
export const HW_ZONES = Object.freeze([
  { id: 'hw_wild', n: 41, hw: true, event: 'hw', name: 'สวนแห่งพงไพร', level: 16, tier: 2, theme: 'hwwild', mechanic: 'none', partyMax: 4,
    desc: 'สวนป่าลึกที่ต้นไม้กระซิบชื่อคนที่หลงเข้ามา สมุนไพรกว่าร้อยชนิดขึ้นอยู่ที่นี่ มอนสเตอร์และผู้เฝ้าสวนจะทิ้งมันไว้เมื่อล้ม',
    mechanicText: 'ทุกตัวดรอปสมุนไพรสำหรับหม้อปรุงยาปีศาจ · แมนเดรกกรีดร้อง = วงกว้าง หยุดฟังชั่วครู่',
    monsters: ['hw_mandrake', 'hw_vine_snake', 'hw_witchcap'], boss: 'hw_treant',
    rooms: [[['hw_mandrake', 2], ['hw_vine_snake', 2]], [['hw_witchcap', 2], ['hw_vine_snake', 2], ['hw_mandrake', 2]], [['hw_witchcap', 2], ['hw_mandrake', 3]], 'boss'] },
  { id: 'hw_jack', n: 42, hw: true, event: 'hw', name: 'คฤหาสน์ฟักทองหลอน', level: 22, tier: 3, theme: 'hwmanor', mechanic: 'none', partyMax: 4,
    desc: 'คฤหาสน์ที่ฟักทองทุกลูกมีหน้า และทุกหน้ากำลังยิ้มให้คุณ เจ้าของบ้านคือแจ็กโอแลนเทิร์นผู้ถือเคียวมฤตยู',
    mechanicText: 'แจ็กโอแลนเทิร์นดึงผู้เล่นเข้าโลกกระจกให้สู้กับตัวเอง ชนะ = บอสเสียเลือด 20% · แพ้ = ล้มทันที (ของคืนชีพยังช่วยได้)',
    monsters: ['hw_pumpkin_imp', 'hw_lantern_ghost', 'hw_bat_swarm', 'hw_candy_skeleton'], boss: 'hw_jack',
    rooms: [[['hw_pumpkin_imp', 3], ['hw_lantern_ghost', 2]], [['hw_bat_swarm', 2], ['hw_candy_skeleton', 2], ['hw_pumpkin_imp', 2]], [['hw_candy_skeleton', 2], ['hw_lantern_ghost', 2], ['hw_bat_swarm', 2]], 'boss'] },
  { id: 'hw_reaper', n: 43, hw: true, event: 'hw', name: 'ทุ่งเก็บเกี่ยววิญญาณ', level: 30, tier: 3, theme: 'hwreaper', mechanic: 'none', partyMax: 4,
    desc: 'ทุ่งหญ้าสีเทาใต้จันทร์เต็มดวง ยมทูตถือเคียวสีดำยืนรอเก็บวิญญาณ ยิ่งถูกตี ยิ่งอยู่นาน มันยิ่งตื่น',
    mechanicText: 'ตีโดนยมทูตแล้วแคนดี้หลุดจากตัว · ยิ่งโดนดาเมจมาก/อยู่ในดันนาน ยมทูตยิ่งเก่งขึ้นและได้ท่าใหม่',
    monsters: [], boss: 'hw_reaper', rooms: ['boss'] },
  { id: 'hw_lure', n: 44, hw: true, event: 'hw', name: 'กระท่อมขนมของแม่มดจอมล่อลวง', level: 28, tier: 3, theme: 'hwcandy', mechanic: 'none', partyMax: 4,
    desc: 'บ้านขนมปังขิงกลางป่าที่หอมหวานจนลืมตัว แม่มดเจ้าของบ้านหลบเก่ง ล้อเลียนเก่ง และปายาสาปได้สิบห้าแบบ',
    mechanicText: 'ขวดยาสาป 15 แบบ (ดูชื่อคำสาปเหนือหัว) · ตีโดนแล้วแคนดี้หลุด · มีโอกาส 0.01% ได้ปืนคู่ฟักทอง (การันตีที่ 1,500 ตัว)',
    monsters: [], boss: 'hw_witch_lure', rooms: ['boss'] },
  { id: 'hw_deceiver', n: 45, hw: true, event: 'hw', name: 'หอแม่มดจอมหลอกลวง', level: 36, tier: 3, theme: 'hwtower', mechanic: 'none', partyMax: 8,
    desc: 'หอคอยที่ทุกอย่างโกหก วงเตือนบางวงเป็นของปลอม ร่างบางร่างเป็นภาพลวง ทำดาเมจใส่แม่มดให้ถึง 1,000,000 แล้วเธอจะสตั้น… และมิติสีดำบางอย่างจะเปิดออก',
    mechanicText: 'เล่นได้สูงสุด 8 คน (เฉพาะบอสนี้) · ดาเมจรวมถึง 1,000,000 = แม่มดสตั้น · มิติ ??? สีดำเปิดทางซ้าย',
    monsters: [], boss: 'hw_witch_deceiver', rooms: ['boss'], fixedHp: true,
    // the secret dungeon behind the ??? portal (opens only when the witch is stunned)
    nested: [{ hw: 'wizard' }, [['hw_g_dark', 1]], [['hw_g_wisdom', 1]], [['hw_g_light', 1]], [['hw_g_alchemy', 1]], [['hw_emperor', 1]], { hw: 'wrath' }],
    secret: true },
]);
export const getHwZone = (id) => HW_ZONES.find((z) => z.id === id) || null;
export const HW_ZONE_IDS = Object.freeze(HW_ZONES.map((z) => z.id));
// level gates (a gentle ladder: herbs first, the secret last)
export const HW_REQ = Object.freeze({ hw_wild: 10, hw_jack: 18, hw_reaper: 26, hw_lure: 24, hw_deceiver: 32 });

// ------------------------------------------------------------------ drop tables
const herbsOf = (rarities) => HERB_IDS.filter((id) => rarities.includes(HERBS[id].rarity)).map((id) => ({ id, weight: 1, qty: [1, 2] }));
const HERB_LOW = herbsOf(['common', 'uncommon']), HERB_MID = herbsOf(['uncommon', 'rare']), HERB_HIGH = herbsOf(['epic', 'legendary']);
const BLOOD = { chance: 0.4, entries: [{ id: 'm_bloodstone', weight: 1, qty: [1, 1] }] };
const POTS = (g) => [{ id: `bh_atk_${g}`, weight: 1, qty: [1, 1] }, { id: `bh_def_${g}`, weight: 1, qty: [1, 1] }, { id: `bh_hp_${g}`, weight: 1, qty: [1, 1] }, { id: `bh_candy_${g}`, weight: 1, qty: [1, 1] }];

// ------------------------------------------------------------------ monsters
// o: { model, ai, p (ai params), boss, hp/atk/def multipliers, radius, speed, flying, candyHit (chance of candy per hit),
//      candyKill [min,max], npc (talks/fights beside you, cannot be hit), ally, fixedHp (no party / bar scaling) }
function hk(id, level, zone, name, o) {
  const base = zoneStats(level), boss = !!o.boss;
  return [id, Object.freeze({
    id, name, sprite: 'hw_sprite', model: o.model, zone, boss, hw: true, faces: true, particles: o.particles || ['#ff8a1f', '#ffcf5a', '#3a2a4a'],
    hp: o.fixedHp || Math.round(base.hp * (o.hp ?? 1) * (boss ? 16 : 1)), atk: Math.round(base.atk * (o.atk ?? 1) * (boss ? 1.25 : 1)), def: Math.round(base.def * (o.def ?? 1) * (boss ? 1.4 : 1)),
    speed: o.speed ?? 110, radius: o.radius ?? 24, mass: o.mass ?? (boss ? 10 : 1), xp: Math.round(base.xp * (boss ? 16 : o.xp ?? 1)),
    gold: boss ? [base.gold[0] * 12, base.gold[1] * 12] : base.gold, sparks: boss ? 10 : 0,
    interruptAt: o.interruptAt ?? (boss ? 3 : 1.2), scale: o.scale, flying: !!o.flying, split: null, guardFront: o.guardFront || 0, revive: !!o.revive,
    ai: o.ai, ai_params: Object.freeze(o.p || {}), drops: o.drops || [],
    candyHit: o.candyHit || 0, candyKill: o.candyKill || null, npc: !!o.npc, ally: !!o.ally, fixedHp: !!o.fixedHp, untargetable: !!o.npc, noDeath: !!o.noDeath,
    clashable: !!o.clashable, chess: o.chess || null, noBars: true,
  })];
}
const L = { wild: 16, jack: 22, reaper: 30, lure: 28, dec: 36, sec: 38 };
export const HW_ENEMIES = Object.freeze(Object.fromEntries([
  // ---- สวนแห่งพงไพร (herbs)
  hk('hw_mandrake', L.wild, 'hw_wild', 'แมนเดรกกรีดร้อง', { model: 'mandrake', ai: 'hw_mandrake', hp: 1.0, radius: 20, speed: 60, candyKill: [1, 2],
    drops: [{ chance: 0.85, entries: HERB_LOW }, { chance: 0.25, entries: HERB_MID }], p: { hide: 1.6, scream: 0.9, ring: 210 } }),
  hk('hw_vine_snake', L.wild, 'hw_wild', 'งูเถาวัลย์หนามพิษ', { model: 'vineSnake', ai: 'hw_vine', hp: 0.9, radius: 22, speed: 150, candyKill: [1, 2],
    drops: [{ chance: 0.85, entries: HERB_LOW }, { chance: 0.2, entries: HERB_MID }], p: { lunge: 560, windup: 0.55 } }),
  hk('hw_witchcap', L.wild, 'hw_wild', 'เห็ดแม่มดเดินได้', { model: 'witchcap', ai: 'hw_witchcap', hp: 1.2, radius: 24, speed: 70, candyKill: [1, 3],
    drops: [{ chance: 0.9, entries: HERB_MID }, { chance: 0.05, entries: HERB_HIGH }], p: { blink: 3.2, spores: 3 } }),
  hk('hw_treant', L.wild, 'hw_wild', 'ต้นไม้พันปีผู้เฝ้าสวน', { boss: true, model: 'treant', ai: 'hw_treant', hp: 2.2, radius: 64, speed: 50, mass: 30, candyKill: [30, 50],
    drops: [{ chance: 1, entries: HERB_MID }, { chance: 1, entries: HERB_MID }, { chance: 1, entries: HERB_LOW }, { chance: 0.6, entries: HERB_HIGH }, { chance: 0.3, entries: HERB_HIGH }, BLOOD],
    p: { roots: 5, seeds: 6 } }),
  // ---- คฤหาสน์ฟักทองหลอน
  hk('hw_pumpkin_imp', L.jack, 'hw_jack', 'ปีศาจฟักทองกระโดด', { model: 'pumpkinImp', ai: 'hw_imp', hp: 0.9, radius: 20, speed: 120, candyKill: [2, 4],
    drops: [{ chance: 0.3, entries: HERB_LOW }, { chance: 0.04, entries: POTS(1) }], p: { hop: 0.9, bite: 1.0 } }),
  hk('hw_lantern_ghost', L.jack, 'hw_jack', 'ผีโคมลอยเงียบ', { model: 'lanternGhost', ai: 'hw_ghost', hp: 0.8, radius: 22, speed: 90, flying: true, candyKill: [2, 4],
    drops: [{ chance: 0.3, entries: HERB_LOW }, { chance: 0.04, entries: POTS(1) }], p: { phase: 2.4, volley: 3 } }),
  hk('hw_bat_swarm', L.jack, 'hw_jack', 'ฝูงค้างคาวดูดฝัน', { model: 'batSwarm', ai: 'hw_bats', hp: 0.7, radius: 26, speed: 170, flying: true, candyKill: [2, 4],
    drops: [{ chance: 0.3, entries: HERB_LOW }], p: { dive: 720, windup: 0.6 } }),
  hk('hw_candy_skeleton', L.jack, 'hw_jack', 'โครงกระดูกลูกกวาด', { model: 'candySkeleton', ai: 'hw_skeleton', hp: 1.1, radius: 22, speed: 95, revive: true, candyKill: [3, 5],
    drops: [{ chance: 0.3, entries: HERB_MID }, { chance: 0.05, entries: POTS(2) }], p: { throwEvery: 1.6 } }),
  hk('hw_jack', L.jack, 'hw_jack', 'แจ็กโอแลนเทิร์น เจ้าเคียวมฤตยู', { boss: true, model: 'jack', ai: 'hw_jack', hp: 3.2, radius: 52, speed: 130, candyKill: [80, 120],
    drops: [{ chance: 1, entries: POTS(2) }, { chance: 0.6, entries: HERB_MID }, { chance: 0.06, entries: [{ id: 'a_hw_jack_plate', weight: 1, qty: [1, 1] }] },
      { chance: 0.04, entries: [{ id: 'wg_hw_bat', weight: 1, qty: [1, 1] }] }, { chance: 0.02, entries: [{ id: 'w_hw_pumpkin_blade', weight: 1, qty: [1, 1] }] }, BLOOD],
    p: { mirrorEvery: 22 } }),
  hk('hw_mirror_self', L.jack, 'hw_jack', 'เงาในกระจก (ตัวคุณเอง)', { model: 'mirrorSelf', ai: 'hw_none', hp: 1, radius: 20, speed: 200 }),
  // ---- ทุ่งเก็บเกี่ยววิญญาณ
  hk('hw_reaper', L.reaper, 'hw_reaper', 'ยมทูตเคียวนิลกาฬ', { boss: true, model: 'reaper', ai: 'hw_reaper', hp: 5, radius: 50, speed: 150, flying: true, candyHit: 0.45, candyKill: [150, 220],
    drops: [{ chance: 1, entries: POTS(3) }, { chance: 0.012, entries: [{ id: 'w_hw_reaper_scythe', weight: 1, qty: [1, 1] }] }, { chance: 0.03, entries: [{ id: 'a_hw_reaper_shroud', weight: 1, qty: [1, 1] }] },
      { chance: 0.02, entries: [{ id: 'wg_hw_lantern', weight: 1, qty: [1, 1] }] }, BLOOD] }),
  hk('hw_soul_wisp', L.reaper, 'hw_reaper', 'ดวงวิญญาณหลงทาง', { model: 'soulWisp', ai: 'hw_soulwisp', hp: 0.5, radius: 16, speed: 140, flying: true, candyHit: 0.25, xp: 0.3 }),
  // ---- กระท่อมขนม
  hk('hw_witch_lure', L.lure, 'hw_lure', 'แม่มดจอมล่อลวง', { boss: true, model: 'witchLure', ai: 'hw_lure', hp: 4.2, radius: 40, speed: 210, candyHit: 0.4, candyKill: [140, 200],
    drops: [{ chance: 1, entries: POTS(3) }, { chance: 0.03, entries: [{ id: 'a_hw_witch_robe', weight: 1, qty: [1, 1] }] }, { chance: 0.02, entries: [{ id: 'c_hw_candy_heart', weight: 1, qty: [1, 1] }] }, BLOOD] }),
  hk('hw_gumdrop', L.lure, 'hw_lure', 'เยลลี่กัมดรอปกระเด้ง', { model: 'gumdrop', ai: 'hw_gumdrop', hp: 0.6, radius: 18, speed: 160, candyHit: 0.3, xp: 0.4 }),
  // ---- หอแม่มดจอมหลอกลวง (8 players) — HP exactly 1,000,000: at zero she is stunned, not killed
  hk('hw_witch_deceiver', L.dec, 'hw_deceiver', 'แม่มดจอมหลอกลวง', { boss: true, model: 'witchDeceiver', ai: 'hw_deceiver', fixedHp: 1_000_000, atk: 1.1, radius: 42, speed: 180, noDeath: true, candyHit: 0.12 }),
  hk('hw_illusion', L.dec, 'hw_deceiver', 'ภาพลวงของแม่มด', { model: 'witchDeceiver', ai: 'hw_illusion', hp: 0.8, radius: 40, speed: 200, xp: 0.2 }),
  // ---- ดันเจี้ยนลับของพ่อมด
  hk('hw_wizard_npc', L.sec, 'hw_deceiver', 'พ่อมดผู้หายสาบสูญ', { model: 'wizard', ai: 'hw_wizard', hp: 1, npc: true, radius: 30, speed: 0, mass: 999 }),
  hk('hw_wizard_ally', L.sec, 'hw_deceiver', 'เทพแห่งการสร้างสรรค์', { model: 'wizardGod', ai: 'hw_wizard_ally', hp: 1, npc: true, ally: true, radius: 34, speed: 120, mass: 999 }),
  hk('hw_g_dark', L.sec, 'hw_deceiver', 'ผู้พิทักษ์แห่งความมืด', { boss: true, model: 'gDark', ai: 'hw_g_dark', hp: 5, radius: 44, speed: 160, particles: ['#7a3aff', '#14101c', '#c8a8ff'] }),
  hk('hw_g_dark_clone', L.sec, 'hw_deceiver', 'ร่างแยกแห่งความมืด', { model: 'gDark', ai: 'hw_g_dark_clone', hp: 0.6, radius: 44, speed: 160, xp: 0.1 }),
  hk('hw_g_pillar', L.sec, 'hw_deceiver', 'เสาค้ำจุนพลังมืด', { model: 'pillar', ai: 'hw_static', hp: 4, radius: 34, speed: 0, mass: 999, xp: 0.2 }),
  hk('hw_shadow_fake', L.sec, 'hw_deceiver', 'ร่างเงาปลอม', { model: 'shadowFake', ai: 'hw_shadow_fake', hp: 0.7, radius: 22, speed: 170, xp: 0.2 }),
  hk('hw_g_wisdom', L.sec, 'hw_deceiver', 'ผู้พิทักษ์แห่งปัญญา', { boss: true, model: 'gWisdom', ai: 'hw_g_wisdom', hp: 5, radius: 44, speed: 90, particles: ['#5fb0ff', '#e8f4ff', '#1a2438'] }),
  ...[['pawn', 'เบี้ยหินอ่อน', 0.6], ['knight', 'ม้าหินอ่อน', 0.9], ['bishop', 'โคนหินอ่อน', 0.9], ['rook', 'เรือหินอ่อน', 1.2], ['queen', 'ควีนหินอ่อน', 1.4], ['king', 'คิงหินอ่อน', 1.6]]
    .map(([k, n, hp]) => hk(`hw_chess_${k}`, L.sec, 'hw_deceiver', n, { model: 'chess', chess: k, ai: 'hw_chess', hp, radius: 26, speed: 0, mass: 50, xp: 0.2 })),
  hk('hw_g_light', L.sec, 'hw_deceiver', 'ผู้พิทักษ์แห่งแสงสว่าง', { boss: true, model: 'gLight', ai: 'hw_g_light', hp: 5, radius: 46, speed: 240, clashable: true, particles: ['#fff3c4', '#ffe89a', '#ffffff'] }),
  hk('hw_g_alchemy', L.sec, 'hw_deceiver', 'เทพผู้พิทักษ์แห่งการแปรธาตุ', { boss: true, model: 'gAlchemy', ai: 'hw_g_alchemy', hp: 5, radius: 40, speed: 200, particles: ['#6fe08a', '#ff6a1a', '#5fb0ff'] }),
  hk('hw_emperor', L.sec, 'hw_deceiver', 'จักรพรรดิสวรรค์ผู้ไร้เลือดเนื้อ', { boss: true, model: 'emperor', ai: 'hw_emperor', hp: 8, radius: 56, speed: 140, guardFront: 0.75, particles: ['#efe4cc', '#ffe89a', '#ffffff'],
    drops: [{ chance: 0.08, entries: [{ id: 'wg_hw_bone6', weight: 1, qty: [1, 1] }] }, { chance: 1, entries: POTS(4) }] }),
  hk('hw_emp_imp', L.sec, 'hw_deceiver', 'ฟักทองรับใช้จักรพรรดิ', { model: 'pumpkinImp', ai: 'hw_imp', hp: 0.6, radius: 20, speed: 130, candyHit: 0.5, xp: 0.2, p: { hop: 0.8, bite: 1 } }),
  hk('hw_emp_ghost', L.sec, 'hw_deceiver', 'โคมผีรับใช้จักรพรรดิ', { model: 'lanternGhost', ai: 'hw_ghost', hp: 0.5, radius: 22, speed: 90, flying: true, candyHit: 0.5, xp: 0.2, p: { phase: 2.4, volley: 3 } }),
  hk('hw_witch_wrath', L.sec, 'hw_deceiver', 'แม่มดแห่งความโกรธเกรี้ยว', { boss: true, model: 'witchWrath', ai: 'hw_wrath', hp: 7, atk: 0.55, radius: 44, speed: 200, particles: ['#ff3a1a', '#ffcf5a', '#3a0a0a'] }),
]));
export const HW_ENEMY_IDS = Object.freeze(Object.keys(HW_ENEMIES));
