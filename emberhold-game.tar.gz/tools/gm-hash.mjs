// Make the game-master password hash for the server (no password is ever stored in the game files).
// Run: node tools/gm-hash.mjs "your new password"
// Then set two secrets on the Cloudflare Worker (Settings → Variables and Secrets): GM_SALT and GM_HASH (printed below).
import { randomBytes, scryptSync } from 'node:crypto';
const pass = process.argv[2];
if (!pass || pass.length < 8) { console.error('ใส่รหัสผ่านอย่างน้อย 8 ตัว: node tools/gm-hash.mjs "รหัสใหม่"'); process.exit(1); }
const salt = randomBytes(16).toString('hex');
console.log('GM_SALT =', salt);
console.log('GM_HASH =', scryptSync(pass.normalize('NFC'), salt, 32, { N: 16384, r: 8, p: 1 }).toString('hex'));
