// v10.2 สกินอาวุธ: every weapon in the game can wear a skin.
//   · normal weapons: ten skins each, one per tier (ธรรมดา → ซีเคร็ต), from the skin boxes in the shop (gold)
//   · Halloween weapons: their three event skins (data/halloween.js), from the Halloween skin box (candy) or the candy shop
// A skin re-colours the weapon's own model, adds crit (and a little more at high tiers) while worn, from อีปิค up keeps a
// living effect around the hero all the time, and from เลเจนด์ up changes how every hit of the weapon looks.
import { ITEMS, getItem } from './items.js';
import { HW_SKINS } from './halloween.js';

// ------------------------------------------------------------------ the ten tiers
// w: box weight (per 10 000) · crit / critMult / atkPct: worn bonus · aura: living effect · hit: own hit effect
export const SKIN_TIERS = Object.freeze([
  { id: 'common', n: 0, name: 'ธรรมดา', col: '#c9bfa9', w: 3200, crit: 0.005, critMult: 0, atkPct: 0, refund: 300 },
  { id: 'uncommon', n: 1, name: 'ไม่ธรรมดา', col: '#7fc77a', w: 2500, crit: 0.01, critMult: 0, atkPct: 0, refund: 600 },
  { id: 'rare', n: 2, name: 'แรร์', col: '#5fa8ec', w: 1800, crit: 0.015, critMult: 0.02, atkPct: 0, refund: 1200 },
  { id: 'epic', n: 3, name: 'อีปิค', col: '#c27ff0', w: 1250, crit: 0.02, critMult: 0.04, atkPct: 0.01, aura: true, refund: 2500 },
  { id: 'legendary', n: 4, name: 'เลเจนด์', col: '#f2b544', w: 700, crit: 0.025, critMult: 0.06, atkPct: 0.02, aura: true, hit: true, refund: 5000 },
  { id: 'divine', n: 5, name: 'เทพ', col: '#fff3a0', w: 300, crit: 0.03, critMult: 0.08, atkPct: 0.03, aura: true, hit: true, refund: 9000 },
  { id: 'mythical', n: 6, name: 'เทพนิยาย', col: '#ff7ab8', w: 140, crit: 0.035, critMult: 0.1, atkPct: 0.04, aura: true, hit: true, refund: 15000 },
  { id: 'universe', n: 7, name: 'จักรวาล', col: '#7a9aff', w: 60, crit: 0.04, critMult: 0.12, atkPct: 0.05, aura: true, hit: true, refund: 25000 },
  { id: 'cosmic', n: 8, name: 'คอสมิค', col: '#5affe0', w: 25, crit: 0.045, critMult: 0.15, atkPct: 0.06, aura: true, hit: true, refund: 40000 },
  { id: 'secret', n: 9, name: 'ซีเคร็ต', col: '#ff2a5a', w: 5, crit: 0.05, critMult: 0.18, atkPct: 0.07, aura: true, hit: true, refund: 80000 },
]);
export const tierOfSkin = (sk) => SKIN_TIERS[sk?.t ?? 0] || SKIN_TIERS[0];

// ------------------------------------------------------------------ per-tier looks
// For every tier a handful of themes; each weapon takes the theme its own number points to, so neighbouring weapons in
// the same tier never look the same. pal: blade · edge · metal · grip · glow · gem
const THEMES = [
  [['เหล็กกล้าขัดเงา', ['#cfd6de', '#ffffff', '#8a8f98', '#4a3a2a', '#e8eef5', '#9aa4b0']], ['ไม้โอ๊กแกะลาย', ['#b08a5a', '#e8d0a8', '#6b4a2c', '#3a2a1a', '#e0c8a0', '#8a6a3a']],
    ['หินแกรนิต', ['#9a9690', '#d8d4cc', '#5a5650', '#3a3632', '#c8c4bc', '#7a7670']], ['ทองแดงหม่น', ['#c87a4a', '#f0b08a', '#8a4a2a', '#3a2418', '#f0a878', '#a85a30']]],
  [['ใบไผ่เขียวหยก', ['#6ac07a', '#d8ffd8', '#3a7a4a', '#2a3a1a', '#9fe0a0', '#3aa05a']], ['ทะเลสาบเงียบ', ['#5aa0c8', '#d8f0ff', '#2a5a7a', '#1a2a3a', '#8fd0f0', '#2a7aa8']],
    ['ทรายพระอาทิตย์', ['#e0c07a', '#fff0c8', '#a8803a', '#4a3418', '#ffe0a0', '#c8902a']], ['ดอกท้อสีชมพู', ['#f0a0b8', '#fff0f4', '#a85a78', '#3a1a28', '#ffc8d8', '#d86a90']]],
  [['คลื่นทะเลลึก', ['#2a7ac8', '#a8e0ff', '#1a4a8a', '#0a1a3a', '#5ac8ff', '#1a8ae0']], ['ป่าสนหิมะ', ['#3a8a6a', '#e8fff4', '#1a5a40', '#1a2a20', '#9fe6cf', '#2aa080']],
    ['ทับทิมสายเลือด', ['#c2142a', '#ffb0b8', '#7a0a1a', '#2a0a0a', '#ff4a5a', '#e0203a']], ['อเมทิสต์หม่น', ['#8a5ac8', '#e8d8ff', '#5a3a8a', '#1a1030', '#b88aff', '#7a3ad0']]],
  [['เพลิงอัสนี', ['#ff6a1a', '#fff0a0', '#a8300a', '#2a0a04', '#ffb03a', '#ff3a0a']], ['น้ำแข็งนิรันดร์', ['#8fd6ff', '#ffffff', '#3a7fbf', '#0a2a4a', '#c8f0ff', '#5ac0ff']],
    ['พิษม่วงหมอก', ['#9a4ad0', '#e8ff9a', '#5a2a8a', '#1a0a2a', '#a8e05a', '#c87aff']], ['สายฟ้าคำราม', ['#ffe65a', '#ffffff', '#7a6cff', '#1a1440', '#fff9c4', '#c8d8ff']]],
  [['มังกรทองคำ', ['#f2b544', '#fff6c0', '#a8701a', '#3a1a08', '#ffd27a', '#ff8a1f']], ['พายุสุริยะ', ['#ffcf5a', '#ffffff', '#c2412f', '#3a1008', '#ffe08a', '#ff6a1a']],
    ['คลื่นอัสนีมรกต', ['#3ad08a', '#e0ffe8', '#1a7a4a', '#0a2a18', '#7affb8', '#00c870']]],
  [['ปีกเทวาขาวทอง', ['#ffffff', '#fff6c0', '#e0b45a', '#c8a050', '#fff3a0', '#ffe08a']], ['รัศมีเทพสวรรค์', ['#fff8e0', '#ffffff', '#ffd27a', '#a88a4a', '#fffbd0', '#ffe8a0']],
    ['เทพธิดาแสงจันทร์', ['#e8f0ff', '#ffffff', '#b8c8f0', '#5a6a9a', '#d8e8ff', '#a8c0ff']]],
  [['หงส์เพลิงนิรันดร์', ['#ff5a3a', '#fff3c4', '#ff9a1a', '#5a1a0a', '#ffcf5a', '#ff2a6a']], ['มังกรหยกเทพนิยาย', ['#3ae0a0', '#e8fff4', '#1a8a6a', '#0a2a20', '#9fffd8', '#00e0a0']],
    ['ราชินีภูตชมพู', ['#ff7ab8', '#ffe8f4', '#c23a8a', '#3a0a2a', '#ffb0d8', '#ff3aa0']]],
  [['ดาราจักรทางช้างเผือก', ['#3a3aa8', '#e0e8ff', '#1a1a5a', '#0a0a20', '#7a9aff', '#c8d0ff']], ['ดาวเคราะห์วงแหวน', ['#5a7ad0', '#ffe8c0', '#2a3a7a', '#101830', '#a8c0ff', '#ffd08a']],
    ['สุริยะจักรวาล', ['#2a2a6a', '#fff6c0', '#ff8a1f', '#0a0a1a', '#ffcf5a', '#7a9aff']]],
  [['เนบิวลาสีรุ้ง', ['#5affe0', '#ffffff', '#8a3aff', '#0a0a20', '#ff7ad8', '#5ae0ff']], ['ดาวหางคอสมิค', ['#7afff0', '#ffffff', '#3a5aff', '#0a1030', '#c8fff8', '#ff9ae0']],
    ['หลุมดำพลิกฟ้า', ['#1a0a2a', '#ff9af0', '#5a1a8a', '#000000', '#c86aff', '#5affe0']]],
  [['???', ['#0a0a0a', '#ff2a5a', '#ffffff', '#000000', '#ff2a5a', '#5affe0']], ['ความจริงที่ถูกลบ', ['#f0f0f0', '#000000', '#ff2a5a', '#1a1a1a', '#ffffff', '#ff2a5a']]],
];
// living effects (aura) by tier, and how every hit looks (hit) from เลเจนด์ up
const AURAS = [null, null, null, ['ember_rise', 'frost_mote', 'leaf_spiral', 'spark_coil'], ['thunder_coil', 'flame_wings', 'tidal_orbit'], ['halo_feather', 'sun_crown', 'moon_veil'],
  ['dragon_wisp', 'phoenix_tail', 'fairy_ring'], ['planet_orbit', 'galaxy_disc', 'star_rain'], ['nebula_cloud', 'comet_trail', 'black_hole'], ['glitch', 'void_eye']];
const HITS = [null, null, null, null, 'fork', 'cross', 'fang', 'starburst', 'nebula', 'glitchcut'];

const hash = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
// colour keys of every weapon model → the skin palette slot they take
const KEYMAP = { blade: 0, body: 0, head: 0, edge: 1, bevel: 1, string: 1, guard: 2, trim: 2, gold: 2, goldDark: 2, grip: 3, wrap: 3, wood: 3, shaft: 3, linen: 3, vine: 3, bristle: 3, glow: 4, orb: 5, gem: 5, rune: 5, lapis: 5, stain: 5 };
function recolor(art, pal) {
  const out = {};
  for (const [k, v] of Object.entries(art || {})) if (typeof v === 'string' && v.startsWith('#') && KEYMAP[k] != null) out[k] = pal[KEYMAP[k]];
  out.glow = pal[4];
  return out;
}

// the ten skins of one weapon
function skinsForWeapon(def) {
  const h = hash(def.id), short = def.name.replace(/^(ดาบ|หอก|ธนู|คทา|เคียว|มีด)/, (m) => m);
  return THEMES.map((themes, t) => {
    const [theme, pal] = themes[(h + t * 7) % themes.length];
    const aura = AURAS[t] ? AURAS[t][(h >> 3) % AURAS[t].length] : null;
    return Object.freeze({ id: `${def.id}~s${t}`, wid: def.id, t, name: `${short} · ${theme}`, theme, pal, art: recolor(def.art, pal), aura, hit: HITS[t], fx: null });
  });
}
const NORMAL_WEAPONS = Object.values(ITEMS).filter((d) => d.category === 'weapon' && !d.art?.hw);
const GEN = NORMAL_WEAPONS.flatMap(skinsForWeapon);
// Halloween skins keep their own effects; their tiers: skin 1 อีปิค · skin 2 เทพ · skin 3 คอสมิค
const HW_TIER = { 1: 3, 2: 5, 3: 8 };
const HW = HW_SKINS.map((s) => Object.freeze({ ...s, t: HW_TIER[s.n] ?? 3, pal: [s.art.blade || s.art.body || s.art.shaft || s.art.wood, s.art.edge || s.art.trim, s.art.trim || '#e0b45a', '#2a1a10', s.art.glow, s.art.orb || s.art.glow], aura: null, hit: s.n >= 2 ? (s.n === 2 ? 'cross' : 'nebula') : null, event: 'hw' }));

export const SKINS = Object.freeze(Object.fromEntries([...GEN, ...HW].map((s) => [s.id, s])));
export const SKIN_IDS = Object.freeze(Object.keys(SKINS));
export const getSkinAny = (id) => (typeof id === 'string' && Object.prototype.hasOwnProperty.call(SKINS, id) ? SKINS[id] : null);
export const skinsOfWeapon = (wid) => SKIN_IDS.filter((id) => SKINS[id].wid === wid).map((id) => SKINS[id]).sort((a, b) => a.t - b.t);
export const GEN_SKIN_COUNT = GEN.length;

// ------------------------------------------------------------------ boxes
// gold boxes in the shop: every skin, or one weapon family; the candy box holds the Halloween skins
const WT_NAMES = { sword: 'ดาบ', katana: 'ดาบซามูไร', dagger: 'ดาบเล็กคู่', greatsword: 'ดาบใหญ่', staff: 'คทาเวท', bow: 'ธนู', spear: 'หอก', scythe: 'เคียว', twinblades: 'ดาบคู่' };
export const SKIN_BOXES = Object.freeze([
  { id: 'all', name: 'กล่องสกินรวมทุกอาวุธ', desc: 'สุ่มจากสกินทุกอาวุธในเกม', price: 12000, cur: 'gold', pool: (s) => !s.event },
  ...Object.entries(WT_NAMES).map(([wt, name]) => ({ id: `wt_${wt}`, wtype: wt, name: `กล่องสกิน${name}`, desc: `สุ่มเฉพาะสกินของ${name}ทุกเล่ม`, price: 16000, cur: 'gold', pool: (s) => !s.event && getItem(s.wid)?.wtype === wt })),
  { id: 'hw', name: 'กล่องสกินฮาโลวีน', desc: 'สุ่มสกินของอาวุธลิมิเต็ดฮาโลวีน 21 แบบ', price: 2400, cur: 'candy', pool: (s) => s.event === 'hw', hw: true },
]);
export const getBox = (id) => SKIN_BOXES.find((b) => b.id === id) || null;
export const PITY_AT = 60;          // a box of เทพ or better is guaranteed by the 60th box without one
export const PITY_TIER = 5;
export { WT_NAMES };
