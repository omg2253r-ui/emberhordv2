// v10 จอยเกม in menus: while a window is open, or outside the action scenes (camp menus), the gamepad moves a gold
// focus ring between buttons (stick / d-pad), A clicks, B closes the window (like Esc), LB / RB switch tabs, and a
// slider under the ring moves with left / right. Start opens Settings / pause from anywhere.
import { readPad } from './input.js';

const SEL = 'button:not([disabled]), input:not([disabled]):not([type=hidden]), select:not([disabled]), [data-pad], a[href]';
const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 2 && r.height > 2 && r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth && getComputedStyle(el).visibility !== 'hidden'; };

export function createPadUi({ gameHasPad, onStart, onConnect }) {
  let prev = [], cur = null, repeatAt = 0, lastDir = '', known = false;
  function scope() {
    const backs = document.querySelectorAll('.modal-back');
    if (backs.length) return backs[backs.length - 1];
    return document.getElementById('ui') || document.body;
  }
  function items(root) { return [...root.querySelectorAll(SEL)].filter(visible); }
  function focus(el) {
    if (cur && cur !== el) cur.classList.remove('pad-focus');
    cur = el;
    if (!el) return;
    el.classList.add('pad-focus');
    el.focus?.({ preventScroll: true });
    el.scrollIntoView?.({ block: 'nearest', inline: 'nearest' });
  }
  function move(dir) {
    const list = items(scope());
    if (!list.length) return;
    if (!cur || !list.includes(cur)) { focus(list[0]); return; }
    if (cur.type === 'range' && (dir === 'left' || dir === 'right')) {
      const step = Number(cur.step) || Math.max(1, Math.round((Number(cur.max) - Number(cur.min)) / 20));
      cur.value = String(Number(cur.value) + (dir === 'right' ? step : -step));
      cur.dispatchEvent(new Event('input', { bubbles: true })); cur.dispatchEvent(new Event('change', { bubbles: true }));
      return;
    }
    const a = cur.getBoundingClientRect(), ax = a.left + a.width / 2, ay = a.top + a.height / 2;
    let best = null, bd = Infinity;
    for (const el of list) {
      if (el === cur) continue;
      const b = el.getBoundingClientRect(), bx = b.left + b.width / 2, by = b.top + b.height / 2, dx = bx - ax, dy = by - ay;
      const ok = dir === 'left' ? dx < -4 : dir === 'right' ? dx > 4 : dir === 'up' ? dy < -4 : dy > 4;
      if (!ok) continue;
      const main = dir === 'left' || dir === 'right' ? Math.abs(dx) : Math.abs(dy), side = dir === 'left' || dir === 'right' ? Math.abs(dy) : Math.abs(dx);
      const d = main + side * 2.5;
      if (d < bd) { bd = d; best = el; }
    }
    if (best) focus(best);
  }
  function back() {
    const root = scope();
    if (root.classList?.contains('modal-back')) { window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true })); return; }
    document.querySelector('[data-action="close-panel"], .sheet-close')?.click();
  }
  function tab(step) {
    const root = scope();
    const tabs = [...root.querySelectorAll('[role=tab], [data-hw-tab], [data-gm-tab], [data-honor-tab], .tab')].filter(visible);
    if (!tabs.length) return;
    const i = tabs.findIndex((t) => t.getAttribute('aria-selected') === 'true' || t.getAttribute('aria-checked') === 'true' || t.classList.contains('on'));
    tabs[(Math.max(0, i) + step + tabs.length) % tabs.length].click();
  }
  function frame(t) {
    requestAnimationFrame(frame);
    const pad = readPad();
    if (!pad) { if (known) { known = false; onConnect?.(false); } return; }
    if (!known) { known = true; onConnect?.(true, pad.id); }
    const down = pad.buttons.map((b) => !!b.pressed);
    const edge = (i) => down[i] && !prev[i];
    const menus = !gameHasPad() || !!document.querySelector('.modal-back');
    if (edge(9)) onStart?.();
    if (menus) {
      const x = pad.axes[0] || 0, y = pad.axes[1] || 0;
      const dir = down[12] || y < -0.6 ? 'up' : down[13] || y > 0.6 ? 'down' : down[14] || x < -0.6 ? 'left' : down[15] || x > 0.6 ? 'right' : '';
      if (dir && (dir !== lastDir || t > repeatAt)) { move(dir); repeatAt = t + (dir === lastDir ? 120 : 380); }
      lastDir = dir;
      if (edge(0)) { if (cur && document.contains(cur)) { if (cur.type === 'checkbox') { cur.click(); } else cur.click(); } else move('down'); }
      if (edge(1)) back();
      if (edge(4)) tab(-1);
      if (edge(5)) tab(1);
    } else if (cur) { cur.classList.remove('pad-focus'); cur = null; }
    prev = down;
  }
  requestAnimationFrame(frame);
  return { get focused() { return cur; } };
}
