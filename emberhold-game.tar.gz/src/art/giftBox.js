// v10 กล่องแจกจากแอดมินจ้า — the game master's gift box on the ground (village and the Halloween world).
// a game-master gift box: falls from the sky along the trail, then bobs and glows until someone opens it
export function drawGiftBox(ctx, b, time) {
  const age = (Date.now() - b.at) / 1000, fall = Math.max(0, 1 - age / 2.2), z = fall * fall * 700, bob = fall ? 0 : Math.sin(time * 3 + b.idx) * 4;
  ctx.save();
  ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(b.x, b.y, 22 * (1 - fall * 0.6), 7, 0, 0, Math.PI * 2); ctx.fill();
  ctx.translate(b.x, b.y - 26 - z - bob);
  if (!fall) { ctx.globalCompositeOperation = 'lighter'; const g = ctx.createRadialGradient(0, 0, 4, 0, 0, 60); g.addColorStop(0, 'rgba(255,220,120,0.7)'); g.addColorStop(1, 'rgba(255,200,80,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, 60, 0, Math.PI * 2); ctx.fill(); ctx.globalCompositeOperation = 'source-over'; }
  ctx.fillStyle = '#6a2ab0'; ctx.strokeStyle = '#120c09'; ctx.lineWidth = 3; ctx.beginPath(); ctx.roundRect(-22, -18, 44, 38, 5); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#ffd34a'; ctx.fillRect(-5, -18, 10, 38); ctx.fillRect(-22, -2, 44, 8);
  ctx.fillStyle = '#8a3ad0'; ctx.beginPath(); ctx.roundRect(-25, -26, 50, 12, 4); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#ffd34a'; ctx.beginPath(); ctx.ellipse(-9, -30, 9, 6, -0.5, 0, Math.PI * 2); ctx.ellipse(9, -30, 9, 6, 0.5, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.restore();
  if (!fall) { ctx.font = '800 12px "Bai Jamjuree", system-ui'; ctx.textAlign = 'center'; ctx.lineWidth = 4; ctx.strokeStyle = '#120c09'; ctx.fillStyle = '#ffe28a'; ctx.strokeText('กล่องแจกจากแอดมินจ้า', b.x, b.y - 74 - bob); ctx.fillText('กล่องแจกจากแอดมินจ้า', b.x, b.y - 74 - bob); }
}

