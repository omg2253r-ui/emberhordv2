// Unified input: keyboard, mouse/pointer on the canvas, and on-screen touch controls.
// Gameplay reads `intent` only, so all devices behave the same.
const KEYMAP = {
  KeyW: 'up', ArrowUp: 'up', KeyS: 'down', ArrowDown: 'down', KeyA: 'left', ArrowLeft: 'left', KeyD: 'right', ArrowRight: 'right',
  KeyJ: 'attack', Space: 'attack', KeyK: 'dash', ShiftLeft: 'dash', ShiftRight: 'dash', KeyQ: 'potion', Escape: 'pause', KeyP: 'pause',
  KeyL: 'guard', KeyC: 'guard',
  Digit1: 'skill0', Digit2: 'skill1', Digit3: 'skill2', KeyU: 'skill0', KeyI: 'skill1', KeyO: 'skill2', KeyE: 'interact', KeyF: 'interact', KeyR: 'race', Digit4: 'race', KeyG: 'ult', Digit5: 'ult', KeyH: 'job', Digit6: 'job',
};

// v10 จอยเกม: the first connected gamepad drives the same intent. Left stick / d-pad move (unless the d-pad is bound),
// every other action follows the player's bindings (settings.pad). While a window is open the pad drives the menus
// instead (engine/padUi.js), so game input ignores it then.
const DEAD = 0.22;
export function readPad() {
  if (typeof navigator === 'undefined' || !navigator.getGamepads) return null;
  for (const g of navigator.getGamepads()) if (g && g.connected) return g;
  return null;
}

export function createInput(canvas) {
  const held = new Set();
  let padMap = null, padPrev = new Set(), padHooks = {};
  const pressed = new Set();     // edge-triggered this frame
  const intent = { mx: 0, my: 0, attack: false, attackHeld: false, dash: false, potion: false, pause: false, aim: null, skill: -1, interact: false, interactHeld: false, race: false, guard: false, ult: false, job: false };
  const stick = { active: false, x: 0, y: 0 };  // virtual joystick (-1..1)
  const virtualHeld = new Set();
  let enabled = false;
  let pointerAim = null;

  const isTyping = (e) => e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA');
  function onKeyDown(e) {
    const a = KEYMAP[e.code];
    if (!a || isTyping(e)) return;
    if (enabled) e.preventDefault();
    if (!held.has(a)) pressed.add(a);
    held.add(a);
  }
  function onKeyUp(e) { const a = KEYMAP[e.code]; if (a) held.delete(a); }
  function onBlur() { held.clear(); virtualHeld.clear(); stick.active = false; stick.x = stick.y = 0; }
  function onPointerDown(e) {
    if (!enabled || e.pointerType === 'touch') return;
    if (e.button === 2) { virtualHeld.add('guard'); return; }        // right mouse button: guard
    if (e.button !== 0) return;
    pointerAim = { sx: e.offsetX, sy: e.offsetY };
    pressed.add('attack'); virtualHeld.add('attack');
  }
  function onPointerUp(e) { if (e.pointerType !== 'touch') { if (e.button === 2) virtualHeld.delete('guard'); else virtualHeld.delete('attack'); } }
  function onContextMenu(e) { if (enabled) e.preventDefault(); }
  function onPointerMove(e) { if (e.pointerType !== 'touch' && virtualHeld.has('attack')) pointerAim = { sx: e.offsetX, sy: e.offsetY }; }

  window.addEventListener('keydown', onKeyDown);
  window.addEventListener('keyup', onKeyUp);
  window.addEventListener('blur', onBlur);
  canvas.addEventListener('pointerdown', onPointerDown);
  window.addEventListener('pointerup', onPointerUp);
  canvas.addEventListener('pointermove', onPointerMove);
  canvas.addEventListener('contextmenu', onContextMenu);

  return {
    intent, stick,
    setEnabled(v) { enabled = v; if (!v) onBlur(); },
    // Touch buttons call these
    press(action) { pressed.add(action); virtualHeld.add(action); },
    release(action) { virtualHeld.delete(action); },
    setPadMap(map) { padMap = map; },
    get enabled() { return enabled; },
    onPad(action, fn) { padHooks[action] = fn; },
    get padConnected() { return !!readPad(); },
    // Build this frame's intent
    poll() {
      let mx = (held.has('right') ? 1 : 0) - (held.has('left') ? 1 : 0);
      let my = (held.has('down') ? 1 : 0) - (held.has('up') ? 1 : 0);
      if (stick.active) { mx = stick.x; my = stick.y; }
      // gamepad (skipped while a window is open: the menus have it then)
      const pad = enabled && padMap && !(typeof document !== 'undefined' && document.querySelector('.modal-back')) ? readPad() : null;
      const padNow = new Set();
      if (pad) {
        const bound = new Set(Object.values(padMap));
        const btn = (i) => !!pad.buttons[i]?.pressed;
        let px = Math.abs(pad.axes[0] || 0) > DEAD ? pad.axes[0] : 0, py = Math.abs(pad.axes[1] || 0) > DEAD ? pad.axes[1] : 0;
        if (!bound.has(15) && btn(15)) px = 1; if (!bound.has(14) && btn(14)) px = -1;
        if (!bound.has(13) && btn(13)) py = 1; if (!bound.has(12) && btn(12)) py = -1;
        if (px || py) { mx = px; my = py; }
        for (const [action, b] of Object.entries(padMap)) if (btn(b)) padNow.add(action);
        for (const a of padNow) if (!padPrev.has(a)) { pressed.add(a); if (padHooks[a]) padHooks[a](); }
        // right stick aims (screen-space offset from the centre of the canvas)
        const ax = pad.axes[2] || 0, ay = pad.axes[3] || 0;
        if (Math.hypot(ax, ay) > 0.5 && canvas.clientWidth) { pointerAim = { sx: canvas.clientWidth / 2 + ax * 200, sy: canvas.clientHeight / 2 + ay * 200 }; }
      }
      padPrev = padNow;
      const len = Math.hypot(mx, my);
      if (len > 1) { mx /= len; my /= len; }
      intent.mx = mx; intent.my = my;
      intent.attack = pressed.has('attack');
      intent.attackHeld = held.has('attack') || virtualHeld.has('attack') || padNow.has('attack');
      intent.dash = pressed.has('dash');
      intent.potion = pressed.has('potion');
      intent.pause = pressed.has('pause');
      intent.skill = pressed.has('skill0') ? 0 : pressed.has('skill1') ? 1 : pressed.has('skill2') ? 2 : -1;
      intent.interact = pressed.has('interact');
      intent.interactHeld = held.has('interact') || virtualHeld.has('interact') || padNow.has('interact');   // revive: hold for 7 seconds
      intent.race = pressed.has('race');
      intent.ult = pressed.has('ult');
      intent.job = pressed.has('job');   // v10.2 the class skill
      intent.guard = held.has('guard') || virtualHeld.has('guard') || padNow.has('guard');
      intent.aim = pointerAim; pointerAim = virtualHeld.has('attack') || padNow.has('attack') ? pointerAim : null;
      pressed.clear();
      return intent;
    },
    reset() { onBlur(); pressed.clear(); },
    destroy() {
      window.removeEventListener('keydown', onKeyDown); window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur); canvas.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointerup', onPointerUp); canvas.removeEventListener('pointermove', onPointerMove);
    },
  };
}
