// v10 โลกฮาโลวีน (the Halloween world): a small haunted plaza behind the portal in the village, open while the event
// runs. Other players who are here walk here too (presence zone "halloween"). In it: the candy shop, the demon
// cauldron, the event board, and five gates to the event dungeons. The portal at the bottom leads back.
import { drawHero } from '../battle/heroDraw.js';
import { getItem } from '../data/items.js';
import { getWeaponType } from '../data/weapons.js';
import { getPet } from '../data/pets.js';
import { teamOf } from '../systems/pets.js';
import { drawTitleLine } from '../ui/nameplate.js';
import { badgeTier } from '../data/titles.js';
import { hwLeftMs, countdownParts } from '../data/halloween.js';
import { HW_ZONES, HW_REQ } from '../data/hwZones.js';
import { drawPumpkin } from '../art/hwShots.js';
import { drawHwAura, myHwLook } from '../battle/hwLook.js';
import { drawJobGround, drawJobHead } from '../battle/jobLook.js';
import { drawRankLine } from '../ui/nameplate.js';
import { drawGiftBox } from '../art/giftBox.js';
import { raysSprite, createLighting, createFireworks, createLightning, createWanderers, createFall, drawGhost, drawBat, drawCrow, drawRuneCircle, drawRays, drawBeam, drawArc, viewRect, fxAmount, rand, hexA } from './ambientFx.js';

const TAU = Math.PI * 2;
export const HWW = Object.freeze({
  w: 2400, h: 1500, spawn: { x: 1200, y: 1250 }, exit: { x: 1200, y: 1430 },
  shop: { x: 520, y: 980 }, cauldron: { x: 860, y: 1100 }, board: { x: 1560, y: 1080 }, statue: { x: 1200, y: 860 },
  gates: [
    { zone: 'hw_wild', x: 360, y: 560 }, { zone: 'hw_jack', x: 760, y: 520 }, { zone: 'hw_deceiver', x: 1200, y: 470, big: true },
    { zone: 'hw_lure', x: 1640, y: 520 }, { zone: 'hw_reaper', x: 2040, y: 560 },
  ],
  speed: 270, sendEvery: 0.1, talkRange: 120,
});
const V = HWW;
const TREES = [[120, 700], [2280, 700], [200, 1300], [2200, 1300], [640, 760], [1760, 760], [80, 1050], [2320, 1050]];
const GRAVES = [[300, 900], [420, 1200], [1960, 920], [2080, 1220], [1000, 1300], [1400, 1300], [1900, 1100], [700, 1300]];
// v10.1: lamp posts with a jack-o'-lantern swinging on a chain, glowing mushroom rings, pumpkin patches, crows on the fence
const LAMPS = [[560, 800], [1840, 800], [980, 1180], [1420, 1180], [300, 1100], [2100, 1060], [700, 640], [1700, 640]];
const SHROOMS = [[180, 860, '#5affd8'], [2220, 900, '#c86aff'], [1080, 700, '#7aff6a'], [1320, 700, '#ff8ad8'], [620, 1400, '#5ae0ff'], [1780, 1400, '#ffd24a']];
const PATCHES = [[250, 770], [1980, 760], [260, 1380], [2140, 1380]];
const CROWS = [[150, 612], [470, 606], [930, 610], [1470, 608], [1990, 612], [2300, 606]];
const GATE_COL = { hw_wild: '#8aff5a', hw_jack: '#ff8a1f', hw_deceiver: '#c86aff', hw_lure: '#ff7ab8', hw_reaper: '#b8f0ff' };

function blocked(x, y, r = 18) {
  if (x < 60 + r || x > V.w - 60 - r || y < 600 + r * 0.5 || y > V.h - 30) return true;
  const circles = [...LAMPS.map(([a, b]) => [a, b, 14]), [V.statue.x, V.statue.y, 80], [V.cauldron.x, V.cauldron.y, 50], [V.shop.x, V.shop.y - 10, 90], [V.board.x, V.board.y, 50], ...TREES.map(([a, b]) => [a, b, 34]), ...GRAVES.map(([a, b]) => [a, b, 26])];
  for (const [cx, cy, cr] of circles) if (Math.hypot(x - cx, (y - cy) * 1.4) < cr + r) return true;
  return false;
}

export function createHalloweenScene(app) {
  const { renderer, input, sprites, audio } = app;
  const ctx = renderer.ctx;
  let w = null, ground = null;

  function paintGround() {
    const c = document.createElement('canvas'); c.width = V.w; c.height = V.h;
    const g = c.getContext('2d');
    const sky = g.createLinearGradient(0, 0, 0, V.h); sky.addColorStop(0, '#0e0a1e'); sky.addColorStop(0.35, '#22163a'); sky.addColorStop(1, '#1a1428');
    g.fillStyle = sky; g.fillRect(0, 0, V.w, V.h);
    let seed = 31; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    // stars and the big moon
    for (let i = 0; i < 260; i++) { g.fillStyle = `rgba(255,248,220,${0.3 + rnd() * 0.6})`; g.fillRect(rnd() * V.w, rnd() * 420, 1.6, 1.6); }
    const mg = g.createRadialGradient(1880, 170, 20, 1880, 170, 260); mg.addColorStop(0, 'rgba(255,240,200,0.45)'); mg.addColorStop(1, 'rgba(255,240,200,0)'); g.fillStyle = mg; g.fillRect(1500, 0, 800, 500);
    g.fillStyle = '#fff4d8'; g.beginPath(); g.arc(1880, 170, 92, 0, TAU); g.fill(); g.fillStyle = 'rgba(200,180,140,0.35)'; for (const [x, y, r] of [[1850, 150, 18], [1910, 200, 12], [1880, 120, 8]]) { g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); }
    // a ruined castle on the far hill, then three hill lines, the nearest with dead trees
    g.fillStyle = '#0a0614';
    const castle = (cx, base, k) => { for (const [dx, wd, ht, roof] of [[-120, 40, 150, 1], [-70, 60, 110, 0], [-10, 50, 210, 1], [50, 70, 130, 0], [120, 36, 170, 1]]) { const x = cx + dx * k, ww = wd * k, hh = ht * k; g.fillRect(x - ww / 2, base - hh, ww, hh); if (roof) { g.beginPath(); g.moveTo(x - ww / 2 - 6, base - hh); g.lineTo(x, base - hh - 60 * k); g.lineTo(x + ww / 2 + 6, base - hh); g.fill(); } else for (let b = 0; b < 4; b++) g.fillRect(x - ww / 2 + b * ww / 4, base - hh - 10 * k, ww / 8, 10 * k); } };
    castle(560, 330, 1);
    g.fillStyle = '#0d0818'; g.beginPath(); g.moveTo(0, 360); for (let x = 0; x <= V.w; x += 40) g.lineTo(x, 340 - Math.sin(x * 0.003 + 1) * 70 - Math.sin(x * 0.011) * 18); g.lineTo(V.w, 620); g.lineTo(0, 620); g.closePath(); g.fill();
    // the haunted hill line
    g.fillStyle = '#120c1e'; g.beginPath(); g.moveTo(0, 420); for (let x = 0; x <= V.w; x += 40) g.lineTo(x, 400 - Math.sin(x * 0.004) * 60 - Math.sin(x * 0.013) * 20); g.lineTo(V.w, 620); g.lineTo(0, 620); g.closePath(); g.fill();
    // dead trees on the near hill
    g.strokeStyle = '#0a0612'; g.lineCap = 'round';
    for (const tx of [140, 980, 1500, 2260]) { const ty = 420 - Math.sin(tx * 0.004) * 60; g.lineWidth = 7; g.beginPath(); g.moveTo(tx, ty + 10); g.lineTo(tx + 6, ty - 70); g.stroke(); g.lineWidth = 3; for (const [a, l] of [[-0.8, 40], [0.6, 46], [-0.2, 30], [1.1, 34]]) { g.beginPath(); g.moveTo(tx + 5, ty - 50); g.lineTo(tx + Math.sin(a) * l, ty - 70 - Math.cos(a) * l * 0.5); g.stroke(); } }
    // ground: dark violet grass
    g.fillStyle = '#251a32'; g.fillRect(0, 600, V.w, V.h - 600);
    // iron fence along the top of the plaza
    g.strokeStyle = '#08060c'; g.fillStyle = '#08060c'; g.lineWidth = 4; g.beginPath(); g.moveTo(40, 590); g.lineTo(V.w - 40, 590); g.moveTo(40, 556); g.lineTo(V.w - 40, 556); g.stroke();
    for (let x = 40; x <= V.w - 40; x += 22) { g.fillRect(x - 2, 540, 4, 64); g.beginPath(); g.moveTo(x - 6, 542); g.lineTo(x, 526); g.lineTo(x + 6, 542); g.fill(); }
    // pumpkin patches: dark tilled soil with curling vines
    for (const [px, py] of PATCHES) { g.fillStyle = '#1a1018'; g.beginPath(); g.ellipse(px, py, 120, 46, 0, 0, TAU); g.fill(); g.strokeStyle = '#2a4a1a'; g.lineWidth = 3; for (let k = 0; k < 6; k++) { g.beginPath(); g.moveTo(px - 100 + k * 40, py - 10); g.bezierCurveTo(px - 80 + k * 40, py - 40, px - 60 + k * 40, py + 30, px - 40 + k * 40, py); g.stroke(); } }
    // bones and skulls scattered on the grass
    for (let i = 0; i < 40; i++) { const x = 80 + rnd() * (V.w - 160), y = 640 + rnd() * (V.h - 700); g.fillStyle = 'rgba(220,210,190,0.55)'; if (i % 3) { g.save(); g.translate(x, y); g.rotate(rnd() * 3); g.fillRect(-8, -1.5, 16, 3); g.beginPath(); g.arc(-8, -2, 2.4, 0, TAU); g.arc(-8, 2, 2.4, 0, TAU); g.arc(8, -2, 2.4, 0, TAU); g.arc(8, 2, 2.4, 0, TAU); g.fill(); g.restore(); } else { g.beginPath(); g.arc(x, y, 6, 0, TAU); g.fill(); g.fillStyle = '#1a1424'; g.beginPath(); g.arc(x - 2, y - 1, 1.4, 0, TAU); g.arc(x + 2, y - 1, 1.4, 0, TAU); g.fill(); } }
    for (let i = 0; i < 3200; i++) { const x = rnd() * V.w, y = 600 + rnd() * (V.h - 600); g.strokeStyle = ['#3a2a4a', '#2e2040', '#47325a'][i % 3]; g.lineWidth = 1.6; g.beginPath(); g.moveTo(x, y); g.lineTo(x - 2 + rnd() * 4, y - 6 - rnd() * 6); g.stroke(); }
    // paths of pale stone to every gate and back to the portal
    g.strokeStyle = '#4a3e52'; g.lineCap = 'round';
    const path = (pts, wd) => { g.lineWidth = wd; g.beginPath(); g.moveTo(...pts[0]); for (const p of pts.slice(1)) g.lineTo(...p); g.stroke(); };
    path([[V.exit.x, V.h], [V.statue.x, V.statue.y]], 140);
    for (const gt of V.gates) path([[V.statue.x, V.statue.y], [gt.x, gt.y + 40]], 90);
    path([[V.statue.x, V.statue.y], [V.shop.x, V.shop.y]], 90); path([[V.statue.x, V.statue.y], [V.board.x, V.board.y]], 90);
    for (let i = 0; i < 900; i++) { const a = rnd() * TAU, r = Math.sqrt(rnd()); const x = V.statue.x + Math.cos(a) * r * 330, y = V.statue.y + 40 + Math.sin(a) * r * 200; g.fillStyle = ['#5a4e62', '#4a4054', '#625670'][i % 3]; g.beginPath(); g.roundRect(x - 8, y - 5, 14 + rnd() * 6, 9 + rnd() * 3, 3); g.fill(); }
    // the plaza's flagstones get cracks and moss
    for (let i = 0; i < 220; i++) { const a = rnd() * TAU, r = Math.sqrt(rnd()) * 300; const x = V.statue.x + Math.cos(a) * r, y = V.statue.y + 40 + Math.sin(a) * r * 0.6; g.strokeStyle = 'rgba(10,6,14,0.6)'; g.lineWidth = 1; g.beginPath(); g.moveTo(x, y); g.lineTo(x + rnd() * 14 - 7, y + rnd() * 10 - 5); g.lineTo(x + rnd() * 20 - 10, y + rnd() * 14 - 7); g.stroke(); if (i % 4 === 0) { g.fillStyle = 'rgba(60,110,50,0.35)'; g.beginPath(); g.arc(x, y, 3 + rnd() * 4, 0, TAU); g.fill(); } }
    ground = c;
  }

  // ------------------------------------------------------------ v10.1 ambience (sky, light, creatures)
  function makeFx() {
    const amt = fxAmount();
    const stars = Array.from({ length: Math.round(90 * amt) }, () => ({ x: Math.random() * V.w, y: Math.random() * 380, p: Math.random() * TAU, s: 1 + Math.random() * 1.6 }));
    const clouds = Array.from({ length: 5 }, (_, i) => ({ x: Math.random() * V.w, y: 90 + i * 55, w: 260 + Math.random() * 260, v: 8 + Math.random() * 10 }));
    return {
      stars, clouds,
      light: createLighting(),
      fireworks: createFireworks(audio), fwWait: 2,
      lightning: createLightning(audio),
      ghosts: createWanderers(Math.round(7 * amt) + 2, { x0: 120, x1: V.w - 120, y0: 680, y1: V.h - 80 }, 34),
      flock: { t: -99, y: 0, dir: 1, wait: 6 },
      crows: CROWS.map(([x, y], i) => ({ x, y, flap: 0, hop: 0, wait: 2 + i * 1.3, flip: i % 2 ? -1 : 1, fly: null })),
      leaves: createFall(Math.round(46 * amt), ['#e06a1a', '#c2410e', '#8a3a12', '#ffb03a', '#6a2a14']),
      shooting: null, shootWait: 4,
    };
  }
  function updateFx(dt) {
    const F = w.fx, t = w.time;
    for (const c of F.clouds) { c.x += c.v * dt; if (c.x - c.w > V.w) c.x = -c.w; }
    F.fireworks.update(dt);
    F.fwWait -= dt;
    if (F.fwWait <= 0) { F.fwWait = rand(2.2, 5); const gt = V.gates[(Math.random() * V.gates.length) | 0]; F.fireworks.launch(gt.x + rand(-80, 80), gt.y - 60, rand(260, 420), null, [GATE_COL[gt.zone], '#ffffff']); if (Math.random() < 0.35) setTimeout(() => w && F.fireworks.launch(V.statue.x + rand(-200, 200), V.statue.y - 120, rand(300, 460)), 300); }
    F.lightning.update(dt, 200, V.w - 200, 0, 380);
    F.ghosts.update(dt);
    F.leaves.update(dt, viewRect(renderer));
    // a flock of bats sweeps across every so often
    const fl = F.flock; fl.wait -= dt;
    if (fl.wait <= 0) { fl.wait = rand(10, 20); fl.t = 0; fl.y = rand(640, 1100); fl.dir = Math.random() < 0.5 ? 1 : -1; audio.play('summon', { power: 0.3 }); }
    fl.t += dt;
    for (const c of F.crows) {
      if (c.fly) { c.fly.t += dt; if (c.fly.t > 3) { c.fly = null; c.wait = rand(4, 9); } continue; }
      c.wait -= dt; c.flap = Math.max(0, c.flap - dt * 3);
      if (c.wait <= 0) { c.wait = rand(2, 6); if (Math.random() < 0.6) c.flap = 1; else c.flip *= -1; }
      if (Math.hypot(c.x - w.me.x, c.y - w.me.y) < 140) { c.fly = { t: 0, vx: (c.x < w.me.x ? -1 : 1) * 260 }; audio.play('blink', { power: 0.3 }); }
    }
    F.shootWait -= dt;
    if (F.shootWait <= 0) { F.shootWait = rand(5, 12); F.shooting = { x: rand(200, V.w - 200), y: rand(40, 200), t: 0 }; }
    if (F.shooting) { F.shooting.t += dt; if (F.shooting.t > 0.9) F.shooting = null; }
    // embers from the statue, green bubbles from the cauldron, motes sucked into the gates
    const amt = fxAmount();
    if (Math.random() < dt * 7 * amt) app.particles.spawn({ x: V.statue.x + rand(-60, 60), y: V.statue.y - 60, vx: rand(-20, 20), vy: rand(-80, -40), life: 1.6, size: 3, size2: 0.3, color: Math.random() < 0.5 ? '#ffb648' : '#ff6a1a', drag: 0.4, glow: true });
    for (const gt of V.gates) if (Math.random() < dt * 3 * amt) { const a = Math.random() * TAU, r = gt.big ? 170 : 130; app.particles.spawn({ x: gt.x + Math.cos(a) * r, y: gt.y - 60 + Math.sin(a) * r * 0.6, vx: -Math.cos(a) * 120, vy: -Math.sin(a) * 70, life: 1, size: 3, size2: 0.2, color: GATE_COL[gt.zone], drag: 0.2, glow: true }); }
    for (const [x, y, c] of SHROOMS) if (Math.random() < dt * 1.2 * amt) app.particles.spawn({ x: x + rand(-40, 40), y: y - 10, vx: rand(-6, 6), vy: rand(-26, -12), life: 2.4, size: 2.2, size2: 0.2, color: c, drag: 0.2, glow: true });
    void t;
  }
  function drawSky() {
    const F = w.fx, t = w.time;
    // aurora ribbons (only the part on screen)
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    const vr = viewRect(renderer), ax0 = Math.max(0, Math.floor(vr.x0 / 60) * 60), ax1 = Math.min(V.w, Math.ceil(vr.x1 / 60) * 60);
    if (vr.y0 < 320) for (let k = 0; k < (fxAmount() > 0.5 ? 3 : 1); k++) {
      const col = ['#5affb0', '#a86aff', '#ff7ab8'][k];
      const g = ctx.createLinearGradient(0, 40 + k * 40, 0, 260 + k * 40); g.addColorStop(0, hexA(col, 0)); g.addColorStop(0.5, hexA(col, 0.14)); g.addColorStop(1, hexA(col, 0));
      ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(ax0, 300);
      for (let x = ax0; x <= ax1; x += 60) ctx.lineTo(x, 120 + k * 40 + Math.sin(x * 0.004 + t * 0.4 + k) * 50 + Math.sin(x * 0.011 - t * 0.7) * 16);
      for (let x = ax1; x >= ax0; x -= 60) ctx.lineTo(x, 220 + k * 40 + Math.sin(x * 0.005 + t * 0.3 + k * 2) * 40);
      ctx.closePath(); ctx.fill();
    }
    // twinkling stars and a shooting star
    for (const st of F.stars) { const a = 0.35 + 0.65 * Math.abs(Math.sin(t * 1.6 + st.p)); ctx.fillStyle = `rgba(255,250,230,${a})`; ctx.fillRect(st.x, st.y, st.s, st.s); if (st.s > 2.2) { ctx.fillRect(st.x - 3, st.y + 0.8, 7, 0.6); ctx.fillRect(st.x + 0.8, st.y - 3, 0.6, 7); } }
    if (F.shooting) { const s = F.shooting, k = s.t / 0.9, x = s.x + k * 360, y = s.y + k * 140; const g = ctx.createLinearGradient(x - 120, y - 46, x, y); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, `rgba(255,255,255,${1 - k})`); ctx.strokeStyle = g; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.moveTo(x - 120, y - 46); ctx.lineTo(x, y); ctx.stroke(); }
    // the moon breathes light
    w.lights.push({ x: 1880, y: 170, r: 380 + Math.sin(t * 0.8) * 20, col: '#ffe6b4', ga: 0.3 });
    ctx.restore();
    // castle windows flicker
    for (const [x, y] of [[440, 230], [490, 268], [552, 180], [552, 236], [610, 262], [680, 220]]) { const f = 0.5 + 0.5 * Math.sin(t * 7 + x) * Math.sin(t * 3.3 + y); ctx.fillStyle = `rgba(255,${150 + 60 * f | 0},60,${0.55 + 0.4 * f})`; ctx.fillRect(x - 4, y - 7, 8, 12); }
    F.lightning.draw(ctx);
    // clouds drift over the moon
    for (const c of F.clouds) { ctx.fillStyle = 'rgba(30,22,48,0.75)'; ctx.beginPath(); for (let i = 0; i < 5; i++) ctx.ellipse(c.x + i * c.w * 0.18, c.y + Math.sin(i * 1.7) * 10, c.w * 0.18, 26 + (i % 2) * 10, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(255,230,180,0.18)'; ctx.lineWidth = 2; ctx.stroke(); }
    // bats circling the moon
    for (let i = 0; i < 8; i++) { const a = t * 0.4 + i * 0.8; drawBat(ctx, 1880 + Math.cos(a) * (170 + i * 18), 190 + Math.sin(a * 1.3) * 80, t + i, 0.9); }
  }
  function drawLamp([x, y], i) {
    const t = w.time, sw = Math.sin(t * 1.6 + i) * 0.25;
    ctx.fillStyle = '#0c0812'; ctx.strokeStyle = '#2a2034'; ctx.lineWidth = 2;
    ctx.fillRect(x - 5, y - 150, 10, 150); ctx.beginPath(); ctx.ellipse(x, y, 16, 6, 0, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.moveTo(x, y - 146); ctx.quadraticCurveTo(x + 30, y - 170, x + 52, y - 150); ctx.lineWidth = 5; ctx.strokeStyle = '#0c0812'; ctx.stroke();
    // the chain and the swinging lantern
    const ax = x + 50, ay = y - 150, lx = ax + Math.sin(sw) * 36, ly = ay + Math.cos(sw) * 36;
    ctx.strokeStyle = '#3a3040'; ctx.lineWidth = 1.6; ctx.setLineDash([3, 2]); ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(lx, ly); ctx.stroke(); ctx.setLineDash([]);
    drawPumpkin(ctx, lx, ly + 10, 13, t + i, sw, undefined, undefined, false);
    w.lights.push({ x: lx, y: ly + 40, r: 220, col: '#ff9a3a', ga: 0.3 + 0.08 * Math.sin(t * 9 + i) });
  }
  // mushroom rings and pumpkin patches are painted once (their light breathes in the light map)
  const decoCache = new Map();
  function deco(key, w0, h0, ox, oy, paint) {
    let c = decoCache.get(key);
    if (!c) { c = document.createElement('canvas'); c.width = w0; c.height = h0; const g = c.getContext('2d'); g.translate(ox, oy); paint(g); decoCache.set(key, c); }
    ctx.drawImage(c, -ox, -oy);
  }
  function drawShrooms([x, y, col], i) {
    const t = w.time;
    ctx.save(); ctx.translate(x, y);
    deco('sh' + i, 140, 70, 70, 40, (g) => {
      for (let k = 0; k < 7; k++) {
        const a = (k / 7) * TAU, mx = Math.cos(a) * 46, my = Math.sin(a) * 18, sc = 0.8 + (k % 3) * 0.2;
        g.fillStyle = '#e8e0f0'; g.fillRect(mx - 2 * sc, my - 10 * sc, 4 * sc, 10 * sc);
        g.fillStyle = col; g.beginPath(); g.ellipse(mx, my - 10 * sc, 9 * sc, 6 * sc, 0, Math.PI, 0); g.fill();
        g.fillStyle = 'rgba(255,255,255,0.7)'; g.beginPath(); g.arc(mx - 3 * sc, my - 13 * sc, 1.4 * sc, 0, TAU); g.fill();
      }
    });
    ctx.restore();
    w.lights.push({ x, y, r: 150, col, ga: 0.16 + 0.1 * Math.sin(t * 2 + i) });
  }
  function drawPatch([x, y], i) {
    ctx.save(); ctx.translate(x, y);
    deco('pp' + i, 220, 80, 110, 50, (g) => { [[-70, -6, 16], [-30, 12, 20], [10, -10, 14], [50, 8, 22], [86, -4, 12]].forEach(([dx, dy, r], k) => drawPumpkin(g, dx, dy, r, i * 3 + k, 0, undefined, undefined, false)); });
    ctx.restore();
    w.lights.push({ x, y, r: 200, col: '#ff8a1f', ga: 0.2 + 0.05 * Math.sin(w.time * 9 + i) });
  }

  // ------------------------------------------------------------ remote players (presence zone "halloween")
  function syncRemote(dt) {
    const seen = new Set();
    for (const x of app.online.peers) {
      if (x.p.zone !== 'halloween') continue;
      seen.add(x.peer);
      let r = w.remote.get(x.peer);
      if (!r) { r = { peer: x.peer, x: x.p.x, y: x.p.y, walkT: 0, fade: 0 }; w.remote.set(x.peer, r); }
      r.p = x.p; r.by = x.by;
      const k = Math.min(1, dt * 10), jump = Math.hypot(x.p.x - r.x, x.p.y - r.y) > 400;
      r.x = jump ? x.p.x : r.x + (x.p.x - r.x) * k; r.y = jump ? x.p.y : r.y + (x.p.y - r.y) * k;
      r.moving = x.p.moving; r.flip = x.p.flip; r.dash = x.p.dash;
      if (r.moving) r.walkT += dt * 10;
      r.fade = Math.min(1, r.fade + dt * 3);
    }
    for (const k of [...w.remote.keys()]) if (!seen.has(k)) w.remote.delete(k);
  }
  function move(dt, intent) {
    const p = w.me;
    let mx = intent.mx, my = intent.my;
    if (w.walkTo) { const dx = w.walkTo.x - p.x, dy = w.walkTo.y - p.y, d = Math.hypot(dx, dy); if (d < 8 || mx || my) w.walkTo = null; else { mx = dx / d; my = dy / d; } }
    if (intent.dash && p.dashCd <= 0 && (mx || my)) { p.dashT = 0.18; p.dashCd = 0.6; p.dashDir = Math.atan2(my, mx); audio.play('dash'); }
    p.dashCd -= dt;
    let vx = mx * V.speed, vy = my * V.speed;
    if (p.dashT > 0) { p.dashT -= dt; vx = Math.cos(p.dashDir) * 720; vy = Math.sin(p.dashDir) * 720; }
    const nx = p.x + vx * dt, ny = p.y + vy * dt;
    if (!blocked(nx, p.y)) p.x = nx; else w.walkTo = null;
    if (!blocked(p.x, ny)) p.y = ny; else w.walkTo = null;
    p.moving = Math.hypot(vx, vy) > 10;
    if (p.moving) { p.walkT += dt * 10; if (Math.abs(vx) > 5) p.flip = vx < 0; }
    p.vx = vx;
  }
  function publishMe(force) {
    const p = w.me;
    const snap = { z: 'halloween', x: Math.round(p.x), y: Math.round(p.y), f: p.flip ? 1 : 0, m: p.moving ? 1 : 0, d: p.dashT > 0 ? 1 : 0 };
    const key = `${snap.x},${snap.y},${snap.f},${snap.m},${snap.d}`;
    if (!force && key === w.lastKey) return;
    w.lastKey = key; app.online.publish(snap);
  }
  // ------------------------------------------------------------ interaction
  function nearestTarget() {
    const p = w.me;
    let best = null, bd = 100;
    for (const r of w.remote.values()) { const d = Math.hypot(r.x - p.x, r.y - p.y); if (d < bd) { bd = d; best = { kind: 'player', r }; } }
    if (best) return best;
    if (Math.hypot(p.x - V.exit.x, p.y - V.exit.y) < 130) return { kind: 'exit' };
    if (Math.hypot(p.x - V.shop.x, p.y - (V.shop.y + 40)) < 150) return { kind: 'shop' };
    if (Math.hypot(p.x - V.cauldron.x, p.y - (V.cauldron.y + 30)) < 130) return { kind: 'cauldron' };
    if (Math.hypot(p.x - V.board.x, p.y - (V.board.y + 30)) < 120) return { kind: 'board' };
    for (const gt of V.gates) if (Math.hypot(p.x - gt.x, p.y - (gt.y + 60)) < (gt.big ? 150 : 120)) return { kind: 'gate', gt };
    return null;
  }
  function labelFor(t) {
    if (!t) return null;
    if (t.kind === 'player') return `ดูข้อมูล ${t.r.p.name}`;
    if (t.kind === 'exit') return app.online.online ? 'กลับหมู่บ้าน' : 'กลับค่าย';
    if (t.kind === 'shop') return 'ร้านแคนดี้: แลกอาวุธ สกิน ชุด สัตว์เลี้ยง ยา';
    if (t.kind === 'cauldron') return 'หม้อปรุงยาปีศาจ';
    if (t.kind === 'board') return 'กระดานกิจกรรมฮาโลวีน';
    if (t.kind === 'gate') { const z = HW_ZONES.find((x) => x.id === t.gt.zone); return `ประตู: ${z.name}`; }
    return null;
  }
  function activate(t) {
    if (!t) return;
    audio.play('click');
    if (t.kind === 'player') app.village.openPlayer(t.r.peer);
    else if (t.kind === 'exit') app.leaveHalloween();
    else if (t.kind === 'shop') app.openCandyShop();
    else if (t.kind === 'cauldron') app.openCauldron('hw');
    else if (t.kind === 'board') app.openHwBoard();
    else if (t.kind === 'gate') app.openHwGate(t.gt.zone);
  }
  function onPointer(e) {
    if (!w || app.village.blocking() || document.querySelector('.modal-back')) return;
    const rect = renderer.ctx.canvas.getBoundingClientRect();
    const pt = renderer.screenToWorld(e.clientX - rect.left, e.clientY - rect.top);
    for (const r of w.remote.values()) if (Math.hypot(r.x - pt.x, (r.y - 50) - pt.y) < 60) { audio.play('click'); app.village.openPlayer(r.peer); return; }
    if (Math.hypot(pt.x - V.shop.x, pt.y - (V.shop.y - 80)) < 110) { activate({ kind: 'shop' }); return; }
    if (Math.hypot(pt.x - V.cauldron.x, pt.y - (V.cauldron.y - 30)) < 80) { activate({ kind: 'cauldron' }); return; }
    if (Math.hypot(pt.x - V.board.x, pt.y - (V.board.y - 60)) < 80) { activate({ kind: 'board' }); return; }
    for (const gt of V.gates) if (Math.hypot(pt.x - gt.x, pt.y - (gt.y - 60)) < (gt.big ? 130 : 100)) { activate({ kind: 'gate', gt }); return; }
    if (!blocked(pt.x, pt.y)) w.walkTo = { x: pt.x, y: pt.y };
  }

  // ------------------------------------------------------------ frame
  function update(dt) {
    if (!w) return;
    w.time += dt;
    const intent = input.poll();
    const busy = app.village.blocking() || !!document.querySelector('.modal-back');
    if (busy) { intent.mx = 0; intent.my = 0; intent.dash = false; intent.interact = false; }
    move(dt, intent);
    syncRemote(dt);
    w.sendAcc += dt; if (w.sendAcc >= V.sendEvery) { w.sendAcc = 0; publishMe(false); }
    w.heartbeat += dt; if (w.heartbeat > 5) { w.heartbeat = 0; publishMe(true); }
    w.target = nearestTarget();
    app.hud.setInteract(labelFor(w.target));
    if (intent.interact) activate(w.target);
    if (intent.pause && !busy) { if (app.online.online) app.village.toggleMenu(); else app.leaveHalloween(); }
    for (const [k, b] of w.bubbles) if (w.time - b.t > 6) w.bubbles.delete(k);
    if (app.gm?.active) app.gm.trail('halloween', w.me.x, w.me.y);
    for (const b of app.live.boxesIn('halloween')) if (Math.hypot(b.x - w.me.x, b.y - w.me.y) < 60 && Date.now() - b.at > 2500) app.live.claimBox(b);
    // ambience: fog, embers from the cauldron, bats over the moon
    if (Math.random() < dt * 10) app.particles.spawn({ x: V.cauldron.x + (Math.random() - 0.5) * 50, y: V.cauldron.y - 50, vx: (Math.random() - 0.5) * 30, vy: -40 - Math.random() * 40, life: 1.2, size: 4, size2: 0.4, color: '#8aff5a', drag: 0.6, glow: true });
    if (Math.random() < dt * 4) app.particles.spawn({ x: Math.random() * V.w, y: 640 + Math.random() * (V.h - 640), vx: (Math.random() - 0.5) * 16, vy: -8, life: 3, size: 2.2, size2: 0.4, color: '#ffb648', drag: 0.1, glow: true });
    updateFx(dt);
    app.particles.update(dt);
    renderer.update(dt);
    const v = renderer.view, cam = renderer.cam;
    cam.zoom = Math.max(0.55, Math.min(1.05, app.touch ? Math.min(v.w / 560, v.h / 560) : Math.min(v.w / 1150, v.h / 720)));
    const halfW = v.w / 2 / cam.zoom, halfH = v.h / 2 / cam.zoom;
    const clamp = (val, lo, hi) => (lo > hi ? (lo + hi) / 2 : Math.max(lo, Math.min(hi, val)));
    const tx = clamp(w.me.x, halfW, V.w - halfW), ty = clamp(w.me.y - 60, halfH, V.h - halfH);
    const k = Math.min(1, dt * 6); cam.x += (tx - cam.x) * k; cam.y += (ty - cam.y) * k;
  }

  function drawPerson(o, isMe) {
    const st = app.store.get();
    const wid = isMe ? st.equipment.weapon.id : (getItem(o.p.weapon) ? o.p.weapon : 'w_rust_blade');
    const parts = isMe ? sprites.heroParts : app.heroPartsFor(o.p.armor, o.p.race, o.p.wings);
    const weapon = isMe ? sprites.weapon : app.weaponSpriteFor(wid, o.p.skin);
    const type = getWeaponType(getItem(wid)?.wtype);
    ctx.globalAlpha = isMe ? 1 : o.fade;
    ctx.fillStyle = 'rgba(8,4,12,0.45)'; ctx.beginPath(); ctx.ellipse(o.x, o.y, 22, 8, 0, 0, TAU); ctx.fill();
    const jid = isMe ? (st.job?.own?.[st.job?.on] ? st.job.on : null) : o.p.job;   // v10.2 class look
    if (jid) drawJobGround(ctx, o.x, o.y, w.time, jid, 0.95);
    drawHero(renderer, parts, weapon, { x: o.x, y: o.y, flip: o.flip, time: w.time, walkT: o.walkT, moving: o.moving, type, scale: 0.9, dashing: isMe ? o.dashT > 0 : o.dash, vx: o.vx || 0, speed: V.speed, alpha: isMe ? 1 : o.fade });
    drawHwAura(ctx, o.x, o.y, isMe ? myHwLook(st, o.flip) : { w: wid, sk: o.p.skin, mk: o.p.mask, flip: o.flip }, w.time, 0.9);
    if (jid) drawJobHead(ctx, o.x, o.y, w.time, jid, o.flip, 0.9 / 0.95);
    ctx.globalAlpha = 1;
    // pets
    const ids = isMe ? teamOf(st) : o.p.pets;
    (ids || []).forEach((petId, i) => { const pet = getPet(petId), s = pet && sprites[pet.sprite]; if (!s) return; const px = o.x + (o.flip ? 54 + i * 26 : -54 - i * 26), py = o.y + (i % 2 ? -20 : 8), z = pet.flying ? 40 + Math.sin(w.time * 3 + i) * 6 : 0; renderer.sprite(s, px, py - z, { sx: 0.75 * (o.flip ? -1 : 1), sy: 0.75 }); });
  }
  function tag(o, isMe) {
    const st = app.store.get();
    const name = isMe ? st.story.name : o.p.name, lv = isMe ? st.player.level : o.p.lv;
    ctx.font = '700 14px "Bai Jamjuree", system-ui, sans-serif'; ctx.textAlign = 'center';
    const y = o.y - 108;
    ctx.lineWidth = 4; ctx.strokeStyle = '#08040c'; ctx.fillStyle = isMe ? '#ffcf5a' : '#f3e6c8';
    ctx.strokeText(`${name}  Lv.${lv}`, o.x, y); ctx.fillText(`${name}  Lv.${lv}`, o.x, y);
    let up = drawTitleLine(ctx, o.x, y - 16, isMe ? st.titles?.equipped : o.p.title, isMe ? badgeTier(st) : o.p.badge);
    up += drawRankLine(ctx, o.x, y - 16 - up, isMe ? (st.settings.showRank === false ? -1 : null) : o.p.rank, isMe ? st.rank?.pts : null);
    const b = w.bubbles.get(isMe ? 'me' : o.peer);
    if (b) { ctx.save(); ctx.globalAlpha = Math.min(1, (6 - (w.time - b.t)) * 2); ctx.font = '600 14px "Bai Jamjuree", system-ui'; const tw = Math.min(240, ctx.measureText(b.text).width) + 20; ctx.fillStyle = 'rgba(243,230,200,0.96)'; ctx.beginPath(); ctx.roundRect(o.x - tw / 2, y - 50 - up, tw, 28, 8); ctx.fill(); ctx.fillStyle = '#2a1a10'; ctx.fillText(b.text.slice(0, 40), o.x, y - 31 - up); ctx.restore(); }
  }

  function drawGate(gt) {
    const t = w.time, z = HW_ZONES.find((x) => x.id === gt.zone), lv = HW_REQ[gt.zone] || 1;
    const s = gt.big ? 1.35 : 1, hot = w.target?.gt === gt, gc = GATE_COL[gt.zone];
    // v10.1: a rune circle under every gate, a beam into the sky, stones orbiting, and crackling arcs on the big one
    const hq = fxAmount() >= 1;   // rune circles and sky beams under every gate: high quality only
    if (hq) { drawRuneCircle(ctx, gt.x, gt.y + 40, 120 * s, t * (gt.big ? 1.4 : 1), gc); drawBeam(ctx, gt.x, gt.y - 60 * s, 44 * s, 520, t, gc); }
    for (let k = 0; k < 6; k++) { const a = t * 0.9 + (k / 6) * TAU, ox = Math.cos(a) * 110 * s, oy = Math.sin(a) * 34 * s - 90 * s - Math.sin(t * 2 + k) * 8; if (Math.sin(a) < 0) continue; ctx.fillStyle = '#2a2234'; ctx.strokeStyle = gc; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(gt.x + ox, gt.y + oy - 9); ctx.lineTo(gt.x + ox + 8, gt.y + oy); ctx.lineTo(gt.x + ox, gt.y + oy + 8); ctx.lineTo(gt.x + ox - 7, gt.y + oy); ctx.closePath(); ctx.fill(); ctx.stroke(); }
    if (gt.big && Math.sin(t * 5) > 0.6) drawArc(ctx, gt.x - 70 * s, gt.y - 150 * s, gt.x + 70 * s, gt.y - 150 * s, gc, 9, 22);
    w.lights.push({ x: gt.x, y: gt.y - 40, r: gt.big ? 360 : 280, col: gc, ga: 0.32 });
    ctx.save(); ctx.translate(gt.x, gt.y);
    // the stone arch, its glowing inside and its sign are painted once per gate
    const col = gc, art = gateArt(gt, z, lv, hot);
    ctx.drawImage(art.c, -art.ox, -art.oy);
    ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = col; ctx.lineWidth = 2;
    for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.ellipse(0, -40 * s, (18 + i * 8) * s, (40 + i * 12) * s, t * (i % 2 ? 1 : -1) * 0.6, 0, TAU); ctx.globalAlpha = 0.25 + 0.1 * i; ctx.stroke(); }
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    for (let k = 0; k < 6; k++) { const a = t * 0.9 + (k / 6) * TAU, ox = Math.cos(a) * 110 * s, oy = Math.sin(a) * 34 * s - 90 * s - Math.sin(t * 2 + k) * 8; if (Math.sin(a) >= 0) continue; ctx.fillStyle = '#3a3048'; ctx.strokeStyle = gc; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(ox, oy - 9); ctx.lineTo(ox + 8, oy); ctx.lineTo(ox, oy + 8); ctx.lineTo(ox - 7, oy); ctx.closePath(); ctx.fill(); ctx.stroke(); }
    drawPumpkin(ctx, -70 * s, 30, 16, t, 0, undefined, undefined, false); drawPumpkin(ctx, 70 * s, 30, 16, t + 1, 0, undefined, undefined, false);
    ctx.restore();
  }
  const gateCache = new Map();
  function gateArt(gt, z, lv, hot) {
    const key = gt.zone + (hot ? 1 : 0);
    if (gateCache.has(key)) return gateCache.get(key);
    const s = gt.big ? 1.35 : 1, col = GATE_COL[gt.zone], W = 420, ox = W / 2, oy = Math.ceil(200 * s), H = oy + 50;
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const g = c.getContext('2d'); g.translate(ox, oy);
    g.fillStyle = '#3a3048'; g.strokeStyle = '#120a1c'; g.lineWidth = 4;
    g.beginPath(); g.moveTo(-70 * s, 40); g.lineTo(-70 * s, -80 * s); g.arc(0, -80 * s, 70 * s, Math.PI, 0); g.lineTo(70 * s, 40); g.lineTo(48 * s, 40); g.lineTo(48 * s, -80 * s); g.arc(0, -80 * s, 48 * s, 0, Math.PI, true); g.lineTo(-48 * s, 40); g.closePath(); g.fill(); g.stroke();
    // carved stones on the arch
    g.strokeStyle = '#2a2034'; g.lineWidth = 2; for (let i = 0; i < 7; i++) { const a = Math.PI + (i / 6) * Math.PI; g.beginPath(); g.moveTo(Math.cos(a) * 48 * s, -80 * s + Math.sin(a) * 48 * s); g.lineTo(Math.cos(a) * 70 * s, -80 * s + Math.sin(a) * 70 * s); g.stroke(); }
    const gr = g.createRadialGradient(0, -60 * s, 4, 0, -60 * s, 70 * s); gr.addColorStop(0, col); gr.addColorStop(1, 'rgba(10,6,20,0.9)');
    g.fillStyle = gr; g.beginPath(); g.moveTo(-48 * s, 40); g.lineTo(-48 * s, -80 * s); g.arc(0, -80 * s, 48 * s, Math.PI, 0); g.lineTo(48 * s, 40); g.closePath(); g.fill();
    g.font = `900 ${gt.big ? 20 : 16}px "Chonburi", serif`; g.textAlign = 'center'; g.lineWidth = 5; g.strokeStyle = '#08040c'; g.fillStyle = hot ? '#fff3c4' : col;
    g.strokeText(z.name, 0, -170 * s); g.fillText(z.name, 0, -170 * s);
    g.font = '700 13px "Bai Jamjuree", system-ui'; g.fillStyle = '#e8dcc0'; const sub = `เลเวล ${lv}+ · สูงสุด ${z.partyMax} คน`; g.strokeText(sub, 0, -150 * s); g.fillText(sub, 0, -150 * s);
    const out = { c, ox, oy };
    if (document.fonts?.status === 'loaded') gateCache.set(key, out);     // until the fonts are in, paint again next frame
    return out;
  }
  function drawExit() {
    const t = w.time, x = V.exit.x, y = V.exit.y;
    drawRuneCircle(ctx, x, y - 4, 110, t, '#c86aff');
    w.lights.push({ x, y: y - 70, r: 280, col: '#c86aff', ga: 0.3 });
    ctx.save(); ctx.translate(x, y - 70);
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 4; i++) { ctx.strokeStyle = `rgba(${i % 2 ? '255,138,31' : '200,106,255'},${0.7 - i * 0.12})`; ctx.lineWidth = 6 - i; ctx.beginPath(); ctx.ellipse(0, 0, 54 + i * 8 + Math.sin(t * 3 + i) * 3, 84 + i * 8, 0, 0, TAU); ctx.stroke(); }
    ctx.restore();
    // the countdown over the portal: days, hours, minutes, seconds
    const c = countdownParts(hwLeftMs());
    ctx.save(); ctx.font = '900 18px "Chonburi", serif'; ctx.textAlign = 'center'; ctx.lineWidth = 5; ctx.strokeStyle = '#08040c'; ctx.fillStyle = '#ffcf5a';
    const txt = `ประตูปิดใน ${c.d} วัน ${c.h} ชม. ${c.m} นาที ${c.s} วินาที`;
    ctx.strokeText(txt, x, y - 190); ctx.fillText(txt, x, y - 190);
    ctx.font = '700 14px "Bai Jamjuree", system-ui'; ctx.fillStyle = '#e8dcc0'; ctx.strokeText(app.online.online ? 'ทางกลับหมู่บ้าน' : 'ทางกลับค่าย', x, y - 168); ctx.fillText(app.online.online ? 'ทางกลับหมู่บ้าน' : 'ทางกลับค่าย', x, y - 168);
    ctx.restore();
  }
  function drawStatue() {
    const t = w.time, x = V.statue.x, y = V.statue.y;
    w.lights.push({ x, y: y - 110, r: 340, img: raysSprite('#ffb648'), rot: t * 0.15, ga: 0.13 + 0.04 * Math.sin(t * 2), glowOnly: true });
    if (fxAmount() >= 1) drawRuneCircle(ctx, x, y + 10, 150, -t * 0.6, '#ff8a1f', 0.4);
    w.lights.push({ x, y: y - 80, r: 460, col: '#ff9a3a', ga: 0.3 + 0.06 * Math.sin(t * 6) });
    ctx.fillStyle = '#2a2234'; ctx.strokeStyle = '#120a1c'; ctx.lineWidth = 4; ctx.beginPath(); ctx.roundRect(x - 90, y - 30, 180, 40, 8); ctx.fill(); ctx.stroke();
    drawPumpkin(ctx, x, y - 110, 74, t, Math.sin(t * 0.5) * 0.03, '#d8641a', '#ffcf5a', false);

  }
  function drawShop() {
    const t = w.time, x = V.shop.x, y = V.shop.y;
    w.lights.push({ x, y: y - 80, r: 280, col: '#ff8ad8', ga: 0.24 });
    ctx.save(); ctx.translate(x, y);
    ctx.fillStyle = '#5a3020'; ctx.strokeStyle = '#1a0a06'; ctx.lineWidth = 3; ctx.fillRect(-110, -60, 220, 70); ctx.strokeRect(-110, -60, 220, 70);
    for (let i = 0; i < 8; i++) { ctx.fillStyle = i % 2 ? '#ff7ab8' : '#fff0f6'; ctx.beginPath(); ctx.moveTo(-120 + i * 30, -100); ctx.lineTo(-120 + (i + 1) * 30, -100); ctx.lineTo(-105 + i * 30, -70); ctx.closePath(); ctx.fill(); ctx.stroke(); }
    ctx.fillStyle = '#3a1a4a'; ctx.fillRect(-124, -112, 248, 14); ctx.strokeRect(-124, -112, 248, 14);
    // jars of candy on the counter
    for (let i = 0; i < 5; i++) { const jx = -80 + i * 40; ctx.fillStyle = 'rgba(220,240,255,0.5)'; ctx.fillRect(jx - 12, -84, 24, 26); ctx.strokeRect(jx - 12, -84, 24, 26); for (let k = 0; k < 4; k++) { ctx.fillStyle = ['#e0303a', '#ffd84a', '#5ae0ff', '#8ad04a'][(i + k) % 4]; ctx.beginPath(); ctx.arc(jx - 5 + (k % 2) * 10, -66 + Math.floor(k / 2) * -8, 4, 0, TAU); ctx.fill(); } }
    // the shopkeeper witch peeking behind the counter
    ctx.fillStyle = '#fde8d8'; ctx.beginPath(); ctx.arc(0, -130 + Math.sin(t * 2) * 2, 16, 0, TAU); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#5a2a6a'; ctx.beginPath(); ctx.moveTo(-26, -138); ctx.lineTo(26, -138); ctx.lineTo(8, -196 + Math.sin(t * 2) * 4); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#1a0a14'; ctx.beginPath(); ctx.arc(-5, -132, 2, 0, TAU); ctx.arc(5, -132, 2, 0, TAU); ctx.fill();
    ctx.font = '900 16px "Chonburi", serif'; ctx.textAlign = 'center'; ctx.lineWidth = 5; ctx.strokeStyle = '#08040c'; ctx.fillStyle = '#ff9ac8'; ctx.strokeText('ร้านแคนดี้', 0, -214); ctx.fillText('ร้านแคนดี้', 0, -214);
    ctx.restore();
  }
  function drawCauldron() {
    const t = w.time, x = V.cauldron.x, y = V.cauldron.y;
    w.lights.push({ x, y: y - 40, r: 260, col: '#7aff5a', ga: 0.3 + 0.1 * Math.sin(t * 5) });
    if (Math.random() < 0.06) for (let k = 0; k < 5; k++) app.particles.spawn({ x: x + rand(-30, 30), y: y - 40, vx: rand(-90, 90), vy: rand(-220, -120), life: 0.9, size: 3.4, size2: 0.6, color: '#8aff5a', drag: 0.2, grav: 420, glow: true });
    ctx.save(); ctx.translate(x, y);
    for (let i = 0; i < 3; i++) { ctx.strokeStyle = '#2a1a10'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(-40 + i * 40, 10); ctx.lineTo(-30 + i * 30, -20); ctx.stroke(); }
    const fl = 0.7 + 0.3 * Math.sin(t * 12); ctx.fillStyle = `rgba(255,${120 + 60 * fl | 0},40,0.9)`; ctx.beginPath(); ctx.ellipse(0, 6, 40, 12, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#1a1a1a'; ctx.strokeStyle = '#000'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(0, -36, 56, 46, 0, 0, Math.PI); ctx.fill(); ctx.stroke(); ctx.beginPath(); ctx.ellipse(0, -36, 56, 12, 0, 0, TAU); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#6aff3a'; ctx.beginPath(); ctx.ellipse(0, -36, 50, 9, 0, 0, TAU); ctx.fill();
    for (let i = 0; i < 4; i++) { const k = (t * 0.8 + i / 4) % 1; ctx.fillStyle = `rgba(160,255,120,${1 - k})`; ctx.beginPath(); ctx.arc(-30 + i * 20, -40 - k * 30, 4 + k * 6, 0, TAU); ctx.fill(); }
    ctx.font = '900 15px "Chonburi", serif'; ctx.textAlign = 'center'; ctx.lineWidth = 5; ctx.strokeStyle = '#08040c'; ctx.fillStyle = '#9fff7a'; ctx.strokeText('หม้อปรุงยาปีศาจ', 0, -100); ctx.fillText('หม้อปรุงยาปีศาจ', 0, -100);
    ctx.restore();
  }
  function drawBoard() {
    const x = V.board.x, y = V.board.y;
    ctx.fillStyle = '#4a3020'; ctx.strokeStyle = '#1a0a06'; ctx.lineWidth = 3;
    ctx.fillRect(x - 6, y - 30, 12, 34); ctx.fillRect(x - 60, y - 100, 120, 76); ctx.strokeRect(x - 60, y - 100, 120, 76);
    ctx.fillStyle = '#efe4cc'; ctx.fillRect(x - 50, y - 92, 44, 30); ctx.fillRect(x + 4, y - 90, 44, 56);
    drawPumpkin(ctx, x - 28, y - 46, 10, w.time, 0);
    ctx.font = '900 14px "Chonburi", serif'; ctx.textAlign = 'center'; ctx.lineWidth = 5; ctx.strokeStyle = '#08040c'; ctx.fillStyle = '#ffcf5a'; ctx.strokeText('กระดานกิจกรรม', x, y - 110); ctx.fillText('กระดานกิจกรรม', x, y - 110);
  }
  function drawTree([x, y], i) {
    ctx.strokeStyle = '#120a14'; ctx.lineCap = 'round';
    ctx.lineWidth = 16; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 4, y - 120); ctx.stroke();
    ctx.lineWidth = 7; for (const [a, l] of [[-0.9, 70], [0.7, 80], [-0.3, 60], [1.2, 50]]) { ctx.beginPath(); ctx.moveTo(x + 4, y - 90 - l * 0.3); ctx.quadraticCurveTo(x + Math.cos(a - 1.57) * l * 0.5, y - 120 - l * 0.3, x + Math.sin(a) * l, y - 140 - Math.cos(a) * l * 0.4 + Math.sin(w.time + i) * 2); ctx.stroke(); }
  }
  function drawGrave([x, y], i = 0) {
    const t = w.time, fl = 0.7 + 0.3 * Math.sin(t * 13 + i * 2) * Math.sin(t * 7 + i);
    ctx.fillStyle = '#efe4cc'; ctx.fillRect(x + 20, y - 12, 5, 12); ctx.fillStyle = `rgba(255,${180 + 60 * fl | 0},80,1)`; ctx.beginPath(); ctx.ellipse(x + 22.5, y - 17, 3, 6 * fl, 0, 0, TAU); ctx.fill();
    w.lights.push({ x: x + 22, y: y - 14, r: 110, col: '#ffb648', ga: 0.25 * fl });
    ctx.fillStyle = '#5a5466'; ctx.strokeStyle = '#1a1424'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(x - 18, y); ctx.lineTo(x - 18, y - 34); ctx.arc(x, y - 34, 18, Math.PI, 0); ctx.lineTo(x + 18, y); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = '#2a2434'; ctx.beginPath(); ctx.moveTo(x, y - 44); ctx.lineTo(x, y - 20); ctx.moveTo(x - 7, y - 36); ctx.lineTo(x + 7, y - 36); ctx.stroke();
  }
  function render() {
    if (!w) return;
    const v = renderer.view;
    renderer.screenSpace(); ctx.fillStyle = '#0e0a1e'; ctx.fillRect(0, 0, v.w, v.h);
    renderer.worldSpace();
    if (!ground) paintGround();
    w.lights = [];
    ctx.drawImage(ground, 0, 0);
    drawSky();
    w.fx.fireworks.draw(ctx);
    // crows on the fence (they take off when you come close)
    for (const c of w.fx.crows) { if (c.fly) { const k = c.fly.t; drawCrow(ctx, c.x + c.fly.vx * k, c.y - k * 180 - Math.sin(k * 8) * 6, 1 + Math.sin(k * 30), c.fly.vx > 0 ? 1 : -1); } else drawCrow(ctx, c.x, c.y, c.flap, c.flip); }
    if (w.walkTo) { ctx.strokeStyle = 'rgba(255,207,90,0.8)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(w.walkTo.x, w.walkTo.y, 16 + Math.sin(w.time * 8) * 3, 7, 0, 0, TAU); ctx.stroke(); }
    const list = [];
    for (const gt of V.gates) list.push({ y: gt.y + 40, draw: () => drawGate(gt) });
    TREES.forEach((tr, i) => list.push({ y: tr[1], draw: () => drawTree(tr, i) }));
    GRAVES.forEach((g, i) => list.push({ y: g[1], draw: () => drawGrave(g, i) }));
    LAMPS.forEach((l, i) => list.push({ y: l[1], draw: () => drawLamp(l, i) }));
    SHROOMS.forEach((m, i) => list.push({ y: m[1] - 20, draw: () => drawShrooms(m, i) }));
    PATCHES.forEach((m, i) => list.push({ y: m[1], draw: () => drawPatch(m, i) }));
    for (const a of w.fx.ghosts.list) w.lights.push({ x: a.x, y: a.y - 70, r: 120, col: '#d8e8ff', ga: 0.25, glowOnly: true });
    for (const a of w.fx.ghosts.list) list.push({ y: a.y, draw: () => drawGhost(ctx, a.x, a.y - 70 + Math.sin(a.t * 1.6 + a.ph) * 14, a.t, (a.vx || 0) < 0 ? -0.9 : 0.9, 0.45 + 0.25 * Math.sin(a.t * 0.8 + a.ph), ['#e8f0ff', '#d0ffe8', '#f0e0ff'][a.i % 3]) });
    list.push({ y: V.statue.y, draw: drawStatue }, { y: V.shop.y, draw: drawShop }, { y: V.cauldron.y, draw: drawCauldron }, { y: V.board.y, draw: drawBoard }, { y: V.exit.y - 10, draw: drawExit });
    list.push({ y: w.me.y, draw: () => drawPerson(w.me, true) });
    for (const r of w.remote.values()) list.push({ y: r.y, draw: () => drawPerson(r, false) });
    for (const b of app.live.boxesIn('halloween')) list.push({ y: b.y, draw: () => drawGiftBox(ctx, b, w.time) });
    list.sort((a, b) => a.y - b.y);
    for (const o of list) o.draw();
    w.fx.leaves.draw(ctx);
    // fog on top
    for (let i = 0; i < 6; i++) { const fx = ((w.time * 20 + i * 400) % (V.w + 600)) - 300, fy = 700 + i * 130; w.lights.push({ x: fx, y: fy, r: 300, col: '#c8b4e6', ga: 0.11, a: 0.2 }); }
    // night: everything outside the lamps sinks into violet dark (lightning lights the whole plaza for a moment)
    w.lights.push({ x: w.me.x, y: w.me.y - 40, r: 260, a: 0.85 }, ...[...w.remote.values()].map((r) => ({ x: r.x, y: r.y - 40, r: 200, a: 0.7 })), ...w.fx.fireworks.lights());
    if (fxAmount() > 0.5) w.fx.light.draw(renderer, w.lights, { dark: 'rgba(14,6,30,0.5)', flash: w.fx.lightning.flash }); else w.fx.light.hide();
    app.particles.draw(ctx);
    // a flock of bats in front of everything
    const fl = w.fx.flock;
    if (fl.t < 5) for (let i = 0; i < 18; i++) { const k = fl.t * 520 - i * 26 - (i % 3) * 14, x = fl.dir > 0 ? k - 200 : V.w + 200 - k; drawBat(ctx, x, fl.y + Math.sin(fl.t * 3 + i) * 40 + (i % 4) * 22, w.time + i, 1.3); }
    tag(w.me, true);
    for (const r of w.remote.values()) tag(r, false);
    if (w.target?.kind === 'player') { const r = w.target.r; ctx.strokeStyle = 'rgba(255,207,90,0.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(r.x, r.y, 30, 11, 0, 0, TAU); ctx.stroke(); }
    renderer.screenSpace();
    if (app.vignette) ctx.drawImage(app.vignette, 0, 0, v.w, v.h);
  }

  return {
    enter() {
      app.particles.clear(); app.refreshHeroSprites(); ground = null;
      const at = V.spawn;
      w = { time: 0, sendAcc: 0, heartbeat: 0, lastKey: '', target: null, walkTo: null, bubbles: new Map(), remote: new Map(),
        me: { x: at.x + (Math.random() - 0.5) * 200, y: at.y, flip: false, moving: false, walkT: 0, dashT: 0, dashCd: 0, vx: 0 }, unsub: [], lights: [] };
      w.fx = makeFx();
      w.unsub.push(app.online.on('chat', (line) => { if (line.ch === 'village' || line.ch === 'party') w.bubbles.set(line.me ? 'me' : line.peer, { text: line.text, t: w.time }); }));
      renderer.ctx.canvas.addEventListener('pointerdown', onPointer);
      renderer.cam.x = w.me.x; renderer.cam.y = w.me.y;
      input.setEnabled(true); input.reset();
      app.hud.showVillage();
      audio.music('village');
      publishMe(true);
    },
    exit() {
      w?.fx?.light.hide();
      if (w) for (const u of w.unsub) u();
      renderer.ctx.canvas.removeEventListener('pointerdown', onPointer);
      input.setEnabled(false); app.hud.hide(); app.hud.setMode('dungeon'); audio.stopMusic();
      w = null;
    },
    update, render,
    get world() { return w; },
    snapshot() { return w ? { me: { x: Math.round(w.me.x), y: Math.round(w.me.y) }, target: w.target?.kind || null, gate: w.target?.gt?.zone || null, remote: w.remote.size } : null; },
    teleport(x, y) { if (w && !blocked(x, y)) { w.me.x = x; w.me.y = y; } },
  };
}
