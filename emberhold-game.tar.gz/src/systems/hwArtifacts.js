// v10.2 Halloween artifacts: owning (level 1–5), the three altar slots, the candy-shop chest, drops, and their bonus
// part for stats (registered into extraBonuses). Pure transactions like the other systems.
import { cloneState } from '../core/state.js';
import { HW_ARTIFACTS, HWA_IDS, getHwArtifact, HWA_LEVEL_MAX, HWA_SLOTS, HWA_CHEST, HWA_RARITY_W, hwaStatMult, hwaProcMult } from '../data/hwArtifacts.js';
import { hwActive } from '../data/halloween.js';
import { registerBonus } from './extraBonuses.js';

export const HWA_MAXED_CANDY = 600;     // a copy of an artifact already at level 5 becomes candy
export const hwaLevel = (st, id) => st.hwa?.own?.[id] | 0;

// pick an artifact by rarity weight (rnd: () => [0,1))
export function rollHwArtifact(rnd) {
  const ids = HWA_IDS, tot = ids.reduce((a, id) => a + HWA_RARITY_W[HW_ARTIFACTS[id].rarity], 0);
  let r = rnd() * tot;
  for (const id of ids) { r -= HWA_RARITY_W[HW_ARTIFACTS[id].rarity]; if (r < 0) return id; }
  return ids[ids.length - 1];
}
// add one copy in place (on a cloned state). Returns { lvl, maxed, candy }
export function grantHwArtifactInPlace(next, id) {
  if (!getHwArtifact(id)) return { lvl: 0, maxed: false, candy: 0 };
  const cur = next.hwa.own[id] | 0;
  if (cur >= HWA_LEVEL_MAX) { next.candy = (next.candy || 0) + HWA_MAXED_CANDY; return { lvl: cur, maxed: true, candy: HWA_MAXED_CANDY }; }
  next.hwa.own[id] = cur + 1;
  if (!cur && next.hwa.on.length < HWA_SLOTS) next.hwa.on.push(id);    // the first ones go straight onto the altar
  return { lvl: cur + 1, maxed: false, candy: 0, isNew: !cur };
}
export function buyHwaChest(state, rnd) {
  if (!hwActive()) return { ok: false, reason: 'event_over' };
  if ((state.candy || 0) < HWA_CHEST.price) return { ok: false, reason: 'candy' };
  const next = cloneState(state);
  next.candy -= HWA_CHEST.price;
  const id = rollHwArtifact(rnd);
  const g = grantHwArtifactInPlace(next, id);
  return { ok: true, state: next, id, ...g };
}
export function wearHwArtifact(state, id) {
  if (!hwaLevel(state, id)) return { ok: false, reason: 'not_owned' };
  if (state.hwa.on.includes(id)) return { ok: false, reason: 'worn' };
  if (state.hwa.on.length >= HWA_SLOTS) return { ok: false, reason: 'full' };
  const next = cloneState(state); next.hwa.on.push(id);
  return { ok: true, state: next };
}
export function removeHwArtifact(state, id) {
  if (!state.hwa.on.includes(id)) return { ok: false, reason: 'not_worn' };
  const next = cloneState(state); next.hwa.on = next.hwa.on.filter((x) => x !== id);
  return { ok: true, state: next };
}
// stat part of the worn ones
export function hwaBonuses(state) {
  const out = {};
  for (const id of state.hwa?.on || []) {
    const a = getHwArtifact(id), lv = hwaLevel(state, id);
    if (!a || !lv) continue;
    for (const [k, v] of Object.entries(a.fx)) out[k] = (out[k] || 0) + v * hwaStatMult(lv);
  }
  return out;
}
registerBonus(hwaBonuses);
// what the battle needs: the worn artifacts with their trick multiplier
export function hwaCombat(state) {
  return (state.hwa?.on || []).map((id) => ({ id, def: getHwArtifact(id), k: hwaProcMult(hwaLevel(state, id)) })).filter((x) => x.def && hwaLevel(state, x.id) > 0);
}
