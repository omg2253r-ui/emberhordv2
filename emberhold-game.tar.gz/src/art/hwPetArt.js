// v10.2 bodies of the twenty Halloween pets that drop in the Halloween lands. Each is drawn for itself (no recolours):
// ink outlines and flat fills like the rest of the bestiary, about 60×60, anchored at the feet.
import { INK } from './palette.js';

const T = `stroke="${INK}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"`;
const T1 = `stroke="${INK}" stroke-width="1.4" stroke-linejoin="round" stroke-linecap="round"`;
const svg = (w, h, body) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}">${body}</svg>`;
const SP = (W, H, body, ay = H - 3) => () => ({ w: W, h: H, ax: W / 2, ay, svg: svg(W, H, body) });
const eyes = (x1, x2, y, col = '#ffd84a', r = 3) => `<ellipse cx="${x1}" cy="${y}" rx="${r}" ry="${r * 1.2}" fill="${col}"/><ellipse cx="${x2}" cy="${y}" rx="${r}" ry="${r * 1.2}" fill="${col}"/><circle cx="${x1}" cy="${y}" r="${r * 0.45}" fill="${INK}"/><circle cx="${x2}" cy="${y}" r="${r * 0.45}" fill="${INK}"/>`;

export const HW_PET_ART = Object.freeze({
  // สวนแห่งพงไพร
  pet_hwp_vine_imp: SP(56, 58, `<path d="M12 56 C8 44 14 40 20 42 C18 34 22 30 28 30 C36 30 40 36 38 42 C44 40 50 46 44 56 Z" fill="#4a8a3a" ${T}/>
    <path d="M28 30 C26 22 30 16 36 16" stroke="#3a6a2a" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M34 16 C40 10 48 12 46 18 C42 20 36 18 34 16 Z" fill="#7fd06a" ${T1}/>
    <ellipse cx="28" cy="40" rx="12" ry="9" fill="#e8801f" ${T}/><path d="M22 38 L26 36 L26 41 Z M34 38 L30 36 L30 41 Z" fill="#ffd84a"/><path d="M22 44 Q28 48 34 44" stroke="${INK}" stroke-width="1.6" fill="none"/>
    <path d="M10 46 C2 40 4 30 10 28 M46 48 C54 44 54 34 48 30" stroke="#5a9a3a" stroke-width="3" fill="none" stroke-linecap="round"/><circle cx="10" cy="28" r="3" fill="#9fe05a" ${T1}/><circle cx="48" cy="30" r="3" fill="#9fe05a" ${T1}/>`),
  pet_hwp_candle_moth: SP(62, 50, `<path d="M31 26 C20 8 4 8 4 20 C4 30 16 34 30 30 Z" fill="#f3e6c8" ${T}/><path d="M31 26 C42 8 58 8 58 20 C58 30 46 34 32 30 Z" fill="#f3e6c8" ${T}/>
    <path d="M30 30 C18 34 10 44 18 46 C24 46 28 40 30 34 Z M32 30 C44 34 52 44 44 46 C38 46 34 40 32 34 Z" fill="#e0c07a" ${T1}/>
    <circle cx="14" cy="18" r="4" fill="#ffb84a" opacity="0.9"/><circle cx="48" cy="18" r="4" fill="#ffb84a" opacity="0.9"/>
    <ellipse cx="31" cy="30" rx="4" ry="12" fill="#8a6a3a" ${T}/><path d="M29 18 C26 10 22 8 20 10 M33 18 C36 10 40 8 42 10" stroke="${INK}" stroke-width="1.6" fill="none"/>
    <path d="M31 6 C28 10 30 14 31 14 C32 14 34 10 31 6 Z" fill="#ffe08a" ${T1}/>${eyes(28.5, 33.5, 22, '#ffe08a', 1.8)}`, 46),
  pet_hwp_scarecrow: SP(56, 70, `<path d="M28 68 L28 30" stroke="#6a4424" stroke-width="5"/><path d="M6 36 L50 36" stroke="#6a4424" stroke-width="5" stroke-linecap="round"/>
    <path d="M14 34 L42 34 L46 56 L10 56 Z" fill="#7a5a9a" ${T}/><path d="M20 40 L22 46 M34 42 L36 48 M26 50 L30 50" stroke="#e0b45a" stroke-width="2"/>
    <path d="M6 36 L2 44 M6 36 L4 46 M50 36 L54 44 M50 36 L52 46" stroke="#e0b45a" stroke-width="2"/>
    <circle cx="28" cy="22" r="11" fill="#e8c890" ${T}/><path d="M22 20 L26 22 L22 24 Z M34 20 L30 22 L34 24 Z" fill="${INK}"/><path d="M22 27 L25 29 L28 27 L31 29 L34 27" stroke="${INK}" stroke-width="1.6" fill="none"/>
    <path d="M12 14 L44 14 L36 4 L22 4 Z" fill="#3a2a1a" ${T}/><path d="M8 15 L48 15" stroke="${INK}" stroke-width="3"/><path d="M14 56 L12 60 M42 56 L44 60" stroke="#e0b45a" stroke-width="2"/>`, 68),
  pet_hwp_mushroom_ghoul: SP(58, 60, `<path d="M18 58 L20 34 L38 34 L40 58 Z" fill="#efe4cc" ${T}/>${eyes(24, 34, 44, '#c8a8ff', 2.6)}<path d="M25 52 Q29 54 33 52" stroke="${INK}" stroke-width="1.6" fill="none"/>
    <path d="M4 34 C4 14 18 6 29 6 C40 6 54 14 54 34 Z" fill="#6a3a8a" ${T}/><circle cx="16" cy="22" r="5" fill="#efe4cc" opacity="0.9"/><circle cx="30" cy="14" r="4" fill="#efe4cc" opacity="0.9"/><circle cx="42" cy="24" r="6" fill="#efe4cc" opacity="0.9"/>
    <path d="M10 34 L48 34" stroke="${INK}" stroke-width="2"/><path d="M20 22 L26 26 M38 18 L44 20" stroke="#c8a8ff" stroke-width="1.6"/>`),
  // คฤหาสน์ฟักทองหลอน
  pet_hwp_jack_jr: SP(56, 62, `<path d="M18 60 L20 44 L36 44 L38 60" fill="#2a1a3a" ${T}/><path d="M14 46 L42 46 L40 52 L16 52 Z" fill="#5a2a6a" ${T1}/>
    <ellipse cx="20" cy="28" rx="10" ry="14" fill="#c8641a" ${T1}/><ellipse cx="36" cy="28" rx="10" ry="14" fill="#c8641a" ${T1}/><ellipse cx="28" cy="28" rx="12" ry="16" fill="#ff8a1f" ${T}/>
    <path d="M27 12 C26 6 30 4 32 6" stroke="#3a6a2a" stroke-width="3.4" fill="none" stroke-linecap="round"/>
    <path d="M19 24 L25 21 L24 28 Z M37 24 L31 21 L32 28 Z" fill="#fff1a0"/><path d="M18 34 L22 37 L26 34 L30 37 L34 34 L38 37 L36 40 L20 40 Z" fill="#fff1a0"/>
    <path d="M44 40 L54 36" stroke="${INK}" stroke-width="2.6"/><circle cx="54" cy="35" r="4" fill="#ff8a1f" ${T1}/>`),
  pet_hwp_candelabra: SP(54, 64, `<path d="M18 62 L36 62 L32 56 L22 56 Z" fill="#c8a060" ${T}/><path d="M27 56 L27 30" stroke="${INK}" stroke-width="5"/><path d="M27 56 L27 30" stroke="#e0b45a" stroke-width="3"/>
    <path d="M8 34 Q8 44 27 44 Q46 44 46 34" stroke="${INK}" stroke-width="5" fill="none"/><path d="M8 34 Q8 44 27 44 Q46 44 46 34" stroke="#e0b45a" stroke-width="3" fill="none"/>
    ${[8, 27, 46].map((x, i) => `<rect x="${x - 4}" y="${i === 1 ? 16 : 24}" width="8" height="${i === 1 ? 14 : 10}" fill="#f3e6c8" ${T1}/><path d="M${x} ${i === 1 ? 4 : 12} C${x - 4} ${i === 1 ? 10 : 18} ${x - 2} ${i === 1 ? 15 : 23} ${x} ${i === 1 ? 15 : 23} C${x + 2} ${i === 1 ? 15 : 23} ${x + 4} ${i === 1 ? 10 : 18} ${x} ${i === 1 ? 4 : 12} Z" fill="#ffb84a" ${T1}/>`).join('')}
    ${eyes(23, 31, 50, '#ffe08a', 2)}`),
  pet_hwp_portrait: SP(52, 62, `<rect x="4" y="4" width="44" height="54" rx="3" fill="#8a5a2a" ${T}/><rect x="10" y="10" width="32" height="42" fill="#2a1a3a" ${T1}/>
    <path d="M14 52 L14 34 Q14 22 26 22 Q38 22 38 34 L38 52 Z" fill="#4a3a5a"/><circle cx="26" cy="22" r="8" fill="#e8d8c0" ${T1}/>
    ${eyes(22.5, 29.5, 21, '#ffffff', 2.4)}<circle cx="22.5" cy="21" r="1.4" fill="#c27ff0"/><circle cx="29.5" cy="21" r="1.4" fill="#c27ff0"/>
    <path d="M4 4 L10 10 M48 4 L42 10 M4 58 L10 52 M48 58 L42 52" stroke="#e0b45a" stroke-width="2"/>`, 60),
  pet_hwp_butler: SP(52, 68, `<path d="M14 66 L16 40 L36 40 L38 66" fill="#1a1a24" ${T}/><path d="M20 40 L26 54 L32 40" fill="#f4f0ff" ${T1}/><path d="M24 42 L26 46 L28 42 Z" fill="#c2142a"/>
    <path d="M14 12 Q14 0 26 0 Q38 0 38 12 Q38 22 32 24 L32 30 L20 30 L20 24 Q14 22 14 12 Z" fill="#efe8d8" ${T}/><circle cx="21" cy="12" r="4" fill="${INK}"/><circle cx="31" cy="12" r="4" fill="${INK}"/><circle cx="21" cy="12" r="1.4" fill="#e8f4ff"/><circle cx="31" cy="12" r="1.4" fill="#e8f4ff"/>
    <path d="M22 26 L22 30 M26 26 L26 30 M30 26 L30 30" stroke="${INK}" stroke-width="1.4"/><path d="M36 44 L48 40" stroke="${INK}" stroke-width="2.6"/>
    <path d="M42 34 L52 34 L50 40 L44 40 Z" fill="#f4f0ff" ${T1}/><path d="M44 30 C44 26 48 26 46 22" stroke="#e8f4ff" stroke-width="1.4" fill="none"/>`, 66),
  // ทุ่งเก็บเกี่ยววิญญาณ
  pet_hwp_crow: SP(60, 46, `<path d="M6 30 Q16 14 34 16 L48 10 L44 20 Q50 30 38 36 L28 38 L18 44 L20 36 Q10 36 6 30 Z" fill="#14101c" ${T}/>
    <path d="M18 28 Q26 18 40 24" stroke="#3a3048" stroke-width="2" fill="none"/><circle cx="40" cy="17" r="2.4" fill="#9a6aff"/><path d="M48 12 L58 14 L48 18" fill="#c8a060" ${T1}/>
    <path d="M26 38 L24 44 M32 37 L32 44" stroke="#c8a060" stroke-width="2"/>`, 44),
  pet_hwp_soul_wisp: SP(48, 56, `<circle cx="24" cy="24" r="20" fill="#8ff0e0" opacity="0.25"/><path d="M24 4 C38 10 40 24 34 34 C30 42 24 44 22 54 C18 44 10 40 10 30 C10 18 16 10 24 4 Z" fill="#e8fffb" ${T}/>
    ${eyes(19, 28, 26, '#24405a', 2.4)}<path d="M20 34 Q24 36 28 34" stroke="#24405a" stroke-width="1.4" fill="none"/><circle cx="34" cy="14" r="2" fill="#8ff0e0"/>`, 52),
  pet_hwp_scythe_spirit: SP(60, 62, `<path d="M36 60 L22 10" stroke="${INK}" stroke-width="6" stroke-linecap="round"/><path d="M36 60 L22 10" stroke="#4a3a2a" stroke-width="3.4" stroke-linecap="round"/>
    <path d="M24 12 C36 2 54 8 58 26 C48 16 36 14 26 20 Z" fill="#e8eef8" ${T}/><path d="M28 16 C38 12 48 16 54 22" stroke="#cfe0f0" stroke-width="1.6" fill="none"/>
    <path d="M14 40 C10 30 18 22 26 26 C34 28 32 40 26 44 C22 46 18 46 14 40 Z" fill="#cfe0f0" opacity="0.8" ${T1}/>${eyes(19, 26, 34, '#24405a', 1.8)}`, 60),
  pet_hwp_reaper_kid: SP(52, 64, `<path d="M8 62 C8 36 14 18 26 16 C38 18 44 36 44 62 L38 58 L32 62 L26 58 L20 62 L14 58 Z" fill="#1a1428" ${T}/>
    <path d="M14 30 Q14 10 26 8 Q38 10 38 30 Q32 24 26 24 Q20 24 14 30 Z" fill="#2a2038" ${T}/><ellipse cx="26" cy="30" rx="9" ry="8" fill="#0a0612"/>${eyes(22, 30, 30, '#5affc8', 2)}
    <path d="M44 62 L48 18" stroke="${INK}" stroke-width="3.6"/><path d="M48 18 C40 14 34 16 32 20 C38 18 44 20 46 24 Z" fill="#cfe0f0" ${T1}/>`, 62),
  // กระท่อมขนมของแม่มด
  pet_hwp_gingerbread: SP(52, 58, `<path d="M26 4 C34 4 36 12 34 16 L44 20 C50 22 48 30 42 28 L36 26 L38 40 L46 52 C48 56 42 58 40 54 L32 44 L26 46 L20 44 L12 54 C10 58 4 56 6 52 L14 40 L16 26 L10 28 C4 30 2 22 8 20 L18 16 C16 12 18 4 26 4 Z" fill="#c87a3a" ${T}/>
    <circle cx="22" cy="11" r="1.8" fill="${INK}"/><circle cx="30" cy="11" r="1.8" fill="${INK}"/><path d="M22 15 Q26 18 30 15" stroke="#fff3f8" stroke-width="1.6" fill="none"/>
    <circle cx="26" cy="26" r="2.4" fill="#ff5a8a"/><circle cx="26" cy="34" r="2.4" fill="#5ac8ff"/><path d="M14 22 Q18 24 14 26 M38 22 Q34 24 38 26 M14 48 Q18 46 16 44 M38 48 Q34 46 36 44" stroke="#fff3f8" stroke-width="1.6" fill="none"/>`, 56),
  pet_hwp_lollipop_slime: SP(56, 56, `<path d="M6 52 C2 36 12 24 28 24 C44 24 54 36 50 52 Z" fill="#ff7ab0" opacity="0.92" ${T}/><path d="M10 46 C14 38 20 34 28 34" stroke="#ffd0e4" stroke-width="3" fill="none"/>
    ${eyes(21, 35, 40, '#ffffff', 3)}<path d="M24 47 Q28 50 32 47" stroke="${INK}" stroke-width="1.6" fill="none"/>
    <path d="M28 24 L28 10" stroke="${INK}" stroke-width="3"/><circle cx="28" cy="8" r="7" fill="#fff0f6" ${T1}/><path d="M28 8 m0 -2 a2 2 0 1 1 -2 2 a4 4 0 1 1 4 4" stroke="#5ac8ff" stroke-width="1.6" fill="none"/>`),
  pet_hwp_cotton_bat: SP(64, 46, `<path d="M32 22 C26 10 12 8 2 12 C8 16 8 22 6 26 C12 22 18 24 22 30 C24 26 28 26 32 28 C36 26 40 26 42 30 C46 24 52 22 58 26 C56 22 56 16 62 12 C52 8 38 10 32 22 Z" fill="#ffc8e8" ${T}/>
    <circle cx="14" cy="16" r="5" fill="#fff0f6" opacity="0.9"/><circle cx="50" cy="16" r="5" fill="#fff0f6" opacity="0.9"/><circle cx="24" cy="22" r="3.4" fill="#c8f0ff" opacity="0.9"/><circle cx="40" cy="22" r="3.4" fill="#c8f0ff" opacity="0.9"/>
    <ellipse cx="32" cy="26" rx="8" ry="9" fill="#ff9fd0" ${T1}/>${eyes(29, 35, 24, '#ffffff', 1.8)}<path d="M30 30 L31 32 M34 30 L33 32" stroke="#ffffff" stroke-width="1.4"/>`, 42),
  pet_hwp_candy_golem: SP(60, 64, `<rect x="10" y="22" width="40" height="34" rx="10" fill="#fff0f6" ${T}/><path d="M12 30 L48 50 M12 42 L40 56 M20 22 L50 38" stroke="#ff5a8a" stroke-width="4"/>
    <circle cx="8" cy="40" r="8" fill="#5ac8ff" ${T}/><circle cx="52" cy="40" r="8" fill="#9fe05a" ${T}/><path d="M4 40 L12 40 M48 40 L56 40" stroke="#ffffff" stroke-width="2"/>
    <rect x="18" y="4" width="24" height="20" rx="7" fill="#ffcf5a" ${T}/>${eyes(25, 35, 13, '#c2142a', 2.4)}<path d="M18 58 L18 62 M42 58 L42 62" stroke="${INK}" stroke-width="5" stroke-linecap="round"/>`, 62),
  // หอแม่มดจอมหลอกลวง
  pet_hwp_mirror_imp: SP(52, 58, `<ellipse cx="26" cy="26" rx="20" ry="24" fill="#2a3a5a" ${T}/><ellipse cx="26" cy="26" rx="15" ry="19" fill="#bfe8ff" opacity="0.75"/>
    <path d="M18 14 L24 26 M26 10 L32 22" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/><path d="M14 30 Q26 44 38 30" stroke="#2a3a5a" stroke-width="2" fill="none"/>
    ${eyes(20, 32, 28, '#2a3a5a', 2.6)}<path d="M20 50 L32 50 L30 56 L22 56 Z" fill="#c8a060" ${T1}/><path d="M6 20 L2 16 M46 20 L50 16" stroke="#bfe8ff" stroke-width="2"/>`, 56),
  pet_hwp_hex_owl: SP(54, 60, `<path d="M10 54 C6 34 12 18 27 16 C42 18 48 34 44 54 Z" fill="#3a2a4a" ${T}/><path d="M10 20 L14 6 L22 16 M44 20 L40 6 L32 16" fill="#3a2a4a" ${T}/>
    <circle cx="19" cy="28" r="7" fill="#9fe05a" ${T1}/><circle cx="35" cy="28" r="7" fill="#9fe05a" ${T1}/><circle cx="19" cy="28" r="2.6" fill="${INK}"/><circle cx="35" cy="28" r="2.6" fill="${INK}"/>
    <path d="M25 34 L27 38 L29 34 Z" fill="#e0b45a" ${T1}/><path d="M16 42 Q27 50 38 42 M18 48 Q27 54 36 48" stroke="#9fe05a" stroke-width="1.4" fill="none"/>
    <path d="M12 4 L27 -2 L42 4" stroke="none"/><path d="M14 10 L27 0 L40 10 L27 12 Z" fill="#4a2a6a" ${T1}/>`, 58),
  pet_hwp_broom_sprite: SP(64, 44, `<path d="M58 10 L22 30" stroke="${INK}" stroke-width="5" stroke-linecap="round"/><path d="M58 10 L22 30" stroke="#8a5a32" stroke-width="2.6" stroke-linecap="round"/>
    <path d="M24 26 L4 30 L2 40 L12 42 L28 34 Z" fill="#e0b45a" ${T}/><path d="M6 34 L22 30 M8 38 L24 33" stroke="#8a6a2a" stroke-width="1.4"/>
    <circle cx="44" cy="16" r="7" fill="#fff3c4" ${T1}/>${eyes(42, 47, 15, '#3a2a1a', 1.4)}<path d="M38 22 C34 28 36 32 40 30" stroke="#ffd84a" stroke-width="2" fill="none"/>`, 42),
  pet_hwp_tome_familiar: SP(60, 52, `<path d="M30 14 C20 8 8 8 4 12 L4 44 C10 40 22 40 30 46 Z" fill="#7a2a5a" ${T}/><path d="M30 14 C40 8 52 8 56 12 L56 44 C50 40 38 40 30 46 Z" fill="#9a3a7a" ${T}/>
    <path d="M8 16 C14 14 22 14 28 18 L28 42 C22 38 14 38 8 40 Z" fill="#fff3e0" ${T1}/><path d="M52 16 C46 14 38 14 32 18 L32 42 C38 38 46 38 52 40 Z" fill="#fff3e0" ${T1}/>
    <path d="M12 22 L24 24 M12 28 L22 29 M36 24 L48 22 M38 29 L48 28" stroke="#ff7ad8" stroke-width="1.4"/>${eyes(16, 44, 34, '#ff7ad8', 2)}<path d="M26 6 L30 2 L34 6" stroke="#ffe08a" stroke-width="2" fill="none"/>`, 50),
});
