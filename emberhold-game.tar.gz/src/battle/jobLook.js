// v10.2 how a class changes the hero: a ring and an aura at the feet (drawJobGround, under the hero) and headgear with
// little class touches around the head (drawJobHead, over the hero). Used for my hero, party members, the village
// and the class hall's ceremony. Everything is drawn with paths in the hero's ink style, no images.
import { getJob } from '../data/jobs.js';
import { glowSprite } from '../scenes/ambientFx.js';

const TAU = Math.PI * 2;
const INK = '#141022';
function glow(ctx, x, y, r, col, a) { const p = ctx.globalAlpha; ctx.globalAlpha = p * a; ctx.drawImage(glowSprite(col), x - r, y - r, r * 2, r * 2); ctx.globalAlpha = p; }
function rnd(i) { const s = Math.sin(i * 127.1) * 43758.5453; return s - Math.floor(s); }

// ------------------------------------------------------------------ at the feet
export function drawJobGround(ctx, x, y, t, id, scale = 1) {
  const j = getJob(id); if (!j) return;
  const L = j.look, G = L.glow;
  ctx.save(); ctx.translate(x, y); ctx.scale(scale, scale);
  ctx.globalCompositeOperation = 'lighter';
  glow(ctx, 0, 0, 46, G, 0.35);
  ctx.save(); ctx.scale(1, 0.36); ctx.rotate(t * 0.8);
  ctx.strokeStyle = G; ctx.globalAlpha = 0.55; ctx.lineWidth = 2.4; ctx.setLineDash([10, 6]);
  ctx.beginPath(); ctx.arc(0, 0, 40, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
  ctx.globalAlpha = 0.8;
  const n = j.grade === 'SS' ? 6 : j.grade === 'S' ? 4 : 3;
  for (let i = 0; i < n; i++) { const a = (i / n) * TAU; ctx.fillStyle = G; ctx.beginPath(); ctx.arc(Math.cos(a) * 40, Math.sin(a) * 40, 3.4, 0, TAU); ctx.fill(); }
  ctx.restore();
  // the aura of the class
  ctx.globalAlpha = 1;
  const A = L.aura;
  for (let i = 0; i < 8; i++) {
    const q = (t * (0.35 + rnd(i) * 0.3) + rnd(i + 9)) % 1, ang = rnd(i + 3) * TAU, rr = 14 + rnd(i + 5) * 26;
    const px = Math.cos(ang + t * 0.4) * rr, py = Math.sin(ang) * rr * 0.35 - q * 90;
    const a = (1 - q) * (q < 0.1 ? q * 10 : 1);
    ctx.globalAlpha = a;
    if (A === 'petal' || A === 'leaves' || A === 'ribbonfx') { ctx.fillStyle = A === 'leaves' ? '#7fd06a' : A === 'petal' ? '#ffc8de' : G; ctx.save(); ctx.translate(px, py); ctx.rotate(t * 3 + i); ctx.beginPath(); ctx.ellipse(0, 0, 4, 2, 0, 0, TAU); ctx.fill(); ctx.restore(); }
    else if (A === 'notes') { ctx.fillStyle = G; ctx.font = '700 13px serif'; ctx.fillText(i % 2 ? '♪' : '♫', px, py); }
    else if (A === 'clocks' || A === 'runes') { ctx.strokeStyle = G; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(px, py, 4, 0, TAU); ctx.stroke(); ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + Math.cos(t * 4 + i) * 3, py + Math.sin(t * 4 + i) * 3); ctx.stroke(); }
    else if (A === 'bubbles') { ctx.strokeStyle = G; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(px, py, 2.5 + rnd(i) * 3, 0, TAU); ctx.stroke(); }
    else if (A === 'cross' || A === 'holyring') { ctx.fillStyle = G; ctx.fillRect(px - 0.8, py - 4, 1.6, 8); ctx.fillRect(px - 3, py - 1.5, 6, 1.6); }
    else if (A === 'paws') { ctx.fillStyle = G; ctx.beginPath(); ctx.arc(px, py, 2.4, 0, TAU); for (let k = 0; k < 3; k++) ctx.arc(px - 3 + k * 3, py - 3.4, 1.1, 0, TAU); ctx.fill(); }
    else glow(ctx, px, py, A === 'rage' ? 9 : 6, A === 'rage' ? '#ff4a5a' : A === 'smoke' ? '#5a3a9a' : G, 0.9);
  }
  ctx.restore();
}

// ------------------------------------------------------------------ on the head
const HEAD_Y = -97;     // top of the hero's head at scale 0.95
export function drawJobHead(ctx, x, y, t, id, flip = false, scale = 1) {
  const j = getJob(id); if (!j) return;
  const L = j.look, d = flip ? -1 : 1;
  ctx.save(); ctx.translate(x + 3 * d * scale, y + HEAD_Y * scale); ctx.scale(d * scale, scale);
  ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.strokeStyle = INK; ctx.lineWidth = 2.2;
  const H = HATS[L.hat];
  if (H) H(ctx, t, L);
  ctx.restore();
}
const fillStroke = (ctx, col) => { ctx.fillStyle = col; ctx.fill(); ctx.stroke(); };
const HATS = {
  plume(ctx, t, L) {
    ctx.beginPath(); ctx.moveTo(-16, 8); ctx.quadraticCurveTo(-16, -8, 0, -9); ctx.quadraticCurveTo(16, -8, 16, 8); ctx.lineTo(10, 10); ctx.lineTo(-10, 10); ctx.closePath(); fillStroke(ctx, '#c8d4e4');
    ctx.beginPath(); ctx.moveTo(-12, 4); ctx.lineTo(12, 4); ctx.stroke();
    const sw = Math.sin(t * 3) * 3;
    ctx.beginPath(); ctx.moveTo(-2, -8); ctx.bezierCurveTo(-10, -26, -26 + sw, -24, -32 + sw, -10); ctx.bezierCurveTo(-22 + sw, -16, -14, -14, 2, -6); ctx.closePath(); fillStroke(ctx, '#c2142a');
  },
  kabuto(ctx, t, L) {
    ctx.beginPath(); ctx.moveTo(-17, 10); ctx.quadraticCurveTo(-17, -10, 0, -10); ctx.quadraticCurveTo(17, -10, 17, 10); ctx.closePath(); fillStroke(ctx, '#2a2a3a');
    ctx.beginPath(); ctx.moveTo(-4, -6); ctx.bezierCurveTo(-14, -16, -22, -28, -16, -36); ctx.bezierCurveTo(-14, -24, -6, -16, 0, -10); ctx.closePath(); fillStroke(ctx, '#ffcf5a');
    ctx.beginPath(); ctx.moveTo(4, -6); ctx.bezierCurveTo(14, -16, 22, -28, 16, -36); ctx.bezierCurveTo(14, -24, 6, -16, 0, -10); ctx.closePath(); fillStroke(ctx, '#ffcf5a');
    ctx.beginPath(); ctx.arc(0, -6, 3.4, 0, TAU); fillStroke(ctx, '#c2142a');
  },
  hood(ctx, t, L) {
    ctx.beginPath(); ctx.moveTo(-19, 18); ctx.quadraticCurveTo(-20, -12, 2, -12); ctx.quadraticCurveTo(22, -10, 18, 16); ctx.quadraticCurveTo(10, 4, 0, 4); ctx.quadraticCurveTo(-10, 4, -19, 18); ctx.closePath(); fillStroke(ctx, '#1a1428');
    const sw = Math.sin(t * 5) * 4;
    ctx.beginPath(); ctx.moveTo(-14, 10); ctx.quadraticCurveTo(-30, 14 + sw, -40, 8 + sw); ctx.lineTo(-38, 14 + sw); ctx.quadraticCurveTo(-28, 20, -14, 16); ctx.closePath(); fillStroke(ctx, '#5a3a9a');
  },
  horns(ctx, t, L) {
    for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(s * 8, -4); ctx.bezierCurveTo(s * 22, -8, s * 26, -22, s * 18, -32); ctx.bezierCurveTo(s * 20, -20, s * 14, -12, s * 4, -8); ctx.closePath(); fillStroke(ctx, '#efe4cc'); }
    ctx.beginPath(); ctx.moveTo(-16, 4); ctx.quadraticCurveTo(0, -8, 16, 4); ctx.lineTo(14, 8); ctx.quadraticCurveTo(0, -2, -14, 8); ctx.closePath(); fillStroke(ctx, '#5a1a1a');
    glow(ctx, 0, 0, 18, '#ff4a5a', 0.25 + 0.15 * Math.sin(t * 6));
  },
  wizard(ctx, t, L) {
    ctx.beginPath(); ctx.ellipse(0, 4, 24, 6, 0, 0, TAU); fillStroke(ctx, '#3a2a7a');
    ctx.beginPath(); ctx.moveTo(-14, 2); ctx.quadraticCurveTo(-6, -24, 10 + Math.sin(t * 2) * 3, -40); ctx.quadraticCurveTo(4, -20, 14, 2); ctx.closePath(); fillStroke(ctx, '#4a3a9a');
    ctx.fillStyle = '#ff7ad8'; ctx.fillRect(-13, -4, 26, 4);
    ctx.fillStyle = '#ffe08a'; ctx.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + (i * TAU) / 10, r = i % 2 ? 2 : 4.6; ctx.lineTo(Math.cos(a) * r, -14 + Math.sin(a) * r); } ctx.fill();
  },
  feather(ctx, t, L) {
    ctx.beginPath(); ctx.moveTo(-16, 6); ctx.quadraticCurveTo(-14, -10, 2, -10); ctx.quadraticCurveTo(18, -8, 18, 6); ctx.closePath(); fillStroke(ctx, '#2f6a3a');
    const sw = Math.sin(t * 2.5) * 0.15;
    ctx.save(); ctx.translate(10, -6); ctx.rotate(-0.6 + sw); ctx.beginPath(); ctx.ellipse(0, -14, 4, 15, 0, 0, TAU); fillStroke(ctx, '#9fe6cf'); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -27); ctx.stroke(); ctx.restore();
  },
  dragonhelm(ctx, t, L) {
    ctx.beginPath(); ctx.moveTo(-16, 10); ctx.quadraticCurveTo(-16, -10, 2, -10); ctx.quadraticCurveTo(18, -8, 16, 10); ctx.closePath(); fillStroke(ctx, '#2a3a6a');
    for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(s * 12, -4); ctx.lineTo(s * 30, -20); ctx.lineTo(s * 24, -6); ctx.lineTo(s * 32, -4); ctx.lineTo(s * 14, 4); ctx.closePath(); fillStroke(ctx, '#ffe65a'); }
    ctx.beginPath(); ctx.moveTo(0, -10); ctx.lineTo(4, -24); ctx.lineTo(8, -9); ctx.closePath(); fillStroke(ctx, '#ffe65a');
  },
  reaperhood(ctx, t, L) {
    ctx.beginPath(); ctx.moveTo(-20, 22); ctx.quadraticCurveTo(-22, -14, 2, -14); ctx.quadraticCurveTo(14, -14, 20, -4); ctx.lineTo(26, -18); ctx.lineTo(22, 2); ctx.quadraticCurveTo(22, 14, 18, 22); ctx.quadraticCurveTo(10, 6, 0, 6); ctx.quadraticCurveTo(-10, 6, -20, 22); ctx.closePath(); fillStroke(ctx, '#1a2a2a');
    for (let i = 0; i < 2; i++) { const a = t * 1.6 + i * Math.PI; glow(ctx, Math.cos(a) * 30, -10 + Math.sin(a) * 8, 7, '#8ff0e0', 0.9); }
  },
  ribbons(ctx, t, L) {
    for (const s of [-1, 1]) { const sw = Math.sin(t * 4 + s) * 6; ctx.beginPath(); ctx.moveTo(s * 10, -2); ctx.bezierCurveTo(s * 24, 4 + sw, s * 30, 20 - sw, s * 40, 26 + sw); ctx.lineTo(s * 38, 30 + sw); ctx.bezierCurveTo(s * 26, 24, s * 20, 10, s * 8, 2); ctx.closePath(); fillStroke(ctx, '#ff9fd0'); }
    ctx.beginPath(); ctx.arc(0, -4, 5, 0, TAU); fillStroke(ctx, '#7a2a5a');
  },
  halo(ctx, t, L) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter'; glow(ctx, 0, -16, 26, '#fff0a0', 0.6); ctx.restore();
    ctx.strokeStyle = '#ffe08a'; ctx.lineWidth = 3.4; ctx.beginPath(); ctx.ellipse(0, -16 - Math.sin(t * 2) * 2, 15, 5, 0, 0, TAU); ctx.stroke();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.strokeStyle = INK; ctx.lineWidth = 2;
    for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(s * 14, 14); ctx.quadraticCurveTo(s * 30, 2, s * 34, 16); ctx.quadraticCurveTo(s * 26, 14, s * 18, 22); ctx.closePath(); fillStroke(ctx, '#f8f4ff'); }
  },
  bonecrown(ctx, t, L) {
    ctx.beginPath(); ctx.moveTo(-14, 2);
    for (let i = 0; i <= 6; i++) { const x = -14 + i * (28 / 6); ctx.lineTo(x, i % 2 ? -6 : -16); }
    ctx.lineTo(14, 2); ctx.closePath(); fillStroke(ctx, '#efe8d8');
    for (const xx of [-9, 0, 9]) { ctx.beginPath(); ctx.arc(xx, -2, 2.4, 0, TAU); fillStroke(ctx, '#b07ad0'); }
    for (let i = 0; i < 3; i++) { const a = t * 1.3 + (i * TAU) / 3; glow(ctx, Math.cos(a) * 26, -8 + Math.sin(a) * 10, 8, '#b07ad0', 0.8); }
  },
  beret(ctx, t, L) {
    ctx.save(); ctx.rotate(-0.25); ctx.beginPath(); ctx.ellipse(-2, -4, 19, 8, 0, 0, TAU); fillStroke(ctx, '#3a6a8a'); ctx.restore();
    ctx.save(); ctx.translate(8, -8); ctx.rotate(0.9 + Math.sin(t * 3) * 0.1); ctx.beginPath(); ctx.ellipse(0, -12, 3.4, 13, 0, 0, TAU); fillStroke(ctx, '#ffcf5a'); ctx.restore();
  },
  goggles(ctx, t, L) {
    ctx.beginPath(); ctx.moveTo(-17, 4); ctx.lineTo(17, 4); ctx.lineWidth = 5; ctx.strokeStyle = INK; ctx.stroke(); ctx.lineWidth = 3; ctx.strokeStyle = '#6a4424'; ctx.stroke();
    ctx.strokeStyle = INK; ctx.lineWidth = 2;
    for (const s of [-1, 1]) { ctx.beginPath(); ctx.arc(s * 7, 2, 6, 0, TAU); fillStroke(ctx, '#c8a060'); ctx.beginPath(); ctx.arc(s * 7, 2, 3.6, 0, TAU); fillStroke(ctx, '#a8e05a'); }
    for (let i = 0; i < 3; i++) { const q = (t * 0.6 + i / 3) % 1; ctx.globalAlpha = 1 - q; ctx.strokeStyle = '#a8e05a'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(-12 + i * 10, -8 - q * 26, 2 + q * 3, 0, TAU); ctx.stroke(); }
    ctx.globalAlpha = 1;
  },
  clockring(ctx, t, L) {
    ctx.save(); ctx.translate(0, 14); ctx.scale(1, 0.4); ctx.rotate(t * 0.8);
    ctx.strokeStyle = '#b8d0ff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, 30, 0, TAU); ctx.stroke();
    for (let i = 0; i < 12; i++) { const a = (i / 12) * TAU; ctx.beginPath(); ctx.moveTo(Math.cos(a) * 26, Math.sin(a) * 26); ctx.lineTo(Math.cos(a) * 31, Math.sin(a) * 31); ctx.stroke(); }
    ctx.restore();
    ctx.beginPath(); ctx.arc(0, -14, 8, 0, TAU); fillStroke(ctx, '#f3e6c8');
    ctx.beginPath(); ctx.moveTo(0, -14); ctx.lineTo(Math.cos(-t * 3) * 6, -14 + Math.sin(-t * 3) * 6); ctx.moveTo(0, -14); ctx.lineTo(Math.cos(-t * 0.5) * 4, -14 + Math.sin(-t * 0.5) * 4); ctx.stroke();
  },
  wolfhood(ctx, t, L) {
    ctx.beginPath(); ctx.moveTo(-19, 16); ctx.quadraticCurveTo(-21, -8, 0, -10); ctx.quadraticCurveTo(21, -8, 19, 16); ctx.quadraticCurveTo(10, 4, 0, 4); ctx.quadraticCurveTo(-10, 4, -19, 16); ctx.closePath(); fillStroke(ctx, '#8a8aa0');
    for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(s * 6, -9); ctx.lineTo(s * 14, -26); ctx.lineTo(s * 18, -6); ctx.closePath(); fillStroke(ctx, '#8a8aa0'); ctx.beginPath(); ctx.moveTo(s * 9, -10); ctx.lineTo(s * 13, -20); ctx.lineTo(s * 15, -9); ctx.closePath(); ctx.fillStyle = '#e8c8d0'; ctx.fill(); }
    ctx.fillStyle = '#7fd06a'; ctx.beginPath(); ctx.arc(-6, -2, 1.6, 0, TAU); ctx.arc(6, -2, 1.6, 0, TAU); ctx.fill();
  },
};
