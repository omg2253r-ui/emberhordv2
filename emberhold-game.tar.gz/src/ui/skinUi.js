// v10.2 กล่องสุ่มสกิน + คลังสกิน: the box list (shop tab "กล่องสกิน" and the Halloween box in the candy shop), the box
// opening (a door of light splits open in the tier's colour; the higher the tier the bigger the show), and the skin
// collection where a skin is worn on its weapon.
import { h, glyph, itemImg, fmt, clear } from './dom.js';
import { getItem } from '../data/items.js';
import { SKIN_TIERS, SKINS, SKIN_IDS, SKIN_BOXES, getBox, getSkinAny, skinsOfWeapon, PITY_AT, PITY_TIER, WT_NAMES } from '../data/skins.js';
import { openSkinBox, ownsSkin, wornSkinId, wearSkin } from '../systems/skins.js';
import { hwActive } from '../data/halloween.js';

const tierChip = (t) => h('span', { class: `chip skin-tier t${t}`, style: { '--tc': SKIN_TIERS[t].col } }, SKIN_TIERS[t].name);
const odds = (pool) => { const tiers = [...new Set(pool.map((s) => s.t))]; const tot = tiers.reduce((a, t) => a + SKIN_TIERS[t].w, 0); return tiers.sort((a, b) => a - b).map((t) => [t, SKIN_TIERS[t].w / tot]); };

export function skinIcon(app, id, cls = 'skin-img') { return h('img', { class: cls, src: app.skinIconUri(id), alt: getSkinAny(id)?.name || '', draggable: 'false' }); }

// the cards of the boxes (used by the shop panel and, for the candy box, the candy shop)
export function boxCards(app, ids, onDone) {
  const st = app.store.get();
  return h('div', { class: 'skinbox-grid' }, ...ids.map((id) => {
    const box = getBox(id), pool = SKIN_IDS.map((k) => SKINS[k]).filter(box.pool), have = pool.filter((s) => ownsSkin(st, s.id)).length;
    const cur = box.cur === 'gold' ? st.gold : st.candy || 0, lock = box.hw && !hwActive();
    const can = cur >= box.price && !lock;
    return h('div', { class: `skinbox ${box.hw ? 'hw' : ''}`, 'data-box': id },
      h('div', { class: 'skinbox-art' }, h('i', {}), h('b', {}, box.wtype ? glyph(box.wtype) : glyph(box.hw ? 'skull' : 'star'))),
      h('b', {}, box.name), h('small', { class: 'muted' }, `${box.desc} · มีแล้ว ${have}/${pool.length}`),
      h('div', { class: 'skinbox-odds' }, ...odds(pool).map(([t, p]) => h('span', { style: { color: SKIN_TIERS[t].col } }, `${SKIN_TIERS[t].name} ${(p * 100).toFixed(p < 0.01 ? 2 : 1)}%`))),
      h('div', { class: 'hw-row' },
        h('button', { class: `btn ${can ? 'gold' : ''}`, type: 'button', 'data-action': 'open-box', disabled: !can, onclick: () => { openBoxFlow(app, id, onDone); } }, itemImg(box.cur === 'gold' ? 'gold' : 'candy'), fmt(box.price))),
      lock ? h('small', { class: 'muted' }, 'กิจกรรมจบแล้ว') : null);
  }));
}
function openBoxFlow(app, id, onDone) {
  const r = openSkinBox(app.store.get(), id, () => app.rng.next());
  if (!r.ok) { app.toast(r.reason === 'gold' ? 'ทองไม่พอ' : r.reason === 'candy' ? 'แคนดี้ไม่พอ' : r.reason === 'event_over' ? 'กิจกรรมจบแล้ว' : 'เปิดไม่ได้', 'warn'); app.audio.play('error'); return; }
  app.store.commit(r.state, { reason: 'skin-box' });
  app.refreshHeroSprites?.(); app.refreshPresence?.();
  revealSkin(app, r, () => onDone?.());
}

// the opening: the box shakes (longer for higher tiers), a slit of light in the tier colour opens, the skin rises
export function revealSkin(app, r, onClose) {
  const sk = r.skin, T = SKIN_TIERS[sk.t], def = getItem(sk.wid);
  let close;
  const stage = h('div', { class: `skin-reveal t${sk.t}`, style: { '--tc': T.col } },
    h('div', { class: 'sr-rays' }), h('div', { class: 'sr-box' }, h('i', {}), h('i', {})),
    h('div', { class: 'sr-prize' }, skinIcon(app, sk.id, 'sr-img')));
  const info = h('div', { class: 'sr-info', hidden: true },
    tierChip(sk.t), h('h2', {}, sk.name), h('small', { class: 'muted' }, `สกินของ ${def?.name || ''}`),
    h('div', { class: 'kv' },
      h('div', {}, h('span', { class: 'muted' }, 'คริติคอล'), h('b', {}, `+${(T.crit * 100).toFixed(1)}%`)),
      T.critMult ? h('div', {}, h('span', { class: 'muted' }, 'แรงคริ'), h('b', {}, `+${Math.round(T.critMult * 100)}%`)) : null,
      T.atkPct ? h('div', {}, h('span', { class: 'muted' }, 'พลังโจมตี'), h('b', {}, `+${Math.round(T.atkPct * 100)}%`)) : null),
    h('small', {}, [T.aura ? 'มีเอฟเฟกต์เคลื่อนไหวรอบตัวตลอดเวลา' : '', T.hit ? 'ฟันแล้วเกิดเอฟเฟกต์ของตัวเอง' : ''].filter(Boolean).join(' · ') || 'สีใหม่ของอาวุธ'),
    r.dup ? h('div', { class: 'notice' }, `มีสกินนี้แล้ว ได้ทองคืน ${fmt(r.refund)}`) : h('div', { class: 'notice ok' }, 'สกินใหม่! ใส่ให้อาวุธนี้แล้ว (เปลี่ยนได้ที่คลังสกิน)'),
    r.pity ? h('small', { class: 'muted' }, `การันตีครบ ${PITY_AT} กล่อง`) : null);
  const content = h('div', { class: 'modal panel skin-reveal-modal', 'data-modal': 'skin-reveal', 'data-tier': sk.t, 'data-skin': sk.id }, stage, info,
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', 'data-action': 'skin-ok', onclick: () => close() }, 'เก็บ')));
  close = app.modal(content, { onClose });
  const wait = 900 + sk.t * 220;
  app.audio.play('open');
  setTimeout(() => { stage.classList.add('open'); app.audio.play(sk.t >= 4 ? 'legendary' : sk.t >= 2 ? 'unlock' : 'gold'); if (sk.t >= 6) app.renderer?.shake?.(8, 0.4); }, wait);
  setTimeout(() => { info.hidden = false; }, wait + 450);
}

// คลังสกิน: every weapon you own with its skins; owned ones can be worn
export function openSkinCollection(app, focusWid = null) {
  let close, filter = focusWid ? 'weapon' : 'owned', wid = focusWid;
  const body = h('div', { class: 'skin-col' });
  function draw() {
    const st = app.store.get();
    clear(body);
    const owned = Object.keys(st.skins.owned).length;
    body.append(h('div', { class: 'hw-row' }, h('span', { class: 'chip ok' }, `มีแล้ว ${owned} / ${SKIN_IDS.length} สกิน`), h('span', { class: 'chip' }, `กล่องที่เปิด ${fmt(st.skins.boxes)} · การันตีระดับ${SKIN_TIERS[PITY_TIER].name}ใน ${PITY_AT - st.skins.pity} กล่อง`)));
    const weapons = [...new Set(SKIN_IDS.map((id) => SKINS[id].wid))].filter((w) => filter !== 'owned' || skinsOfWeapon(w).some((s) => ownsSkin(st, s.id)));
    body.append(h('div', { class: 'seg', role: 'tablist' },
      h('button', { class: 'btn small', type: 'button', 'aria-checked': String(filter === 'owned'), onclick: () => { filter = 'owned'; draw(); } }, 'อาวุธที่มีสกิน'),
      h('button', { class: 'btn small', type: 'button', 'aria-checked': String(filter === 'all'), onclick: () => { filter = 'all'; draw(); } }, 'ทุกอาวุธ')));
    if (!weapons.length) body.append(h('div', { class: 'empty-note' }, 'ยังไม่มีสกิน ลองเปิดกล่องสกินที่ร้านค้า'));
    const list = (filter === 'weapon' && wid ? [wid] : weapons).slice(0, 120);
    for (const w of list) {
      const def = getItem(w), on = wornSkinId(st, w);
      body.append(h('div', { class: 'skin-weapon', 'data-weapon': w },
        h('div', { class: 'skin-wh' }, itemImg(w), h('b', {}, def.name), on ? h('small', { class: 'muted' }, `ใส่อยู่: ${getSkinAny(on).name}`) : h('small', { class: 'muted' }, 'รูปแบบปกติ'),
          on ? h('button', { class: 'btn sm', type: 'button', onclick: () => act(wearSkin(app.store.get(), w, null)) }, 'ถอดสกิน') : null),
        h('div', { class: 'skin-row' }, ...skinsOfWeapon(w).map((sk) => {
          const own = ownsSkin(st, sk.id);
          return h('button', { class: `skin-cell t${sk.t}${own ? '' : ' locked'}${on === sk.id ? ' on' : ''}`, type: 'button', title: `${sk.name} · ${SKIN_TIERS[sk.t].name}`, 'data-skin': sk.id, style: { '--tc': SKIN_TIERS[sk.t].col },
            onclick: () => { if (own) act(wearSkin(app.store.get(), w, sk.id)); else app.toast(`${sk.name} (${SKIN_TIERS[sk.t].name}) — ได้จากกล่องสกิน`, 'info'); } },
          own ? skinIcon(app, sk.id) : h('span', { class: 'skin-q' }, '?'), h('small', {}, SKIN_TIERS[sk.t].name));
        }))));
    }
  }
  function act(r) { if (!r.ok) { app.toast('ยังไม่มีสกินนี้', 'warn'); return; } app.store.commit(r.state, { reason: 'skin' }); app.refreshHeroSprites?.(); app.refreshPresence?.(); app.audio.play('click'); draw(); }
  const content = h('div', { class: 'modal panel skin-col-modal', 'data-modal': 'skins' }, h('h2', {}, 'คลังสกินอาวุธ'), body,
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'ปิด')));
  close = app.modal(content);
  draw();
  return close;
}
export const NORMAL_BOX_IDS = SKIN_BOXES.filter((b) => !b.hw).map((b) => b.id);
export { WT_NAMES, tierChip };
