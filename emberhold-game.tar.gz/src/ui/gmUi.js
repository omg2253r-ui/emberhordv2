// ผู้ดูแลเกม (game master). The ◆ on the left of Settings opens a sign-in; the name and password are checked by the
// SERVER (netlify/lib/live.mjs keeps only a salted hash — nothing secret ships in the game files). With the server's
// token the panel opens: statistics, players and their codes, look at a player's save, gifts, live peek at a hunt,
// spawning items and bosses, announcements, gift boxes dropped along your path, the event clock and ping.
import { h, glyph, itemImg, fmt, clear } from './dom.js';
import { ITEMS, getItem } from '../data/items.js';
import { rarityOf } from '../data/rarity.js';
import { cloneState } from '../core/state.js';
import { addInPlace, canAdd } from '../systems/inventory.js';
import { BALANCE } from '../config/balance.js';
import { PETS, MAX_STARS } from '../data/pets.js';
import { PETS_HW } from '../data/hwPets.js';
import { JOB_IDS, JOB_MAX_STARS } from '../data/jobs.js';
import { HWA_IDS, HWA_LEVEL_MAX } from '../data/hwArtifacts.js';
import { CANDY_MAX, hwEnd, HW_EVENT } from '../data/halloween.js';
import { SKIN_IDS } from '../data/skins.js';
import { STALL_DESIGNS } from '../data/market.js';
import { ZONE_ENEMY_IDS, getEnemy } from '../data/enemies.js';
import { cloudError } from '../net/cloud.js';
import { ATTR_IDS, ATTR_MAX, POINTS_PER_LEVEL } from '../data/attributes.js';
import { SKILL_IDS, getSkill } from '../data/skills.js';
import { TITLES } from '../data/titles.js';
import { ARTIFACTS, ART_LEVEL_MAX } from '../data/artifacts.js';
import { RACE_IDS } from '../data/races.js';
import { STAGES } from '../data/stages.js';
import { ZONES, RAIDS } from '../data/zones.js';
import { HW_RECIPES, allRecipes } from '../data/brewing.js';
import { GAME_VERSION } from '../data/changelog.js';

const TOK = 'emberhold.gm';
const GM_VER = 'emberhold.gmver';   // the game version the admin hero was last filled for
export function createGm(app) {
  let gtok = null, exp = 0;
  try { const v = JSON.parse(sessionStorage.getItem(TOK) || 'null'); if (v && v.exp > Date.now()) { gtok = v.gtok; exp = v.exp; } } catch { /* ignore */ }
  const trails = { village: [], halloween: [] };
  let fab = null;
  function keep() { try { if (gtok) sessionStorage.setItem(TOK, JSON.stringify({ gtok, exp })); else sessionStorage.removeItem(TOK); } catch { /* ignore */ } }
  function showFab() {
    if (fab || !gtok) return;
    fab = h('button', { class: 'gm-fab', type: 'button', 'data-action': 'gm-panel', title: 'แผงผู้ดูแลเกม', onclick: () => openGmPanel(app) }, h('i'));
    document.body.append(fab);
  }
  const api = {
    get active() { return !!gtok && exp > Date.now(); },
    call(op, body = {}) { return app.cloud.live(op, { ...body, gtok }); },
    async login(name, pass) {
      const d = await app.cloud.live('gm_login', { name, pass, peer: app.online.me?.peer });
      if (!d.gtok) return d;
      gtok = d.gtok; exp = d.exp; keep(); showFab();
      app.live.poll();
      return { ok: true };
    },
    logout() { gtok = null; exp = 0; keep(); fab?.remove(); fab = null; },
    // the last positions walked (one every ~70 px): gift boxes fall along them
    trail(zone, x, y) {
      const t = trails[zone]; if (!t) return;
      const last = t[t.length - 1];
      if (!last || Math.hypot(last[0] - x, last[1] - y) > 70) { t.push([Math.round(x), Math.round(y)]); if (t.length > 200) t.shift(); }
    },
    trailOf: (zone) => trails[zone] || [],
    showFab,
  };
  if (api.active) setTimeout(() => {
    showFab(); if (app.online.me?.peer) app.cloud.live('gm_peer', { gtok, peer: app.online.me.peer });
    // the game was updated since this admin hero was last filled: give it everything new straight away
    let seen = null; try { seen = localStorage.getItem(GM_VER); } catch { /* ignore */ }
    if (app.store.get().adminHero && seen !== GAME_VERSION) { makeGmHero(app); app.toast(`อัปเดตบัญชีแอดมินให้มีของครบตามเวอร์ชัน ${GAME_VERSION} แล้ว`, 'ok'); }
  }, 1500);
  return api;
}

// ------------------------------------------------------------------ sign-in (from the ◆ in Settings)
export function openGmLogin(app) {
  if (app.gm.active) { openGmPanel(app); return; }
  let close;
  const name = h('input', { type: 'text', class: 'text-in', autocomplete: 'off', 'data-field': 'gm-name', placeholder: 'ชื่อ' });
  const pass = h('input', { type: 'password', class: 'text-in', autocomplete: 'off', 'data-field': 'gm-pass', placeholder: 'รหัสผ่าน' });
  const msg = h('div', { class: 'notice', hidden: true });
  const go = async () => {
    if (!app.cloud.available) { msg.hidden = false; msg.className = 'notice warn'; msg.textContent = 'ต้องเปิดเกมจากเว็บไซต์ของเกม'; return; }
    msg.hidden = false; msg.className = 'notice'; msg.textContent = 'กำลังตรวจสอบ…';
    const r = await app.gm.login(name.value, pass.value);
    if (!r.ok) { msg.className = 'notice warn'; msg.textContent = r.error === 'wrong' ? 'ชื่อหรือรหัสไม่ถูกต้อง' : r.error === 'locked' ? 'ใส่ผิดหลายครั้ง ลองใหม่ในอีก 15 นาที' : cloudError(r.error); return; }
    close(); app.toast('เข้าสู่โหมดผู้ดูแลเกมแล้ว', 'ok'); app.audio.play('legendary');
    makeGmHero(app);
    openGmPanel(app);
  };
  pass.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
  const content = h('div', { class: 'modal panel gm-login', 'data-modal': 'gm-login' },
    h('div', { class: 'gm-gem' }, h('i')), h('h2', {}, 'รหัสพิเศษ'),
    h('label', { class: 'setting' }, 'ชื่อ', name), h('label', { class: 'setting' }, 'รหัส', pass), msg,
    h('div', { class: 'actions' }, h('button', { class: 'btn gold', type: 'button', 'data-action': 'gm-go', onclick: go }, 'ยืนยัน'), h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'ปิด')));
  close = app.modal(content);
  setTimeout(() => name.focus(), 50);
}

// everything at its maximum. Every list below is read from the game's own registries, so anything added to the game
// later (a weapon, pet, skin, class, skill, title…) is included automatically the next time this runs — and it runs by
// itself on the first load after each update (see createGm) as well as on every admin sign-in.
export function makeGmHero(app) {
  const n = cloneState(app.store.get());
  n.adminHero = true;
  n.player.level = BALANCE.player.maxLevel; n.player.xp = 0;
  const budget = (n.player.level - 1) * POINTS_PER_LEVEL;
  let left = budget; n.attrs = Object.fromEntries(ATTR_IDS.map((id) => { const v = Math.min(ATTR_MAX, Math.floor(budget / ATTR_IDS.length), left); left -= v; return [id, v]; }));
  n.gold = 999_999_999; n.sparks = 999_999; n.candy = CANDY_MAX;
  for (const id of [...Object.keys(PETS), ...Object.keys(PETS_HW)]) n.pets.owned[id] = { stars: MAX_STARS };
  for (const id of SKIN_IDS) n.skins.owned[id] = 1;
  for (const d of STALL_DESIGNS) n.market.designs[d.id] = 1;
  for (const id of JOB_IDS) n.job.own[id] = { stars: JOB_MAX_STARS, stage: 3, acc: 0, base: null };
  if (!n.job.on) n.job.on = JOB_IDS[0];
  for (const id of HWA_IDS) n.hwa.own[id] = HWA_LEVEL_MAX;
  // every skill at its top rank (secret ones too), every title, artifact, bloodline seen, stage, land and raid, every recipe
  for (const id of SKILL_IDS) n.skills.ranks[id] = getSkill(id).maxRank;
  for (const t of TITLES) n.titles.owned[t.id] ||= Date.now();
  for (const id of Object.keys(ARTIFACTS)) n.artifacts.owned[id] = { lvl: ART_LEVEL_MAX };
  for (const id of RACE_IDS) n.raceSeen[id] = true;
  for (const st of STAGES) n.progress.cleared[st.id] = true;
  for (const z of [...ZONES, ...RAIDS]) n.zones.cleared[z.id] = Math.max(1, n.zones.cleared[z.id] || 0);
  for (const r of [...HW_RECIPES, ...allRecipes(ITEMS)]) n.brew.known[r.id] = 1;
  // one of every item in the game: equipment at the highest upgrade, everything else a full stack; the bag grows to fit
  n.inventory.bagLevel = BALANCE.bag.maxLevel;
  n.inventory.capacity = BALANCE.inventory.capacity + BALANCE.bag.step * n.inventory.bagLevel;
  const have = new Set([...n.inventory.slots.map((s) => s.id), ...Object.values(n.equipment).filter(Boolean).map((e) => e.id)]);
  for (const d of Object.values(ITEMS)) {
    if (d.category === 'weapon') n.blueprints[d.id] = true;
    if (have.has(d.id) || n.inventory.slots.length >= n.inventory.capacity) continue;
    const gear = ['weapon', 'armor', 'charm', 'wings'].includes(d.category);
    n.inventory.slots.push({ uid: n.nextUid++, id: d.id, qty: gear ? 1 : BALANCE.inventory.maxStack, lvl: gear ? BALANCE.upgrade.maxLevel : 0 });
  }
  app.store.commit(n, { reason: 'gm' });
  try { localStorage.setItem(GM_VER, GAME_VERSION); } catch { /* ignore */ }
  app.refreshHeroSprites?.(); app.rerender?.();
}

// ------------------------------------------------------------------ the panel
const TABS = [['over', 'ภาพรวม'], ['players', 'ผู้เล่น'], ['spawn', 'เสกของ / บอส'], ['say', 'ประกาศ / กล่อง'], ['ctl', 'ควบคุมเกม']];
export function openGmPanel(app) {
  if (!app.gm.active) { openGmLogin(app); return; }
  let tab = 'over', close;
  const body = h('div', { class: 'gm-body' });
  const tabs = h('div', { class: 'tabs gm-tabs' }, ...TABS.map(([id, label]) => h('button', { class: 'tab', type: 'button', 'data-gm-tab': id, onclick: () => { tab = id; draw(); } }, label)));
  const content = h('div', { class: 'modal panel gm-panel', 'data-modal': 'gm' }, h('div', { class: 'gm-title' }, h('div', { class: 'gm-gem sm' }, h('i')), h('h2', {}, 'แผงผู้ดูแลเกม')), tabs, body,
    h('div', { class: 'actions' }, h('button', { class: 'btn danger', type: 'button', onclick: () => { app.gm.logout(); close(); app.toast('ออกจากโหมดผู้ดูแลแล้ว'); } }, 'ออกจากโหมดผู้ดูแล'), h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'ปิด')));
  const note = (text, kind = '') => h('div', { class: `notice ${kind}` }, text);
  const fail = (d) => note(cloudError(d.error), 'warn');
  async function draw() {
    tabs.querySelectorAll('[data-gm-tab]').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.gmTab === tab)));
    clear(body).append(h('div', { class: 'muted' }, 'กำลังโหลด…'));
    const view = await ({ over, players, spawn, say, ctl })[tab]();
    clear(body).append(...[view].flat().filter(Boolean));
  }
  // ---- ภาพรวม
  async function over() {
    const [d, p] = await Promise.all([app.gm.call('gm_stats'), app.cloud.ping()]);
    if (d.error) return fail(d);
    const peers = app.online.peers;
    const row = (k, a, b2) => h('tr', {}, h('th', {}, k), h('td', {}, fmt(a)), h('td', {}, fmt(b2)));
    return [
      h('div', { class: 'gm-stats' },
        h('div', { class: 'gm-stat' }, h('small', {}, 'บัญชีทั้งหมด'), h('b', {}, fmt(d.accounts))),
        h('div', { class: 'gm-stat' }, h('small', {}, 'ออนไลน์ตอนนี้ (เซิร์ฟเวอร์)'), h('b', {}, d.online == null ? '—' : fmt(d.online))),
        h('div', { class: 'gm-stat' }, h('small', {}, 'เห็นในโลกเดียวกัน'), h('b', {}, fmt(peers.length + 1))),
        h('div', { class: 'gm-stat' }, h('small', {}, 'ปิง'), h('b', { 'data-ping': '' }, p.ms != null ? `${p.ms} ms` : 'วัดไม่ได้'))),
      h('table', { class: 'gm-table' }, h('thead', {}, h('tr', {}, h('th', {}, 'ช่วงเวลา'), h('th', {}, 'ผู้เล่นที่เข้าเล่น'), h('th', {}, 'บัญชีใหม่'))),
        h('tbody', {}, row('วันนี้', d.per.day.active, d.per.day.joined), row('สัปดาห์นี้', d.per.week.active, d.per.week.joined), row('เดือนนี้', d.per.month.active, d.per.month.joined), row('ปีนี้', d.per.year.active, d.per.year.joined))),
      h('small', { class: 'muted' }, 'นับจากบัญชีเกม (เซฟออนไลน์) ที่บันทึกขึ้นเซิร์ฟเวอร์ · เวลาไทย'),
      h('div', { class: 'actions' }, h('button', { class: 'btn', type: 'button', onclick: () => draw() }, glyph('clock'), 'รีเฟรช / วัดปิงใหม่')),
    ];
  }
  // ---- ผู้เล่น
  async function players(q = '') {
    const d = await app.gm.call('gm_players', { q });
    if (d.error) return fail(d);
    const search = h('input', { type: 'search', class: 'text-in', placeholder: 'ค้นชื่อบัญชี / ชื่อนักล่า / รหัส', value: q });
    search.addEventListener('change', async () => { clear(body).append(...[await players(search.value)].flat()); });
    const online = app.online.peers;
    return [
      h('div', { class: 'eyebrow' }, `ออนไลน์ในโลกนี้ (${online.length}) — ส่องการล่าได้`),
      h('div', { class: 'gm-online' }, ...online.map((x) => h('div', { class: 'gm-prow' }, h('b', {}, x.p.name), h('small', { class: 'muted' }, `Lv.${x.p.lv} · ${x.p.zone || '-'}${x.p.busy ? ' · ' + x.p.busy : ''}`),
        h('button', { class: 'btn sm', type: 'button', 'data-action': 'gm-peek', onclick: () => openPeek(app, x.peer, x.p.name) }, glyph('eye'), 'ส่อง')))),
      h('div', { class: 'eyebrow' }, `บัญชีทั้งหมด ${fmt(d.total)} (แสดง ${d.players.length})`), search,
      h('div', { class: 'gm-plist' }, ...d.players.map((p) => h('div', { class: 'gm-prow' },
        h('div', {}, h('b', {}, `${p.hero || '-'} `), h('small', {}, `บัญชี ${p.acct} · Lv.${p.lv}`), h('div', {}, h('code', { class: 'gm-code' }, p.uid)), h('small', { class: 'muted' }, `เข้าเล่นล่าสุด ${new Date(p.seen).toLocaleString('th-TH')}`)),
        h('div', { class: 'gm-pbtns' },
          h('button', { class: 'btn sm', type: 'button', onclick: () => viewPlayer(p) }, glyph('eye'), 'ดูเซฟ'),
          h('button', { class: 'btn sm gold', type: 'button', onclick: () => giftTo(p.uid, `${p.hero} (${p.acct})`) }, glyph('star'), 'ส่งของ'))))),
    ];
  }
  async function viewPlayer(p) {
    const d = await app.gm.call('gm_view', { uid: p.uid });
    let c2;
    const s = d.summary;
    c2 = app.modal(h('div', { class: 'modal panel', 'data-modal': 'gm-view' }, h('h2', {}, p.hero || p.acct),
      d.error ? fail(d) : h('div', { class: 'kv' }, ...[['บัญชี', p.acct], ['รหัสผู้เล่น', p.uid], ['เลเวล', s.lv], ['ทอง', fmt(s.gold)], ['แคนดี้', fmt(s.candy)], ['ไอเทมในกระเป๋า', `${s.items} ช่อง`], ['กำจัดศัตรู', fmt(s.kills)], ['แต้มแรงค์', fmt(s.rank)], ['สถานะเซฟ', s.integrity === 'modified' ? 'ถูกแก้ไขนอกเกม' : 'ปกติ'], ['บันทึกล่าสุด', new Date(s.updatedAt).toLocaleString('th-TH')]].map(([k, v]) => h('div', {}, h('span', { class: 'muted' }, k), h('b', {}, String(v))))),
      d.card ? h('div', { class: 'actions' }, h('button', { class: 'btn', type: 'button', onclick: () => { c2(); app.openAccountProfile(p.acct); } }, 'เปิดโปรไฟล์')) : null,
      h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', onclick: () => c2() }, 'ปิด'))));
  }
  function giftTo(to, label) {
    let c2, picked = [];
    const list = h('div', { class: 'gm-picked' });
    const gold = h('input', { type: 'number', class: 'text-in', min: 0, value: '0' }), candy = h('input', { type: 'number', class: 'text-in', min: 0, value: '0' });
    const noteIn = h('input', { type: 'text', class: 'text-in', maxlength: '80', placeholder: 'ข้อความถึงผู้เล่น' });
    const paint = () => clear(list).append(...picked.map((x, i) => h('span', { class: 'chip' }, itemImg(x.id), `${getItem(x.id).name} ×${x.qty}`, h('button', { class: 'btn sm', type: 'button', onclick: () => { picked.splice(i, 1); paint(); } }, '×'))));
    const finder = itemFinder((id, qty) => { if (picked.length < 10) picked.push({ id, qty }); paint(); });
    c2 = app.modal(h('div', { class: 'modal panel gm-panel', 'data-modal': 'gm-gift' }, h('h2', {}, `ส่งของถึง ${label}`), finder, list,
      h('label', { class: 'setting' }, 'ทอง', gold), h('label', { class: 'setting' }, 'แคนดี้', candy), noteIn,
      h('div', { class: 'actions' }, h('button', { class: 'btn gold', type: 'button', onclick: async () => {
        const d = await app.gm.call('gm_gift', { to, items: picked, gold: Number(gold.value) || 0, candy: Number(candy.value) || 0, note: noteIn.value });
        if (d.error) { app.toast(cloudError(d.error), 'warn'); return; }
        app.toast(to === '*' ? 'ส่งของขวัญให้ทุกคนแล้ว (รับได้คนละครั้ง ภายใน 7 วัน)' : 'ส่งของแล้ว ผู้เล่นจะได้รับเมื่อเข้าเกมด้วยบัญชีนั้น', 'ok'); c2();
      } }, 'ส่ง'), h('button', { class: 'btn primary', type: 'button', onclick: () => c2() }, 'ยกเลิก'))));
  }
  // ---- เสกของ / บอส
  function itemFinder(onPick) {
    const q = h('input', { type: 'search', class: 'text-in', placeholder: 'ค้นหาไอเทม (ชื่อหรือรหัส)' });
    const qty = h('input', { type: 'number', class: 'text-in gm-qty', min: 1, value: '1' });
    const out = h('div', { class: 'gm-items' });
    const paint = () => {
      const s = q.value.trim().toLowerCase();
      const list = Object.values(ITEMS).filter((d) => !s || d.name.toLowerCase().includes(s) || d.id.includes(s)).slice(0, 60);
      clear(out).append(...list.map((d) => h('button', { class: `cell r-${d.rarity}`, type: 'button', title: `${d.name} · ${rarityOf(d.rarity).name}`, 'data-item': d.id, onclick: () => onPick(d.id, Math.max(1, Number(qty.value) | 0)) }, itemImg(d.id))));
    };
    q.addEventListener('input', paint); paint();
    return h('div', { class: 'gm-finder' }, h('div', { class: 'gm-row' }, q, h('label', {}, 'จำนวน ', qty)), out);
  }
  async function spawn() {
    const inHunt = app.peekSnapshot?.()?.kind === 'hunt';
    const bosses = ZONE_ENEMY_IDS.map(getEnemy).filter((e) => e && e.boss);
    return [
      h('div', { class: 'eyebrow' }, 'เสกไอเทมเข้ากระเป๋าตัวเอง (กดที่ไอเทม)'),
      itemFinder((id, n) => {
        const st = app.store.get();
        if (!canAdd(st, id, n)) { app.toast('กระเป๋าเต็ม', 'warn'); return; }
        const nx = cloneState(st); addInPlace(nx, id, n); nx.adminHero = true; app.store.commit(nx, { reason: 'gm-spawn' });
        app.toast(`เสก ${getItem(id).name} ×${n}`, 'ok');
      }),
      h('div', { class: 'actions', style: { flexWrap: 'wrap' } },
        h('button', { class: 'btn', type: 'button', onclick: () => { makeGmHero(app); app.toast('ตัวละครเต็มทุกอย่างแล้ว', 'ok'); } }, glyph('crown'), 'เติมตัวละครให้เต็มทุกอย่าง'),
        h('button', { class: 'btn gold', type: 'button', onclick: () => giftTo('*', 'ผู้เล่นทุกคน') }, glyph('people'), 'ส่งของให้ทุกคน')),
      h('div', { class: 'eyebrow' }, 'เสกบอส (ต้องอยู่ในดันเจี้ยนรวมและเป็นหัวหน้าห้อง หรือเล่นคนเดียว)'),
      inHunt ? null : note('ตอนนี้ไม่ได้อยู่ในดันเจี้ยนรวม เข้าดันก่อนแล้วเปิดแผงนี้อีกครั้ง'),
      h('div', { class: 'gm-boss' }, ...bosses.map((b) => h('button', { class: 'btn sm', type: 'button', disabled: !inHunt, 'data-boss': b.id, onclick: () => { const r = app.gmSpawn(b.id); app.toast(r.ok ? `เสก ${b.name}` : r.reason === 'not_host' ? 'ต้องเป็นหัวหน้าห้อง' : 'เสกไม่ได้', r.ok ? 'ok' : 'warn'); } }, b.name))),
    ];
  }
  // ---- ประกาศ / กล่อง
  async function say() {
    const text = h('input', { type: 'text', class: 'text-in', maxlength: '160', placeholder: 'ข้อความประกาศถึงทุกคน' });
    const count = h('input', { type: 'number', class: 'text-in', min: 1, max: 200, value: '10' });
    const where = app.hwFrom?.() === 'halloween' ? 'halloween' : 'village';
    const trail = app.gm.trailOf(where);
    return [
      h('div', { class: 'eyebrow' }, 'ประกาศ (ขึ้นกลางจอด้านบนของทุกคน และในแชท)'), text,
      h('div', { class: 'actions' }, h('button', { class: 'btn gold', type: 'button', 'data-action': 'gm-say', onclick: async () => { const d = await app.gm.call('gm_announce', { text: text.value }); if (d.error) { app.toast(cloudError(d.error), 'warn'); return; } app.toast('ประกาศแล้ว', 'ok'); text.value = ''; app.live.poll(); } }, glyph('talk'), 'ประกาศ')),
      h('div', { class: 'eyebrow' }, 'กล่องแจกจากแอดมินจ้า (ตกจากฟ้าตามทางที่คุณเดินผ่าน)'),
      h('label', { class: 'setting' }, 'จำนวนกล่อง', count),
      h('small', { class: 'muted' }, `ทางเดินที่จำไว้ใน${where === 'halloween' ? 'โลกฮาโลวีน' : 'หมู่บ้าน'}: ${trail.length} จุด ${trail.length < 3 ? '(เดินในหมู่บ้านก่อน กล่องจะตกตามทางที่เดิน)' : ''}`),
      h('div', { class: 'actions' }, h('button', { class: 'btn gold', type: 'button', 'data-action': 'gm-box', onclick: async () => {
        const n = Math.max(1, Math.min(200, Number(count.value) | 0));
        const t = app.gm.trailOf(where);
        if (!t.length) { app.toast('ยังไม่มีทางเดิน เดินในหมู่บ้านก่อน', 'warn'); return; }
        // spread the boxes evenly along the newest part of the path, a little to either side
        const pts = Array.from({ length: n }, (_, i) => { const p = t[Math.max(0, t.length - 1 - Math.floor((i * t.length) / n))]; return [p[0] + Math.round((Math.random() - 0.5) * 60), p[1] + Math.round((Math.random() - 0.5) * 40)]; });
        const d = await app.gm.call('gm_box', { count: n, pts, from: app.store.get().story.name, zone: where });
        if (d.error) { app.toast(cloudError(d.error), 'warn'); return; }
        app.toast(`โปรยกล่อง ${n} กล่องแล้ว`, 'ok'); app.live.poll(); close();
      } }, glyph('star'), 'โปรยกล่อง')),
    ];
  }
  // ---- ควบคุมเกม
  async function ctl() {
    const end = hwEnd();
    const days = h('input', { type: 'number', class: 'text-in', step: '0.5', value: String(Math.round(((end - Date.now()) / 86400000) * 10) / 10) });
    const inHunt = app.peekSnapshot?.()?.kind === 'hunt';
    return [
      h('div', { class: 'eyebrow' }, 'กิจกรรมฮาโลวีน'),
      h('div', { class: 'notice' }, `ปิดประตู: ${new Date(end).toLocaleString('th-TH')} (ค่าเริ่มต้น ${HW_EVENT.days} วัน)`),
      h('label', { class: 'setting' }, 'เหลืออีก (วัน)', days),
      h('div', { class: 'actions', style: { flexWrap: 'wrap' } },
        h('button', { class: 'btn gold', type: 'button', onclick: async () => { const d = await app.gm.call('gm_event', { end: Date.now() + Number(days.value) * 86400000 }); if (d.error) { app.toast(cloudError(d.error), 'warn'); return; } app.live.poll(); app.toast('ตั้งเวลาปิดกิจกรรมแล้ว (ทุกคนเห็นภายใน 30 วินาที)', 'ok'); draw(); } }, glyph('clock'), 'ตั้งเวลาใหม่'),
        h('button', { class: 'btn', type: 'button', onclick: async () => { await app.gm.call('gm_event', { end: null }); app.live.poll(); app.toast('กลับไปใช้เวลาเดิม', 'ok'); draw(); } }, 'ใช้เวลาเดิม')),
      h('div', { class: 'eyebrow' }, 'ในดันเจี้ยน (หัวหน้าห้อง)'),
      h('div', { class: 'actions', style: { flexWrap: 'wrap' } },
        h('button', { class: 'btn', type: 'button', disabled: !inHunt, onclick: () => { const r = app.gmKillAll(); app.toast(r.ok ? `กำจัด ${r.n} ตัว` : 'ต้องเป็นหัวหน้าห้อง', r.ok ? 'ok' : 'warn'); } }, glyph('skull'), 'กำจัดศัตรูทั้งหมด'),
        h('button', { class: 'btn', type: 'button', disabled: !inHunt, onclick: () => { app.gmHeal(); app.toast('ฟื้นพลังเต็ม', 'ok'); } }, glyph('hp'), 'ฟื้นพลังตัวเอง')),
      h('div', { class: 'eyebrow' }, 'ตลาด'),
      (() => { const lot = h('input', { type: 'number', class: 'text-in', min: 1, max: 100, placeholder: 'เลขล็อต' }); return h('div', { class: 'gm-row' }, lot, h('button', { class: 'btn danger sm', type: 'button', onclick: async () => { const d = await app.gm.call('gm_market_clear', { lot: Number(lot.value) }); app.toast(d.error ? cloudError(d.error) : `ล้างล็อต ${lot.value} แล้ว`, d.error ? 'warn' : 'ok'); app.market.refresh(true); } }, 'ล้างล็อต')); })(),
    ];
  }
  close = app.modal(content);
  draw();
  return close;
}

// ------------------------------------------------------------------ ส่องผู้เล่น: a live minimap of someone's hunt (2 pictures a second)
export function openPeek(app, peer, name) {
  let close, timer = null, alive = true;
  const cv = h('canvas', { class: 'gm-peek', width: 640, height: 400 });
  const info = h('div', { class: 'gm-peek-info muted' }, 'กำลังขอภาพ…');
  const tick = async () => {
    if (!alive) return;
    const r = await app.online.requestPeek(peer);
    if (!alive) return;
    if (!r.ok) { info.textContent = r.reason === 'no_answer' ? 'ผู้เล่นไม่ตอบ (อาจออฟไลน์ หรือยังไม่เห็นว่าคุณเป็นผู้ดูแล รอ 30 วินาที)' : 'ส่องไม่ได้'; }
    else paint(r.snap);
    timer = setTimeout(tick, 500);
  };
  function paint(s) {
    const g = cv.getContext('2d'), W = cv.width, H = cv.height;
    g.fillStyle = '#120c14'; g.fillRect(0, 0, W, H);
    if (s.kind !== 'hunt') { info.textContent = `${name}: ${s.title}`; g.fillStyle = '#f3e6c8'; g.font = '700 22px "Bai Jamjuree", system-ui'; g.textAlign = 'center'; g.fillText(s.title, W / 2, H / 2); return; }
    const k = Math.min(W / s.arena.w, H / s.arena.h), ox = (W - s.arena.w * k) / 2, oy = (H - s.arena.h * k) / 2;
    g.strokeStyle = '#5a4a3a'; g.lineWidth = 2; g.strokeRect(ox, oy, s.arena.w * k, s.arena.h * k);
    for (const f of s.foes || []) {
      const x = ox + f.x * k, y = oy + f.y * k, r = f.b ? 9 : 4;
      g.fillStyle = f.b ? '#ff5a3a' : '#c0504a'; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#300'; g.fillRect(x - 12, y - r - 6, 24, 3); g.fillStyle = '#ff7a5a'; g.fillRect(x - 12, y - r - 6, 24 * Math.max(0, f.hp / Math.max(1, f.max)), 3);
      if (f.b) { g.fillStyle = '#ffd08a'; g.font = '700 11px system-ui'; g.textAlign = 'center'; g.fillText(`${f.n} ${fmt(f.hp)}/${fmt(f.max)}`, x, y - r - 10); }
    }
    for (const a of s.allies || []) { g.fillStyle = a.ko ? '#777' : '#7fd0ff'; g.beginPath(); g.arc(ox + a.x * k, oy + a.y * k, 6, 0, Math.PI * 2); g.fill(); g.fillStyle = '#cfe8ff'; g.font = '600 10px system-ui'; g.textAlign = 'center'; g.fillText(a.name, ox + a.x * k, oy + a.y * k - 9); }
    g.fillStyle = s.me.dead ? '#777' : '#7fff9a'; g.beginPath(); g.arc(ox + s.me.x * k, oy + s.me.y * k, 8, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#eaffea'; g.font = '700 11px system-ui'; g.textAlign = 'center'; g.fillText(name, ox + s.me.x * k, oy + s.me.y * k - 11);
    info.textContent = `${name} · ${s.zone} · ห้อง ${s.room + 1} · พลังชีวิต ${fmt(s.me.hp)}/${fmt(s.me.maxHp)} · ปาร์ตี้ ${s.party} คน · ศัตรู ${s.foes.length} ตัว · กำจัดแล้ว ${s.kills}`;
  }
  close = app.modal(h('div', { class: 'modal panel gm-panel', 'data-modal': 'gm-peek' }, h('h2', {}, `ส่อง ${name}`), cv, info,
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', onclick: () => close() }, 'ปิด'))), { onClose: () => { alive = false; clearTimeout(timer); } });
  tick();
}
