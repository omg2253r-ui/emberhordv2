// v10 แรงค์ PvP: the tier card (emblem, title, points, progress to the next tier) and the five-tier ladder.
import { h } from './dom.js';
import { RANK_TIERS, tierOf, nextTier } from '../data/rank.js';
import { svgDataUri } from '../art/icons.js';

// one emblem per tier, each its own shape: bronze shield · silver kite shield with a star · gold crest with wings ·
// platinum hexagon crystal · diamond crown with a floating gem
export function rankEmblemSvg(n) {
  const t = RANK_TIERS[n] || RANK_TIERS[0], c = t.col, g = t.glow, O = 'stroke="#120c09" stroke-width="3" stroke-linejoin="round"';
  const body = [
    `<path d="M32 6 L54 14 L52 38 Q48 54 32 62 Q16 54 12 38 L10 14 Z" fill="${c}" ${O}/><path d="M32 16 L44 20 L43 36 Q40 46 32 51 Q24 46 21 36 L20 20 Z" fill="#7a4a2a" opacity=".5"/>`,
    `<path d="M32 4 L56 20 L32 64 L8 20 Z" fill="${c}" ${O}/><path d="M32 18 L35 27 L44 27 L37 33 L40 42 L32 36 L24 42 L27 33 L20 27 L29 27 Z" fill="#fff"/>`,
    `<path d="M4 26 Q14 14 22 24 L22 40 Q12 40 4 26 Z M60 26 Q50 14 42 24 L42 40 Q52 40 60 26 Z" fill="${g}" ${O}/><path d="M32 8 L46 16 L46 40 Q42 54 32 60 Q22 54 18 40 L18 16 Z" fill="${c}" ${O}/><circle cx="32" cy="30" r="7" fill="#fff3a0" ${O}/>`,
    `<path d="M32 4 L54 17 L54 45 L32 60 L10 45 L10 17 Z" fill="${c}" ${O}/><path d="M32 4 L32 60 M10 17 L54 45 M54 17 L10 45" stroke="#ffffff" stroke-width="1.5" opacity=".6"/><path d="M32 18 L42 24 L42 38 L32 44 L22 38 L22 24 Z" fill="#d8fff4" ${O}/>`,
    `<path d="M8 40 L14 16 L24 28 L32 10 L40 28 L50 16 L56 40 Z" fill="${c}" ${O}/><rect x="8" y="40" width="48" height="10" rx="3" fill="${g}" ${O}/><path d="M32 52 L40 58 L32 64 L24 58 Z" fill="#fff" ${O}/><circle cx="32" cy="30" r="4" fill="#fff"/>`,
  ][t.n];
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 68">${body}</svg>`;
}
export function rankCard(st, extra = null) {
  const pts = st.rank?.pts || 0, t = tierOf(pts), nx = nextTier(pts);
  const frac = nx ? (pts - t.min) / (nx.min - t.min) : 1;
  return h('div', { class: 'rank-card', 'data-rank': t.id, style: { '--tc': t.col, '--tg': t.glow } },
    h('img', { class: 'rank-emblem', src: svgDataUri(rankEmblemSvg(t.n)), alt: t.name }),
    h('div', { style: { flex: '1', minWidth: '0' } },
      h('small', { class: 'muted' }, `แรงค์ ${t.name}`), h('div', {}, h('b', {}, t.title)),
      h('small', {}, `${pts.toLocaleString('th-TH')} แต้ม${nx ? ` · อีก ${(nx.min - pts).toLocaleString('th-TH')} แต้มถึง${nx.name}` : ' · แรงค์สูงสุด'}`),
      h('div', { class: 'rank-bar' }, h('i', { style: { width: `${Math.round(frac * 100)}%` } }))),
    extra);
}
export function rankLadder(st) {
  const cur = tierOf(st.rank?.pts || 0).n;
  return h('div', { class: 'rank-tiers' }, ...RANK_TIERS.map((t) => h('div', { class: t.n <= cur ? 'on' : '' },
    h('img', { src: svgDataUri(rankEmblemSvg(t.n)), alt: '', style: { width: '36px', height: '38px', opacity: t.n <= cur ? 1 : 0.35 } }), h('div', {}, t.name), h('div', {}, `${t.min}+`))));
}
export function rankDeltaRow(rank) {
  if (!rank) return null;
  const up = rank.delta >= 0;
  return h('div', { class: 'notice ok', 'data-rank-delta': rank.delta, style: { display: 'flex', alignItems: 'center', gap: '10px', justifyContent: 'center' } },
    h('span', { class: `rank-delta ${up ? 'up' : 'down'}` }, `${up ? '+' : ''}${rank.delta} แต้มแรงค์`),
    h('span', {}, `${rank.before} → ${rank.after}`),
    rank.up ? h('b', {}, `เลื่อนเป็น ${tierOf(rank.after).title}!`) : rank.down ? h('b', {}, `ตกลงมาเป็น ${tierOf(rank.after).name}`) : null);
}
