// Buying and selling. Every transaction validates first and only then mutates a cloned state.
import { BALANCE } from '../config/balance.js';
import { SHOP_STOCK } from '../data/shop.js';
import { getItem, isEquipment } from '../data/items.js';
import { cloneState } from '../core/state.js';
import { addInPlace, canAdd, removeSlotInPlace, REASONS } from './inventory.js';

export function stockEntry(itemId, stock = SHOP_STOCK) {
  return stock.find((s) => s.itemId === itemId) || null;
}

export function isStockUnlocked(state, entry) {
  return !entry.requires || !!state.progress.cleared[entry.requires];
}

export function buy(state, itemId, qty = 1, stock = SHOP_STOCK) {
  const entry = stockEntry(itemId, stock);
  if (!entry || !getItem(itemId)) return { ok: false, reason: REASONS.UNKNOWN_ITEM };
  if (!Number.isInteger(qty) || qty <= 0 || qty > 99) return { ok: false, reason: REASONS.BAD_QTY };
  if (!isStockUnlocked(state, entry)) return { ok: false, reason: 'locked' };
  const cost = entry.price * qty;
  if (state.gold < cost) return { ok: false, reason: 'not_enough_gold', cost };
  if (!canAdd(state, itemId, qty)) return { ok: false, reason: REASONS.FULL };
  const next = cloneState(state);
  next.gold -= cost;
  const r = addInPlace(next, itemId, qty);
  if (!r.ok) return r; // defensive: canAdd already checked
  return { ok: true, state: next, cost };
}

export function sellPrice(instance) {
  const def = instance && getItem(instance.id);
  if (!def) return 0;
  if (isEquipment(def)) {
    const e = BALANCE.economy;
    return Math.round(e.sellEquipBase[def.rarity] * (1 + e.sellUpgradeBonus * (instance.lvl || 0)));
  }
  return def.sellPrice || 0;
}

export function sell(state, uid, qty = null) {
  const slot = state.inventory.slots.find((s) => s.uid === uid);
  if (!slot) return { ok: false, reason: REASONS.NOT_FOUND };
  const take = qty == null ? slot.qty : qty;
  if (!Number.isInteger(take) || take <= 0 || take > slot.qty) return { ok: false, reason: REASONS.BAD_QTY };
  const each = sellPrice(slot);
  if (each <= 0) return { ok: false, reason: 'unsellable' };
  const next = cloneState(state);
  const r = removeSlotInPlace(next, uid, take);
  if (!r.ok) return r;
  const earned = each * take;
  next.gold += earned;
  return { ok: true, state: next, earned };
}
