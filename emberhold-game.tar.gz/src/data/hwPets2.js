// v10.2 twenty Halloween pets that only fall in the Halloween lands: four live in each land and drop when its boss
// falls (5% · 2.5% · 1.2% · 0.5%). Each has a body of its own (art/hwPetArt.js), an ability of its own
// (battle/hwPetAbilities.js, kinds 'hw*') and a glow that never stops (aura).
const P = (id, name, rarity, role, zone, chance, flying, aura, ability, text, desc) => [id, Object.freeze({
  id, name, rarity, role, sprite: 'pet_' + id, desc, event: 'hw', hw2: true, zone, chance, flying: !!flying, aura: Object.freeze(aura),
  ability: Object.freeze(ability), text, art: Object.freeze({ glow: true, c3: aura.col }) })];
const pc = (v) => `${Math.round(v * 100)}%`;
export const PETS_HW2 = Object.freeze(Object.fromEntries([
  // ---------------------------------------------------------------- สวนแห่งพงไพร
  P('hwp_vine_imp', 'ภูตเถาฟักทอง', 'rare', 'ควบคุม', 'hw_wild', 0.05, false, { k: 'leaves', col: '#9fe05a' },
    { kind: 'hwvine', name: 'เถารัดรากลึก', every: 5, power: 0.5, count: 3, stun: 0.8, range: 380 },
    (v) => `ทุก ${v.every} วินาที เถาฟักทองรัดศัตรู ${v.count} ตัว ×${v.power.toFixed(2)} และติดราก ${v.stun} วินาที`, 'ภูตตัวจิ๋วที่เกิดจากเถาฟักทองอายุร้อยปี ชอบรัดทุกอย่างที่ขยับ'),
  P('hwp_candle_moth', 'ผีเสื้อราตรีเทียนไข', 'epic', 'ฟื้นฟู + ทำให้ช้า', 'hw_wild', 0.025, true, { k: 'dust', col: '#ffe08a' },
    { kind: 'hwmoth', name: 'ผงแสงเทียน', every: 6, healPct: 0.025, slow: 0.5, r: 170 },
    (v) => `ทุก ${v.every} วินาที โปรยผงแสง ศัตรูรอบตัวช้าลง และฟื้นพลังชีวิต ${(v.healPct * 100).toFixed(1)}%`, 'ปีกของมันคือเปลวเทียนสองดวงที่ไม่มีวันมอด'),
  P('hwp_scarecrow', 'หุ่นไล่กาเดินได้', 'legendary', 'ล่อศัตรู', 'hw_wild', 0.012, false, { k: 'straw', col: '#e0b45a' },
    { kind: 'hwscare', name: 'ยืนท้าทายกลางทุ่ง', every: 10, power: 0.3, r: 220, duration: 3, pull: 420 },
    (v) => `ทุก ${v.every} วินาที ปักตัวกลางสนาม ${v.duration} วินาที ดูดศัตรูเข้าหาและฟาด ×${v.power.toFixed(2)} ทุกครึ่งวินาที`, 'อีกาไม่กลัวมัน แต่ปีศาจทุกตัวทนเสียงหัวเราะของมันไม่ได้'),
  P('hwp_mushroom_ghoul', 'เห็ดผีหัวโต', 'legendary', 'พิษ + ฟื้นฟู', 'hw_wild', 0.005, false, { k: 'spores', col: '#c8a8ff' },
    { kind: 'hwspore', name: 'ม่านสปอร์ผี', every: 9, power: 0.32, r: 150, duration: 4, healPct: 0.012 },
    (v) => `ทุก ${v.every} วินาที ปล่อยม่านสปอร์ ${v.duration} วินาที ×${v.power.toFixed(2)} ทุกครึ่งวินาที ถ้ายืนในม่านฟื้น ${(v.healPct * 100).toFixed(1)}% ต่อวินาที`, 'หมวกเห็ดของมันเรืองแสงในความมืดเหมือนหัวกะโหลก'),
  // ---------------------------------------------------------------- คฤหาสน์ฟักทองหลอน
  P('hwp_jack_jr', 'แจ็คน้อยหัวฟักทอง', 'rare', 'ระเบิด', 'hw_jack', 0.05, false, { k: 'embers', col: '#ff8a1f' },
    { kind: 'hwpumpbomb', name: 'ฟักทองลูกเล็ก', every: 3.5, power: 1, r: 85, range: 460 },
    (v) => `ทุก ${v.every} วินาที โยนฟักทองระเบิด ×${v.power.toFixed(2)} รัศมี ${v.r} ติดไฟ`, 'ลูกชายของแจ็คที่ยังไม่โตพอจะถือเคียว แต่โยนฟักทองแม่นมาก'),
  P('hwp_candelabra', 'เชิงเทียนผีสิง', 'epic', 'ยิงไฟ', 'hw_jack', 0.025, true, { k: 'flames', col: '#ffb84a' },
    { kind: 'hwflames', name: 'สามเปลวเทียน', every: 3, power: 0.4, count: 3, range: 480 },
    (v) => `ทุก ${v.every} วินาที ยิงเปลวเทียน ${v.count} ลูกไล่ศัตรู ลูกละ ×${v.power.toFixed(2)} ติดไฟ`, 'เทียนสามเล่มที่จุดเองทุกคืนในห้องโถงที่ไม่มีใครอยู่'),
  P('hwp_portrait', 'ภาพวาดตาเหลือก', 'legendary', 'สาปศัตรู', 'hw_jack', 0.012, true, { k: 'eyes', col: '#c27ff0' },
    { kind: 'hwgaze', name: 'สายตาจากภาพวาด', every: 8, mark: 0.22, markT: 5, stun: 0.7, range: 520 },
    (v) => `ทุก ${v.every} วินาที จ้องศัตรูที่เลือดมากที่สุด ทำให้แข็งทื่อ ${v.stun} วินาทีและรับดาเมจเพิ่ม ${pc(v.mark)} นาน ${v.markT} วินาที`, 'ดวงตาในภาพวาดขยับตามทุกคนที่เดินผ่าน'),
  P('hwp_butler', 'พ่อบ้านโครงกระดูก', 'legendary', 'บริการ', 'hw_jack', 0.005, false, { k: 'steam', col: '#e8f4ff' },
    { kind: 'hwtea', name: 'ชาร้อนยามดึก', every: 12, healPct: 0.06, haste: 0.15, duration: 4 },
    (v) => `ทุก ${v.every} วินาที เสิร์ฟชาร้อน ฟื้นพลังชีวิต ${pc(v.healPct)} และตีเร็วขึ้น ${pc(v.haste)} นาน ${v.duration} วินาที`, 'รับใช้คฤหาสน์มาสามร้อยปี ยังไม่เคยทำถ้วยแตกสักใบ'),
  // ---------------------------------------------------------------- ทุ่งเก็บเกี่ยววิญญาณ
  P('hwp_crow', 'อีกาทุ่งเก็บเกี่ยว', 'rare', 'โจมตีต่อเนื่อง', 'hw_reaper', 0.05, true, { k: 'feathers', col: '#9a6aff' },
    { kind: 'hwpeck', name: 'โฉบสามเป้า', every: 2.6, power: 0.45, count: 3, range: 420 },
    (v) => `ทุก ${v.every} วินาที โฉบจิกศัตรูต่อกัน ${v.count} ตัว ตัวละ ×${v.power.toFixed(2)}`, 'อีกาที่เกาะไหล่ยมทูตมานานจนรู้ว่าใครใกล้ตาย'),
  P('hwp_soul_wisp', 'ดวงวิญญาณน้อย', 'epic', 'ดูดพลัง', 'hw_reaper', 0.025, true, { k: 'souls', col: '#8ff0e0' },
    { kind: 'hwsoul', name: 'วิญญาณกลับบ้าน', every: 4, power: 0.7, healPct: 0.01, range: 460 },
    (v) => `ทุก ${v.every} วินาที ส่งวิญญาณไล่ศัตรู ×${v.power.toFixed(2)} แล้ววิญญาณกลับมาฟื้นพลังชีวิต ${(v.healPct * 100).toFixed(1)}%`, 'วิญญาณที่หลงทางในทุ่ง เลือกเจ้าเป็นบ้านหลังใหม่'),
  P('hwp_scythe_spirit', 'วิญญาณเคียวลอย', 'legendary', 'หมุนรอบตัว', 'hw_reaper', 0.012, true, { k: 'arcs', col: '#cfe0f0' },
    { kind: 'hwspin', name: 'วงเคียวพิทักษ์', every: 8, power: 0.32, r: 130, duration: 3 },
    (v) => `ทุก ${v.every} วินาที เคียวหมุนรอบตัวเจ้านาย ${v.duration} วินาที ฟันศัตรูรอบๆ ×${v.power.toFixed(2)} ทุก 0.3 วินาที`, 'เคียวของยมทูตที่ลืมเจ้าของไว้ในทุ่ง'),
  P('hwp_reaper_kid', 'ยมทูตฝึกหัด', 'legendary', 'ปลิดชีพ', 'hw_reaper', 0.005, false, { k: 'soulsdark', col: '#5affc8' },
    { kind: 'hwreap', name: 'บทเรียนแรกของยมทูต', every: 6, power: 1.1, below: 0.15, range: 360 },
    (v) => `ทุก ${v.every} วินาที เก็บวิญญาณศัตรูทั่วไปที่เลือดต่ำกว่า ${pc(v.below)} ทันที ถ้าไม่มีก็ฟัน ×${v.power.toFixed(2)}`, 'ยังสอบใบอนุญาตยมทูตไม่ผ่าน เลยมาฝึกกับเจ้าก่อน'),
  // ---------------------------------------------------------------- กระท่อมขนมของแม่มด
  P('hwp_gingerbread', 'ตุ๊กตาขนมปังขิง', 'rare', 'กับดัก', 'hw_lure', 0.05, false, { k: 'crumbs', col: '#e0a060' },
    { kind: 'hwcrumb', name: 'เศษขนมเหนียวหนึบ', every: 4, power: 0.8, r: 90, slow: 0.5, life: 6 },
    (v) => `ทุก ${v.every} วินาที วางลูกอมเหนียว ศัตรูที่เหยียบโดน ×${v.power.toFixed(2)} รัศมี ${v.r} และช้าลง`, 'วิ่งหนีออกจากเตาอบของแม่มด แล้วไม่เคยหยุดวิ่ง'),
  P('hwp_lollipop_slime', 'สไลม์อมยิ้ม', 'epic', 'กระเด้งแตก', 'hw_lure', 0.025, false, { k: 'candy', col: '#ff7ab0' },
    { kind: 'hwsticky', name: 'กระเด้งแตกสามทาง', every: 4, power: 0.5, r: 65, count: 3, range: 420 },
    (v) => `ทุก ${v.every} วินาที กระเด้งทับศัตรู แล้วแตกเป็น ${v.count} ก้อนกระจาย ก้อนละ ×${v.power.toFixed(2)} ทำให้ช้าลง`, 'หวานจนมดยังไม่กล้าเข้าใกล้'),
  P('hwp_cotton_bat', 'ค้างคาวสายไหม', 'legendary', 'บัพความเร็ว', 'hw_lure', 0.012, true, { k: 'sparkle', col: '#ffc8e8' },
    { kind: 'hwsugar', name: 'ความหวานพุ่งพล่าน', every: 10, speed: 0.22, crit: 0.08, duration: 5 },
    (v) => `ทุก ${v.every} วินาที โปรยน้ำตาล เจ้านายวิ่งเร็วขึ้น ${pc(v.speed)} และคริติคอล +${pc(v.crit)} นาน ${v.duration} วินาที`, 'ปีกทำจากสายไหม บินทีไรหวานทั้งห้อง'),
  P('hwp_candy_golem', 'โกเลมลูกกวาด', 'legendary', 'ป้องกัน', 'hw_lure', 0.005, false, { k: 'stripes', col: '#ff5a8a' },
    { kind: 'hwshell', name: 'เปลือกลูกกวาดแข็ง', every: 12, shieldPct: 0.15, duration: 6, power: 0.8, r: 130 },
    (v) => `ทุก ${v.every} วินาที ทุบพื้นรอบตัว ×${v.power.toFixed(2)} และให้โล่ลูกกวาด ${pc(v.shieldPct)} นาน ${v.duration} วินาที`, 'สร้างจากลูกกวาดทุกเม็ดที่เด็กๆ ทำหล่นในคืนฮาโลวีน'),
  // ---------------------------------------------------------------- หอแม่มดจอมหลอกลวง
  P('hwp_mirror_imp', 'ภูตกระจกหลอกตา', 'rare', 'ล่อ + ระเบิด', 'hw_deceiver', 0.05, true, { k: 'shards', col: '#bfe8ff' },
    { kind: 'hwdecoy', name: 'เงาจำแลง', every: 9, power: 1, r: 130, duration: 3, pull: 360 },
    (v) => `ทุก ${v.every} วินาที สร้างเงาจำแลงของเจ้านาย ล่อศัตรูเข้าหา ${v.duration} วินาที แล้วระเบิด ×${v.power.toFixed(2)} รัศมี ${v.r}`, 'มันชอบแกล้งทำเป็นคนอื่น โดยเฉพาะเจ้า'),
  P('hwp_hex_owl', 'นกฮูกคำสาป', 'epic', 'สาปศัตรู', 'hw_deceiver', 0.025, true, { k: 'runes', col: '#9fe05a' },
    { kind: 'hwhex', name: 'สามคำสาปเงียบ', every: 5, count: 3, mark: 0.15, markT: 4, slow: 0.6, range: 460 },
    (v) => `ทุก ${v.every} วินาที สาปศัตรู ${v.count} ตัว รับดาเมจเพิ่ม ${pc(v.mark)} และช้าลง นาน ${v.markT} วินาที`, 'นกฮูกของแม่มดที่ท่องคาถาได้ดีกว่าเจ้าของ'),
  P('hwp_broom_sprite', 'ภูตไม้กวาดบิน', 'legendary', 'พุ่งกวาด', 'hw_deceiver', 0.012, true, { k: 'dustswirl', col: '#ffd84a' },
    { kind: 'hwsweep', name: 'กวาดล้างทั้งแถว', every: 4, power: 0.8, len: 420, width: 70 },
    (v) => `ทุก ${v.every} วินาที พุ่งกวาดเป็นแนวยาว ${v.len} หน่วย ศัตรูที่ขวาง ×${v.power.toFixed(2)} กระเด็น`, 'ไม้กวาดที่หนีจากแม่มดเพราะไม่อยากกวาดบ้าน'),
  P('hwp_tome_familiar', 'คัมภีร์มีชีวิต', 'legendary', 'ร่ายเวทสุ่ม', 'hw_deceiver', 0.005, true, { k: 'pages', col: '#ff7ad8' },
    { kind: 'hwtome', name: 'เปิดหน้าสุ่ม', every: 7, power: 1.1, r: 160, healPct: 0.06, slow: 0.5 },
    (v) => `ทุก ${v.every} วินาที เปิดหน้าคาถาสุ่ม: ระเบิดเพลิง ×${v.power.toFixed(2)} / พายุน้ำแข็งทำให้ช้า / แสงรักษา ${pc(v.healPct)}`, 'คัมภีร์ของแม่มดจอมหลอกลวง ที่เบื่อเจ้าของเลยกระโดดหนีมา'),
]));
// one boss of a Halloween land falls: each of the land's four pets rolls its own chance
export function hwPetsOfZone(zone) { return Object.values(PETS_HW2).filter((p) => p.zone === zone); }
