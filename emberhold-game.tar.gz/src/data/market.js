// v10 ตลาดซุ้ม (player stalls). The village grew a market street: 100 lots (ล็อก) in five long rows. A hero with an
// online account rents one lot, dresses it in one of the stall designs they own, and lays out items with their own
// prices. Anyone walking past can open the stall and buy at once — even while the owner is offline: the items wait
// on the server, and the gold waits there for the owner to collect (ตลาดซุ้ม › เก็บเงิน).
// 50 everyday designs (gold, the first five free) + 10 Halloween designs (candy, event only).

export const MARKET = Object.freeze({
  lots: 100, perRow: 20, x0: 2260, dx: 96, rows: [470, 650, 830, 1010, 1190],
  maxListings: 8, minPrice: 1, maxPrice: 999_999_999, fee: 0.05,   // 5% of every sale goes to the village (gold sink)
  rentDays: 7,                                                      // a lot is kept 7 days after the owner's last visit
});
export const LOTS = Object.freeze(Array.from({ length: MARKET.lots }, (_, i) => {
  const row = Math.floor(i / MARKET.perRow), col = i % MARKET.perRow;
  return { n: i + 1, x: MARKET.x0 + col * MARKET.dx, y: MARKET.rows[row], row };
}));
export const lotOf = (n) => LOTS[(n | 0) - 1] || null;

// ------------------------------------------------------------------ designs
// roof: awning | tent | dome | pagoda | scallop | flat · pattern: stripes | dots | plain | checker | stars | waves | diamonds | leaves
const ROOFS = ['awning', 'tent', 'dome', 'pagoda', 'scallop', 'flat'];
const PATTERNS = ['stripes', 'dots', 'plain', 'checker', 'stars', 'waves', 'diamonds', 'leaves'];
const PALETTE = [
  ['#c2412f', '#f3e6c8'], ['#2f6f86', '#f3e6c8'], ['#5a8a3a', '#f5d48a'], ['#8a3a7a', '#ffd8e8'], ['#e0b45a', '#5a2a14'], ['#3a4a8a', '#bfe3ff'],
  ['#d06a1a', '#fff3c4'], ['#1a6a5a', '#9fffd8'], ['#7a2a1a', '#e0b45a'], ['#4a2a6a', '#e0b8ff'], ['#2a2a34', '#ff7a5a'], ['#e86a8a', '#ffffff'],
  ['#6a8ab8', '#ffe89a'], ['#8a6a3a', '#efe4cc'], ['#3a8a8a', '#ffcf5a'], ['#a83a3a', '#2a1a14'], ['#5a6a2a', '#fff3a0'],
];
const NAMES = ['ซุ้มผ้าใบแดง', 'ซุ้มทะเลคราม', 'ซุ้มใบไม้ทอง', 'ซุ้มม่วงกุหลาบ', 'ซุ้มทองเหลือง', 'ซุ้มฟ้าคืนหนาว', 'ซุ้มส้มตะวันรอน', 'ซุ้มหยกน้ำ', 'ซุ้มอิฐถ่าน', 'ซุ้มม่วงหมอก',
  'ซุ้มเหล็กแดงเพลิง', 'ซุ้มชมพูขนมหวาน', 'ซุ้มฟ้าดาวทอง', 'ซุ้มไม้โอ๊ก', 'ซุ้มเขียวทะเลทอง', 'ซุ้มเลือดนก', 'ซุ้มมะกอกป่า'];
export const STALL_DESIGNS = Object.freeze([
  ...Array.from({ length: 50 }, (_, i) => {
    const pal = PALETTE[i % PALETTE.length], roof = ROOFS[(i * 7) % ROOFS.length], pattern = PATTERNS[(i * 5 + Math.floor(i / 8)) % PATTERNS.length];
    const tier = Math.floor(i / 10);
    return { id: `st_${String(i + 1).padStart(2, '0')}`, name: `${NAMES[i % NAMES.length]}${i >= NAMES.length ? ` ${['ลายพิเศษ', 'ฉบับงานวัด', 'ฉบับราชสำนัก'][Math.floor(i / NAMES.length) - 1]}` : ''}`,
      roof, pattern, main: pal[0], trim: pal[1], post: ['#6b4a2c', '#4a3020', '#8a6a3a', '#2a1a14', '#c8a050'][tier],
      flag: i % 3 === 0, lantern: i % 4 === 1, plant: i % 5 === 2, sign: i % 2 === 0, free: i < 5, price: i < 5 ? 0 : Math.round(1500 * Math.pow(1.105, i)) };
  }),
  ...[
    ['ซุ้มฟักทองยักษ์', 'pumpkin', '#e06a1a', '#2a1a10'], ['ซุ้มโลงศพเปิดได้', 'coffin', '#2a1a24', '#b8a8c8'], ['ซุ้มใยแมงมุมพันชั้น', 'web', '#3a3450', '#e8e8ff'],
    ['ซุ้มธงค้างคาว', 'bats', '#1a1424', '#ff5a7a'], ['ซุ้มเสาลูกกวาด', 'candycane', '#ffffff', '#e0303a'], ['ซุ้มหมวกแม่มด', 'witchhat', '#3a1a4a', '#9a5aff'],
    ['ซุ้มหม้อต้มเดือด', 'cauldron', '#2a3a2a', '#8aff5a'], ['ซุ้มผ้าคลุมผี', 'ghost', '#eaf6ff', '#5ae0ff'], ['ซุ้มสุสานจันทร์ซีด', 'grave', '#5a5a6a', '#d8e0f0'], ['ซุ้มโคมหัวกะโหลก', 'skulls', '#1a0a0a', '#ffcf5a'],
  ].map(([name, theme, main, trim], i) => ({ id: `sth_${String(i + 1).padStart(2, '0')}`, name, roof: 'hw', theme, pattern: 'plain', main, trim, post: '#2a1a14', halloween: true, candy: 900 + i * 260 })),
]);
export const getDesign = (id) => STALL_DESIGNS.find((d) => d.id === id) || null;
